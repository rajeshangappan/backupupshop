﻿using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace MobileUI2.Logging
{
    public class DebugLoggingService : ILoggingService
    {
        public void Debug(string message, Dictionary<string, string> properties = null)
        {
            System.Diagnostics.Debug.WriteLine(message, properties);
        }

        public void Warning(string message)
        {
            Debug($"# {nameof(Warning)}");
            Debug(message);
        }

        public void Error(Exception exception, Dictionary<string, string> properties = null)
        {
            Debug($"# {nameof(Error)}");
            Debug(exception.ToString(), properties);
        }

        public Dictionary<string, string> ErrorFileInfo([CallerFilePath] string filePath = "", [CallerMemberName] string methodName = "")
        {
            var filePathSplit = filePath.Split('\\');
            var fileName = filePathSplit[filePathSplit.Length - 1];

            var dict = new Dictionary<string, string> { { "FileName ", fileName }, { "MethodName ", methodName } };

            return dict;
        }

        public Task ShareFiles(string fileName= "DaymarkDebug.txt")
        {
            throw new NotImplementedException();
        }

        public Task Log(string message)
        {
            throw new NotImplementedException();
        }
        public Task PerformanceLog(string message, string fileName, bool separator = false)
        {
            throw new NotImplementedException();
        }
    }
}
