﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.Threading.Tasks;
//using Microsoft.AppCenter.Analytics;
using MobileUI2.Models;

// INFO: How to use Codebenchmarks setup and examples

/*
Setup: To use this code follow the following standards and implementation practices.
     The following code is to be constructor injected into each page at runtime so all you need to do is
    
      Set up a field
          private readonly ICodeBenchmarks _codeBenchmarks;
    
      Set up the constructor
          public ConstructorName(ICodeBenchmarks codeBenchmarks)

Synchronous Method:
    public void DoSomething()
    {
        var benchmarkId = _codeBenchmarks.StartTracking(BenchmarkType.Method, nameof(DoSomething));

        // Your code here...

        _ = _codeBenchmarks.StopAndReportAsync(benchmarkId);
    }

Asynchronous Method:
    public async Task DoSomethingAsync()
    {
        var benchmarkId = _codeBenchmarks.StartTracking(BenchmarkType.AsyncMethod, nameof(DoSomethingAsync));

        // Your code here...

        await _codeBenchmarks.StopAndReportAsync(benchmarkId);
    }

Synchronous Method with Return Value:
    public int DoSomethingAndReturnValue()
    {
        var benchmarkId = _codeBenchmarks.StartTracking(BenchmarkType.Method, nameof(DoSomethingAndReturnValue));

        // Your code here...
        int result = SomeMethodThatReturnsInt();

        _ = _codeBenchmarks.StopAndReportAsync(benchmarkId, result);

        return result;
    }

Asynchronous Method with Return Value:
    public async Task<int> DoSomethingAndReturnValueAsync()
    {
        var benchmarkId =
            _codeBenchmarks.StartTracking(BenchmarkType.AsyncMethod, nameof(DoSomethingAndReturnValueAsync));

        // Your code here...
        int result = await SomeAsyncMethodThatReturnsInt();

        await _codeBenchmarks.StopAndReportAsync(benchmarkId, result);

        return result;
    }
Multiple benchmarks from single method:
    public async Task<int> CalculateSomethingAsync()
        {
            var methodBenchmarkId = _codeBenchmarks.StartTracking(BenchmarkType.Method, nameof(CalculateSomethingAsync));
    
            int result = 0;
    
            var loop1BenchmarkId = _codeBenchmarks.StartTracking(BenchmarkType.Method, "FirstLoopInCalculateSomethingAsync");
            for (int i = 0; i < 1000000; i++)
            {
                result += i;
            }
            _codeBenchmarks.StopAndReportAsync(loop1BenchmarkId);

            var loop2BenchmarkId = _codeBenchmarks.StartTracking(BenchmarkType.Method, "SecondLoopInCalculateSomethingAsync");
            for (int i = 0; i < 1000000; i++)
            {
                result += i;
            }
            _codeBenchmarks.StopAndReportAsync(loop2BenchmarkId);

            return await _codeBenchmarks.StopAndReportAsync(methodBenchmarkId, result);
        }
*/


namespace MobileUI2.Logging
{
    public interface ICodeBenchmarks
    {
        string StartTracking(BenchmarkType type, string methodName, TimeSpan? durationThreshold = null);
        Task StopAndReportAsync(string benchmarkId);
        Task<TResult> StopAndReportAsync<TResult>(string benchmarkId, TResult result);
    }

    public enum BenchmarkType
    {
        Method,
        AsyncMethod,
        Api,
        AsyncApi,
        MessageCenter,
        MessageCenterAsync,
        MessageCenterDataProcessing,
        Constructor,
        Hydrate,
        AsyncHydrate
    }

    public class CodeBenchmarks : BaseViewModel, ICodeBenchmarks
    {
        private const int DefaultDurationThresholdMilliseconds = 250;

        private readonly ConcurrentDictionary<string, (Stopwatch Stopwatch, string MethodName, string Type, TimeSpan DurationThreshold)> _benchmarks;
        private readonly ILoggingService _log;
        private readonly UserInfo _userInfo;
        private readonly IServiceProvider _serviceProvider;

        public CodeBenchmarks(ILoggingService logEvent,IServiceProvider serviceProvider):base(serviceProvider)
        {

            _log = logEvent;
            _userInfo = GetValueOrDefaultInternal<UserInfo>(GlobalSettings.UserData);
            _benchmarks = new ConcurrentDictionary<string, (Stopwatch, string, string, TimeSpan)>();
        }

        public string StartTracking(BenchmarkType type, string methodName, TimeSpan? durationThreshold = null)
        {
            var benchmarkId = Guid.NewGuid().ToString();
            var stopwatch = Stopwatch.StartNew();

            TimeSpan threshold;
            if (durationThreshold == null)
            {
                switch (type)
                {
                    case BenchmarkType.Method:
                        threshold = TimeSpan.FromMilliseconds(15);
                        break;
                    case BenchmarkType.AsyncMethod:
                        threshold = TimeSpan.FromMilliseconds(500);
                        break;
                    case BenchmarkType.Api:
                        threshold = TimeSpan.FromMilliseconds(150);
                        break;
                    case BenchmarkType.AsyncApi:
                        threshold = TimeSpan.FromMilliseconds(200);
                        break;
                    case BenchmarkType.MessageCenter:
                        threshold = TimeSpan.FromMilliseconds(25);
                        break;
                    case BenchmarkType.MessageCenterAsync:
                        threshold = TimeSpan.FromMilliseconds(25);
                        break;
                    case BenchmarkType.MessageCenterDataProcessing:
                        threshold = TimeSpan.FromMilliseconds(25);
                        break;
                    case BenchmarkType.Constructor:
                        threshold = TimeSpan.FromMilliseconds(250);
                        break;
                    case BenchmarkType.Hydrate:
                        threshold = TimeSpan.FromMilliseconds(100);
                        break;
                    case BenchmarkType.AsyncHydrate:
                        threshold = TimeSpan.FromMilliseconds(500);
                        break;
                    default:
                        threshold = TimeSpan.FromMilliseconds(DefaultDurationThresholdMilliseconds);
                        break;
                }
            }
            else
            {
                threshold = durationThreshold.Value;
            }

            _benchmarks[benchmarkId] = (stopwatch, methodName, type.ToString(), threshold);

            return benchmarkId;
        }

        private async Task LogBenchmarkDetails(string methodName, string type, TimeSpan durationThreshold, TimeSpan timeElapsed, long epochTime)
        {
            if (timeElapsed >= durationThreshold)
            {
                //await Task.Run(() => Analytics.TrackEvent($"End: {methodName}", new Dictionary<string, string>
                //{
                //    { "Tenant", _userInfo.TenantCode },
                //    { "UserId", _userInfo.UserId.ToString() },
                //    { "EpochTime", epochTime.ToString() },
                //    { "Type", type },
                //    { "Duration threshold", durationThreshold.ToString() },
                //    { "Duration", timeElapsed.ToString() },
                //}));
                //_log.Debug($"Tenant: \"{_userInfo.TenantCode}\", UserId: \"{_userInfo.UserId}\", Epoch: \"{epochTime}\", Type: {type}, Method: {methodName}, Expected duration threshold: {durationThreshold}, Actual duration threshold: {timeElapsed}");
            }
        }

        public async Task StopAndReportAsync(string benchmarkId)
        {
            if (!_benchmarks.TryRemove(benchmarkId, out var benchmarkData))
            {
                _log.Warning($"No benchmark found with ID {benchmarkId}");
                return;
            }

            var (stopwatch, methodName, type, durationThreshold) = benchmarkData;
            stopwatch.Stop();

            var timeElapsed = stopwatch.Elapsed;
            var epochTime = DateTimeOffset.Now.ToUnixTimeSeconds();

            await LogBenchmarkDetails(methodName, type, durationThreshold, timeElapsed, epochTime);
        }

        public async Task<TResult> StopAndReportAsync<TResult>(string benchmarkId, TResult result)
        {
            if (!_benchmarks.TryRemove(benchmarkId, out var benchmarkData))
            {
                _log.Warning($"No benchmark found with ID {benchmarkId}");
                return result;
            }

            var (stopwatch, methodName, type, durationThreshold) = benchmarkData;
            stopwatch.Stop();

            var timeElapsed = stopwatch.Elapsed;
            var epochTime = DateTimeOffset.Now.ToUnixTimeSeconds();

            await LogBenchmarkDetails(methodName, type, durationThreshold, timeElapsed, epochTime);

            return result;
        }
    }
}
