﻿using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace MobileUI2.Logging
{
    public interface ILoggingService
    {
        void Debug(string message, Dictionary<string, string> properties = null);

        //void Warning(string message);

        void Warning(string message);
        Task Log(string message);
        Task PerformanceLog(string message,string fileName,bool separator=false);

        void Error(Exception exception, Dictionary<string, string> properties = null);

        Task ShareFiles(string fileName = "DaymarkDebug.txt");
        Dictionary<string, string> ErrorFileInfo([CallerFilePath] string filePath = "", [CallerMemberName] string methodName = "");
    }
}
