﻿//using Microsoft.AppCenter;
//using Microsoft.AppCenter.Analytics;
//using Microsoft.AppCenter.Crashes;
using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using Microsoft.Maui.ApplicationModel.DataTransfer;
using Microsoft.Maui.Storage;

namespace MobileUI2.Logging
{
    public class AppCenterLoggingService : ILoggingService
    {
        public AppCenterLoggingService()
        {
            //AppCenter.LogLevel = LogLevel.Verbose;
            //AppCenter.Start(
            //    $"ios={GlobalSettings.AppCenteriOSSecret}​;android={GlobalSettings.AppCenterAndroidSecret};",
            //    typeof(Analytics),
            //    typeof(Crashes));
            //Analytics.SetEnabledAsync(true);
        }

        public void Debug(string message, Dictionary<string, string> properties = null)
        {
            //    Analytics.TrackEvent(message, properties);
        }

        /// <summary>
        /// ToDo:- Temp Changes
        /// </summary>
        /// <param name="message"></param>
        public void Warning(string message)
        {
            //Analytics.TrackEvent(nameof(Warning), new Dictionary<string, string> { { nameof(message), message } });
        }

        public async Task Log(string message)
        {
            try
            {
                if (!GlobalSettings.EnableMobileLogging)
                    return;
                string documentsPath = FileSystem.AppDataDirectory;
                string fileName = "DaymarkDebug.txt";
                string filePath = Path.Combine(documentsPath, fileName);
                if (!File.Exists(filePath))
                {
                    using (StreamWriter writer = new StreamWriter(filePath, false))
                    {
                        await writer.WriteAsync("\n" + DateTime.UtcNow.ToString("MM/dd/yyyy hh:mm:ss tt") + " : " + message);
                    }
                }
                else
                {
                    using (StreamWriter writer = File.AppendText(filePath))
                    {
                        await writer.WriteAsync("\n" + DateTime.UtcNow.ToString("MM/dd/yyyy hh:mm:ss tt") + " : " + message);
                    }
                }
            }
            catch (Exception ex)
            {
                Error(ex, null);
            }
        }

        public async Task ShareFiles(string fileName = "DaymarkDebug.txt")
        {
            if (!GlobalSettings.EnableMobileLogging)
                return;
            string documentsPath = FileSystem.AppDataDirectory;
            string filePath = Path.Combine(documentsPath, fileName);
            if (File.Exists(filePath))
            {
                await Share.RequestAsync(new ShareFileRequest
                {
                    Title = "Share File",
                    File = new ShareFile(filePath)
                });
                File.Delete(filePath);
            }
        }

        //public void Warning(string message)
        //{
        //    Analytics.TrackEvent(message, new Dictionary<string, string> { { nameof(message), message } });
        //}

        public void Error(Exception exception, Dictionary<string, string> properties)
        {
            //Crashes.TrackError(exception, properties);
        }

        public Dictionary<string, string> ErrorFileInfo([CallerFilePath] string filePath = "", [CallerMemberName] string methodName = "")
        {
            var filePathSplit = filePath.Split('\\');
            var fileName = filePathSplit[filePathSplit.Length - 1];

            var dict = new Dictionary<string, string> { { "FileName ", fileName }, { "MethodName ", methodName } };

            return dict;
        }

        public async Task PerformanceLog(string message, string fileName, bool separator = false)
        {
             try
            {
                if (!GlobalSettings.EnableMobileLogging)
                    return;
                string documentsPath = FileSystem.AppDataDirectory;
                string filePath = Path.Combine(documentsPath, fileName);

                var logMessage = (separator ? "--------------------------------------------------\n" : string.Empty) +
                          $"[{DateTime.UtcNow:MM/dd/yyyy hh:mm:ss tt}]: {message}\n";

                if (!File.Exists(filePath))
                {
                    using (StreamWriter writer = new StreamWriter(filePath, false))
                    {
                        await writer.WriteAsync(logMessage);
                    }
                }
                else
                {
                    using (StreamWriter writer = File.AppendText(filePath))
                    {
                        await writer.WriteAsync(logMessage);
                    }
                }
            }
            catch (Exception ex)
            {
                Error(ex, null);
            }
        }
    }
}
