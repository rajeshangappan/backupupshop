﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using Microsoft.Maui.Controls.Compatibility;
using Microsoft.Maui.Controls;
using Microsoft.Maui;

namespace MobileUI2.Behaviors
{

    public class EntryValidationBehavior : Behavior<Entry>
    {
        private static string SpecialCharacters { get; set; }
        private static bool TypeKeyboard { get; set; }
        protected override void OnAttachedTo(Entry entry)
        {

            entry.TextChanged += OnEntryTextChanged;
            base.OnAttachedTo(entry);
        }
        protected override void OnDetachingFrom(Entry entry)
        {
            entry.TextChanged -= OnEntryTextChanged;
            base.OnDetachingFrom(entry);
        }
        private static void OnEntryTextChanged(object sender, TextChangedEventArgs args)
        {
            try
            {
                if (!string.IsNullOrWhiteSpace(args.NewTextValue))
                {
                    var filteredText = Regex.Replace(args.NewTextValue, "[^0-9.]", "");
                    bool isValid;
                    Entry entry = (Entry)sender;
                    int.TryParse(filteredText, out int data);
                    if (data>999)
                    {
                        isValid = false;
                    }
                    else
                    {
                        isValid = true;
                    }
                   
                    ((Entry)sender).Text = isValid ? data.ToString() : args.NewTextValue.Remove(args.NewTextValue.Length - 1);
                }else ((Entry)sender).Text = null;
            }
            catch (Exception exception)
            {
                
            }
        }
    }
    public static class Extenstions
    {
        public static string RemoveWhitespace(this string input)
        {
            if (string.IsNullOrWhiteSpace(input))
                return input;

            return new string(input.Where(c => !Char.IsWhiteSpace(c))
                                   .ToArray());
        }
    }
}
