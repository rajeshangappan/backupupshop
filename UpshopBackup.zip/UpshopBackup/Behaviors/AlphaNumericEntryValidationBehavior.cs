﻿using System.Text.RegularExpressions;
using Microsoft.Maui.Controls.Compatibility;
using Microsoft.Maui.Controls;
using Microsoft.Maui;

namespace MobileUI2
{
    public class AlphaNumericEntryValidationBehavior : Behavior<Entry>
    {
        private string _previousValidText = "";
        private const string Pattern ="^[a-zA-Z0-9]+$";
        public static readonly BindableProperty MaxAllowCharactersProperty = BindableProperty.Create("MaxAllowCharacters", typeof(int), typeof(AlphaNumericEntryValidationBehavior), 64);
        public int MaxAllowCharacters
        {
            get => (int)GetValue(MaxAllowCharactersProperty);
            set => SetValue(MaxAllowCharactersProperty, value);
        }
        protected override void OnAttachedTo(Entry entry)
        {
            _previousValidText = entry.Text;
            entry.TextChanged += OnEntryTextChanged;
            base.OnAttachedTo(entry);
        }
        protected override void OnDetachingFrom(Entry entry)
        {
            entry.TextChanged -= OnEntryTextChanged;
            base.OnDetachingFrom(entry);
        }
        private void OnEntryTextChanged(object sender, TextChangedEventArgs args)
        {
            if (sender is Entry entry)
            {
                if (string.IsNullOrEmpty(args.NewTextValue))
                {
                    _previousValidText = "";
                    return;
                }

                if (IsMatchPattern(args.NewTextValue) && IsWithinCharacterLimit(args.NewTextValue))
                {
                    _previousValidText = args.NewTextValue;
                }
                else
                {
                    if (string.IsNullOrEmpty(_previousValidText))
                    {
                        entry.Text = string.Empty;
                    }
                    else
                    {
                        entry.Text = _previousValidText;
                    }
                }
            }
        }
        private bool IsMatchPattern(string text)
        {
            return Regex.IsMatch(text, Pattern);
        }

        private bool IsWithinCharacterLimit(string text)
        {
            return text.Length <= MaxAllowCharacters;
        }
    }
}
