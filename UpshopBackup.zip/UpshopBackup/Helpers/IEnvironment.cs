﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Text;


namespace MobileUI2
{
    public interface IEnvironment
    {
        void SetStatusBarColor(Microsoft.Maui.Graphics.Color color, bool darkStatusBarTint);
    }
}
