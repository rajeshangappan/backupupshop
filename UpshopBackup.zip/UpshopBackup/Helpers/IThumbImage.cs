﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Maui.Controls.Compatibility;
using Microsoft.Maui.Controls;
using Microsoft.Maui;

namespace MobileUI2.Helpers
{
    public interface IThumbImage
    {
        ImageSource GenerateThumbImage(string url, long usecond);
    }
}
