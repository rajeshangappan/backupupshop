﻿using SkiaSharp;
using System;
using System.IO;
using System.Threading.Tasks;

namespace MobileUI2.Helpers.Converters
{
    public class ImageConverter
    {
        // Convert a JPEG file to binary format directly
        public static async Task<byte[]> ConvertJpgToBinaryAsync(string filename)
        {
            string filePath = Path.Combine(GlobalSettings.appDirectory, filename);

            if (!File.Exists(filePath))
            {
                throw new FileNotFoundException($"The file {filename} was not found.");
            }

            using (var stream = new FileStream(filePath, FileMode.Open, System.IO.FileAccess.Read))
            {
                using (var memoryStream = new MemoryStream())
                {
                    await stream.CopyToAsync(memoryStream);
                    return memoryStream.ToArray();
                }
            }
        }

        // Convert a JPEG file to binary format using SkiaSharp (better compression)
        public static async Task<byte[]> CompressAndConvertToBinaryAsync(string filename, int quality = 75, int? width = null, int? height = null)
        {
            return await Task.Run(() =>
            {
                string filePath = Path.Combine(GlobalSettings.appDirectory, filename);

                if (!File.Exists(filePath))
                {
                    throw new FileNotFoundException($"The file {filename} was not found.");
                }

                using (var inputStream = File.OpenRead(filePath))
                {
                    var bitmap = SKBitmap.Decode(inputStream);

                    if (width.HasValue && width > 0 && height.HasValue && height > 0)
                    {
                        bitmap = ResizeBitmap(bitmap, width.Value, height.Value);
                    }

                    using (var memoryStream = new MemoryStream())
                    {
                        var image = SKImage.FromBitmap(bitmap);
                        image.Encode(SKEncodedImageFormat.Jpeg, quality).SaveTo(memoryStream);

                        return memoryStream.ToArray();
                    }
                }
            });
        }

        // ResizeBitmap method as previously defined
        private static SKBitmap ResizeBitmap(SKBitmap originalBitmap, int width, int height)
        {
            return originalBitmap.Resize(new SKImageInfo(width, height), SKFilterQuality.High);
        }
    }
}