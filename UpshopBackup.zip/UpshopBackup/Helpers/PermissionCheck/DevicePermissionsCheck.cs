﻿using static Microsoft.Maui.ApplicationModel.Permissions;

namespace MobileUI2.Helpers.PermissionCheck
{
    public static class DevicePermissionsCheck
    {
        public static async Task CheckAllRequriedPermissions()
        {
            await CameraPermission();
            //await StoragePermission();
            ////await LocationPermission();
            //await PhotosPermission();
        }
        public static async Task<bool> CameraPermission()
        {
            var status = await CheckAndRequestPermissionAsync(new Microsoft.Maui.ApplicationModel.Permissions.Camera());
            if (status != PermissionStatus.Granted)
            {
                // Notify user permission was denied
                return false;
            }
            return true;
        }
        public static async Task<bool> LocationPermission()
        {
            var status = await CheckAndRequestPermissionAsync(new LocationWhenInUse());
            if (status != PermissionStatus.Granted)
            {
                // Notify user permission was denied
                return false;
            }
            status = await CheckAndRequestPermissionAsync(new LocationAlways());
            if (status != PermissionStatus.Granted)
            {
                // Notify user permission was denied
                return false;
            }
            return true;
        }

        public static async Task<bool> StoragePermission()
        {
            var status = await CheckAndRequestPermissionAsync(new StorageRead());
            if (status != PermissionStatus.Granted)
            {
                // Notify user permission was denied
                return false;
            }
            status = await CheckAndRequestPermissionAsync(new StorageWrite());
            if (status != PermissionStatus.Granted)
            {
                // Notify user permission was denied
                return false;
            }
            return true;
        }
        public static async Task<bool> PhotosPermission()
        {
            var status = await Permissions.RequestAsync<Permissions.Photos>();

            if (status != PermissionStatus.Granted)
            {
                // Notify user permission was denied
                return false;
            }
            return true;
        }
        public async static Task<PermissionStatus> CheckAndRequestPermissionAsync<T>(T permission)
            where T : BasePermission
        {
            var status = await permission.CheckStatusAsync();
            if (status != PermissionStatus.Granted)
            {
                status = await permission.RequestAsync();
            }
            return status;
        }


    }
}
