
namespace MobileUI2
{
    public static class FontAwesomeRegularFont
    {
        public const string Next = "\uf061";
        public const string Check = "\uf00c";
    }
}