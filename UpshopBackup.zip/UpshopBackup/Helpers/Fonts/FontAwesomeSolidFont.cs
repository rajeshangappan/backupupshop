﻿namespace MobileUI2
{
    public static class FontAwesomeSolidFont
    {
        public const string Close = "\uf00d";
    }
}
