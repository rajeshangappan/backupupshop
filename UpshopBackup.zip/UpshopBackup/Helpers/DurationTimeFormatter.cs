﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Helpers
{
    public static class DurationTimeFormatter
    {
        public static string GetDurationTimeFormat(int mins)
        {
            var returnString = string.Empty;
            int hours = (mins - mins % 60) / 60;
            int min = mins - hours * 60;
            if (min != 0 && hours != 0)
            {
                if (hours > 1)
                    returnString = returnString + hours + LiteralTranslator.GetValue("HoursShort") + " ";
                else
                    returnString = returnString + hours + LiteralTranslator.GetValue("HourShort") + " ";
                if (min > 1)
                    returnString = returnString + min + LiteralTranslator.GetValue("MinutesShort") + " ";
                else
                    returnString = returnString + min + LiteralTranslator.GetValue("MinuteShort") + " ";
            }
            //Only minutes populated
            if (min != 0 && hours == 0)
            {
                if (min > 1)
                    returnString = returnString + min + LiteralTranslator.GetValue("MinutesShort") + " ";
                else
                    returnString = returnString + min + LiteralTranslator.GetValue("MinuteShort") + " ";
            }
            //Only hours populated
            if (min == 0 && hours != 0)
            {
                if (hours > 1)
                    returnString = returnString + hours + LiteralTranslator.GetValue("HoursShort") + " ";
                else
                    returnString = returnString + hours + LiteralTranslator.GetValue("HourShort") + " ";
            }
            //Neither are populated
            if (min == 0 && hours == 0)
            {
                returnString = hours + LiteralTranslator.GetValue("MinuteShort") + " " + min + LiteralTranslator.GetValue("HourShort");
            }
            return returnString;
        }
    }
}
