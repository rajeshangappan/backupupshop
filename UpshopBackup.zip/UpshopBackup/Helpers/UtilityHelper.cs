using System.Text.RegularExpressions;
using Microsoft.Maui.Platform;
using MobileUI2.Constants;

#if IOS
using UIKit;
#endif

namespace MobileUI2.Helpers
{
    public static class UtilityHelper
    {
        /// <summary>
        /// returns true if value is numeric
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        public static bool IsValidNumericValue(string value, bool restricDecimals = true)
        {
            return restricDecimals ?
                Regex.IsMatch(value, ValidationRegexPatterns.NumericWithNoDecimalsRegex)
                : Regex.IsMatch(value, ValidationRegexPatterns.NumericWithDecimalsRegex);
        }

        /// <summary>
        /// This method can be used To fill the gap coming between Status Bar and Navigation Bar in iOS with AppliedColorCodeKeyFromAppResource
        /// </summary>
        /// <param name="AppliedPage"></param>
        /// <param name="AppliedColorCodeKeyFromAppResource"></param>
        public static void RemoveWhiteSpaceAboveNavigationBariOS(ContentPage AppliedPage, string AppliedColorCodeKeyFromAppResource)
        {

#if IOS
            var window = AppliedPage.GetParentWindow()?.Handler?.PlatformView as UIWindow;
            if (window is not null)
            {
                var topPadding = window?.SafeAreaInsets.Top ?? 0;

                if (Application.Current != null)
                {
                    var hasValue = Application.Current.Resources.TryGetValue(AppliedColorCodeKeyFromAppResource, out object UpshopBackgroundColor);

                    if (hasValue)
                    {
                        var color = (Color)UpshopBackgroundColor;

                        var statusBar = new UIView(new CoreGraphics.CGRect(0, 0, UIScreen.MainScreen.Bounds.Size.Width, topPadding))
                        {
                            BackgroundColor = color.ToPlatform()
                        };

                        var view = AppliedPage.Handler?.PlatformView as UIView;
                        if (view is not null)
                        {
                            view?.AddSubview(statusBar);
                        }
                    }
                }

            }
#endif
        }
    }
}