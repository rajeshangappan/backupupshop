﻿using MobileUI2.Services;

namespace MobileUI2
{
    public static class CheckDeviceStatus
    {
        internal static readonly ISyncService syncService;
        internal static readonly ISignalRService rService;
        internal static readonly IConnectivity connectivityservice;
        internal static readonly IServiceProvider _serviceProvider;
        static CheckDeviceStatus()
        {

            _serviceProvider = App._serviceProvider;
            syncService = _serviceProvider.GetRequiredService<ISyncService>();
            rService = _serviceProvider.GetRequiredService<ISignalRService>();
            connectivityservice = _serviceProvider.GetRequiredService<IConnectivity>();
        }

        public static void ConnectDevice()
        {
            connectivityservice.ConnectivityChanged += Connectivity_ConnectivityChanged;
        }
        public static bool GetCheckDeviceStatus()
        {
            return (int)connectivityservice.NetworkAccess == 4 || (int)connectivityservice.NetworkAccess == 3 ? true : false;
        }

        private static void Connectivity_ConnectivityChanged(object sender, ConnectivityChangedEventArgs e)
        {
            if (e.NetworkAccess == NetworkAccess.Internet)
            {
                try
                {
                    CacheQDTypes.UpdateCacheQDTypes();
                }
                catch (Exception)
                {
                    
                }

                rService.ConnectAsync();
                syncService.SyncPush();
            }

        }
    }
}
