﻿using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Text;

namespace MobileUI2.Helpers
{
    class GetPropertyByNameExpressionHelper
    {
        public static Expression<Func<T, object>> GetPropertyByNameExpression<T>(string propertyName)
        {
            var param = Expression.Parameter(typeof(T), "x");
            var property = Expression.Property(param, propertyName);
            var conversion = Expression.Convert(property, typeof(object));
            return Expression.Lambda<Func<T, object>>(conversion, param);
        }
    }
}
