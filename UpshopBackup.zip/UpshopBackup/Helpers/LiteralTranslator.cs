﻿using MobileUI2.Models;
using MobileUI2.Services;


namespace MobileUI2
{
    public static class LiteralTranslator
    {
        public static ILocalCacheService? cache;
        public static IServiceProvider? _serviceProvider;

        public static void Initialize(IServiceProvider serviceProvider)
        {

            _serviceProvider = serviceProvider;
            cache = _serviceProvider.GetService<ILocalCacheService>();
        }
        public static void JsonInitialize()
        {
            if (GlobalSettings.Literals == null || GlobalSettings.Literals.Count == 0)
            {
                GetLiterals();
            }
        }
        public static string GetValue(string key)
        {
            string keyvalue = "";
            if (GlobalSettings.Literals != null && GlobalSettings.Literals.Count > 0 && GlobalSettings.Literals.ContainsKey(key))
            {
                keyvalue = GetTermininologyValue(GlobalSettings.Literals[key]);
            }
            else
            {
                GetLiterals();
                if (GlobalSettings.Literals != null && GlobalSettings.Literals.Count > 0 && GlobalSettings.Literals.ContainsKey(key))
                {
                    keyvalue = GetTermininologyValue(GlobalSettings.Literals[key]);
                }
                else
                {
                    keyvalue = key;
                }
            }
            return keyvalue;
        }
        public static string GetTermininologyValue(string value)
        {
            if (string.IsNullOrEmpty(value) && (GlobalSettings.TerminologyData == null || GlobalSettings.TerminologyData.Count == 0))
                return value;

            foreach (var item in GlobalSettings.TerminologyData)
            {
                if (!string.IsNullOrEmpty(item.Key) && !string.IsNullOrEmpty(item.Value))
                {
                    if (value.Contains(item.Key))
                    {
                        value = value.Replace(item.Key, GlobalSettings.TerminologyData[item.Key]);
                    }
                    else if (value.Contains(item.Key.ToLowerInvariant()))
                    {
                        value = value.Replace(item.Key.ToLowerInvariant(), GlobalSettings.TerminologyData[item.Key].ToLowerInvariant());
                    }
                }
            }
            return value;
        }
        public static bool ContainLiteralKey(string key)
        {
            bool response;
            if (GlobalSettings.Literals != null && GlobalSettings.Literals.Count > 0)
            {
                response = GlobalSettings.Literals.ContainsKey(key);
            }
            else
            {
                GetLiterals();
                response = GlobalSettings.Literals.ContainsKey(key);
            }
            return response;
        }
        private async static Task GetLiterals()
        {
            MobileLiteralResponse literals = await cache.Get<MobileLiteralResponse>(CacheQDTypes.Literals);
                if (literals != null)
                {
                    GlobalSettings.Literals = literals.MobileLiterals;
                    GlobalSettings.TerminologyData = ConvertFromObjectToDictionary(literals.TerminologyDTO);
                }
            
        }
        public static Dictionary<string, string> ConvertFromObjectToDictionary(object termData)
        {
            if (termData != null && GlobalSettings.Literals != null && GlobalSettings.Literals.Count > 0)
            {
                return termData.GetType().GetProperties().ToDictionary(property => GlobalSettings.Literals[property.Name] ?? "" , property => property.GetValue(termData) != null ? property.GetValue(termData).ToString(): "");
            }
            return null;
        }
    }
}
