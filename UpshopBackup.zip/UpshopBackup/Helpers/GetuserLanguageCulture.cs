﻿using MobileUI2.Models;
using System.Globalization;
using Newtonsoft.Json;

namespace MobileUI2.Helpers
{
    public static class GetUserLanguageCulture
    {
        public static CultureInfo UserCultureInfo()
        {
            CultureInfo ct;
            try
            {
                var usrdata = Preferences.Get(GlobalSettings.UserData, null);
                if(usrdata == null)
                {
                    ct = CultureInfo.CurrentCulture;
                    return ct;
                }
                var userInfo = JsonConvert.DeserializeObject<UserInfo>(usrdata);
                var languageCode = userInfo?.LanguageCode ?? string.Empty;
                if (string.IsNullOrEmpty(languageCode))
                {
                    if (GlobalSettings.Instance.TenantCultureInfo != null)
                        ct = GlobalSettings.Instance.TenantCultureInfo;
                    else
                        ct = CultureInfo.CurrentCulture;
                    return ct;
                }
                if (LanguageXRef.TryGetValue(languageCode, out string language))
                    languageCode = language;

                ct = GetUserLangCulture(languageCode);
            }
            catch (Exception)
            {
                ct = CultureInfo.CurrentCulture;
            }
            return ct;
        }
        private static readonly Dictionary<string, string> LanguageXRef = new Dictionary<string, string>()
        {
            {"0", ""  },
            {"3001", "en"  },
            {"3002", "en-US"  },
            { "3003","en-GB" },
            { "3004","fr" },
            { "3005","es" },
            { "3006","pt"  },
            { "3007","ro"  }
        };

        public static CultureInfo GetUserLangCulture(string languageCode)
        {
            if (languageCode is null)
            {
                return CultureInfo.CurrentCulture;
            }
            CultureInfo[] allCultures = CultureInfo.GetCultures(CultureTypes.AllCultures & ~CultureTypes.NeutralCultures);
            var culture = allCultures.FirstOrDefault(c => c.Name.Equals(languageCode, StringComparison.OrdinalIgnoreCase));
            if (culture == null)
            {
                var regionCode = "-" + languageCode.Split('-')[1];
                culture = allCultures.FirstOrDefault(c => c.Name.EndsWith(regionCode, StringComparison.OrdinalIgnoreCase));
            }

            return culture;
        }
    }
}
