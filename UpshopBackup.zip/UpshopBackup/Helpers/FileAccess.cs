﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Threading.Tasks;

namespace MobileUI2.Helpers
{
    public class FileAccess
    {
        public static bool VideoExists(string filename)
        {
            string videoFile = Path.Combine(GlobalSettings.appDirectory, filename);

            return File.Exists(videoFile);
        }

        public static void DeleteAllFiles()
        {
            if (Directory.Exists(GlobalSettings.appDirectory))
            {
                Directory.Delete(GlobalSettings.appDirectory, true);
            }
        }
    }
}
