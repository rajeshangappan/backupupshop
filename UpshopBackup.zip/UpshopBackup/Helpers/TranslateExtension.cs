﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Globalization;
using System.Resources;
using Microsoft.Maui.Controls;

namespace MobileUI2.Helpers
{
    [ContentProperty(nameof(Text))]
    public class TranslateExtension : IMarkupExtension
    {
        private const string ResourceId = "MobileUI2.Resources";

        private static readonly ResourceManager resourceManager = new(ResourceId, typeof(TranslateExtension).Assembly);

        public string Text { get; set; }

        public object ProvideValue(IServiceProvider serviceProvider)
        {
            if (Text == null)
                return string.Empty;

            return resourceManager.GetString(Text, CultureInfo.CurrentUICulture) ?? Text;
        }
    }
}
