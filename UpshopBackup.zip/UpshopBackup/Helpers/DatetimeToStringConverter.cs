﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;
using Microsoft.Maui.Controls.Compatibility;
using Microsoft.Maui.Controls;
using Microsoft.Maui;

namespace MobileUI2.Helpers
{
    public class DatetimeToStringConverter : IValueConverter
    {
       public static CultureInfo cultureInfo= null;
        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            if (value == null || parameter == null)
                return string.Empty;

            if(cultureInfo == null)
            {
                cultureInfo = GetUserLanguageCulture.UserCultureInfo();
            }

            var param = parameter as string;
            switch (param)
            {
                case "Date":
                    if (((DateTime)value).Date == DateTime.Now.Date)
                        return "Today";

                    return ((DateTime)value).ToString("d", cultureInfo);
                case "Time":
                    return ((DateTime)value).ToString("t", cultureInfo);
                case "DateTime":                   
                default:
                    return ((DateTime)value).ToString("g", cultureInfo);
            }
        }

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            return "";
        }

    }
}
