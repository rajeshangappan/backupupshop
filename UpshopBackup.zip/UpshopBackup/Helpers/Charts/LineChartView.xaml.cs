namespace MobileUI2.Helpers.Charts;

public partial class LineChartView : ContentView
{
    public static readonly BindableProperty LabelsProperty =
       BindableProperty.Create(nameof(Labels), typeof(List<string>), typeof(LineChartView), propertyChanged: OnChartDataChanged);

    public static readonly BindableProperty ValuesProperty =
        BindableProperty.Create(nameof(Values), typeof(List<double>), typeof(LineChartView), propertyChanged: OnChartDataChanged);

    public static readonly BindableProperty ChartTitleProperty =
        BindableProperty.Create(nameof(ChartTitle), typeof(string), typeof(LineChartView), propertyChanged: OnChartDataChanged);

    public static readonly BindableProperty YAxisLabelProperty =
        BindableProperty.Create(nameof(YAxisLabel), typeof(string), typeof(LineChartView), propertyChanged: OnChartDataChanged);

    public static readonly BindableProperty XAxisLabelProperty =
        BindableProperty.Create(nameof(XAxisLabel), typeof(string), typeof(LineChartView), propertyChanged: OnChartDataChanged);

    public static readonly BindableProperty StepSizeProperty =
        BindableProperty.Create(nameof(StepSize), typeof(double?), typeof(LineChartView), propertyChanged: OnChartDataChanged);

    public static readonly BindableProperty NumberOfDaysProperty =
        BindableProperty.Create(nameof(NumberOfDays), typeof(int), typeof(LineChartView), propertyChanged: OnChartDataChanged);
    public static readonly BindableProperty ShowFutureDaysProperty =
        BindableProperty.Create(nameof(ShowFutureDays), typeof(bool), typeof(LineChartView), propertyChanged: OnChartDataChanged);

    public List<string> Labels
    {
        get => (List<string>)GetValue(LabelsProperty);
        set => SetValue(LabelsProperty, value);
    }

    public List<double> Values
    {
        get => (List<double>)GetValue(ValuesProperty);
        set => SetValue(ValuesProperty, value);
    }

    public double? StepSize
    {
        get => (double?)GetValue(StepSizeProperty);
        set => SetValue(StepSizeProperty, value);
    }

    public string ChartTitle
    {
        get => (string)GetValue(ChartTitleProperty);
        set => SetValue(ChartTitleProperty, value);
    }

    public string YAxisLabel
    {
        get => (string)GetValue(YAxisLabelProperty);
        set => SetValue(YAxisLabelProperty, value);
    }

    public string XAxisLabel
    {
        get => (string)GetValue(XAxisLabelProperty);
        set => SetValue(XAxisLabelProperty, value);
    }
    public int NumberOfDays
    {
        get => (int)GetValue(NumberOfDaysProperty);
        set => SetValue(NumberOfDaysProperty, value);
    }

    public bool ShowFutureDays
    {
        get => (bool)GetValue(ShowFutureDaysProperty);
        set => SetValue(ShowFutureDaysProperty, value);
    }
    private readonly IChartService _chartService;
    private readonly WebView _webView;
    public LineChartView()
    {
        InitializeComponent();
        _chartService = new ChartService();
        _webView = new WebView()
        {
            HeightRequest = 400,
            VerticalOptions = LayoutOptions.FillAndExpand,
            HorizontalOptions = LayoutOptions.FillAndExpand
        };
        Content = _webView;
    }

    private static void OnChartDataChanged(BindableObject bindable, object oldValue, object newValue)
    {
        ((LineChartView)bindable).UpdateChart();
    }

    private void UpdateChart()
    {
        if (Labels == null || Values == null) return;
        var config = new ChartConfiguration
        {
            Title = ChartTitle,
            YAxisLabel = YAxisLabel,
            XAxisLabel = XAxisLabel,
            StepSize = StepSize,
            NumberOfDays = NumberOfDays,
            ShowFutureData = ShowFutureDays
        };

        var chartData = new ChartData(Labels, Values, config);
        var html = _chartService.GenerateChartHtml(chartData);
        _webView.Source = new HtmlWebViewSource { Html = html };
    }
}