﻿namespace MobileUI2.Helpers.Charts
{
    public class ChartData
    {
        public List<string> Labels { get; }
        public List<double> Values { get; }
        public ChartConfiguration Configuration { get; }

        public ChartData(List<string> labels, List<double> values, ChartConfiguration configuration)
        {
            Labels = labels ;
            Values = values ;
            Configuration = configuration;
        }
    }
}
