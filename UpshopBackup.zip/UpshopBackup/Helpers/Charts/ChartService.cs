﻿using System.Text.Json;

namespace MobileUI2.Helpers.Charts
{
    public interface IChartService
    {
        string GenerateChartHtml(ChartData chartData);
    }
    public class ChartService : IChartService
    {
        private const int DEFAULT_DAYS = 14;
        private const string DATE_FORMAT = "MMM dd";
        private const double DEFAULT_MAX_VALUE = 100;
        private const double DEFAULT_STEP_SIZE = 20;
        private const int DEFAULT_STEPS = 5;

        public string GenerateChartHtml(ChartData chartData)
        {
            var completeData = GenerateTimeSeriesData(chartData);
            var (labels, values) = SplitDataIntoLabelsAndValues(completeData);
            var (yMax, yStep) = CalculateYAxisBounds(values);
            var formattedLabels = FormatLabels(labels);
            
            return $@"
                <!DOCTYPE html>
                <html>
                <head>
                    <meta charset='utf-8'>
                    <meta name='viewport' content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no'>
                    <script src='https://cdn.jsdelivr.net/npm/chart.js'></script>
                    <style>
                        * {{
                            margin: 0;
                            padding: 0;
                            box-sizing: border-box;
                        }}
                        html, body {{
                            width: 100%;
                            height: 100vh;
                            overflow: hidden;
                        }}
                        .chart-container {{
                            position: relative;
                            width: 100%;
                            height: 100%;
                            display: flex;
                            justify-content: center;
                            align-items: center;
                        }}
                        canvas {{
                            max-width: 100%;
                            max-height: 100%;
                            object-fit: contain;
                        }}
                    </style>
                </head>
                <body>
                    <div class='chart-container'>
                        <canvas id='chart'></canvas>
                    </div>
                    <script>
                        const ctx = document.getElementById('chart');
                        new Chart(ctx, {{
                            type: 'line',
                            data: {{
                                labels: {JsonSerializer.Serialize(formattedLabels)},
                                datasets: [{{
                                    label: '{chartData.Configuration.Title}',
                                    data: {JsonSerializer.Serialize(values)},
                                    borderColor: 'rgb(6, 115, 134)',
                                    backgroundColor: 'rgba(208, 255, 238, 0.5)',
                                    borderWidth: 2,
                                    tension: 0,
                                    fill: true,
                                    pointRadius: 0,
                                    pointHoverRadius: 0
                                }}]
                            }},
                            options: {{
                                responsive: true,
                                maintainAspectRatio: true,
                                aspectRatio: 2,
                                layout: {{
                                    padding: 10
                                }},
                                plugins: {{
                                    legend: {{
                                        display: false
                                    }}
                                }},
                                scales: {{
                                    y: {{
                                        min: 0,
                                        max: {yMax},
                                        title: {{
                                            display: true,
                                            text: '{chartData.Configuration.YAxisLabel}',
                                            font: {{ size: 10 }},
                                            color: '#000000'
                                        }},
                                        ticks: {{
                                            stepSize: {yStep},
                                            callback: function(value) {{ 
                                                return Number(value).toLocaleString(undefined, {{ 
                                                    minimumFractionDigits: 0,
                                                    maximumFractionDigits: 2
                                                }}); 
                                            }},
                                            font: {{ size: 10 }},
                                            color: '#000000',
                                            padding: 5
                                        }},
                                        grid: {{
                                            color: 'rgba(0, 0, 0, 0.1)',
                                            drawBorder: true,
                                            borderColor: '#000000',
                                            borderWidth: 1
                                        }}
                                    }},
                                    x: {{
                                        title: {{
                                            display: false
                                        }},
                                        ticks: {{
                                            font: {{ size: 10 }},
                                            color: '#000000',
                                            maxRotation: 0,
                                            minRotation: 0,
                                            padding: 5
                                        }},
                                        grid: {{
                                            display: false,
                                            drawBorder: true,
                                            borderColor: '#000000',
                                            borderWidth: 1
                                        }}
                                    }}
                                }},
                                animation: false
                            }}
                        }});
                    </script>
                </body>
                </html>";
        }

        private List<(string Label, double Value)> GenerateTimeSeriesData(ChartData chartData)
        {
            int numberOfDays = chartData.Configuration.NumberOfDays;
            DateTime startDate = chartData.Configuration.ShowFutureData
                ? DateTime.Now.Date.AddDays(1)
                : DateTime.Now.Date.AddDays(-numberOfDays);

            var dateRange = Enumerable.Range(0, numberOfDays)
                .Select(i => startDate.AddDays(i));

            var existingData = chartData.Labels.Zip(chartData.Values, (l, v) => (l, v))
                .GroupBy(x=>x.l)
                .ToDictionary(x => x.Key, x => x.First().v);

            return dateRange.Select(date =>
            {
                var label = date.ToString(DATE_FORMAT).ToUpperInvariant();
                return existingData.TryGetValue(label, out var value)
                    ? (Label: label, Value: value)
                    : (Label: label, Value: 0);
            }).ToList();
        }

        private (List<string> Labels, List<double> Values) SplitDataIntoLabelsAndValues(List<(string Label, double Value)> data)
        {
            return (
                data.Select(x => x.Label).ToList(),
                data.Select(x => Math.Round(x.Value,1,MidpointRounding.AwayFromZero)).ToList()
            );
        }

        private List<string[]> FormatLabels(List<string> labels)
        {
            return labels.Select(label =>
            {
                var parts = label.Split(' ');
                return parts.Length == 2 ? new[] { parts[0], parts[1] } : new[] { label };
            }).ToList();
        }

        private (double yMax, double yStep) CalculateYAxisBounds(List<double> values, double? configuredStepSize = null)
        {
            if (!values?.Any() ?? true)
                return (DEFAULT_MAX_VALUE, DEFAULT_STEP_SIZE);

            double maxValue = values.Max();
            if (maxValue <= 0)
                return (DEFAULT_MAX_VALUE, DEFAULT_STEP_SIZE);

            if (configuredStepSize.HasValue)
            {
                double steps = Math.Round(maxValue / configuredStepSize.Value);
                return (steps * configuredStepSize.Value, configuredStepSize.Value);
            }

            double roundedMax = Math.Round(maxValue,2);
            double step = roundedMax / DEFAULT_STEPS;
            return (roundedMax, step);
        }
    }
}
