﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Helpers.Charts
{
    public class ChartConfiguration
    {
        public string Title { get; set; }
        public string YAxisLabel { get; set; }
        public string XAxisLabel { get; set; }
        public double? StepSize { get; set; }
        public int NumberOfDays { get; set; }
        public bool ShowFutureData { get; set; }
    }
}
