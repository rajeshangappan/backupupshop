﻿namespace MobileUI2.Events
{
	public class PrintEventArgs : EventArgs
	{
		public string Message { get; set; }

		public PrintEventArgs(string mes)
		{
			Message = mes;
		}
	}
}

