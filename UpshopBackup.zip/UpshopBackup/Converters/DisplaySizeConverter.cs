﻿using System;
using Microsoft.Maui.Controls.Compatibility;
using Microsoft.Maui.Controls;
using Microsoft.Maui;
using Microsoft.Maui.Devices;

namespace MobileUI2.Converters
{
    public class DisplaySizeConverter : IValueConverter
    {
        private const double HeightMultiplier = 0.069;
        private const double DefaultSize = 50;

        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            if (value is double baseSize)
            {
                var displayInfo = DeviceDisplay.MainDisplayInfo;
                var screenHeight = displayInfo.Height / displayInfo.Density;
                return HeightMultiplier * screenHeight;
            }
            return DefaultSize;
        }

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}