﻿using System;
using System.Globalization;
using static MobileUI2.Components.UpshopPage;
using Microsoft.Maui.Controls.Compatibility;
using Microsoft.Maui.Controls;
using Microsoft.Maui;

namespace MobileUI2.Converters
{
    public class NavigationGlyphConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value is NavigationGlyph glyphValue)
            {
                if (GlyphMappings.TryGetValue(glyphValue, out var convert))
                {
                    return convert;
                }
            }

            return string.Empty; // Return empty string if no glyph is found.
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
