﻿using System;
using System.Globalization;

namespace MobileUI2.Converters
{
    class BoolToColourConverter : IValueConverter
    {
        public Color TrueColor { get; set; } = (Color)Application.Current.Resources["UpshopBackgroundColor"];
        public Color FalseColor { get; set; } = (Color)Application.Current.Resources["UpshopWhite"];

        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value is bool boolValue)
                return boolValue ? TrueColor : FalseColor;

            return FalseColor;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }

    class BoolToTextColorConverter : IValueConverter
    {
        public Color TrueColor { get; set; } = (Color)Application.Current.Resources["UpshopWhite"];
        public Color FalseColor { get; set; } = (Color)Application.Current.Resources["UpshopBackgroundColor"];

        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value is bool boolValue)
                return boolValue ? TrueColor : FalseColor;

            return FalseColor;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
