﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;
using Microsoft.Maui.Controls.Compatibility;
using Microsoft.Maui.Controls;
using Microsoft.Maui;

namespace MobileUI2.Converters
{
    public class CurrencyFormatConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value == null)
                return value;

            var decimalValue=decimal.Parse(value.ToString());
            if (decimal.Remainder(decimalValue, 0.01m) == 0m)
            {
                return decimalValue.ToString("F2");
            }
            if (decimal.Remainder(decimalValue, 0.001m) == 0m)
            {
                return decimalValue.ToString("F3");
            }
            return decimalValue.ToString("F4");
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
