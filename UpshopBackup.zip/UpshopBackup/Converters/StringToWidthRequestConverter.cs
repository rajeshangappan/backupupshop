﻿using System.Globalization;
using Font = Microsoft.Maui.Font;

namespace MobileUI2.Converters
{
    public class StringToWidthRequestConverter : IValueConverter
    {
        private double FontSize { get; set; }

        private string FontFamily { get; set; }

        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (!(value is string text) || string.IsNullOrEmpty(text))
            {
                return 0.0;
            }

            var font = Font.OfSize(FontFamily, FontSize);

            var layout = new FormattedString();
            layout.Spans.Add(new Span { Text = text, FontSize = FontSize, FontFamily = FontFamily });

            var label = new Label
            {
                FormattedText = layout,
                FontFamily = FontFamily,
                FontSize = FontSize
            };
            label.Measure(double.PositiveInfinity, double.PositiveInfinity, MeasureFlags.IncludeMargins);

            return label.Width;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}