﻿using System.Globalization;

namespace MobileUI2.Converters
{
    public class OperatorTextColorConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            var selectedOperator = value as string;
            var buttonOperator = parameter as string;

            return selectedOperator == buttonOperator ? Colors.White : Color.FromHex("#666666");
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
