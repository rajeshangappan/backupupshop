﻿using System;
using System.Globalization;
using Microsoft.Maui.Controls.Compatibility;
using Microsoft.Maui.Controls;
using Microsoft.Maui;

namespace MobileUI2.Converters
{
    public class HeightToFontSizeOvalConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            var heightRequest = (double)value;

            return heightRequest * .5;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            var fontSize = (double)value;

            return fontSize * 2;
        }
    }
}
