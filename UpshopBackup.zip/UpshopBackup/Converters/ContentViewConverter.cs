﻿using MobileUI2.TabletViews;
using System.Globalization;

namespace MobileUI2.Converters
{
    public class ContentViewConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value is int tabIndex)
            {
                switch (tabIndex)
                {
                    case 0:
                        return new OrderItemDetailsContentTabletView();
                    case 1:
                        return new PromotionDetailsContentTabletView();
                    case 2:
                        return new PromotionHistoryContentTabletView();
                    case 3:
                        return new HistoricalDailyMovementContentTabletView();
                    case 4:
                        return new ForecastedDailyMovementContentTabletView();
                }
            }
            return null;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
