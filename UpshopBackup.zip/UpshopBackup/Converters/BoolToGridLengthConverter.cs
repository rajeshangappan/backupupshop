﻿using System.Globalization;

namespace MobileUI2.Converters
{
    public class BoolToGridLengthConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (int.TryParse(parameter.ToString(), out var gridLength) && value is bool boolValue && boolValue)
                return new GridLength(gridLength);
            return new GridLength(0);
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            return new GridLength(0);
        }
    }
}
