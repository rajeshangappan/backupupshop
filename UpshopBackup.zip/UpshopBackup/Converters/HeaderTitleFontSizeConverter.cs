﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Maui.Controls.Compatibility;
using Microsoft.Maui.Controls;
using Microsoft.Maui;
using Microsoft.Maui.Devices;

namespace MobileUI2.Converters
{
    public class HeaderTitleFontSizeConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            var displayInfo = DeviceDisplay.MainDisplayInfo;
            double screenWidthDp = displayInfo.Width / displayInfo.Density;

            double baseFontSize = 16; 
            double referenceWidthDp = 360; 
            double dynamicFontSize = baseFontSize * (screenWidthDp / referenceWidthDp);
            if (parameter is string scaleFactorString && double.TryParse(scaleFactorString, out double scaleFactor))
            {
                dynamicFontSize *= scaleFactor;
            }
            return dynamicFontSize;
        }

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
