﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.BluetoothHelper
{
    public class BluetoothDeviceModel
    {
        public string Name { get; set; }
        public string Uuid { get; set; }
        public bool IsConnected { get; set; }
    }
}
