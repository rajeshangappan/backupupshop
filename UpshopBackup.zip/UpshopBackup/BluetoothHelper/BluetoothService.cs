﻿using Shiny;
using Shiny.BluetoothLE;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reactive.Linq;
using System.Threading.Tasks;

namespace MobileUI2.BluetoothHelper
{
    public interface IBluetoothService
    {
        Task ScanForDevicesAsync(Action<BluetoothDeviceModel> onDeviceFound, BluetoothDeviceTypeEnum deviceType, bool refreshList = false);
        Task ConnectToDeviceAsync(BluetoothDeviceModel device, Action<bool> onDeviceConnected);
        Task SubscribeToTempProbeNotifications(BluetoothDeviceModel device, Action<float> onDataReceived, Action<bool> onButtonClick);
        void StopScanning();
        void DisconnectDeviceAsync(BluetoothDeviceModel device);
        Task StopNotifications();
        Task<bool> IsDeviceAlreadyConnected();
        Task FindDeviceConnected(Action<List<BluetoothDeviceModel>> onDeviceFound);
    }

    public class BluetoothService : IBluetoothService
    {
        private readonly IBleManager _bleManager;
        private readonly List<IPeripheral> _bleDevices = new List<IPeripheral>();
        private const string ServiceUuid = "45544942-4c55-4554-4845-524db87ad700";
        private const string CharacteristicForContinueReadingUuid = "45544942-4c55-4554-4845-524db87ad701";
        private const string CharacteristicForButtonClickUuid = "45544942-4c55-4554-4845-524db87ad705";
        private IDisposable _subContinueDisposable = null;
        private IDisposable _subButtonDisposable = null;
        private IDisposable _subScanDevice = null;
        private List<BluetoothDeviceModel> _connectedDevices = new List<BluetoothDeviceModel>();
        public BluetoothService(IBleManager bleManager)
        {
            _bleManager = bleManager;
        }

        public async Task ScanForDevicesAsync(Action<BluetoothDeviceModel> onDeviceFound,
            BluetoothDeviceTypeEnum deviceType, bool refreshList = false)
        {
            _bleManager.RequestAccess();

            if (_bleManager.IsScanning)
                return;

            _bleDevices.Clear();
            _subScanDevice= _bleManager.Scan().Subscribe(scanResult =>
                {
                    if (string.IsNullOrWhiteSpace(scanResult.Peripheral.Name))
                        return;

                    if (_bleDevices.Any(x => x.Uuid == scanResult.Peripheral.Uuid))
                        return;

                    var knownDevice = CheckDeviceTypeAndAddDeviceToList(scanResult.AdvertisementData, deviceType);
                    if (!knownDevice)
                        return;

                    _bleDevices.Add(scanResult.Peripheral);
                    var device = new BluetoothDeviceModel
                    {
                        Name = scanResult.Peripheral.Name,
                        Uuid = scanResult.Peripheral.Uuid
                    };
                    onDeviceFound?.Invoke(device);
                });
        }

        public void StopScanning()
        {
            _subScanDevice?.Dispose();
            _bleManager.StopScan();
        }

        public async Task<bool> IsDeviceAlreadyConnected()
        {
            // Request access to Bluetooth (ensure you have requested permissions before accessing Bluetooth)
            var accessStatus = await _bleManager.RequestAccess();
            if (accessStatus != AccessState.Available)
            {
                // Handle Bluetooth access not available (e.g., permissions denied)
                return false;
            }

            // Get the connected peripheral for the specified service UUID
            var connectedPeripheral = _bleManager.GetKnownPeripheral(ServiceUuid);

            // Return true if a connected peripheral is found, otherwise return false
            return connectedPeripheral != null;


        }


        public async Task FindDeviceConnected(Action<List<BluetoothDeviceModel>> onDeviceFound)
        {
            try
            {
                // Request Bluetooth access (ensure you have permissions)
                var accessStatus = await _bleManager.RequestAccess();
                if (accessStatus != AccessState.Available)
                {
                    // Handle Bluetooth access not available
                    onDeviceFound?.Invoke(new List<BluetoothDeviceModel>());
                    return;
                }

                // Get all connected peripherals
                var connectedPeripherals = _bleManager.GetConnectedPeripherals();

                if (connectedPeripherals.Any())
                {
                    // Initialize the list of connected devices
                    _connectedDevices = new List<BluetoothDeviceModel>();

                    foreach (var device in connectedPeripherals)
                    {
                        // Get the known services for this peripheral
                        var services = await device.GetServices();

                        // Check if the device has the desired service UUID
                        if (services.Any(service => service.Uuid.ToString() == ServiceUuid))
                        {
                            _connectedDevices.Add(new BluetoothDeviceModel
                            {
                                Name = device.Name,
                                Uuid = device.Uuid
                            });
                        }
                    }

                    // Invoke the callback with the connected devices filtered by Service UUID
                    onDeviceFound?.Invoke(_connectedDevices);
                }
                else
                {
                    // If no connected devices are found, return an empty list
                    onDeviceFound?.Invoke(new List<BluetoothDeviceModel>());
                }
            }
            catch (Exception ex)
            {
                // Handle any exceptions that occur during the process
                Console.WriteLine($"Error occurred: {ex.Message}");
                onDeviceFound?.Invoke(new List<BluetoothDeviceModel>());
            }
        }



        private bool CheckDeviceTypeAndAddDeviceToList(IAdvertisementData advertisementData, BluetoothDeviceTypeEnum deviceType)
        {
            if (deviceType != BluetoothDeviceTypeEnum.TempProbe)
                return false;

            if (advertisementData.ManufacturerData != null &&
                advertisementData.ManufacturerData.CompanyId == 886) // 886 is the company id for the temperature probe
            {
                return true;
            }

            return false;
        }

        public async Task ConnectToDeviceAsync(BluetoothDeviceModel device, Action<bool> onDeviceConnected)
        {
            try
            {
                await StopNotifications();
                DisconnectAllDevicesAsync();

                var connectedDevice = _bleDevices.FirstOrDefault(x => x.Uuid == device.Uuid);
                if (connectedDevice == null)
                    return;
                var knownPeripheral = _bleManager.GetKnownPeripheral(connectedDevice.Uuid);
                if (knownPeripheral != null)
                {

                    knownPeripheral.WhenConnected().Subscribe(_ =>
                {
                    onDeviceConnected?.Invoke(true);
                    _bleManager.StopScan();
                });
                    await knownPeripheral.ConnectAsync();
                }

            }
            catch (Exception)
            {
                onDeviceConnected?.Invoke(false);
            }
        }


        public async Task SubscribeToTempProbeNotifications(BluetoothDeviceModel selectedDevice, Action<float> onDataReceived, Action<bool> onButtonClick)
        {
            var device = _bleDevices.FirstOrDefault(x => x.Uuid == selectedDevice.Uuid);
            if (device == null)
                return;
            var serviceForContinuesReading = await device.GetCharacteristicAsync(ServiceUuid, CharacteristicForContinueReadingUuid);
        //Todo
            //   if (serviceForContinuesReading != null)
              //  await SubscribeContinuesReading(serviceForContinuesReading, onDataReceived);
//Todo
            var serviceForProbeButtonClick = await device.GetCharacteristicAsync(ServiceUuid, CharacteristicForButtonClickUuid);
          //  if (serviceForProbeButtonClick != null)
              //  await SubscribeButtonClick(serviceForProbeButtonClick, onButtonClick);
        }

        //Todo
        //private Task SubscribeContinuesReading(IGattCharacteristic serviceForContinuesReading, Action<float> onDataReceived)
        //{
        //    serviceForContinuesReading.EnableNotifications(true).Subscribe(data =>
        //    {
        //        _subContinueDisposable = serviceForContinuesReading.WhenNotificationReceived()
        //            .Subscribe(reading =>
        //            {
        //                var temp = ConvertToTemp(reading.Data);
        //                onDataReceived?.Invoke(temp);
        //            });
        //    });
        //    return Task.CompletedTask;


        //}
        //Todo
        //private Task SubscribeButtonClick(IGattCharacteristic serviceForProbeButtonClick, Action<bool> onButtonClick, bool isInitialSubscribe = true)
        //{
        //    serviceForProbeButtonClick.EnableNotifications(true).Subscribe(data =>
        //    {
        //        _subButtonDisposable = serviceForProbeButtonClick.WhenNotificationReceived()
        //            .Subscribe(reading =>
        //            {
        //                if (isInitialSubscribe)
        //                {
        //                    isInitialSubscribe = false;
        //                    return;
        //                }
        //                onButtonClick?.Invoke(true);
        //            });
        //    });
        //    return Task.CompletedTask;
        //}

        public void DisconnectDeviceAsync(BluetoothDeviceModel device)
        {
            var connectedDevice = _bleDevices.FirstOrDefault(x => x.Uuid == device.Uuid);
            if (connectedDevice == null)
                return;
           
            connectedDevice.CancelConnection();
        }

        private void DisconnectAllDevicesAsync()
        {
            foreach (var device in _connectedDevices)
            {
                var connectedDevice = _bleDevices.FirstOrDefault(x => x.Uuid == device.Uuid);
                if (connectedDevice == null)
                    return;

                connectedDevice.CancelConnection();
            }
        }

        public async Task StopNotifications()
        {
            if (_subContinueDisposable != null)
            {
                _subContinueDisposable.Dispose();
            }

            if (_subButtonDisposable != null)
            {
                _subButtonDisposable.Dispose();
            }
        }

        private float ConvertToTemp(byte[] temperatureBytes)
        {
            try
            {
                if (temperatureBytes.Length != 4)
                    return 0;
                var temperature = BitConverter.ToSingle(temperatureBytes, 0);
                return temperature;
            }
            catch (Exception)
            {
                return 0;
            }
        }
    }
}
