﻿
using Shiny;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reactive.Linq;
using System.Threading;
using System.Threading.Tasks;
using MobileUI2.Services.Navigation;
using Plugin.BLE.Abstractions.Contracts;
using Plugin.BLE;
using Plugin.BLE.Abstractions.EventArgs;
using Microsoft.Maui.Controls.Compatibility;
using Microsoft.Maui.Controls;
using Microsoft.Maui;
using Shiny.BluetoothLE;

namespace MobileUI2.BluetoothHelper
{
    public interface IBLEService
    {
        Task ScanForDevicesAsync(Action<BluetoothDeviceModel> onDeviceFound, string nameContains = "");
        void DisconnectDevice(BluetoothDeviceModel device);
        void FindDeviceConnected(Action<List<BluetoothDeviceModel>> onDeviceFound, string serviceUuid);
        void StopScanning();
        void StopNotifications();
        void StopAllNotifications();
        Task<bool> IsDeviceAlreadyConnected(string serviceUuid);
        Task ConnectToDeviceAsync(BluetoothDeviceModel device, Action<bool> onDeviceConnected);
        Task SubscribeNotifications(BluetoothDeviceModel selectedDevice, Action<byte[]> action, string serviceUuid, string characteristicUuid);
        Task SubscribeNotificationCommands(BluetoothDeviceModel selectedDevice, Action<bool> action, string serviceUuid, string characteristicUuid, CancellationToken cancellationToken = default);
    }

    public class BLEService : IBLEService
    {
        private readonly IBleManager _bleManager;
        private readonly IBluetoothLE _bluetoothLe;
        private List<IPeripheral> _bleDevices = new List<IPeripheral>();
        private List<BluetoothDeviceModel> _connectedDevices;
        private IPeripheral _connectedDevice;
        private IDisposable _subScanDevice;
        private IDisposable _scanPairedDevice;
        private IDisposable _subNotificationsDisposable;
        private IDisposable _subCommandsDisposable;
        private IDisposable _getKnownPeripheral;
        private IDisposable _pairDevices;
        private Timer _scanTimeoutTimer;
        private Action<bool> _onDeviceConnected;
        public static EventHandler<EventArgs> BleConnection;
        private bool _isSubscribed;
        public static void RaiseBleConnectionEventType(bool status)
        {
            BleConnection?.Invoke(status, EventArgs.Empty);
        }
        public BLEService(IBleManager bleManager)
        {
            _bluetoothLe = CrossBluetoothLE.Current;
            _bleManager = bleManager;
            if (_bluetoothLe!=null)
            {
                _bluetoothLe.StateChanged += BluetoothLeOnStateChanged;
            }
        }

        private void BluetoothLeOnStateChanged(object sender, BluetoothStateChangedArgs e)
        {
            OnAdapterStateChanged(e.NewState == BluetoothState.On ? AccessState.Available : AccessState.Unknown);
        }

        public async Task ScanForDevicesAsync(Action<BluetoothDeviceModel> onDeviceFound, string nameContains="")
        {
            var status = await _bleManager.RequestAccess();
            if(status != AccessState.Available)
                return;

            if (_bleManager.IsScanning)
                return;

            _bleDevices = new List<IPeripheral>();
            _subScanDevice = _bleManager.Scan().Subscribe(device =>
            {
                AddKnownDevicesInListBasedOnName(device.Peripheral,device.AdvertisementData ,onDeviceFound, nameContains);
            });
            //todo
            //_scanPairedDevice = _bleManager.TryGetPairedPeripherals().Subscribe(async scanResult =>
            //{
            //    foreach (var device in scanResult)
            //    {
            //        AddKnownDevicesInListBasedOnName(device,null,onDeviceFound,nameContains);
            //    }
            //});

            //_scanTimeoutTimer = new Timer(StopScanCallback, null, 10000, Timeout.Infinite);
        }

        private void StopScanCallback(object state)
        {
            Device.BeginInvokeOnMainThread(() =>
            {
                _bleManager?.StopScan();
                _subScanDevice?.Dispose();
                _scanPairedDevice?.Dispose();
            });
        }

        private void AddKnownDevicesInListBasedOnName(IPeripheral device, IAdvertisementData advertisementData, Action<BluetoothDeviceModel> onDeviceFound, string nameContains)
        {
            if (string.IsNullOrWhiteSpace(device.Name) || _bleDevices.Any(dev => dev.Uuid == device.Uuid))
                return;

            if (!string.IsNullOrWhiteSpace(nameContains) && advertisementData != null
                && !string.IsNullOrWhiteSpace(advertisementData.LocalName)
                && advertisementData.LocalName.ToLowerInvariant().Contains(nameContains))
            {
                _bleDevices.Add(device);
                onDeviceFound?.Invoke(new BluetoothDeviceModel
                {
                    Name = device.Name,
                    Uuid = device.Uuid
                });
                return;
            }

            if(!string.IsNullOrWhiteSpace(nameContains) && !device.Name.ToLowerInvariant().Contains(nameContains))
                return;

            _bleDevices.Add(device);
            onDeviceFound?.Invoke(new BluetoothDeviceModel
            {
                Name = device.Name,
                Uuid = device.Uuid
            });
        }

        public void StopScanning()
        {
            _subScanDevice?.Dispose();
            _bleManager?.StopScan();
        }

        public async Task<bool> IsDeviceAlreadyConnected(string serviceUuid)
        {
          //  return await _bleManager.GetConnectedPeripherals(serviceUuid).Any();

            // Request access to Bluetooth (ensure you have requested permissions before accessing Bluetooth)
            var accessStatus = await _bleManager.RequestAccess();
            if (accessStatus != AccessState.Available)
            {
                // Handle Bluetooth access not available (e.g., permissions denied)
                return false;
            }

            // Get the connected peripheral for the specified service UUID
            var connectedPeripheral = _bleManager.GetKnownPeripheral(serviceUuid);

            // Return true if a connected peripheral is found, otherwise return false
            return connectedPeripheral != null;
        }

        public async void FindDeviceConnected(Action<List<BluetoothDeviceModel>> onDeviceFound, string serviceUuid)
        {
           
            try
            {
                // Request Bluetooth access (ensure you have permissions)
                var accessStatus = await _bleManager.RequestAccess();
                if (accessStatus != AccessState.Available)
                {
                    // Handle Bluetooth access not available
                    onDeviceFound?.Invoke(new List<BluetoothDeviceModel>());
                    return;
                }

                // Get all connected peripherals
                var connectedPeripherals = _bleManager.GetConnectedPeripherals();

                if (connectedPeripherals.Any())
                {
                    // Initialize the list of connected devices
                    _connectedDevices = new List<BluetoothDeviceModel>();

                    foreach (var device in connectedPeripherals)
                    {
                        // Get the known services for this peripheral
                        var services = await device.GetServices();

                        // Check if the device has the desired service UUID
                        if (services.Any(service => service.Uuid.ToString() == serviceUuid))
                        {
                            _connectedDevices.Add(new BluetoothDeviceModel
                            {
                                Name = device.Name,
                                Uuid = device.Uuid
                            });
                        }
                    }

                    // Invoke the callback with the connected devices filtered by Service UUID
                    onDeviceFound?.Invoke(_connectedDevices);
                }
                else
                {
                    // If no connected devices are found, return an empty list
                    onDeviceFound?.Invoke(new List<BluetoothDeviceModel>());
                }
            }
            catch (Exception ex)
            {
                // Handle any exceptions that occur during the process
                Console.WriteLine($"Error occurred: {ex.Message}");
                onDeviceFound?.Invoke(new List<BluetoothDeviceModel>());
            }
        }

        public async Task ConnectToDeviceAsync(BluetoothDeviceModel selectedDevice, Action<bool> onDeviceConnected)
        {
            try
            {
                StopAllNotifications();
                DisconnectAllDevices();

                var connectedDevice = _bleDevices.FirstOrDefault(x => x.Uuid == selectedDevice.Uuid);
                if (connectedDevice == null)
                    return;
                if(connectedDevice.IsConnected())
                    return;

                _onDeviceConnected = onDeviceConnected;
                _getKnownPeripheral?.Dispose();
                //todo
                //_getKnownPeripheral = _bleManager.GetKnownPeripheral(connectedDevice.Uuid).Subscribe( device =>
                //{
                //    device.WhenConnected().Subscribe(_ =>
                //    {
                //        Task.Delay(1000).ContinueWith(t =>
                //        {
                //            onDeviceConnected?.Invoke(true);
                //            _connectedDevice = device;
                //        });
                //    });

                //    device.WhenConnectionFailed().Subscribe(_ =>
                //    {
                //        onDeviceConnected?.Invoke(false);
                //    });

                //    device.WhenDisconnected().Subscribe(_ =>
                //    {
                //        onDeviceConnected?.Invoke(false);
                //        RaiseBleConnectionEventType(false);
                //    });

                //    device.ConnectIf(new ConnectionConfig()
                //    {
                //        AndroidConnectionPriority = ConnectionPriority.Low,
                //        AutoConnect = true
                //    });
                //});
            }
            catch (Exception)
            {
                onDeviceConnected?.Invoke(false);
            }
        }
        //todo
        //public async Task SubscribeNotifications(BluetoothDeviceModel selectedDevice, Action<byte[]> action,string serviceUuid, string characteristicUuid)
        //{
        //    try
        //    {
        //        var device = _bleDevices.FirstOrDefault(x => x.Uuid == selectedDevice.Uuid);
        //        if (device == null)
        //            return;
        //        if (!device.IsConnected())
        //        {
        //            await Task.Delay(1000);
        //        }

        //        if (!device.IsConnected())
        //            return;

        //        _subNotificationsDisposable?.Dispose();

        //        var service = await device.GetKnownService(serviceUuid);
        //        if (service == null)
        //            return;

        //        var characteristic = await service.GetKnownCharacteristic(characteristicUuid);
        //        if (characteristic == null)
        //            return;

        //        await characteristic.EnableNotifications(true);

        //        _subNotificationsDisposable = characteristic.WhenNotificationReceived()
        //            .Subscribe(reading =>
        //            {
        //                action?.Invoke(reading.Data);
        //            });
        //    }
        //    catch (Exception e)
        //    {
        //        Console.WriteLine(e);
        //    }
        //}
        //todo
        //public async Task SubscribeNotificationCommands(BluetoothDeviceModel selectedDevice, Action<bool> action, string serviceUuid, string characteristicUuid, CancellationToken cancellationToken = default)
        //{
        //    try
        //    {
        //        var device = _bleDevices.FirstOrDefault(x => x.Uuid == selectedDevice.Uuid);
        //        if (device == null)
        //            return;
        //        if (!device.IsConnected())
        //        {
        //            await Task.Delay(1000, cancellationToken);
        //        }
        //        if (!device.IsConnected())
        //            return;
        //        _subCommandsDisposable?.Dispose();
        //        var serviceForCommand = await device.GetKnownCharacteristicAsync(serviceUuid, characteristicUuid, cancellationToken);
        //        if (serviceForCommand != null)
        //        {
        //            serviceForCommand.EnableNotifications(true).Subscribe(data =>
        //            {
        //                _isSubscribed = false;
        //                _subCommandsDisposable = serviceForCommand.WhenNotificationReceived()
        //                    .Subscribe(reading =>
        //                    {
        //                        if (cancellationToken.IsCancellationRequested)
        //                        {
        //                            _subCommandsDisposable.Dispose();
        //                            _isSubscribed = false;
        //                            return;
        //                        }

        //                        if (!_isSubscribed)
        //                        {
        //                            _isSubscribed = true;
        //                            return;
        //                        }
        //                        _isSubscribed = true;
        //                        if (reading.Data == null || reading.Data.Length == 0)
        //                            return;

        //                        if (reading.Data?.Length == 2 &&
        //                            ((reading.Data[0] == 1 && reading.Data[1] == 0) || (reading.Data[0] == 0 && reading.Data[1] == 1)))
        //                            action?.Invoke(true);
        //                    });
        //            });
        //        }
        //    }
        //    catch (Exception e)
        //    {
        //        Console.WriteLine(e);
        //    }
        //}

        public void StopAllNotifications()
        {
            _subNotificationsDisposable?.Dispose();
            _subCommandsDisposable?.Dispose();
        }

        public void StopNotifications()
        {
            _subNotificationsDisposable?.Dispose();
        }

        private void DisconnectAllDevices()
        {
            try
            {
                foreach (var device in _connectedDevices)
                {
                    var connectedDevice = _bleDevices.FirstOrDefault(x => x.Uuid == device.Uuid);
                    if (connectedDevice == null)
                        return;

                    connectedDevice.CancelConnection();
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public void DisconnectDevice(BluetoothDeviceModel device)
        {
            try
            {
                var connectedDevice = _bleDevices.FirstOrDefault(x => x.Uuid == device.Uuid);
                if (connectedDevice == null)
                    return;

                connectedDevice.CancelConnection();
                StopAllNotifications();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public Task OnAdapterStateChanged(AccessState state)
        {
            if (state != AccessState.Available)
            {
               StopAllActions();
            }
            else
            {
                if (_connectedDevice != null)
                {
                    _connectedDevice.CancelConnection();
                    StopAllActions();
                }
            }
           return Task.CompletedTask;
        }

        private void StopAllActions()
        {
            try
            {
                _bleManager?.StopScan();
                _subScanDevice?.Dispose();
                _scanPairedDevice?.Dispose();
                StopAllNotifications();
                DisconnectAllDevices();
                RaiseBleConnectionEventType(false);
            }
            catch (Exception e)
            {
            }
          
        }

        public Task SubscribeNotifications(BluetoothDeviceModel selectedDevice, Action<byte[]> action, string serviceUuid, string characteristicUuid)
        {
            // throw new NotImplementedException();
            return null;
        }

        public Task SubscribeNotificationCommands(BluetoothDeviceModel selectedDevice, Action<bool> action, string serviceUuid, string characteristicUuid, CancellationToken cancellationToken = default)
        {
            //  throw new NotImplementedException();
            return null;

        }
    }
}
