﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Components.ItemTagsComponent
{
    public class ItemTags
    {
        public int ItemTagId { get; set; }
        public string ItemTagName { get; set; }
        public List<int> Children { get; set; }
    }
}
