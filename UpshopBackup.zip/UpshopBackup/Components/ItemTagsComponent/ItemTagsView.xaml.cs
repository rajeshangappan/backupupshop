﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace MobileUI2.Components.ItemTagsComponent
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class ItemTagsView : ContentView
    {
        private ObservableCollection<FilterItem> _tempFilterItems;
        private FilterItem _currentChild;
        private FilterItem _currentParent;
        private FilterItem _coreTag;
        private Stack<FilterItem> _parentStack;

        public static readonly BindableProperty FilterItemsProperty = BindableProperty.Create(nameof(FilterItems), typeof(ObservableCollection<FilterItem>), typeof(ItemTagsView), new ObservableCollection<FilterItem>(), BindingMode.TwoWay);
        public static readonly BindableProperty SelectionChangedCommandProperty = BindableProperty.Create(nameof(SelectionChangedCommand), typeof(Command), typeof(ItemTagsView), null);
        public static readonly BindableProperty SelectedOptionProperty = BindableProperty.Create(nameof(SelectedOption), typeof(int), typeof(ItemTagsView), int.MinValue, BindingMode.TwoWay);
        public static readonly BindableProperty IsResetRequestedProperty = BindableProperty.Create(nameof(IsResetRequested), typeof(bool), typeof(ItemTagsView), false,BindingMode.TwoWay, propertyChanged: OnIsResetRequestedChanged);
        public bool IsResetRequested
        {
            get => (bool)GetValue(IsResetRequestedProperty);
            set => SetValue(IsResetRequestedProperty, value);
        }
        public FilterItem SelectedItem { get; set; }
        public ObservableCollection<FilterItem> FilterItems
        {
            get => (ObservableCollection<FilterItem>)GetValue(FilterItemsProperty);
            set => SetValue(FilterItemsProperty, value);
        }
        public int SelectedOption
        {
            get => (int)GetValue(SelectedOptionProperty);
            set => SetValue(SelectedOptionProperty, value);
        }
        public Command SelectionChangedCommand
        {
            get => (Command)GetValue(SelectionChangedCommandProperty);
            set => SetValue(SelectionChangedCommandProperty, value);
        }

        public ItemTagsView()
        {
            InitializeComponent();
            _tempFilterItems = new ObservableCollection<FilterItem>();
            _parentStack = new Stack<FilterItem>();
        }
        private static void OnIsResetRequestedChanged(BindableObject bindable, object oldValue, object newValue)
        {
            var view = (ItemTagsView)bindable;
            if ((bool)newValue)
            {
                view.ResetTags();
                view.IsResetRequested = false; 
            }
        }

        private void ResetTags()
        {
            if (_currentParent != null)
            {
                _currentParent.IsSelected = false;
            }

            if (_currentChild != null)
            {
                _currentChild.IsSelected = false;
            }

            DisplayParentOrTopLevel();
        }

        private void TapGestureRecognizer_OnTapped(object sender, EventArgs e)
        {
            InitializeFilterItems();
            var param = ((TappedEventArgs)e).Parameter;
            var selectedItem = param as FilterItem;
            if (selectedItem == null)
                return;

            selectedItem.IsSelected = !selectedItem.IsSelected;

            if (_tempFilterItems.Contains(selectedItem))
            {
                if(selectedItem.IsSelected)
                    SelectionChangedCommand?.Execute(selectedItem.FilterId);
                else SelectionChangedCommand?.Execute(null);

                TopLevelItemSelected(selectedItem);
                return;
            }

            if (_currentParent != null && _currentParent.Children.Contains(selectedItem))
            {
                if (_currentChild == selectedItem)
                {
                    _currentChild.IsSelected = false;
                    _currentChild = null;
                    SelectionChangedCommand?.Execute(_currentParent.FilterId);
                    return;
                }

                SelectionChangedCommand?.Execute(selectedItem.FilterId);
                HandleChildSelection(selectedItem);
                return;
            }

            if (_currentParent != null && selectedItem == _currentParent)
            {
                HandleParentDeselection();
                SelectionChangedCommand?.Execute(_currentParent?.FilterId);
                return;
            }

            if (!selectedItem.HasChildren)
            {
                _currentChild = selectedItem;
            }
        }

        private void ResetCurrentValues(FilterItem item)
        {
            if (_currentParent != null && _currentParent != item)
            {
                _currentParent.IsSelected = false;
            }

            if (_currentChild != null && _currentChild != item)
            {
                _currentChild.IsSelected = false;
            }
        }

        private void InitializeFilterItems()
        {
            if (_tempFilterItems.Any())
                return;

            _tempFilterItems = new ObservableCollection<FilterItem>(FilterItems);
            _coreTag = _tempFilterItems.FirstOrDefault(x => x.IsCoreTag);
        }

        private void TopLevelItemSelected(FilterItem selectedItem)
        {
            ResetCurrentValues(selectedItem);
            if (!selectedItem.HasChildren)
            {
                DisplayParentOrTopLevel();
                _currentParent = selectedItem;
                return;
            }

            if (_currentParent == selectedItem)
            {
                DisplayParentOrTopLevel();
            }
            else
            {
                _parentStack.Clear();
                _currentParent = selectedItem;
                _currentChild = null;

                selectedItem.IsSelected = true;
                DisplayChildren(_currentParent);
            }
        }

        private void HandleChildSelection(FilterItem selectedItem)
        {
            ResetCurrentValues(selectedItem);
            selectedItem.IsSelected = true;
            if (!selectedItem.HasChildren)
            {
                _currentChild = selectedItem;
                DisplayChildren(_currentParent);
            }
            else
            {
                _parentStack.Push(_currentParent);
                _currentParent = selectedItem;
                if (_currentChild != null)
                    _currentChild.IsSelected = false;

                _currentChild = null;
                DisplayChildren(_currentParent);
            }
        }

        private void HandleParentDeselection()
        {
            if (_parentStack.Count > 0)
            {
                ResetCurrentValues(_currentParent);
                _currentParent = _parentStack.Pop();
                _currentParent.IsSelected = true;
                DisplayChildren(_currentParent);
                _currentChild = null;
            }
            else
            {
                DisplayParentOrTopLevel();
            }
        }

        private void DisplayChildren(FilterItem parent)
        {
            FilterItems.Clear();

            if (_coreTag != null)
                FilterItems.Insert(0, _coreTag);

            parent.IsSelected = true;
            FilterItems.Add(parent);
            FilterItems.Add(new FilterItem { ShowFilter = false, IsSeparator = true });
            foreach (var child in parent.Children)
            {
                FilterItems.Add(child);
            }
        }

        private void DisplayParentOrTopLevel()
        {
            if (!_tempFilterItems.Any())
                return;

            FilterItems.Clear();
            foreach (var item in _tempFilterItems)
            {
                FilterItems.Add(item);
            }
            _currentParent = null;
            _currentChild = null;
        }
    }
}