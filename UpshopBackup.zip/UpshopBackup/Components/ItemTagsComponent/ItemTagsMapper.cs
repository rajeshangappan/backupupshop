﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;

namespace MobileUI2.Components.ItemTagsComponent
{
    public interface IItemTagsMapper
    {
        ObservableCollection<FilterItem> MapToFilterItems(List<int> topLevelTags, List<ItemTags> tags, bool addOnPromotionTag);
    }

    public class ItemTagsMapper : IItemTagsMapper
    {
        public ObservableCollection<FilterItem> MapToFilterItems(List<int> topLevelTags, List<ItemTags> tags, bool addOnPromotionTag)
        {
            PreprocessTags(topLevelTags, tags, addOnPromotionTag);
            var tagDictionary = tags.ToDictionary(tag => tag.ItemTagId);
            var topLevelFilterItems = new List<FilterItem>();

            foreach (var topLevelId in topLevelTags)
            {
                if (tagDictionary.TryGetValue(topLevelId, out var topTag))
                {
                    var filterItem = CreateFilterItem(topTag, tagDictionary);
                    topLevelFilterItems.Add(filterItem);
                }
            }

            // Sort: CoreTag first, then by Name
            var sortedFilterItems = topLevelFilterItems
                .OrderByDescending(item => item.IsCoreTag)
                .ThenByDescending(item => item.OnPromotionTag)
                .ThenBy(item => item.Name)
                .ToList();

            return new ObservableCollection<FilterItem>(sortedFilterItems);
        }

        private void PreprocessTags(List<int> topLevelTags, List<ItemTags> tags, bool addOnPromotionTag)
        {
            if (!topLevelTags.Contains(1) && tags.Any(x => x.ItemTagId == 1))
                topLevelTags.Add(1);

            if (addOnPromotionTag && !topLevelTags.Contains(-1))
            {
                topLevelTags.Add(-1);
                tags.Add(new ItemTags()
                {
                    ItemTagId = -1,
                    ItemTagName = "On Promotion",
                    Children = new List<int>()
                });
            }
        }


        private FilterItem CreateFilterItem(ItemTags tag, Dictionary<int, ItemTags> tagDictionary)
        {
            var childrenDetails = MapChildItems(tag, tagDictionary);

            return new FilterItem
            {
                Name = tag.ItemTagName,
                FilterId = tag.ItemTagId,
                IsCoreTag = tag.ItemTagId == 1,
                OnPromotionTag = tag.ItemTagId == -1,
                Children = childrenDetails,
                HasChildren = childrenDetails != null && childrenDetails.Count > 0
            };
        }

        private ObservableCollection<FilterItem> MapChildItems(ItemTags parentTag,
            Dictionary<int, ItemTags> tagDictionary)
        {
            var childItems = new ObservableCollection<FilterItem>();

            foreach (var childId in parentTag.Children)
            {
                if (tagDictionary.TryGetValue(childId, out var childTag))
                {
                    var childItem = CreateFilterItem(childTag, tagDictionary);
                    childItems.Add(childItem);
                }
            }

            return childItems;
        }
    }
}
