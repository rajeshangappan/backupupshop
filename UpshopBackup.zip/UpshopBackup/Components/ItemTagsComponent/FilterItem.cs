﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Text;

namespace MobileUI2.Components.ItemTagsComponent
{
    public class FilterItem: NotifyPropertyChanged
    {
        private string _backgroundColor;
        private bool _isSeparator;
        private bool _showFilter = true;
        private bool _isSelected;
        public int FilterId { get; set; }
        public string Name { get; set; }
        public string Icon { get; set; }
        public ObservableCollection<FilterItem> Children { get; set; }
        public bool HasChildren { get; set; }
        public bool IsCoreTag { get; set; }
        public bool OnPromotionTag { get; set; }
        public string BackgroundColor
        {
            get => _backgroundColor;
            set
            {
                if (_backgroundColor != value)
                {
                    _backgroundColor = value;
                    OnPropertyChanged();
                }
            }
        }
        public bool IsSeparator
        {
            get => _isSeparator;
            set
            {
                if (_isSeparator != value)
                {
                    _isSeparator = value;
                    OnPropertyChanged();
                }
            }
        }
        public bool IsSelected
        {
            get => _isSelected;
            set
            {
                if (_isSelected != value)
                {
                    _isSelected = value;
                    OnPropertyChanged();
                }
            }
        }
        public bool ShowFilter
        {
            get => _showFilter;
            set
            {
                if (_showFilter != value)
                {
                    _showFilter = value;
                    OnPropertyChanged();
                }
            }
        }
    }
}
