﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Components.TaskMultipleSelectCheckboxView
{
    public class TaskMultipleSelectCheckboxService : ITaskMultipleSelectCheckboxService
    {
        public List<TaskMultipleSelectCheckboxModel> GetQuestions()
        {
            return new List<TaskMultipleSelectCheckboxModel>
            {
                new TaskMultipleSelectCheckboxModel
                {
                    QuestionId = 1,
                    QuestionText = "What is your favorite programming language?",
                    Options = new List<Option> {
                       new Option{OptionsTxt = "option1"},
                        new Option{OptionsTxt = "option2"},
                         new Option{OptionsTxt = "option3"},
                          new Option{OptionsTxt = "option4"},
                    }
                }
            };
        }
    }
}
