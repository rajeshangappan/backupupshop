﻿using MobileUI2.Controls;
using MobileUI2.Models.Tasks;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows.Input;
using Microsoft.Maui.Controls.Xaml;
using Microsoft.Maui.Controls.Compatibility;
using Microsoft.Maui.Controls;
using Microsoft.Maui;
using StackLayout = Microsoft.Maui.Controls.StackLayout;

namespace MobileUI2.Components.TaskMultipleSelectCheckboxView
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class TaskMultipleSelectCheckboxView : ContentView
    {
        public bool IsCompletedTask;
        private IServiceProvider _serviceProvider;
        public TaskMultipleSelectCheckboxView()
        {
            InitializeComponent();
            ViewModel = new TaskMultipleSelectCheckboxViewModel(_serviceProvider);
            ViewModel.PropertyChanged += (sender, e) =>
            {
                try
                {
                    var data = Items;
                    if (e.PropertyName == nameof(ViewModel.OptionList))
                        UpdateCheckBoxes();
                }
                catch (Exception ex)
                {

                }
            };
        }

        public static readonly BindableProperty ItemsProperty = BindableProperty.Create(nameof(Items), typeof(ObservableCollection<Option>), typeof(TaskMultipleSelectCheckboxView), defaultBindingMode: BindingMode.TwoWay, propertyChanged: OnItemsChanged);
        public static readonly BindableProperty DisplayMemberProperty = BindableProperty.Create(nameof(DisplayMember), typeof(string), typeof(TaskMultipleSelectCheckboxView), string.Empty);
        public static readonly BindableProperty SelectedValuesProperty = BindableProperty.Create(nameof(SelectedValues), typeof(List<Option>), typeof(TaskMultipleSelectCheckboxView), defaultBindingMode: BindingMode.TwoWay, propertyChanged: OnSelectedValuesChanged);
        public static readonly BindableProperty IsControlVisibleProperty = BindableProperty.Create(nameof(IsControlVisible), typeof(bool), typeof(TaskMultipleSelectCheckboxView), true, propertyChanged: OnIsControlVisibleChanged);
        public static readonly BindableProperty ViewModelProperty = BindableProperty.Create(nameof(ViewModel), typeof(TaskMultipleSelectCheckboxViewModel), typeof(TaskMultipleSelectCheckboxView), propertyChanged: OnViewModelChanged);
        public static readonly BindableProperty IsAnswerRequiredProperty = BindableProperty.Create(nameof(IsAnswerRequired), typeof(bool), typeof(TaskMultipleSelectCheckboxView), false);
        public static readonly BindableProperty AnswersProperty = BindableProperty.Create(nameof(QuestionText), typeof(List<string>), typeof(TaskMultipleSelectCheckboxView), defaultValue: default(List<string>), defaultBindingMode: BindingMode.TwoWay, propertyChanged: SelectValues);
        public List<string> Answers
        {
            get => (List<string>)GetValue(AnswersProperty);
            set => SetValue(AnswersProperty, value);
        }
        public Command Command
        {
            get { return (Command)GetValue(CommandProperty); }
            set { SetValue(CommandProperty, value); }
        }

        public static BindableProperty CommandProperty =
            BindableProperty.Create(
                nameof(Command),
                typeof(Command),
                typeof(TaskMultipleSelectCheckboxView),
                defaultBindingMode: BindingMode.TwoWay);

        public static BindableProperty CommandParameterProperty =
            BindableProperty.Create(
                nameof(CommandParameter),
                typeof(object),
                typeof(TaskMultipleSelectCheckboxView),
                defaultBindingMode: BindingMode.TwoWay);

        public object CommandParameter
        {
            get => GetValue(CommandParameterProperty);
            set => SetValue(CommandParameterProperty, value);
        }
        public bool IsAnswerRequired
        {
            get => (bool)GetValue(IsAnswerRequiredProperty);
            set => SetValue(IsAnswerRequiredProperty, value);
        }
        public static readonly BindableProperty ItemListProperty = BindableProperty.Create(
            nameof(ItemList),
            typeof(List<string>),
            typeof(TaskMultipleSelectCheckboxView),
            defaultValue: null,
            defaultBindingMode: BindingMode.TwoWay,
            propertyChanged: OnItemListChanged);

        public static readonly BindableProperty QuestionTextProperty =
            BindableProperty.Create(nameof(QuestionText), typeof(string), typeof(TaskMultipleSelectCheckboxView), string.Empty);

        public string QuestionText
        {
            get => (string)GetValue(QuestionTextProperty);
            set => SetValue(QuestionTextProperty, value);
        }
        public static readonly BindableProperty FormattedQuestionTextProperty =
           BindableProperty.Create(nameof(FormattedQuestionText), typeof(FormattedString), typeof(TaskMultipleSelectCheckboxView), defaultValue: default(FormattedString), defaultBindingMode: BindingMode.TwoWay);

        public FormattedString FormattedQuestionText
        {
            get => (FormattedString)GetValue(FormattedQuestionTextProperty);
            set => SetValue(FormattedQuestionTextProperty, value);
        }
        public List<string> ItemList
        {
            get => (List<string>)GetValue(ItemListProperty);
            set
            {
                SetValue(ItemListProperty, value);
                OnPropertyChanged();
            }
        }
        private static void SelectValues(BindableObject bindable, object oldvalue, object newvalue)
        {
            try
            {
                if (newvalue == null)
                    return;
                var customView = (TaskMultipleSelectCheckboxView)bindable;
                customView.IsCompletedTask = true;
                var value = (List<string>)newvalue;
                if (!value.Any())
                    return;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }
        private static void OnItemListChanged(BindableObject bindable, object oldValue, object newValue)
        {
            if (newValue == null)
                return;
            // Cast the bindable parameter to your view type
            var view = (TaskMultipleSelectCheckboxView)bindable;

            // Do something with the new value
            var newItems = (List<string>)newValue;
            var optionsList = new ObservableCollection<Option>();
            foreach (var option in newItems)
            {
                optionsList.Add(new Option()
                {
                    OptionsTxt = option,
                    IsChecked = false
                });
            }
            view.ViewModel.OptionList = optionsList;
            view.UpdateCheckBoxes();

        }
        public List<Option> SelectedValues
        {
            get => (List<Option>)GetValue(SelectedValuesProperty);
            set => SetValue(SelectedValuesProperty, value);
        }

        private static void OnSelectedValuesChanged(BindableObject bindable, object oldValue, object newValue)
        {
            if (bindable is TaskMultipleSelectCheckboxView control && newValue is List<Option> selectedValues)
            {
                control.ViewModel.SelectedValues = selectedValues;
            }
        }

        public TaskMultipleSelectCheckboxViewModel ViewModel
        {
            get => (TaskMultipleSelectCheckboxViewModel)GetValue(ViewModelProperty);
            set => SetValue(ViewModelProperty, value);
        }

        public ObservableCollection<Option> Items
        {
            get => (ObservableCollection<Option>)GetValue(ItemsProperty);
            set => SetValue(ItemsProperty, value);
        }

        public string DisplayMember
        {
            get => (string)GetValue(DisplayMemberProperty);
            set => SetValue(DisplayMemberProperty, value);
        }

        public bool IsControlVisible
        {
            get => (bool)GetValue(IsControlVisibleProperty);
            set => SetValue(IsControlVisibleProperty, value);
        }

        private static void OnViewModelChanged(BindableObject bindable, object oldValue, object newValue)
        {
            try
            {
                if (bindable is TaskMultipleSelectCheckboxView control)
                    control.UpdateCheckBoxes();
            }
            catch (Exception ex)
            {

            }
        }

        private static void OnItemsChanged(BindableObject bindable, object oldValue, object newValue)
        {
            try
            {
                if (bindable is TaskMultipleSelectCheckboxView control && newValue is ObservableCollection<Option> items)
                {
                    control.UpdateCheckBoxes();
                }
            }
            catch (Exception ex)
            {

            }
        }

        private void UpdateCheckBoxes()
        {
            try
            {
                QuestionStack?.Children.Clear();
                if(!(ViewModel.OptionList?.Any() ?? false))
                    return;

                var checkBoxes = ViewModel?.OptionList.OfType<Option>().Select((item, index) => CreateCheckBox(item, index)).ToList();

                // Add space between checkboxes
                if (checkBoxes != null)
                {
                    for (int i = 0; i < checkBoxes.Count; i++)
                    {
                        var checkBox = checkBoxes[i];
                        QuestionStack?.Children.Add(checkBox);
                    }
                }
            }
            catch (Exception ex)
            {
            }
        }

        private StackLayout CreateCheckBox(Option item, int index)
        {
            try
            {
                string displayText = item.OptionsTxt;
                if (IsCompletedTask && (Answers?.Any() ?? false))
                    item.IsChecked = Answers.Contains(item.OptionsTxt);
                    
                //Added index parameter to make automationid unique for every element below.  
                ColoredCheckBox checkBox = new ColoredCheckBox() { Value = displayText, GroupName = "options", ParentControl = this, IsChecked = item.IsChecked, AutomationId = $"chckbx_colored_{index}" };
                Label label = new Label { Text = displayText, VerticalOptions = LayoutOptions.Center, FontAttributes = FontAttributes.None, FontSize = 16, TextColor = Color.FromArgb("067386"), AutomationId = $"lbl_coloredcheckbxoptiontxt_{index}" };
     
                StackLayout horizontalStack = new StackLayout
                {
                    Orientation = StackOrientation.Horizontal,
                    Children = { checkBox, label },
                    Spacing = 13,
                    AutomationId = $"stk_multiplecheckboxstack_{index}"
                };
                horizontalStack.Margin = new Thickness(0, 9, 9, 9);

                var tapGesture = new TapGestureRecognizer
                {
                    Command = new Command(() =>
                    {
                        if (IsCompletedTask)
                            return;
                        checkBox.IsChecked = !checkBox.IsChecked;
                        UpdateSelectedValues(checkBox);
                    })
                };

                horizontalStack.GestureRecognizers.Add(tapGesture);

                checkBox.IsCheckedChanged += (sender, args) =>
                {
                    if(IsCompletedTask)
                        return;
                    var selectedcheckbox = (ColoredCheckBox)sender;
                    UpdateSelectedValues(selectedcheckbox);
                };

                return horizontalStack;
            }
            catch (Exception ex)
            {
                return null;
            }
        }


        private void UpdateSelectedValues(ColoredCheckBox selectedCheckBox)
        {
            try
            {
                if(IsCompletedTask)
                    return;

                // Update ViewModel.OptionList based on the selected checkbox
                var updatedOptionList = ViewModel.OptionList
                    .Select(option =>
                    {
                        if (option.OptionsTxt == (string)selectedCheckBox.Value)
                        {
                            option.IsChecked = selectedCheckBox.IsChecked;
                        }
                        return option;
                    })
                    .ToList();

                ViewModel.OptionList = new ObservableCollection<Option>(updatedOptionList);

                // Update ViewModel.SelectedValues based on the updated OptionList
                ViewModel.SelectedValues = updatedOptionList
                    .Where(option => option.IsChecked)
                    .Select(option => new Option { OptionsTxt = option.OptionsTxt, IsChecked = true })
                    .ToList();
                UpdateData(ViewModel.SelectedValues.Select(value => value.OptionsTxt).ToList());
            }
            catch (Exception ex)
            {
            }
        }

        private void UpdateData(List<string> answers)
        {
            if (answers == null)
                answers = new List<string>();

            if (CommandParameter is StoreWalkQuestionDetails)
            {
                var data = (StoreWalkQuestionDetails)CommandParameter;
                data.Answer = answers;
                Command.Execute(CommandParameter);
            }
        }

        private static void OnIsControlVisibleChanged(BindableObject bindable, object oldValue, object newValue)
        {
            try
            {
                var control = (TaskMultipleSelectCheckboxView)bindable;
                control.ViewModel.IsControlVisible = (bool)newValue;
            }
            catch (Exception ex)
            {
            }
        }

        public void UncheckAllExcept(ColoredCheckBox checkBoxToSkip)
        {
            try
            {
                if(IsCompletedTask)
                    return;

                foreach (var child in QuestionStack.Children)
                {
                    if (child is TaskMultipleSelectCheckboxView checkboxView &&
                        checkboxView.Children[0] is ColoredCheckBox checkBox &&
                        checkBox != checkBoxToSkip)
                    {
                        checkBox.IsChecked = false;
                    }
                }
            }
            catch (Exception ex)
            {
            }
        }
    }
}