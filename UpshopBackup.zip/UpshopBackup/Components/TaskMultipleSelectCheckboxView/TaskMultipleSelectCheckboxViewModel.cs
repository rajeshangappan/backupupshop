﻿using MobileUI2.ViewModels.StoreWalks;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Windows.Input;
using Microsoft.Maui.Controls.Compatibility;
using Microsoft.Maui.Controls;
using Microsoft.Maui;

namespace MobileUI2.Components.TaskMultipleSelectCheckboxView
{
    public class TaskMultipleSelectCheckboxViewModel : INotifyPropertyChanged
    {
        private IServiceProvider _serviceProvider;
        public TaskMultipleSelectCheckboxViewModel(IServiceProvider serviceProvider,ITaskMultipleSelectCheckboxService service = null)
        {
            Initialize(service);
            _serviceProvider = serviceProvider;
        }

        public void Initialize(ITaskMultipleSelectCheckboxService service)
        {
            try
            {
                if (service == null)
                    service = _serviceProvider.GetService<ITaskMultipleSelectCheckboxService>();
                //Questions = service.GetQuestions();
                //foreach (var question in Questions)
                //{
                //    Title = question.QuestionText;
                //    Options = question.Options;
                //    if (Options != null && Options.Any())
                //    {
                //        DisplayMember = string.Join(", ", Options.Select(x => x.OptionsTxt));
                //    }
                //}
                //OptionList = new ObservableCollection<Option>(Options);
            }
            catch (Exception ex)
            {
            }
        }

        private ObservableCollection<Option> _optionList;
        public ObservableCollection<Option> OptionList
        {
            get => _optionList;
            set
            {
                if (_optionList != value)
                {
                    _optionList = value;
                    OnPropertyChanged(nameof(OptionList));
                }
            }
        }

        private string _title;
        public string Title
        {
            get => _title;
            set
            {
                if (_title != value)
                {
                    _title = value;
                    OnPropertyChanged(nameof(Title));
                }
            }
        }

        private bool _isControlVisible = true;
        public bool IsControlVisible
        {
            get => _isControlVisible;
            set
            {
                if (_isControlVisible != value)
                {
                    _isControlVisible = value;
                    OnPropertyChanged(nameof(IsControlVisible));
                }
            }
        }

        private List<Option> _options;
        public List<Option> Options
        {
            get => _options;
            set
            {
                if (_options != value)
                {
                    _options = value;
                    OnPropertyChanged(nameof(Options));
                }
            }
        }

        private List<Option> _selectedValues = new List<Option>();
        public List<Option> SelectedValues
        {
            get => _selectedValues;
            set
            {
                if (_selectedValues != value)
                {
                    _selectedValues = value;
                    OnPropertyChanged(nameof(SelectedValues));
                }
            }
        }

        private List<TaskMultipleSelectCheckboxModel> _questions;
        public List<TaskMultipleSelectCheckboxModel> Questions
        {
            get => _questions;
            set
            {
                if (_questions != value)
                {
                    _questions = value;
                    OnPropertyChanged(nameof(Questions));
                }
            }
        }

        public void UpdateQuestions(List<TaskMultipleSelectCheckboxModel> questions)
        {
            try
            {
                Questions = questions;
            }
            catch (Exception ex)
            {
            }
        }

        private string _displayMember;
        public string DisplayMember
        {
            get { return _displayMember; }
            set
            {
                _displayMember = value;
                OnPropertyChanged(nameof(DisplayMember));
            }
        }

        private ICommand checkboxCommand;

        public ICommand CheckboxCommand => checkboxCommand ?? (checkboxCommand = new Command<bool>(OnCheckboxChecked));

        private void OnCheckboxChecked(bool isChecked)
        {
            UpdateSelectedValues();
        }

        private void UpdateSelectedValues()
        {
            try
            {
                SelectedValues = OptionList
                    .Where(option => option.IsChecked)
                    .ToList();
            }
            catch (Exception ex)
            {
                
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}

