﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Components.TaskMultipleSelectCheckboxView
{
    public class TaskMultipleSelectCheckboxModel
    {
        public int QuestionId { get; set; }
        public string QuestionText { get; set; }
        public List<Option> Options { get; set; }
    }

    public class Option
    {
        public string OptionsTxt { get; set; }

        public bool IsChecked { get; set; } 
    }
}
