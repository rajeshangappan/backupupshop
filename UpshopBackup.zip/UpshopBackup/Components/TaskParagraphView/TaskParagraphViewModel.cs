﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace MobileUI2.Components.TaskParagraphView
{
    public class TaskParagraphViewModel : INotifyPropertyChanged
    {
        private TaskParagraphModel _taskSingleLineModel;
        private IServiceProvider _serviceProvider;

        public TaskParagraphViewModel(IServiceProvider serviceProvider,ITaskPararaphService service = null)
        {
            Initialize(service);
            _serviceProvider = serviceProvider;
        }

        public void Initialize(ITaskPararaphService service)
        {
            try
            {
                if (service == null)
                    service = _serviceProvider.GetService<ITaskPararaphService>();

                _taskSingleLineModel = service?.GetQuestion() ?? throw new ArgumentNullException(nameof(service));
            }
            catch (Exception ex)
            {
            }
        }

        public string QuestionTitle
        {
            get { return _taskSingleLineModel?.QuestionTxt; }
            set
            {
                if (_taskSingleLineModel != null)
                {
                    _taskSingleLineModel.QuestionTxt = value;
                    OnPropertyChanged(nameof(QuestionTitle));
                }
            }
        }

        public string AnswerTxt
        {
            get { return _taskSingleLineModel?.AnswerTxt; }
            set
            {
                if (_taskSingleLineModel != null)
                {
                    _taskSingleLineModel.AnswerTxt = value;
                    OnPropertyChanged(nameof(AnswerTxt));
                }
            }
        }


        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
