﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Components.TaskParagraphView
{
    public interface ITaskPararaphService
    {
        TaskParagraphModel GetQuestion();
    }
}
