﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Components.TaskParagraphView
{
    public class TaskParagraphService : ITaskPararaphService
    {
        public TaskParagraphModel GetQuestion()
        {
            var singleLineModel = new TaskParagraphModel
            {
                QuestionTxt = "The question to be asked that prompts the response will go here?"
            };

            return singleLineModel;
        }
    }
}
