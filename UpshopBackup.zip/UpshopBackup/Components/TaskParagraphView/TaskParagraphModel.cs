﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Components.TaskParagraphView
{
    public class TaskParagraphModel
    {
        public string QuestionTxt { get; set; }
        public string AnswerTxt { get; set; }
    }
}
