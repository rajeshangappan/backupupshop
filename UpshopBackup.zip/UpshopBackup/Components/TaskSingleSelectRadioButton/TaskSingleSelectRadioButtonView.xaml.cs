﻿using System.Collections.Generic;
using MobileUI2.Controls;
using System.Collections.ObjectModel;
using System.Linq;
using Microsoft.Maui.Controls.Xaml;
using MobileUI2.ViewModels.StoreWalks;
using MobileUI2.Components.TaskBool;
using MobileUI2.Models.Tasks;
using System;
using Microsoft.Maui.Controls.Compatibility;
using Microsoft.Maui.Controls;
using Microsoft.Maui;
using StackLayout = Microsoft.Maui.Controls.StackLayout;

namespace MobileUI2.Components.TaskSingleSelectRadioButton
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class TaskSingleSelectRadioButtonView
    {
        public bool IsCompletedTask;
        public static readonly BindableProperty DisplayMemberProperty = BindableProperty.Create(nameof(DisplayMember), typeof(string), typeof(TaskSingleSelectRadioButtonView), string.Empty);
        public static readonly BindableProperty TitleProperty = BindableProperty.Create(nameof(Title), typeof(string), typeof(TaskSingleSelectRadioButtonView), string.Empty, propertyChanged: OnTitleChanged);
        public static readonly BindableProperty SelectedValueProperty = BindableProperty.Create(nameof(SelectedValue), typeof(string), typeof(TaskSingleSelectRadioButtonView), defaultBindingMode: BindingMode.TwoWay);
        public static readonly BindableProperty IsControlVisibleProperty = BindableProperty.Create(nameof(IsControlVisible), typeof(bool), typeof(TaskSingleSelectRadioButtonView), true, propertyChanged: OnIsControlVisibleChanged);
        public static readonly BindableProperty ViewModelProperty = BindableProperty.Create(nameof(ViewModel), typeof(TaskSingleSelectRadioButtonViewModel), typeof(TaskSingleSelectRadioButtonView), propertyChanged: OnViewModelChanged);
        public static readonly BindableProperty QuestionTextProperty = BindableProperty.Create(nameof(QuestionText), typeof(string), typeof(TaskSingleSelectRadioButtonView), string.Empty);
        public static readonly BindableProperty IsAnswerRequiredProperty = BindableProperty.Create(nameof(IsAnswerRequired), typeof(bool), typeof(TaskSingleSelectRadioButtonView), false);
        public static readonly BindableProperty ItemListProperty = BindableProperty.Create(nameof(ItemList), typeof(List<string>), typeof(TaskSingleSelectRadioButtonView), defaultValue: default(List<string>), propertyChanged: OnItemListChanged);
        public static readonly BindableProperty CommandProperty = BindableProperty.Create(nameof(Command), typeof(Command), typeof(TaskSingleSelectRadioButtonView), defaultBindingMode: BindingMode.TwoWay);
        public static readonly BindableProperty CommandParameterProperty = BindableProperty.Create(nameof(CommandParameter), typeof(object), typeof(TaskSingleSelectRadioButtonView), defaultBindingMode: BindingMode.TwoWay);
        public static readonly BindableProperty AnswersProperty = BindableProperty.Create(nameof(QuestionText), typeof(List<string>), typeof(TaskSingleSelectRadioButtonView), defaultValue: default(List<string>), defaultBindingMode: BindingMode.TwoWay, propertyChanged: SelectValues);
        public static readonly BindableProperty FormattedQuestionTextProperty = BindableProperty.Create(nameof(FormattedQuestionText), typeof(FormattedString), typeof(TaskSingleSelectRadioButtonView), defaultValue: default(FormattedString), defaultBindingMode: BindingMode.TwoWay);
        public IServiceProvider _serviceProvider;
        public FormattedString FormattedQuestionText
        {
            get => (FormattedString)GetValue(FormattedQuestionTextProperty);
            set => SetValue(FormattedQuestionTextProperty, value);
        }
        public List<string> Answers
        {
            get => (List<string>)GetValue(AnswersProperty);
            set => SetValue(AnswersProperty, value);
        }
        public TaskSingleSelectRadioButtonView()
        {
            InitializeComponent();
            ViewModel = new TaskSingleSelectRadioButtonViewModel(_serviceProvider);
            ViewModel.PropertyChanged += (sender, e) =>
            {
                if (e.PropertyName == nameof(ViewModel.OptionList))
                    UpdateRadioButtons();
            };
        }

        public bool IsAnswerRequired
        {
            get => (bool)GetValue(IsAnswerRequiredProperty);
            set => SetValue(IsAnswerRequiredProperty, value);
        }
        public string QuestionText
        {
            get => (string)GetValue(QuestionTextProperty);
            set => SetValue(QuestionTextProperty, value);
        }
        public List<string> ItemList
        {
            get { return (List<string>)GetValue(ItemListProperty); }
            set { SetValue(ItemListProperty, value); }
        }
        public Command Command
        {
            get { return (Command)GetValue(CommandProperty); }
            set { SetValue(CommandProperty, value); }
        }
        public object CommandParameter
        {
            get => GetValue(CommandParameterProperty);
            set => SetValue(CommandParameterProperty, value);
        }
        public TaskSingleSelectRadioButtonViewModel ViewModel
        {
            get => (TaskSingleSelectRadioButtonViewModel)GetValue(ViewModelProperty);
            set => SetValue(ViewModelProperty, value);
        }

        public string DisplayMember
        {
            get => (string)GetValue(DisplayMemberProperty);
            set => SetValue(DisplayMemberProperty, value);
        }

        public string Title
        {
            get => TitleLabel.Text;
            set => TitleLabel.Text = value;
        }

        public string SelectedValue
        {
            get => (string)GetValue(SelectedValueProperty);
            set => SetValue(SelectedValueProperty, value);
        }

        public bool IsControlVisible
        {
            get => (bool)GetValue(IsControlVisibleProperty);
            set => SetValue(IsControlVisibleProperty, value);
        }
        private static void SelectValues(BindableObject bindable, object oldvalue, object newvalue)
        {
            try
            {
                if (newvalue == null)
                    return;
                var customView = (TaskSingleSelectRadioButtonView)bindable;
                customView.IsCompletedTask = true;
                var value = (List<string>)newvalue;
                if (!value.Any())
                    return;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }
        private static void OnItemListChanged(BindableObject bindable, object oldValue, object newValue)
        {
            if (newValue == null)
                return;
            var view = (TaskSingleSelectRadioButtonView)bindable;
            var newItems = (List<string>)newValue;
            var optionsList = new ObservableCollection<Option>();
            foreach (var option in newItems)
            {
                optionsList.Add(new Option()
                {
                    OptionsTxt = option,
                });
            }
            view.ViewModel.OptionList = optionsList;
            view.UpdateRadioButtons();
        }

        private static void OnViewModelChanged(BindableObject bindable, object oldValue, object newValue)
        {
            if (bindable is TaskSingleSelectRadioButtonView control)
                control.UpdateRadioButtons();
        }

        private void UpdateRadioButtons()
        {

            RadioButtonLayout.Children.Clear();

            var radioButtons = ViewModel?.OptionList?.OfType<Option>().Select((item, index) => CreateRadioButton(item, index)).ToList();
            radioButtons?.ForEach(btn => RadioButtonLayout.Children.Add(btn));
        }

        private StackLayout CreateRadioButton(Option item, int index)
        {
            string displayText =item.OptionsTxt;
            bool isChecked = false;
            if (IsCompletedTask && (Answers?.Any() ?? false))
                isChecked = Answers.Contains(item.OptionsTxt);
            Style stackLayoutStyle = (Style)Application.Current.Resources["LabelSemiBoldStyle"];
            ColoredRadioButton radioButton = new ColoredRadioButton(null, this) { Value = displayText, IsChecked = isChecked, GroupName = "options", TaskRadioParentControl = this, AutomationId = $"coloredradiobtn_singleselect_{index}" };
            Label label = new Label { Text = displayText, VerticalOptions = LayoutOptions.Center, FontSize = 16, TextColor = Color.FromArgb("067386"), AutomationId = $"lbl_coloredsingleselectoptiontxt_{index}" };

            StackLayout horizontalStack = new StackLayout
            {
                Orientation = StackOrientation.Horizontal,
                Spacing = 13,
                Children = { radioButton, label },
                AutomationId = $"stk_singleselectcoloredstack_{index}",
                Margin = new Thickness(0,9,9,9)
            };

            var tapGesture = new TapGestureRecognizer
            {
                Command = new Command(() =>
                {
                    if (IsCompletedTask)
                        return;
                    if (!radioButton.IsChecked)
                    {
                        UncheckAllExcept(radioButton);
                        radioButton.IsChecked = true;
                        ViewModel.SelectedValue = displayText;
                        UpdateData(ViewModel.SelectedValue);
                        //AutomationId = $"coloredsingleselect_tapgesture_{index}";
                    }
                })
            };

            horizontalStack.GestureRecognizers.Add(tapGesture);

            radioButton.IsCheckedChanged += (sender, args) =>
            {
                if (IsCompletedTask)
                    return;
                if (args.IsChecked)
                {
                    ViewModel.SelectedValue = displayText;
                    UncheckAllExcept(radioButton);
                }
                else
                {
                    ViewModel.SelectedValue = null;
                }

                UpdateData(ViewModel.SelectedValue);
            };

            return horizontalStack;
        }
        public void UncheckAllExcept(ColoredRadioButton radioButtonToSkip)
        {
            if (IsCompletedTask)
                return;
            foreach (var child in RadioButtonLayout.Children)
            {
                if (child is StackLayout horizontalStack && horizontalStack.Children[0] is ColoredRadioButton radioButton && radioButton != radioButtonToSkip)
                    radioButton.IsChecked = false;
            }
        }

        private static void OnTitleChanged(BindableObject bindable, object oldValue, object newValue)
        {
            var control = (TaskSingleSelectRadioButtonView)bindable;
            control.ViewModel.Title = (string)newValue;
        }

        private static void OnIsControlVisibleChanged(BindableObject bindable, object oldValue, object newValue)
        {
            var control = (TaskSingleSelectRadioButtonView)bindable;
            control.ViewModel.IsControlVisible = (bool)newValue;
        }
        private void UpdateData(string answer)
        {
            if (CommandParameter is StoreWalkQuestionDetails data)
            {
                if (string.IsNullOrEmpty(answer))
                    data.Answer = new List<string>();
                else data.Answer = new List<string>() { answer };
                Command.Execute(CommandParameter);
            }
        }
    }
}
