﻿using System.Collections.Generic;

namespace MobileUI2.Components.TaskSingleSelectRadioButton
{
    public class TaskSingleSelectRadioButtonModel
    {
        public int QuestionId { get; set; }
        public string QuestionText { get; set; }
        public List<Option> Options { get; set; }
    }

    public class Option
    {
        public string OptionsTxt { get; set; }
    }
}
