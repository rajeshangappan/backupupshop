﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Components.TaskSingleSelectRadioButton
{
    public class TaskSingleSelectRadioButtonService : ITaskSingleSelectRadioButtonService
    {
        public List<TaskSingleSelectRadioButtonModel> GetQuestions()
        {
            return new List<TaskSingleSelectRadioButtonModel>
            {
                new TaskSingleSelectRadioButtonModel
                {
                    QuestionId = 1,
                    QuestionText = "What is your favorite programming language?",
                }
            };
        }
    }
}
