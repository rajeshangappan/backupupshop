﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using MobileUI2.ViewModels;
using MobileUI2.ViewModels.StoreWalks;

namespace MobileUI2.Components.TaskSingleSelectRadioButton
{
    public class TaskSingleSelectRadioButtonViewModel : BaseViewModel
    {

        private IServiceProvider _serviceProvider;
        public TaskSingleSelectRadioButtonViewModel(IServiceProvider serviceProvider):base(serviceProvider)
        {
            _serviceProvider = serviceProvider;
        }

        public void Initialize(ITaskSingleSelectRadioButtonService service)
        {
            if (service == null)
                service = _serviceProvider.GetService<ITaskSingleSelectRadioButtonService>();

            Questions = service.GetQuestions();
            foreach (var question in Questions)
            {
                Title = question.QuestionText;
                Options = question.Options;
                if (Options != null && Options.Any())
                {
                    DisplayMember = string.Join(", ", Options);
                }
            }
            OptionList = new ObservableCollection<Option>(Options);
            OnPropertyChanged(nameof(OptionList));
        }

        private ObservableCollection<Option> _optionList;
        public ObservableCollection<Option> OptionList
        {
            get => _optionList;
            set
            {
                if (_optionList != value)
                {
                    _optionList = value;
                    OnPropertyChanged(nameof(OptionList));
                }
            }
        }

        private List<TaskSingleSelectRadioButtonModel> _questions;
        public List<TaskSingleSelectRadioButtonModel> Questions
        {
            get { return _questions; }
            set
            {
                _questions = value;
                OnPropertyChanged(nameof(Questions));
            }
        }

        private List<Option> _options;
        public List<Option> Options
        {
            get { return _options; }
            set
            {
                _options = value;
                OnPropertyChanged(nameof(Options));
            }
        }

        private string _title;
        public string Title
        {
            get { return _title; }
            set
            {
                _title = value;
                OnPropertyChanged(nameof(Title));
            }
        }

        private string _selectedValue;
        public string SelectedValue
        {
            get { return _selectedValue; }
            set
            {
                _selectedValue = value;
                OnPropertyChanged(nameof(SelectedValue));
            }
        }

        private bool _isControlVisible;
        public bool IsControlVisible
        {
            get { return _isControlVisible; }
            set
            {
                _isControlVisible = value;
                OnPropertyChanged(nameof(IsControlVisible));
            }
        }

        private string _displayMember;
        public string DisplayMember
        {
            get { return _displayMember; }
            set
            {
                _displayMember = value;
                OnPropertyChanged(nameof(DisplayMember));
            }
        }
    }
}
