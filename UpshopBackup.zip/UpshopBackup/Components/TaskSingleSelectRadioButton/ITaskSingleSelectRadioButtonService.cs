﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Components.TaskSingleSelectRadioButton
{
    public interface ITaskSingleSelectRadioButtonService
    {
        List<TaskSingleSelectRadioButtonModel> GetQuestions();
    }
}
