﻿using System;
using System.Globalization;
using System.Text.RegularExpressions;
using Microsoft.Maui.Controls.Compatibility;
using Microsoft.Maui.Controls;
using Microsoft.Maui;

namespace MobileUI2.Components.Behaviors
{
    public class NumericEntryBehavior : Behavior<Entry>
    {
        public static readonly BindableProperty MinValueProperty = BindableProperty.Create("MinValue", typeof(double?), typeof(NumericEntryBehavior));
        public static readonly BindableProperty MaxValueProperty = BindableProperty.Create("MaxValue", typeof(double?), typeof(NumericEntryBehavior));
        public static readonly BindableProperty RestrictDecimalProperty = BindableProperty.Create(nameof(RestrictDecimal), typeof(bool), typeof(NumericEntryBehavior), defaultValue: false);
        public static readonly BindableProperty AllowNullOrEmptyProperty = BindableProperty.Create(nameof(AllowNullOrEmpty), typeof(bool), typeof(NumericEntryBehavior), defaultValue: false);
        //This property is added because Binding Context is not correctly set this leads to unable to bind 'Restrict Decimal' property when used from CollectionView Entry behaviors.
        public static readonly BindableProperty IsDirtyRestrictDecimalProperty = BindableProperty.Create(nameof(IsDirtyRestrictDecimal), typeof(bool), typeof(NumericEntryBehavior), defaultValue: false);
        public static readonly BindableProperty AllowingDecimalPointsProperty = BindableProperty.Create("AllowingDecimalPoints", typeof(int), typeof(NumericEntryBehavior), defaultValue: 3);

        private bool _isProgrammaticChange;

        public double? MinValue
        {
            get => (double?)GetValue(MinValueProperty);
            set => SetValue(MinValueProperty, value);
        }
        public double? MaxValue
        {
            get => (double?)GetValue(MaxValueProperty);
            set => SetValue(MaxValueProperty, value);
        }
        public bool RestrictDecimal
        {
            get => (bool)GetValue(RestrictDecimalProperty);
            set => SetValue(RestrictDecimalProperty, value);
        }
        public bool AllowNullOrEmpty
        {
            get => (bool)GetValue(AllowNullOrEmptyProperty);
            set => SetValue(AllowNullOrEmptyProperty, value);
        }
        public bool IsDirtyRestrictDecimal
        {
            get => (bool)GetValue(IsDirtyRestrictDecimalProperty);
            set => SetValue(IsDirtyRestrictDecimalProperty, value);
        }
        public int AllowingDecimalPoints
        {
            get => (int)GetValue(AllowingDecimalPointsProperty);
            set => SetValue(AllowingDecimalPointsProperty, value);
        }
        protected override void OnAttachedTo(Entry entry)
        {
            entry.TextChanged += OnEntryTextChanged;
            base.OnAttachedTo(entry);
            if (IsDirtyRestrictDecimal)
            {
                entry.BindingContextChanged += (sender, _) => this.BindingContext = ((BindableObject)sender).BindingContext;
            }
        }
        protected override void OnDetachingFrom(Entry entry)
        {
            entry.TextChanged -= OnEntryTextChanged;
            base.OnDetachingFrom(entry);
            if (IsDirtyRestrictDecimal)
            {
                entry.BindingContextChanged -= (sender, _) => this.BindingContext = ((BindableObject)sender).BindingContext;
            }
        }


        private void OnEntryTextChanged(object sender, TextChangedEventArgs args)
        {
            if (_isProgrammaticChange)
            {
                _isProgrammaticChange = false;
                return;
            }
            if (args.NewTextValue == null)
            {
                return;
            }

            if (IsNewTextInvalid(args))
            {
                if (string.IsNullOrEmpty(args.NewTextValue))
                {
                    SetText(sender, AllowNullOrEmpty ? string.Empty : MinValue.GetValueOrDefault().ToString());
                }
                else
                {
                    ResetToOldValue(sender, args);
                }

            }
            else
            {
                ValidateAndApplyNumericConstraints(sender, args);
            }
        }

        private bool IsNewTextInvalid(TextChangedEventArgs args)
        {
            if (AllowNullOrEmpty)
                return IsDecimalRestricted(args);
            else
                return string.IsNullOrEmpty(args.NewTextValue) || IsDecimalRestricted(args);
        }
        private bool IsDecimalRestricted(TextChangedEventArgs args)
        {
            return RestrictDecimal && double.TryParse(args.NewTextValue, NumberStyles.Any, CultureInfo.CurrentCulture, out double value) &&
                   (args.NewTextValue.EndsWith(".") || args.NewTextValue.EndsWith(",") || value > MaxValue || value < MinValue);
        }
        private void ValidateAndApplyNumericConstraints(object sender, TextChangedEventArgs args)
        {
            if (!MinValue.HasValue || !MaxValue.HasValue)
            {
                throw new InvalidOperationException("MinValue and MaxValue must be set");
            }

            bool isValid = IsValidText(args.NewTextValue);
            if (isValid)
            {
                ApplyConstraints(sender, args);
            }
            else
            {
                ResetToOldValue(sender, args);
            }
        }
        private bool IsValidText(string text)
        {
            var regexUs = new Regex(DecimalPatternUs());
            var regexDe = new Regex(DecimalPatternDe());
            return regexUs.IsMatch(text) || regexDe.IsMatch(text);
        }
        private void ApplyConstraints(object sender, TextChangedEventArgs args)
        {
            string normalizedText = NormalizeText(args.NewTextValue);
            if (double.TryParse(normalizedText, NumberStyles.Any, CultureInfo.InvariantCulture, out var newValue))
            {
                if (IsWithinBounds(newValue))
                {
                    SetText(sender, args.NewTextValue);
                }
                else
                {
                    ResetToOldValue(sender, args);
                }
            }
        }
        private string NormalizeText(string text)
        {
            bool isDeFormat = text.Contains(",") && text.IndexOf(",") > text.IndexOf(".");
            return isDeFormat ? text.Replace(".", "").Replace(",", ".") : text.Replace(",", "");
        }
        private bool IsWithinBounds(double value)
        {
            return value >= MinValue.Value && value <= MaxValue.Value;
        }
        private void SetText(object sender, string text)
        {
            ((Entry)sender).Text = RemoveLeadingZeros(text);
        }
        private void ResetToOldValue(object sender, TextChangedEventArgs args)
        {
            if (string.IsNullOrEmpty(args.OldTextValue))
                SetText(sender, AllowNullOrEmpty ? string.Empty : MinValue.GetValueOrDefault().ToString());
            else
                SetText(sender, args.OldTextValue);
        }

        public string RemoveLeadingZeros(string input)
        {
            if (double.TryParse(input, NumberStyles.Float, CultureInfo.InvariantCulture, out double number))
            {
                return input.StartsWith("0") && !input.Contains(".") && !input.Contains(",") ? number.ToString(CultureInfo.InvariantCulture) : input;
            }
            return input;
        }
        public string DecimalPatternUs()
        {
            return $@"^[-−]?(\d{{1,3}}(\,\d{{{AllowingDecimalPoints}}})*(\.\d{{0,{AllowingDecimalPoints}}})?)?$";
        }
        public string DecimalPatternDe()
        {
            return $@"^[-−]?(\d{{1,3}}(\.\d{{{AllowingDecimalPoints}}})*(\,\d{{0,{AllowingDecimalPoints}}})?)?$";
        }
    }
}
