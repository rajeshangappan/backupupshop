﻿using MobileUI2.Components.TaskBool;
using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Components.TaskNumericResponseView
{
    public class TaskNumericResponseService : ITaskNumericResponseService
    {
        public TaskNumericResponseModel GetNumericQuestion()
        {
            var question = new TaskNumericResponseModel
            {
                QuestionTxt = "How many sanitization bottles do you see?",
                MinValue = 0,
                MaxValue = 100,
            };

            return question;
        }
    }
}
