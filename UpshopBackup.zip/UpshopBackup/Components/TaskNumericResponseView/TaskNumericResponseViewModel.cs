﻿using System;
using System.ComponentModel;
using Microsoft.Maui.Controls.Compatibility;
using Microsoft.Maui.Controls;
using Microsoft.Maui;

namespace MobileUI2.Components.TaskNumericResponseView
{
    public class TaskNumericResponseViewModel : INotifyPropertyChanged
    {
        private TaskNumericResponseModel _taskNumericModel;
        private IServiceProvider _serviceProvider;

        public TaskNumericResponseViewModel(IServiceProvider serviceProvider ,TaskNumericResponseService numericservice = null)
        {
            Initialize(numericservice);
            IncrementCommand = new Command(OnBtnIncrementClicked);
            DecrementCommand = new Command(OnBtnDecrementClicked);
            _serviceProvider = serviceProvider;
        }

        public void Initialize(ITaskNumericResponseService numericservice)
        {
            try
            {
                if (numericservice == null)
                    numericservice = _serviceProvider.GetService<ITaskNumericResponseService>();

                _taskNumericModel = numericservice?.GetNumericQuestion() ?? throw new ArgumentNullException(nameof(numericservice));

                _infoText = $"Enter a number from {MinValue} to {MaxValue}";
            }
            catch(Exception ex)
            {

            }
        }

        public string Title
        {
            get { return _taskNumericModel?.QuestionTxt; }
            set
            {
                if (_taskNumericModel != null)
                {
                    _taskNumericModel.QuestionTxt = value;
                    OnPropertyChanged(nameof(Title));
                }
            }
        }

        public int InputValue
        {
            get { return _taskNumericModel.NumericInput; }
            set
            {
                if (_taskNumericModel != null)
                {
                    _taskNumericModel.NumericInput = Math.Max(0, Math.Min(value, MaxValue));
                    OnPropertyChanged(nameof(InputValue));
                }
            }
        }

        public int MaxValue
        {
            get { return _taskNumericModel.MaxValue; }
            set
            {
                OnPropertyChanged(nameof(MaxValue));
            }
        }


        public int MinValue
        {
            get { return _taskNumericModel.MinValue; }
            set
            {
                OnPropertyChanged(nameof(MinValue));
            }
        }

        private string _infoText;
        public string InfoText
        {
            get => _infoText;
            set
            {
                if (_infoText != value)
                {
                    _infoText = value;
                    OnPropertyChanged(nameof(InfoText));
                }
            }
        }

        public Command IncrementCommand { get; private set; }
        public Command DecrementCommand { get; private set; }

        private void OnBtnIncrementClicked(object obj)
        {
            IncrementValue();
        }

        private void OnBtnDecrementClicked(object obj)
        {
            DecrementValue();
        }

        private void IncrementValue()
        {
            try
            {
                if (InputValue == 0)
                {
                    InputValue = 1;
                }
                else
                {
                    InputValue++;
                }

                OnPropertyChanged(nameof(InputValue));
            }
            catch(Exception ex)
            {

            }
        }

        private void DecrementValue()
        {
            try
            {
                if (InputValue > 0)
                {
                    InputValue--;
                    OnPropertyChanged(nameof(InputValue));
                }
            }
            catch(Exception ex)
            {

            }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}

