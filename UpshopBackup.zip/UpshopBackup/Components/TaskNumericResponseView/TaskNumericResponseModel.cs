﻿using MobileUI2.Components.Controls;
using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Components.TaskNumericResponseView
{
    public class TaskNumericResponseModel
    {
        public string QuestionTxt { get; set; }
        private int _numericInput;
        public int NumericInput
        {
            get { return _numericInput; }
            set
            {
                _numericInput = Math.Max(_minValue, Math.Min(value, _maxValue));
            }
        }
        private int _minValue;
        public int MinValue
        {
            get { return _minValue; }
            set
            {
                _minValue = value;
                NumericInput = Math.Max(_minValue, _numericInput);
            }
        }

        private int _maxValue;
        public int MaxValue
        {
            get { return _maxValue; }
            set
            {
                _maxValue = value;
                NumericInput = Math.Min(_maxValue, _numericInput);
            }
        }
    }
}
