﻿using MobileUI2.Components.TaskBool;
using MobileUI2.Components.TaskMultipleSelectCheckboxView;
using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Components.TaskNumericResponseView
{
    public interface ITaskNumericResponseService
    {
        TaskNumericResponseModel GetNumericQuestion();
    }
}
