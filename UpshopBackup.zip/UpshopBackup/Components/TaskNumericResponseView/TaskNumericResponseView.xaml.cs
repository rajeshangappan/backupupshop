﻿using MobileUI2.Components.TaskBool;
using MobileUI2.Models.Tasks;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Maui.Controls.Xaml;
using Microsoft.Maui.Controls.Compatibility;
using Microsoft.Maui.Controls;
using Microsoft.Maui;

namespace MobileUI2.Components.TaskNumericResponseView
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class TaskNumericResponseView : ContentView
    {
        public TaskNumericResponseView()
        {
            InitializeComponent();
        }

        private bool _isCompletedTask;
        private int _inputValue { get; set; }
        public static readonly BindableProperty FormattedQuestionTextProperty =
          BindableProperty.Create(nameof(FormattedQuestionText), typeof(FormattedString), typeof(TaskNumericResponseView), defaultValue: default(FormattedString), defaultBindingMode: BindingMode.TwoWay);

        public FormattedString FormattedQuestionText
        {
            get => (FormattedString)GetValue(FormattedQuestionTextProperty);
            set => SetValue(FormattedQuestionTextProperty, value);
        }

        public static readonly BindableProperty InputValueProperty =
            BindableProperty.Create(nameof(InputValue), typeof(string), typeof(TaskNumericResponseView), string.Empty);

        public string InputValue
        {
            get => (string)GetValue(InputValueProperty);
            set => SetValue(InputValueProperty, value);
        }

        public static readonly BindableProperty QuestionTextProperty =
            BindableProperty.Create(nameof(QuestionText), typeof(string), typeof(TaskNumericResponseView), string.Empty);

        public string QuestionText
        {
            get => (string)GetValue(QuestionTextProperty);
            set => SetValue(QuestionTextProperty, value);
        }

        public static readonly BindableProperty IsAnswerRequiredProperty =
            BindableProperty.Create(nameof(IsAnswerRequired), typeof(bool), typeof(TaskNumericResponseView), false);

        public bool IsAnswerRequired
        {
            get => (bool)GetValue(IsAnswerRequiredProperty);
            set => SetValue(IsAnswerRequiredProperty, value);
        }

        public static readonly BindableProperty BtnIncrementTextProperty =
            BindableProperty.Create(nameof(BtnIncrementText), typeof(string), typeof(TaskNumericResponseView), string.Empty,
                propertyChanged: OnBtnIncrementTextPropertyChanged);

        public string BtnIncrementText
        {
            get => (string)GetValue(BtnIncrementTextProperty);
            set => SetValue(BtnIncrementTextProperty, value);
        }

        public static readonly BindableProperty InfoTextProperty =
            BindableProperty.Create(nameof(InfoText), typeof(string), typeof(TaskNumericResponseView), string.Empty);

        public string InfoText
        {
            get => (string)GetValue(InfoTextProperty);
            set => SetValue(InfoTextProperty, value);
        }

        public static readonly BindableProperty BtnDecrementTextProperty =
            BindableProperty.Create(nameof(BtnDecrementText), typeof(string), typeof(TaskNumericResponseView), string.Empty,
                propertyChanged: OnBtnDecrementTextPropertyChanged);
        public Command Command
        {
            get { return (Command)GetValue(CommandProperty); }
            set { SetValue(CommandProperty, value); }
        }

        public static BindableProperty CommandProperty = BindableProperty.Create(
                nameof(Command),
                typeof(Command),
                typeof(TaskNumericResponseView),
                defaultBindingMode: BindingMode.TwoWay);

        public static BindableProperty CommandParameterProperty = BindableProperty.Create(
                nameof(CommandParameter),
                typeof(object),
                typeof(TaskNumericResponseView),
                defaultBindingMode: BindingMode.TwoWay);
        public static readonly BindableProperty AnswersProperty = BindableProperty.Create(nameof(QuestionText), typeof(List<string>), typeof(TaskNumericResponseView), defaultValue: default(List<string>), defaultBindingMode: BindingMode.TwoWay, propertyChanged: SelectValues);
        public List<string> Answers
        {
            get => (List<string>)GetValue(AnswersProperty);
            set => SetValue(AnswersProperty, value);
        }
        public object CommandParameter
        {
            get => GetValue(CommandParameterProperty);
            set => SetValue(CommandParameterProperty, value);
        }
        public string BtnDecrementText
        {
            get => (string)GetValue(BtnDecrementTextProperty);
            set => SetValue(BtnDecrementTextProperty, value);
        }
        private static void SelectValues(BindableObject bindable, object oldvalue, object newvalue)
        {
            if (newvalue == null)
                return;
            var customView = (TaskNumericResponseView)bindable;
            customView.EntryInput.IsReadOnly = true;
            customView._isCompletedTask = true;
            var value = (List<string>)newvalue;
            if (!value.Any())
                return;
            customView.InputValue = value[0];
        }

        private static void OnBtnIncrementTextPropertyChanged(BindableObject bindable, object oldValue, object newValue)
        {
            var customView = (TaskNumericResponseView)bindable;
            customView.lblincrement.Text = (string)newValue;
        }

        private static void OnBtnDecrementTextPropertyChanged(BindableObject bindable, object oldValue, object newValue)
        {
            var customView = (TaskNumericResponseView)bindable;
            customView.lbldecrement.Text = (string)newValue;
        }

        private void UpdateData(string answer)
        {
            if (CommandParameter is StoreWalkQuestionDetails)
            {
                var data = (StoreWalkQuestionDetails)CommandParameter;
                if (string.IsNullOrEmpty(answer))
                    data.Answer = new List<string>();
                else data.Answer = new List<string>() { answer };
                Command.Execute(CommandParameter);
            }
        }

        private void DecrementGestureRecognizer_OnTapped(object sender, EventArgs e)
        {
            if (!_isCompletedTask && _inputValue > 0)
            {
                _inputValue--;
                EntryInput.Text = _inputValue.ToString();
                UpdateData(EntryInput.Text);
            }
        }

        private void IncrementGestureRecognizer_OnTapped(object sender, EventArgs e)
        {
            if (!_isCompletedTask && _inputValue < 100)
            {
                _inputValue++;
                EntryInput.Text = _inputValue.ToString();
                UpdateData(EntryInput.Text);
            }
        }

        private void EntryInput_OnTextChanged(object sender, TextChangedEventArgs e)
        {
            try
            {
                if(_isCompletedTask)
                    return;

                if (string.IsNullOrWhiteSpace(e.NewTextValue))
                {
                    _inputValue = 0;
                    UpdateData("");
                    return;
                }

                if (int.TryParse(e.NewTextValue, out int value))
                {
                    if (value > 100)
                        EntryInput.Text = e.OldTextValue;
                    else
                    {
                        var userInput = (Math.Max(0, Math.Min(value, 100)));
                        EntryInput.Text = userInput.ToString();
                        _inputValue = userInput;
                        UpdateData(EntryInput.Text);
                    }
                }
            }
            catch (Exception exception)
            {
              
            }
        }
    }
}