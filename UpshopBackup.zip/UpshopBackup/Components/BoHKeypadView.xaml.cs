﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Globalization;
using System.Linq;
using System.Windows.Input;
using MobileUI2.Models;
using Microsoft.Maui.Controls.Xaml;
using Microsoft.Maui.Controls.Compatibility;
using Microsoft.Maui.Controls;
using Microsoft.Maui;

namespace MobileUI2.Components
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class BoHKeypadView : ContentView
    {
        private enum KeyPressType
        {
            WholeNumber,
            Fraction
        }
        public static readonly BindableProperty MinimumValueProperty = BindableProperty.Create(nameof(MinimumValue), typeof(double), typeof(BoHKeypadView), default(double));
        public static readonly BindableProperty MaximumValueProperty = BindableProperty.Create(nameof(MaximumValue), typeof(double), typeof(BoHKeypadView), 999.999);
        public static readonly BindableProperty TitleProperty = BindableProperty.Create(nameof(Title), typeof(string), typeof(Label), default(string), BindingMode.OneWay);
        public static readonly BindableProperty QuantityProperty = BindableProperty.Create(nameof(Quantity), typeof(string), typeof(object), default(string), BindingMode.TwoWay, propertyChanged: OnQuantityChanged);
        public static readonly BindableProperty DefaultCountTypeProperty = BindableProperty.Create(nameof(DefaultCountType), typeof(string), typeof(BoHKeypadView), propertyChanged: OnDefaultCountTypeChanged);
        public static readonly BindableProperty CountTypesProperty = BindableProperty.Create(nameof(CountTypes), typeof(ObservableCollection<CountTypeModel>), typeof(BoHKeypadView), propertyChanged: OnCountTypesChanged);
        public static readonly BindableProperty SubmitCommandProperty = BindableProperty.Create(nameof(SubmitCommand), typeof(ICommand), typeof(Button), defaultBindingMode: BindingMode.TwoWay);
        public static readonly BindableProperty CloseCommandProperty = BindableProperty.Create(nameof(CloseCommand), typeof(ICommand), typeof(Button), defaultBindingMode: BindingMode.TwoWay);
        public static readonly BindableProperty SelectedCountTypeProperty = BindableProperty.Create(nameof(SelectedCountType), typeof(CountTypeModel), typeof(BoHKeypadView), defaultBindingMode: BindingMode.TwoWay);

        public double MaximumValue
        {
            get => (double)GetValue(MaximumValueProperty);
            set => SetValue(MaximumValueProperty, value);
        }

        public double MinimumValue
        {
            get => (double)GetValue(MinimumValueProperty);
            set => SetValue(MinimumValueProperty, value);
        }

        public string Title
        {
            get => (string)GetValue(TitleProperty);
            set => SetValue(TitleProperty, value);
        }
        public string Quantity
        {
            get => (string)GetValue(QuantityProperty);
            set
            {
                SetValue(QuantityProperty, value);
            }
        }
        public string DefaultCountType
        {
            get => (string)GetValue(DefaultCountTypeProperty);
            set => SetValue(DefaultCountTypeProperty, value);
        }
        public ObservableCollection<CountTypeModel> CountTypes
        {
            get => (ObservableCollection<CountTypeModel>)GetValue(CountTypesProperty);
            set => SetValue(CountTypesProperty, value);
        }

        public CountTypeModel SelectedCountType
        {
            get => (CountTypeModel)GetValue(SelectedCountTypeProperty);
            set => SetValue(SelectedCountTypeProperty, value);
        }

        private double _customEntryValue;
        private string _originalValue;
        private bool isFirstWholeNumberHit = true;
        public bool LastFractionEntry;
        private readonly Stack<ValueHistoryItem> valueHistory = new Stack<ValueHistoryItem>();

        public double CustomEntryValue
        {
            get => _customEntryValue;
            set
            {
                _customEntryValue = value;
                OnPropertyChanged(nameof(CustomEntryValue));
                CustomEntryValueDisplay = CustomEntryValue % 1 == 0 ? CustomEntryValue.ToString("F0") : CustomEntryValue.ToString("F2");
            }
        }
        private string _customEntryValueDisplay;
        public string CustomEntryValueDisplay
        {
            get => _customEntryValueDisplay;
            set {
                _customEntryValueDisplay = value;
                OnPropertyChanged(nameof(CustomEntryValueDisplay));
                }
        }

        private class ValueHistoryItem
        {
            public double Value { get; }
            public KeyPressType KeyPressType { get; }

            public ValueHistoryItem(double value, KeyPressType keyPressType)
            {
                Value = value;
                KeyPressType = keyPressType;
            }
        }

        public ICommand SubmitCommand
        {
            get { return (ICommand)GetValue(SubmitCommandProperty); }
            set { SetValue(SubmitCommandProperty, value); }
        }
        public ICommand CloseCommand
        {
            get { return (ICommand)GetValue(CloseCommandProperty); }
            set { SetValue(CloseCommandProperty, value); }
        }
        public ICommand SubmitInternalCommand { get; }
        public ICommand UndoCommand { get; }
        public ICommand CloseInternalCommand { get; }
        public ICommand MinusCommand { get; }
        public ICommand PlusOneCommand { get; }
        public ICommand PlusTwoCommand { get; }
        public ICommand PlusFiveCommand { get; }
        public ICommand PlusTenCommand { get; }
        public ICommand QuarterCommand { get; }
        public ICommand HalfCommand { get; }
        public ICommand ThreeQuartersCommand { get; }
        public ICommand NumberPressCommand { get; }
        public ICommand DeleteCommand { get; }

        public BoHKeypadView()
        {
            InitializeComponent();
            isFirstWholeNumberHit = true;
            valueHistory.Push(new ValueHistoryItem(CustomEntryValue, KeyPressType.WholeNumber));
            valueHistory.Clear();
            SubmitInternalCommand = new Command(SubmitKeypadExecute);
            UndoCommand = new Command(UndoCommandExecute);
            CloseInternalCommand = new Command(CloseKeypadCommandExecute);
            MinusCommand = new Command(() => 
            {
                if (CustomEntryValue - 1 < MinimumValue)
                    return;
                CustomEntryValue -= 1;
                valueHistory.Push(new ValueHistoryItem(CustomEntryValue, KeyPressType.WholeNumber));
            });
            PlusOneCommand = new Command(() => 
            {
                if (CustomEntryValue + 1 > MaximumValue)
                    return;
                CustomEntryValue += 1;
                valueHistory.Push(new ValueHistoryItem(CustomEntryValue, KeyPressType.WholeNumber));
            });
            PlusTwoCommand = new Command(() => {
                if (CustomEntryValue + 2 > MaximumValue)
                    return;
                CustomEntryValue += 2;
                valueHistory.Push(new ValueHistoryItem(CustomEntryValue, KeyPressType.WholeNumber));
            });
            PlusFiveCommand = new Command(() => {
                if (CustomEntryValue + 5 > MaximumValue)
                    return;
                CustomEntryValue += 5; 
                valueHistory.Push(new ValueHistoryItem(CustomEntryValue, KeyPressType.WholeNumber));
            });
            PlusTenCommand = new Command(() => {
                if (CustomEntryValue + 10 > MaximumValue)
                    return;
                CustomEntryValue += 10;
                valueHistory.Push(new ValueHistoryItem(CustomEntryValue, KeyPressType.WholeNumber));
            });
            QuarterCommand = new Command(ExecuteQuarterCommand);
            HalfCommand = new Command(ExecuteHalfCommand);
            ThreeQuartersCommand = new Command(ExecuteThreeQuartersCommand);
            NumberPressCommand = new Command<string>(NumberPressExecute);
            DeleteCommand = new Command(DeleteCommandExecute);
            BindingContext = this;
        }
        public event EventHandler<string> OnBoHKeypadSubmit;

        private static void OnCountTypesChanged(BindableObject bindable, object oldValue, object newValue)
        {
            var control = (BoHKeypadView)bindable;
            if (newValue is ObservableCollection<CountTypeModel> countTypes)
            {
                control.pillBox.CountTypes = countTypes;
                if (countTypes.Count >= 2)
                {
                control.pillBox.Pill1Text = countTypes[0]?.DisplayName;
                control.pillBox.Pill2Text = countTypes[1]?.DisplayName;
                }
                else if(countTypes.Count < 2)
                {
                    control.pillBox.Pill1Text= countTypes[0]?.DisplayName;
                }
            }
            else
            {
                control.pillBox.Pill1Text = string.Empty;
                control.pillBox.Pill2Text = string.Empty;
            }
        }

        private static void OnQuantityChanged(BindableObject bindable, object oldvalue, object newvalue)
        {
            var control = (BoHKeypadView)bindable;

            if (double.TryParse((string)newvalue, out var quantity))
            {
                control.CustomEntryValue = quantity;
                control.valueHistory.Push(new ValueHistoryItem(quantity, KeyPressType.WholeNumber));
            }
            control._originalValue = (string)newvalue;
        }
        private static void OnDefaultCountTypeChanged(BindableObject bindable, object oldvalue, object newvalue)
        {
            var control = (BoHKeypadView)bindable;
            control.pillBox.DefaultCountType = (string)newvalue;
            control.pillBox.SelectedCountType = control.CountTypes.Where(type => string.Equals(type.DisplayName,control.pillBox.DefaultCountType)).FirstOrDefault();
            control.pillBox.HydrateSetDefaultPillValues();
        }
        private void SubmitKeypadExecute()
        {
            isFirstWholeNumberHit = true;
            Quantity = CustomEntryValue.ToString();
            SelectedCountType = pillBox.SelectedCountType;
            SubmitCommand.Execute(null);
            valueHistory.Clear();
        }
        private async void CloseKeypadCommandExecute()
        {
            await this.TranslateTo(Width, 0, 250, Easing.SinInOut);
            IsVisible = false;
            isFirstWholeNumberHit = true;
            CloseCommand.Execute(null);
            valueHistory.Clear();
        }
        private void ExecuteQuarterCommand()
        {
            if (CustomEntryValue + .25 > MaximumValue)
                return;
            CustomEntryValue = Math.Floor(CustomEntryValue) + 0.25;
            valueHistory.Push(new ValueHistoryItem(CustomEntryValue, KeyPressType.Fraction));
            LastFractionEntry = true;
        }
        private void ExecuteHalfCommand()
        {
            if (CustomEntryValue + .5 > MaximumValue)
                return;
            CustomEntryValue = Math.Floor(CustomEntryValue) + 0.50;
            valueHistory.Push(new ValueHistoryItem(CustomEntryValue, KeyPressType.Fraction));
            LastFractionEntry = true;
        }
        private void ExecuteThreeQuartersCommand()
        {
            if (CustomEntryValue + .75 > MaximumValue)
                return;
            CustomEntryValue = Math.Floor(CustomEntryValue) + 0.75;
            valueHistory.Push(new ValueHistoryItem(CustomEntryValue, KeyPressType.Fraction));
            LastFractionEntry = true;
        }
        private void NumberPressExecute(string number)
        {
            double wholeNumberPart = Math.Floor(CustomEntryValue);
            double fractionalPart = CustomEntryValue - wholeNumberPart;
            if(valueHistory.Count <= 1)
            {
                if (isFirstWholeNumberHit)
                {
                    if (!string.IsNullOrEmpty(number))
                    {
                        if (double.Parse(number) + fractionalPart > MaximumValue)
                            return;
                        CustomEntryValue = double.Parse(number) + fractionalPart;
                    }
                    else
                        CustomEntryValue = 0;
                    isFirstWholeNumberHit = false;
                }
                else
                {
                    if (!string.IsNullOrEmpty(number))
                    {
                        string newValue = wholeNumberPart.ToString() + number;
                        if (double.Parse(newValue) + fractionalPart > MaximumValue)
                            return;
                        CustomEntryValue = double.Parse(newValue) + fractionalPart;
                    }
                    else CustomEntryValue = 0;
                }
            }
            else
            {
                if (isFirstWholeNumberHit)
                {
                    if (!string.IsNullOrEmpty(number))
                    {
                        if (CustomEntryValue + double.Parse(number) + fractionalPart > MaximumValue)
                            return;
                        CustomEntryValue += double.Parse(number) + fractionalPart;
                    }
                    else 
                        CustomEntryValue = 0;
                    isFirstWholeNumberHit = false;
                }
                else
                {
                    if (!string.IsNullOrEmpty(number))
                    {
                        string newValue = wholeNumberPart.ToString() + number;
                        if (double.Parse(newValue) + fractionalPart > MaximumValue)
                            return;
                        CustomEntryValue = double.Parse(newValue) + fractionalPart;
                    }
                    else
                        CustomEntryValue = 0;
                }
            }
            valueHistory.Push(new ValueHistoryItem(CustomEntryValue, KeyPressType.WholeNumber));
        }
        private void UndoCommandExecute()
        {
            double fractionalPart = CustomEntryValue - Math.Floor(CustomEntryValue);
            if (valueHistory != null && valueHistory.Count > 0)
            {
                if (valueHistory != null && valueHistory.Count > 1)
                {
                    ValueHistoryItem lastItem = valueHistory.Pop();
                    ValueHistoryItem previousItem = valueHistory.Peek();
                    var previousWholeNumber = Math.Floor(previousItem.Value);
                    if (lastItem.KeyPressType == KeyPressType.Fraction)
                    {
                        CustomEntryValue = previousItem.Value;
                    }
                    else
                    {
                        CustomEntryValue = previousWholeNumber + fractionalPart;
                    }

                    isFirstWholeNumberHit = false;
                }
                else if (valueHistory != null && valueHistory.Count <= 1)
                {

                    if (valueHistory.Peek().KeyPressType != KeyPressType.Fraction)
                    {
                        valueHistory.Pop();
                        CustomEntryValue = double.Parse(_originalValue);
                        isFirstWholeNumberHit = true;
                    }
                    else
                    {
                        valueHistory.Pop();
                        CustomEntryValue = double.Parse(_originalValue) + fractionalPart;
                        isFirstWholeNumberHit = true;
                    }
                }
                else
                {
                    CustomEntryValue = double.Parse(_originalValue);
                    isFirstWholeNumberHit = true;
                    valueHistory.Clear();
                }
            }
        }

        private void DeleteCommandExecute()
        {
            double fractionalPart = CustomEntryValue - Math.Floor(CustomEntryValue);
            double wholeNumberPart = Math.Floor(CustomEntryValue);

            if (fractionalPart > 0)
            {
                CustomEntryValue = wholeNumberPart;
            }
            else if (wholeNumberPart > 0)
            {
                string wholeNumberString = wholeNumberPart.ToString("F0");
                wholeNumberString = wholeNumberString.Substring(0, wholeNumberString.Length - 1);

                CustomEntryValue = string.IsNullOrEmpty(wholeNumberString) ? 0 : double.Parse(wholeNumberString);
            }
            else
            {
                CustomEntryValue = 0;
            }
        }
    }
}