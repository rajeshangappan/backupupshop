﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;
using System.Threading.Tasks;

namespace MobileUI2.Components
{
    public static class ItemDetailsByAICodes
    {
        public static async Task<VendorItemScanInfoList> Get(Dictionary<string, string> data)
        {
            //this is a meatbox barcode
            //if (ean128.StartsWith("10")  )
            if (data.ContainsKey("10"))
            {
                //string receivingItemId = ean128.Substring(2, 6);
                //if (receivingItemId.Contains("."))
                //    return null;
                //DateTime productionDate;
                //if (int.TryParse(ean128.Substring(8, 2), out int year) &&
                //    int.TryParse(ean128.Substring(10, 2), out int month) &&
                //    int.TryParse(ean128.Substring(12, 2), out int day))
                //{
                //    try
                //    {
                //        productionDate = new DateTime(2000 + year, month, day);
                //    }
                //    catch
                //    {
                //        return null;
                //    }
                //}
                //else
                //{
                //    return null;
                //}
            }

            //VendorItemScanInfo result = new VendorItemScanInfo
            //{
            //    ScannedBarcode = ean128,
            //    ProductionNetWeightKG = false
            //};
            VendorItemScanInfoList result = new VendorItemScanInfoList
            {
                ScannedBarcode = "",
                ProductionNetWeightKG = false
            };

            if (data.ContainsKey("01"))
            {
                result.SSCC = data["01"];
                if (result.SSCC.Contains("."))
                    return null;

                Vendor vendor = null;

                if (int.TryParse(data["01"].Substring(0, 8), out int vendorNumber))
                {
                    vendor = OfflineGetVendor(vendorNumber.ToString());
                    if (vendor != null)
                    {
                        result.VendorNum = vendor.VendorNumber;
                        result.VendorId = vendor.VendorId;
                        result.VendorName = vendor.Name;
                    }
                    result.VendorNum = data["01"].Substring(8, 4);
                    if (double.TryParse(data["01"].Substring(9, 4), out double productionLineNum))
                    {
                        result.ProductionLineNum = productionLineNum;
                    }
                    else
                    {
                        result.ProductionLineNum = null;
                    }
                }

                //Try finding a vendor using 7 digits.
                if (vendor == null)
                {
                    if (int.TryParse(data["01"].Substring(0, 7), out int VendorNumber))
                    {
                        vendor = OfflineGetVendor(VendorNumber.ToString());
                        if (vendor != null)
                        {
                            result.VendorNum = vendor.VendorNumber;
                            result.VendorId = vendor.VendorId;
                            result.VendorName = vendor.Name;
                        }
                        result.VendorItemNum = data["01"].Substring(8, 4);
                        if (double.TryParse(data["01"].Substring(8, 4), out double productionLineNum))
                        {
                            result.ProductionLineNum = productionLineNum;
                        }
                        else
                        {
                            result.ProductionLineNum = null;
                        }
                    }
                }

                //if not found, try finding a vendor using 6 digits.
                if (vendor == null)
                {
                    if (int.TryParse(data["01"].Substring(0, 7), out int VendorNumber))
                    {
                        vendor = OfflineGetVendor(VendorNumber.ToString());
                        if (vendor != null)
                        {
                            result.VendorNum = vendor.VendorNumber;
                            result.VendorId = vendor.VendorId;
                            result.VendorName = vendor.Name;
                        }
                        result.VendorItemNum = data["01"].Substring(7, 6);
                        if (double.TryParse(data["01"].Substring(7, 6), out double productionLineNum))
                        {
                            result.ProductionLineNum = productionLineNum;
                        }
                        else
                        {
                            result.ProductionLineNum = null;
                        }
                    }
                }

                //Fall back to using 7 digits for vendor without checking database.
                if (vendor == null)
                {
                    if (int.TryParse(data["10"].Substring(0, 7), out int vendorNum))
                    {
                        result.VendorNum = vendorNum.ToString();
                    }
                    else
                    {
                        result.VendorNum = null;
                    }
                    result.VendorItemNum = data["10"].Substring(8, 5);

                    if (double.TryParse(data["10"].Substring(8, 5), out double productionLineNum))
                    {
                        result.ProductionLineNum = productionLineNum;
                    }
                    else
                    {
                        result.ProductionLineNum = null;
                    }
                }

                //if (vendor != null && vendor.MaxBarCodeLength.HasValue && ean128.Length > vendor.MaxBarCodeLength.Value)
                //{
                //    return null;
                //}
            }

            else if (data.ContainsKey("11"))
            {

                DateTime ProductionDate = DateTime.ParseExact(data["11"], "yy/mm/dd", CultureInfo.InvariantCulture);
                result.ProductionDate = ProductionDate;
                
            }else if (data.ContainsKey("13"))
            {
                DateTime ProductionDate = DateTime.ParseExact(data["13"], "yy/mm/dd", CultureInfo.InvariantCulture);
                result.ProductionDate = ProductionDate;               
            }
            else if (data.ContainsKey("17"))
            {
                DateTime ExpirationDate = DateTime.ParseExact(data["17"], "yy/mm/dd", CultureInfo.InvariantCulture);
                 result.ExpirationDate = ExpirationDate;

            }
            else if (data.ContainsKey("310d"))
            {

                var divisor = GetDivisor('2');
                if (divisor.HasValue)
                {
                    if (decimal.TryParse(data["310d"], out decimal itemweight))
                        result.ProductNetWeight = itemweight / divisor.Value;
                }
                else
                {
                    return null;
                }
            }         
            else if (data.ContainsKey("21"))
            {
                result.SerialNumber = data["21"];
                result.LabelSerialNumber = (data["21"].Length <= 8) ? data["21"] : data["21"].Substring(0, 8);
                var vendorLocation = GetVendorLocationAutoID(data["21"], result.VendorNum);
                if (vendorLocation != null)
                {
                    result.VendorLocationID = vendorLocation.VendorLocationId;
                    result.EstablishmentID = vendorLocation.EstablishmentId;
                }
            }
            else if (data.ContainsKey("15"))
            {
                DateTime SellByDate = DateTime.ParseExact(data["15"], "yy/mm/dd", CultureInfo.InvariantCulture);
                result.SellByDate = SellByDate;               
            }
            //Lot identifier
            else if (data.ContainsKey("10"))
            {
                //we don't capture lot number currently
            }
            else if (data.ContainsKey("3922"))
            {
                int.TryParse(data["3922"], out int retailPrice);
                result.RetailPrice = (double)retailPrice / 100.0;
            }
            else
            {
                return null;
            }
            return result;
        }

        private static VendorLocation GetVendorLocationAutoID(string buffer, string vendorNum)
        {
            return new VendorLocation();
        }

        private static Vendor OfflineGetVendor(string v)
        {
            return new Vendor();
        }

        private static decimal? GetDivisor(char decimalDigits)
        {
            switch (decimalDigits)
            {
                case '0': return 1M;
                case '1': return 10M;
                case '2': return 100M;
                case '3': return 1000M;
                case '4': return 10000M;
                case '5': return 100000M;
                case '6': return 1000000M;
                case '7': return 10000000M;
                case '8': return 100000000M;
                case '9': return 1000000000M;
                default: return null;
            }
        }
    }

    public class VendorItemScanInfoList
    {
        #region Public Properties

        public string ScannedBarcode
        {
            get; set;
        }

        public int VendorId { get; set; }
        public string VendorNum { get; set; }

        public string VendorName
        {
            get; set;
        }

        public DateTime? ProductionDate { get; set; }

        public double? ProductionLineNum { get; set; }

        public decimal? ProductNetWeight { get; set; }

        public string InBarcodeEstablishmentID { get; set; }

        public string EstablishmentID
        {
            get; set;
        }

        public string VendorLocationDescription
        {
            get; set;
        }

        public string SSCC { get; set; }

        public DateTime? SellByDate { get; set; }
        public int? VendorItemID { get; set; }
        public DateTime ScanDateTime { get; set; }
        public bool? ProductionNetWeightKG { get; set; }

        public int? VendorLocationID { get; set; }

        public DateTime? ExpirationDate { get; set; }

        public string SerialNumber { get; set; }

        public string VendorItemNum { get; set; }

        public string VendorItemDesc { get; set; }

        public double? RetailPrice { get; set; }

        public string LabelSerialNumber { get; set; }

        public int? GPCAutoID { get; set; }

        public int? VendorItemRecallAutoID { get; set; }

        public string UserSignOn { get; set; }

        public int? OrgUnitNum { get; set; }

        public string OrgUnitName { get; set; }

        public DateTime ScanDateTimeInUserLocale { get; set; }

        public string BatchLotNumber { get; set; }

        #endregion

        #region Derived Public Properties

        public string ProductionDateValue
        {
            get { return ProductionDate.HasValue ? ProductionDate.Value.ToString() : String.Empty; }
        }

        public double ProductionLineNumValue
        {
            get { return ProductionLineNum ?? 0; }
        }

        public string EstablishmentLabel
        {
            get
            {
                if (!String.IsNullOrEmpty(EstablishmentID))
                    return String.Format("{0} - {1}", EstablishmentID, VendorLocationDescription);
                return String.Empty;
            }
        }

        public string VendorLabel
        {
            get
            {
                if (!string.IsNullOrEmpty(VendorNum))
                    return String.Format("{0} - {1}", VendorNum, VendorName);
                return String.Empty;
            }
        }

        public string VendorItemLabel
        {
            get
            {
                if (!string.IsNullOrEmpty(VendorItemNum) && !string.IsNullOrEmpty(VendorItemDesc))
                    return String.Format("{0} - {1}", VendorItemNum, VendorItemDesc);
                else if (!string.IsNullOrEmpty(VendorItemNum))
                    return VendorItemNum;
                else return string.Empty;
            }
        }

        public string OrgUnitLabel
        {
            get
            {
                if (OrgUnitNum.HasValue)
                    return String.Format("{0} - {1}", OrgUnitNum.Value, OrgUnitName);
                else
                    return String.Empty;
            }
        }

        #endregion
    }

    public class Vendor
    {
        public int? MaxBarCodeLength { get; set; }
        public bool Supplier { get; set; }
        public bool Packer { get; set; }
        public int VendorId { get; set; }
        public string VendorNumber { get; set; }
        public string Name { get; set; }
        public List<VendorLocation> establishmentList { get; set; }
        public List<VendorItemScanDTO> vendorItemList { get; set; }
    }

    public class VendorLocation
    {
        public string EstablishmentId { get; set; }
        public string EstablishmentLabel { get; set; }
        public string LocationDescription { get; set; }
        public int VendorLocationId { get; set; }
        public int VendorId { get; set; }
        public int? LengthOfSerialNumber { get; set; }
        public string BarCodeEstablishmentId { get; set; }
    }
    public class VendorItemScanDTO
    {
        public int VendorItemId { get; set; }
        public string VendorItemNum { get; set; }
        public string VendorItemDesc { get; set; }
        public string VendorItemLabel { get; set; }
    }
}
