﻿using System;
using Microsoft.Maui.Controls.Compatibility;
using Microsoft.Maui.Controls;
using Microsoft.Maui;
namespace MobileUI2.Components.Controls
{
	public class CustomCollectionView : CollectionView
	{
		
	}
}

