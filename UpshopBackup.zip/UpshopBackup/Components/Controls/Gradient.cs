﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Text;
using Microsoft.Maui.Controls.Compatibility;
using Microsoft.Maui.Controls;
using Microsoft.Maui;

namespace MobileUI2.Components.Controls
{
	[ContentProperty("Colors")]
	public abstract class Gradient : BindableObject
	{
		internal static readonly BindableProperty BackgroundGradientForcedHeightProperty = BindableProperty.CreateAttached("__BackgroundGradientForcedHeight", typeof(double), typeof(Gradient), -1.0);

		public ObservableCollection<GradientColor> Colors
		{
			get;
			private set;
		}

		internal static void SetBackgroundGradientForcedHeight(BindableObject view, double value)
		{
			view.SetValue(BackgroundGradientForcedHeightProperty, value);
		}

		internal static double GetBackgroundGradientForcedHeight(BindableObject view)
		{
			return (double)view.GetValue(BackgroundGradientForcedHeightProperty);
		}

		protected Gradient()
		{
			Colors = new ObservableCollection<GradientColor>();
		}
	}
}
