﻿using System;
using System.Text.RegularExpressions;
using System.Linq;
using Microsoft.Maui.Controls.Compatibility;
using Microsoft.Maui.Controls;
using Microsoft.Maui;

namespace MobileUI2.Components.Controls
{
    public class MaximumNumberEntryValidationBehavior : BehaviorBase<Entry>
    {
        public int MaximumCount { get; set; } = 999;
        protected Action<Entry, string> AdditionalCheck;
        public MaximumNumberEntryValidationBehavior()
        {
            AdditionalCheck = (e, ot) =>
            {
                e.Text = Convert.ToInt32(e.Text) > MaximumCount ? ot : e.Text.ToString();
            };
        }
        protected override void OnAttachedTo(Entry bindable)
        {
            base.OnAttachedTo(bindable);

            bindable.TextChanged += TextChanged_Handler;
        }

        protected override void OnDetachingFrom(Entry bindable)
        {
            base.OnDetachingFrom(bindable);
            bindable.TextChanged -= TextChanged_Handler;
        }
        public void TextChanged_Handler(object sender, TextChangedEventArgs e)
        {
            try
            {
                if (!string.IsNullOrWhiteSpace(e.NewTextValue))
                {
                    var filteredText = Regex.Replace(e.NewTextValue, "[^0-9.]", "");
                    var isValid = false;
                    if (filteredText.StartsWith("."))
                    {
                        filteredText = "0" + filteredText;
                    }
                    var entry = (Entry)sender;
                    double.TryParse(filteredText, out double data);
                    if (data >= 1 && data != 0)
                    {
                        while (filteredText[0] == '0')
                        {
                            filteredText = filteredText.Substring(1);
                        }
                    }
                    if (filteredText.Contains("."))
                    {
                        var index = filteredText.IndexOf('.');
                        while (filteredText.Length - index > 3)
                        {
                            filteredText = filteredText.Remove(filteredText.Length - 1);
                        }
                    }

                    if (entry.ReturnCommandParameter != null)
                    {
                        if (entry.ReturnCommandParameter.Equals("Recipe"))
                        {
                            if (data > 9999)
                            {
                                isValid = false;
                            }
                            else
                            {
                                isValid = true;
                            }
                        }
                    }
                    else
                    {
                        if (data > 999 || (filteredText.StartsWith("0") && filteredText.TakeWhile(c => c == '0').Count() > 1))
                        {
                            isValid = false;
                        }
                        else
                        {
                            isValid = true;
                        }
                    }

                    ((Entry)sender).Text = isValid ? filteredText : e.NewTextValue.Remove(e.NewTextValue.Length - 1);
                }
            }
            catch (Exception exception)
            {

            }
        }
    }
}
