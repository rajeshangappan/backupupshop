namespace MobileUI2.Components.Controls
{
    public class CustomSearch : SearchBar
    {
       
    }
}