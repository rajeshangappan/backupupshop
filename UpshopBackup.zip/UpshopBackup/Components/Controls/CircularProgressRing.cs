﻿using SkiaSharp;
using SkiaSharp.Views.Maui;
using SkiaSharp.Views.Maui.Controls;

namespace MobileUI2.Components.Controls
{
    public class CircularProgressRing : SKCanvasView
    {
        public static readonly BindableProperty ProgressProperty =
            BindableProperty.Create(nameof(Progress), typeof(float), typeof(CircularProgressRing), 0f, propertyChanged: OnPropertyChanged);

        public static readonly BindableProperty ProgressColorProperty =
            BindableProperty.Create(nameof(ProgressColor), typeof(Color), typeof(CircularProgressRing), Colors.Green, propertyChanged: OnPropertyChanged);

        public static readonly BindableProperty BackgroundCircleColorProperty =
            BindableProperty.Create(nameof(BackgroundCircleColor), typeof(Color), typeof(CircularProgressRing), Colors.Transparent, propertyChanged: OnPropertyChanged);

        public static readonly BindableProperty ShowCheckProperty =
            BindableProperty.Create(nameof(ShowCheck), typeof(bool), typeof(CircularProgressRing), true, propertyChanged: OnPropertyChanged);

        public float Progress
        {
            get => (float)GetValue(ProgressProperty);
            set => SetValue(ProgressProperty, value);
        }

        public Color ProgressColor
        {
            get => (Color)GetValue(ProgressColorProperty);
            set => SetValue(ProgressColorProperty, value);
        }

        public Color BackgroundCircleColor
        {
            get => (Color)GetValue(BackgroundCircleColorProperty);
            set => SetValue(BackgroundCircleColorProperty, value);
        }

        public bool ShowCheck
        {
            get => (bool)GetValue(ShowCheckProperty);
            set => SetValue(ShowCheckProperty, value);
        }

        private static void OnPropertyChanged(BindableObject bindable, object oldValue, object newValue)
        {
            ((CircularProgressRing)bindable).InvalidateSurface();
        }

        protected override void OnPaintSurface(SKPaintSurfaceEventArgs e)
        {
            base.OnPaintSurface(e);
            var canvas = e.Surface.Canvas;
            canvas.Clear();

            float width = e.Info.Width;
            float height = e.Info.Height;
            float strokeWidth = width * 0.13f;
            float radius = (Math.Min(width, height) - strokeWidth) / 2;
            var center = new SKPoint(width / 2, height / 2);

            using (var paint = new SKPaint
            {
                Style = SKPaintStyle.Stroke,
                Color = BackgroundCircleColor.ToSKColor(),
                StrokeWidth = strokeWidth,
                IsAntialias = true,
                StrokeCap = SKStrokeCap.Round
            })
            {
                canvas.DrawArc(
                    new SKRect(center.X - radius, center.Y - radius, center.X + radius, center.Y + radius),
                    -90, 360, false, paint);
            }

            using (var paint = new SKPaint
            {
                Style = SKPaintStyle.Stroke,
                Color = ProgressColor.ToSKColor(),
                StrokeWidth = strokeWidth,
                IsAntialias = true,
                StrokeCap = SKStrokeCap.Square
            })
            {
                canvas.DrawArc(
                    new SKRect(center.X - radius, center.Y - radius, center.X + radius, center.Y + radius),
                    -90, 360 * Progress, false, paint);
            }

            if (ShowCheck)
            {
                using (var paint = new SKPaint
                {
                    Style = SKPaintStyle.Stroke,
                    Color = SKColor.Parse("#1D283A").WithAlpha(153),
                    StrokeWidth = strokeWidth * 0.5f,
                    IsAntialias = true,
                    StrokeCap = SKStrokeCap.Round
                })
                {
                    float checkSize = radius * 0.8f;
                    var start = new SKPoint(center.X - checkSize * 0.35f, center.Y + checkSize * 0.05f);
                    var mid = new SKPoint(center.X - checkSize * 0.05f, center.Y + checkSize * 0.35f);
                    var end = new SKPoint(center.X + checkSize * 0.4f, center.Y - checkSize * 0.25f);

                    using (var path = new SKPath())
                    {
                        path.MoveTo(start);
                        path.LineTo(mid);
                        path.LineTo(end);
                        canvas.DrawPath(path, paint);
                    }
                }
            }
        }
    }
}
