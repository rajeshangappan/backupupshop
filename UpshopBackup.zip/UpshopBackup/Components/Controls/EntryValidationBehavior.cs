﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using Microsoft.Maui.Controls.Compatibility;
using Microsoft.Maui.Controls;
using Microsoft.Maui;
namespace MobileUI2.Components.Controls
{
    public class EntryValidationBehavior : Behavior<Entry>
    {
        private static string SpecialCharacters { get; set; }
        private static bool TypeKeyboard { get; set; }

        public static readonly BindableProperty MaxValueProperty = BindableProperty.Create(nameof(MaxValue), typeof(double),
                                                typeof(EntryValidationBehavior), null);

        public static readonly BindableProperty MinValueProperty = BindableProperty.Create(nameof(MinValue), typeof(double?),
            typeof(EntryValidationBehavior), null);
        public static readonly BindableProperty AllowDecimalProperty = BindableProperty.Create(nameof(AllowDecimal), typeof(bool?),
         typeof(EntryValidationBehavior), null);
        public bool? AllowDecimal
        {
            get => (bool?)GetValue(AllowDecimalProperty);
            set => SetValue(AllowDecimalProperty, value);
        }
        public double MaxValue
        {
            get => (double)GetValue(MaxValueProperty);
            set => SetValue(MaxValueProperty, value);
        }
        public double? MinValue
        {
            get => (double?)GetValue(MinValueProperty);
            set => SetValue(MinValueProperty, value);
        }
        protected override void OnAttachedTo(Entry entry)
        {

            entry.TextChanged += OnEntryTextChanged;
            base.OnAttachedTo(entry);
        }
        protected override void OnDetachingFrom(Entry entry)
        {
            MinValue = null;
            entry.TextChanged -= OnEntryTextChanged;
            base.OnDetachingFrom(entry);
        }
        protected override void OnAttachedTo(BindableObject bindable)
        {
            base.OnAttachedTo(bindable);
            bindable.BindingContextChanged += (sender, _) => this.BindingContext = ((BindableObject)sender).BindingContext;
        }
        private void OnEntryTextChanged(object sender, TextChangedEventArgs args)
        {
            try
            {
                if (!string.IsNullOrWhiteSpace(args.NewTextValue))
                {
                    var filteredText = Regex.Replace(args?.NewTextValue, @"[^0-9]+\.[^0-9]", string.Empty);
                    var filteredOldText = string.IsNullOrEmpty(args?.OldTextValue) ? string.Empty : Regex.Replace(args?.OldTextValue, @"[^0-9]+\.[^0-9]", string.Empty);
                    bool isValid;
                    Entry entry = (Entry)sender;
                    double.TryParse(filteredText, out double data);
                    double.TryParse(filteredOldText, out double olddata);
                    if (MaxValue != 0 && data > MaxValue)
                    {
                        isValid = false;
                    }
                    else
                    {
                        isValid = true;
                    }

                    if (MinValue.HasValue)
                    {
                        //if (MinValue.Value == 0)
                        //    return;

                        if (olddata < MinValue.Value)
                            olddata = MinValue.Value;
                        if (data < MinValue.Value)
                            isValid = false;
                    }
                    if (!isValid)
                        ((Entry)sender).Text = filteredOldText.ToString();

                    if (isValid)
                    {
                        if (AllowDecimal.HasValue)
                        {
                            if (AllowDecimal.Value)
                            {
                                if (filteredText.Contains("."))
                                {
                                    string[] splitString = filteredText.Split('.');
                                    if (splitString[1].Length < 4)
                                    {
                                        entry.Text = RoundConvertThreeDecimals(filteredText);
                                    }
                                }
                                else if (filteredText.Contains(","))
                                {
                                    string[] splitString = filteredText.Split(',');
                                    if (splitString[1].Length < 4)
                                    {
                                        entry.Text = RoundConvertThreeDecimals(filteredText);
                                    }
                                }
                                else
                                {
                                    entry.Text = RoundConvertThreeDecimals(filteredText);
                                }
                            }
                            else
                            {
                                entry.Text = Convert.ToInt32(data).ToString();
                            }
                        }
                        else
                        {
                            ((Entry)sender).Text = filteredText;
                        }
                    }
                }
                else
                {
                    ((Entry)sender).Text = "0";
                }
            }
            catch (Exception exception)
            {

            }
        }

        private string RoundConvertThreeDecimals(string qty)
        {
            double number;
            if (double.TryParse(qty, out number))
            {
                number = Math.Round(number, 3);
            }
            else
            {
               return string.Format(qty.Remove(qty.Length - 1));
            }

            return string.Format("{0.###}", number);

        }
    }

    public static class Extenstions
    {
        public static string RemoveWhitespace(this string input)
        {
            if (string.IsNullOrWhiteSpace(input))
                return input;

            return new string(input.Where(c => !Char.IsWhiteSpace(c))
                                   .ToArray());
        }
    }
}
