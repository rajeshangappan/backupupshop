﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Maui.Graphics;
using Microsoft.Maui.Controls.Compatibility;
using Microsoft.Maui.Controls;
using Microsoft.Maui;

namespace MobileUI2.Components.Controls
{
	public class GradientColor : BindableObject
	{
		public static readonly BindableProperty ColorProperty = BindableProperty.Create("Color", typeof(Color), typeof(GradientColor), Colors.Transparent);

		public static readonly BindableProperty OpacityProperty = BindableProperty.Create("Opacity", typeof(double), typeof(GradientColor), 1.0);

		public static readonly BindableProperty PositionProperty = BindableProperty.Create("Position", typeof(double?), typeof(GradientColor));

		public Color Color
		{
			get
			{
				return (Color)GetValue(ColorProperty);
			}
			set
			{
				SetValue(ColorProperty, value);
			}
		}

		public double Opacity
		{
			get
			{
				return (double)GetValue(OpacityProperty);
			}
			set
			{
				SetValue(OpacityProperty, value);
			}
		}

		public double? Position
		{
			get
			{
				return (double?)GetValue(PositionProperty);
			}
			set
			{
				SetValue(PositionProperty, value);
			}
		}

		public Color FinalColor
		{
			get
			{
				if (Opacity >= 1.0)
				{
					return Color;
				}
				double num = Opacity;
				if (Opacity < 0.0)
				{
					num = 0.0;
				}
                // Assuming num is between 0 and 1 for alpha scaling
				float adjustedAlpha = (float)(Colors.Red.Alpha * num);  // Get the alpha from Colors.Red and multiply by num

                return new Color(Colors.Red.Red, Colors.Green.Green, Colors.Blue.Blue, adjustedAlpha);

			}
		}
	}
}
