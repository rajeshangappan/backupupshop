﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Maui.Controls.Compatibility;
using Microsoft.Maui.Controls;
using Microsoft.Maui;

namespace MobileUI2.Components.Controls
{
    public class EditorLengthValidatorBehavior : BehaviorBase<Editor>
    {

        public static readonly BindableProperty MaxLengthProperty = BindableProperty.Create(nameof(MaxLength), typeof(int),
                                        typeof(EditorLengthValidatorBehavior), null);
        public int MaxLength
        {
            get => (int)GetValue(MaxLengthProperty);
            set => SetValue(MaxLengthProperty, value);
        }
        protected override void OnAttachedTo(Editor bindable)
        {
            base.OnAttachedTo(bindable);
            bindable.TextChanged += OnEntryTextChanged;
        }

        protected override void OnDetachingFrom(Editor bindable)
        {
            base.OnDetachingFrom(bindable);
            bindable.TextChanged -= OnEntryTextChanged;
        }

        void OnEntryTextChanged(object sender, TextChangedEventArgs e)
        {
            try
            {
                var entry = (Editor)sender;
                var length = entry.Text.Count(c => !char.IsWhiteSpace(c));
                if (length > this.MaxLength)
                {
                    string entryText = entry.Text;
                    if(MaxLength + 1 == length)
                    {
                        entryText = entryText.Remove(entryText.Length - 1);
                        entry.Text = entryText;
                    }
                    else
                    {
                        entryText = entryText.Remove(MaxLength, length);
                        entry.Text = entryText;
                    }                  
                }
            }
            catch (Exception)
            {
            }
            
        }
    }
}
