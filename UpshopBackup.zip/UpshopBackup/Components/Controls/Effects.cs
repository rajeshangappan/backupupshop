﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Maui.Controls.Compatibility;
using Microsoft.Maui.Controls;
using Microsoft.Maui;

namespace MobileUI2.Components.Controls
{
	public static class Effects
	{
		private class CornerRadiusEffect : RoutingEffect
		{
			public CornerRadiusEffect()
				: base("MobileUI2.CornerRadiusEffect")
			{
			}
		}
		public static readonly BindableProperty CornerRadiusProperty = BindableProperty.CreateAttached("CornerRadius", typeof(double), typeof(Effects), 0.0, BindingMode.OneWay, null, OnChanged<CornerRadiusEffect, double>);


		public static void SetCornerRadius(BindableObject view, double radius)
		{
			view.SetValue(CornerRadiusProperty, radius);
		}

		public static double GetCornerRadius(BindableObject view)
		{
			return (double)view.GetValue(CornerRadiusProperty);
		}
		private static void OnChanged<TEffect, TProp>(BindableObject bindable, object oldValue, object newValue) where TEffect : Effect, new()
		{
			VisualElement visualElement = bindable as VisualElement;
			if (visualElement != null)
			{
				Effect effect = visualElement.Effects.FirstOrDefault((Effect e) => e is TEffect);
				if (effect != null)
				{
					visualElement.Effects.Remove(effect);
				}
				if (!object.Equals(newValue, default(TProp)))
				{
					visualElement.Effects.Add(new TEffect());
				}
			}
		}
	}




	//public class Effects : RoutingEffect
	//{
	//    public Effects() : base($"MobileUI2.{nameof(Effects)}")
	//    {
	//    }

	//    public static readonly BindableProperty CornerRadiusProperty =
	//        BindableProperty.CreateAttached(
	//            "CornerRadius",
	//            typeof(int),
	//            typeof(Effects),
	//            0,
	//            propertyChanged: OnCornerRadiusChanged);

	//    public static int GetCornerRadius(BindableObject view) =>
	//        (int)view.GetValue(CornerRadiusProperty);

	//    public static void SetCornerRadius(BindableObject view, int value) =>
	//        view.SetValue(CornerRadiusProperty, value);

	//    private static void OnCornerRadiusChanged(BindableObject bindable, object oldValue, object newValue)
	//    {
	//        if (!(bindable is View view))
	//            return;

	//        var cornerRadius = (int)newValue;
	//        var effect = view.Effects.OfType<Effects>().FirstOrDefault();

	//        if (cornerRadius > 0 && effect == null)
	//            view.Effects.Add(new Effects());

	//        if (cornerRadius == 0 && effect != null)
	//            view.Effects.Remove(effect);
	//    }
	//}
}
