﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Maui.Controls.Compatibility;
using Microsoft.Maui.Controls;
using Microsoft.Maui;

namespace MobileUI2.Components.Controls
{
    public class EntryLengthValidatorBehavior : BehaviorBase<Entry>
    {
        public static readonly BindableProperty MaxLengthProperty = BindableProperty.Create(nameof(MaxLength), typeof(int),
                                  typeof(EditorLengthValidatorBehavior), null);
        public int MaxLength
        {
            get => (int)GetValue(MaxLengthProperty);
            set => SetValue(MaxLengthProperty, value);
        }
        protected override void OnAttachedTo(Entry bindable)
        {
            base.OnAttachedTo(bindable);
            bindable.TextChanged += OnEntryTextChanged;
        }

        protected override void OnDetachingFrom(Entry bindable)
        {
            base.OnDetachingFrom(bindable);
            bindable.TextChanged -= OnEntryTextChanged;
        }
        private string currentText;
        void OnEntryTextChanged(object sender, TextChangedEventArgs e)
        {
            try
            {
                var entry = (Entry)sender;
                var length = entry.Text.Count(c => !char.IsWhiteSpace(c));
                if (length > this.MaxLength)
                {
                    string entryText = entry.Text;
                    if (currentText.Count(c=> !char.IsWhiteSpace(c)) == MaxLength && MaxLength + 1 == length)
                    {
                        entry.Text = currentText;
                    }
                    else
                    {
                        while(length > MaxLength)
                        {
                            entryText = entryText.Remove(entryText.Length - (length - MaxLength));
                            length = entryText.Count(c => !char.IsWhiteSpace(c));
                        }
                        currentText= entry.Text= entryText;
                    }
                    return;
                }
                currentText= entry.Text;
            }
            catch (Exception)
            {
            }
        }
    }
}

