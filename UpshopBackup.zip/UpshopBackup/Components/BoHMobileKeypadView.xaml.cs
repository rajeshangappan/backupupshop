﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text.RegularExpressions;
using System.Windows.Input;
using MobileUI2.Constants;
using MobileUI2.Models;
using Microsoft.Maui.Controls.Xaml;
using Microsoft.Maui.Controls.Compatibility;
using Microsoft.Maui.Controls;
using Microsoft.Maui;

namespace MobileUI2.Components
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class BoHMobileKeypadView : ContentView
    {
        public static readonly BindableProperty MinimumValueProperty = BindableProperty.Create(nameof(MinimumValue), typeof(double), typeof(BoHMobileKeypadView), default(double));
        public static readonly BindableProperty MaximumValueProperty = BindableProperty.Create(nameof(MaximumValue), typeof(double), typeof(BoHMobileKeypadView), 99999.9999);
        public static readonly BindableProperty QuantityProperty = BindableProperty.Create(nameof(Quantity), typeof(string), typeof(object), default(string), BindingMode.TwoWay);
        public static readonly BindableProperty SubmitCommandProperty = BindableProperty.Create(nameof(SubmitCommand), typeof(ICommand), typeof(Button), defaultBindingMode: BindingMode.TwoWay);
        public static readonly BindableProperty IsEnabledButtonProperty = BindableProperty.Create(nameof(IsEnabledButton), typeof(bool), typeof(bool), default(bool), BindingMode.TwoWay);
        public static readonly BindableProperty DecimalSeparatorProperty = BindableProperty.Create(nameof(DecimalSeparator), typeof(string), typeof(object), default(string), BindingMode.TwoWay);
        public static readonly BindableProperty IsVisibleCountTypeProperty = BindableProperty.Create(nameof(IsVisibleCountType), typeof(bool), typeof(bool), default(bool), BindingMode.TwoWay);
        public static readonly BindableProperty CountTypeNameProperty = BindableProperty.Create(nameof(CountTypeName), typeof(string), typeof(object), default(string), BindingMode.TwoWay);
        public static readonly BindableProperty CountTypeCommandProperty = BindableProperty.Create(nameof(CountTypeCommand), typeof(ICommand), typeof(Button), defaultBindingMode: BindingMode.TwoWay);
        public static readonly BindableProperty AllowingDecimalPointsProperty = BindableProperty.Create(nameof(AllowingDecimalPoints), typeof(int), typeof(BoHMobileKeypadView), defaultValue: 2);
        public static readonly BindableProperty MaxNumericDigitsPointsProperty = BindableProperty.Create(nameof(MaxNumericDigitsPoints), typeof(int), typeof(BoHMobileKeypadView), defaultValue: 5);
        public static readonly BindableProperty RestrictDecimalProperty = BindableProperty.Create(nameof(RestrictDecimal), typeof(bool), typeof(BoHMobileKeypadView), defaultValue: false);
        public static readonly BindableProperty RestrictLeadingZerosProperty = BindableProperty.Create(nameof(RestrictLeadingZeros), typeof(bool), typeof(BoHMobileKeypadView), defaultValue: true);
        public static readonly BindableProperty DisableButtonProperty = BindableProperty.Create(nameof(DisableButton), typeof(bool), typeof(bool), false, BindingMode.TwoWay);
        public static readonly BindableProperty RestrictNonZeroDigitsProperty = BindableProperty.Create(nameof(RestrictNonZeroDigits), typeof(bool), typeof(BoHMobileKeypadView), defaultValue: false);
        public static readonly BindableProperty IsWeightedProperty = BindableProperty.Create(nameof(IsWeighted), typeof(bool), typeof(BoHMobileKeypadView), defaultValue: false);
        public static readonly BindableProperty WeightedCountTypeNameProperty = BindableProperty.Create(nameof(WeightedCountTypeName), typeof(string), typeof(object), default(string), BindingMode.TwoWay);
        public static readonly BindableProperty Tab2NameProperty = BindableProperty.Create(nameof(Tab2Name), typeof(string), typeof(object), default(string), BindingMode.TwoWay);


        public bool RestrictLeadingZeros
        {
            get => (bool)GetValue(RestrictLeadingZerosProperty);
            set => SetValue(RestrictLeadingZerosProperty, value);
        }
        public bool RestrictDecimal
        {
            get => (bool)GetValue(RestrictDecimalProperty);
            set => SetValue(RestrictDecimalProperty, value);
        }
        public int MaxNumericDigitsPoints
        {
            get => (int)GetValue(MaxNumericDigitsPointsProperty);
            set => SetValue(MaxNumericDigitsPointsProperty, value);
        }
        public int AllowingDecimalPoints
        {
            get => (int)GetValue(AllowingDecimalPointsProperty);
            set => SetValue(AllowingDecimalPointsProperty, value);
        }
        public bool IsVisibleCountType
        {
            get => (bool)GetValue(IsVisibleCountTypeProperty);
            set => SetValue(IsVisibleCountTypeProperty, value);
        }
        public string CountTypeName
        {
            get => (string)GetValue(CountTypeNameProperty);
            set => SetValue(CountTypeNameProperty, value);
        }
        public bool IsEnabledButton
        {
            get => (bool)GetValue(IsEnabledButtonProperty);
            set => SetValue(IsEnabledButtonProperty, value);
        }
        public bool DisableButton
        {
            get => (bool)GetValue(DisableButtonProperty);
            set => SetValue(DisableButtonProperty, value);
        }
        public double MaximumValue
        {
            get => (double)GetValue(MaximumValueProperty);
            set => SetValue(MaximumValueProperty, value);
        }

        public double MinimumValue
        {
            get => (double)GetValue(MinimumValueProperty);
            set => SetValue(MinimumValueProperty, value);
        }
        public string DecimalSeparator
        {
            get => (string)GetValue(DecimalSeparatorProperty);
            set => SetValue(DecimalSeparatorProperty, value);
        }
        public string Quantity
        {
            get => (string)GetValue(QuantityProperty);
            set
            {
                SetValue(QuantityProperty, value);
                if (string.IsNullOrEmpty(Quantity))
                {
                    IsEnabledButton = false;
                }
                else
                {
                    IsEnabledButton = !DisableButton;
                }
            }
        }

        private string _previousEntryValue;
        private string _wholeNumber;
        public string PreviousEntryValue
        {
            get => _previousEntryValue;
            set
            {
                _previousEntryValue = value;
                OnPropertyChanged(nameof(PreviousEntryValue));
            }
        }
        public string WholeNumber
        {
            get => _wholeNumber;
            set
            {
                _wholeNumber = value;
                OnPropertyChanged(nameof(_wholeNumber));
            }
        }
        public ICommand SubmitCommand
        {
            get { return (ICommand)GetValue(SubmitCommandProperty); }
            set { SetValue(SubmitCommandProperty, value); }
        }
        public ICommand CountTypeCommand
        {
            get { return (ICommand)GetValue(CountTypeCommandProperty); }
            set { SetValue(CountTypeCommandProperty, value); }
        }
        public bool RestrictNonZeroDigits
        {
            get => (bool)GetValue(RestrictNonZeroDigitsProperty);
            set => SetValue(RestrictNonZeroDigitsProperty, value);
        }
        public bool IsWeighted
        {
            get => (bool)GetValue(IsWeightedProperty);
            set => SetValue(IsWeightedProperty, value);
        }
        public string WeightedCountTypeName
        {
            get => (string)GetValue(WeightedCountTypeNameProperty);
            set => SetValue(WeightedCountTypeNameProperty, value);
        }
        public string Tab2Name
        {
            get => (string)GetValue(Tab2NameProperty);
            set => SetValue(Tab2NameProperty, value);
        }
        public ICommand SubmitInternalCommand { get; }
        public ICommand NumberPressCommand { get; }
        public ICommand DeleteCommand { get; }
        public ICommand CountTypeInternalCommand { get; }

        public BoHMobileKeypadView()
        {
            InitializeComponent();
            SubmitInternalCommand = new Command(SubmitKeypadExecute);
            NumberPressCommand = new Command<string>(NumberPressExecute);
            DeleteCommand = new Command(DeleteCommandExecute);
            CountTypeInternalCommand = new Command<int>(CountTypeCommandExecute);
            CountTypeName = LiteralTranslator.GetValue("Case");
            Tab2Name = GetTabName();
            BindingContext = this;
        }
        public event EventHandler<string> OnBoHKeypadSubmit;

        private void SubmitKeypadExecute()
        {
            IsEnabledButton = false;
            SubmitCommand.Execute(null);
        }
        private void NumberPressExecute(string number)
        {
            if (!RestrictNonZeroDigits)
            {
                WholeNumber = Quantity + number;
                ValidateAndApplyNumericConstraints(WholeNumber, number);
            }
            else
            {
                Quantity = "0";
            }
        }
        private void ValidateAndApplyNumericConstraints(string wholenumber, string originalValue)
        {
            if (MaximumValue < 0 || MinimumValue < 0)
            {
                throw new InvalidOperationException("MinValue and MaxValue must be set");
            }

            bool isValid = IsValidText(wholenumber) && !IsDecimalRestricted(wholenumber);
            if (isValid)
            {
                Quantity = RemoveLeadingZeros(wholenumber);
            }
        }

        private bool IsDecimalRestricted(string number)
        {
            return RestrictDecimal && (number.EndsWith('.') || number.EndsWith(','));
        }
        private bool IsInRange(string input) 
        {
            if (double.TryParse(input, NumberStyles.Any, CultureInfo.CurrentCulture, out double value))
            {
                return value >= MinimumValue && value <= MaximumValue;
            }
            else
            {
                return false;
            }
        }
        private bool IsValidText(string text)
        {
            var regexUs = new Regex(DecimalPatternUs());
            var regexDe = new Regex(DecimalPatternDe());
            return regexUs.IsMatch(text) || regexDe.IsMatch(text);
        }
        private void DeleteCommandExecute()
        {
            if (!string.IsNullOrEmpty(Quantity))
            {
                Quantity = Quantity.Substring(0, Quantity.Length - 1);
            }
        }
        public string RemoveLeadingZeros(string input)
        {
            if (RestrictLeadingZeros && double.TryParse(input, NumberStyles.Float, CultureInfo.InvariantCulture, out double number))
            {
                return input.StartsWith("0") && !input.Contains(".") && !input.Contains(",") ? number.ToString(CultureInfo.InvariantCulture) : input;
            }
            return input;
        }
        private void CountTypeCommandExecute(int tab)
        {
            switch (tab)
            {
                case 1:
                    FrameMoveToCase();
                    break;

                case 2:
                    FrameMoveToEach();
                    break;

                case 3:
                    Tab2Name = GetTabName();
                    break;
            }
        }

        void OnText1Tapped(System.Object sender, System.EventArgs e)
        {
            IsEnabledButton = !DisableButton && !string.IsNullOrEmpty(Quantity);
            FrameMoveToCase();
        }

        void OnText2Tapped(System.Object sender, System.EventArgs e)
        {
            IsEnabledButton = !DisableButton && !string.IsNullOrEmpty(Quantity);
            FrameMoveToEach();
        }
        protected void FrameMoveToCase()
        {
            CountTypeName = LiteralTranslator.GetValue("Case");
            Tab2Name = GetTabName();
            tab2.SetDynamicResource(Label.TextColorProperty, "TextColor");
            tab2.Style = (Style)Application.Current.Resources["LabelLightStyle"];
            tab1.SetDynamicResource(Label.TextColorProperty, "UpshopWhite");
            tab1.Style = (Style)Application.Current.Resources["LabelBoldStyle"];
            decimalspoint.IsEnabled = true;
            decimalspoint.Opacity = 1;
            runningFrame.TranslateTo(0, 0);
        }
        protected void FrameMoveToEach()
        {
            CountTypeName = GetTabName();
            Tab2Name = GetTabName();
            tab2.SetDynamicResource(Label.TextColorProperty, "UpshopWhite");
            tab2.Style = (Style)Application.Current.Resources["LabelBoldStyle"];
            tab1.SetDynamicResource(Label.TextColorProperty, "TextColor");
            tab1.Style = (Style)Application.Current.Resources["LabelLightStyle"];
            if(CountTypeName == LiteralTranslator.GetValue("Each"))
            {
                decimalspoint.IsEnabled = false;
                decimalspoint.Opacity = 0.5;
            }
            else
            {
                decimalspoint.IsEnabled = true;
                decimalspoint.Opacity = 1;
            }
            // runningFrame.TranslateTo(0, 0);
            runningFrame.TranslateTo(runningFrame.Width, 0);
        }
        public string DecimalPatternUs()
        {
            return $@"^[-−]?(\d{{1,{MaxNumericDigitsPoints}}}(\,\d{{{AllowingDecimalPoints}}})*(\.\d{{0,{AllowingDecimalPoints}}})?)?$";
        }
        public string DecimalPatternDe()
        {
            return $@"^[-−]?(\d{{1,{MaxNumericDigitsPoints}}}(\.\d{{{AllowingDecimalPoints}}})*(\,\d{{0,{AllowingDecimalPoints}}})?)?$";
        }
        private string GetTabName()
        {
            return IsWeighted && !string.IsNullOrEmpty(WeightedCountTypeName)
                ? WeightedCountTypeName
                : LiteralTranslator.GetValue("Each");
        }
    }
}