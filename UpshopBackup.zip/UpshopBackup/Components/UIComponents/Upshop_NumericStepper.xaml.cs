﻿using System.Globalization;

namespace MobileUI2.Components
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class Upshop_NumericStepper : ContentView
    {
        public event EventHandler KeyboardDismissed;
        public event EventHandler ShowKeyboard;
        public Upshop_NumericStepper()
        {
            InitializeComponent();
        }

        public static BindableProperty NumericStepperLabelTextProperty =
       BindableProperty.Create(
           nameof(NumericStepperLabelText),
           typeof(string),
           typeof(Label),
           defaultValue: default(string),
           defaultBindingMode: BindingMode.TwoWay
       );

        public string NumericStepperLabelText
        {
            get { return (string)GetValue(NumericStepperLabelTextProperty); }
            set { SetValue(NumericStepperLabelTextProperty, value); }
        }

        public static BindableProperty ShowNumericStepperLabelTextProperty =
         BindableProperty.Create(
             nameof(ShowNumericStepperLabelText),
             typeof(bool),
             typeof(Label),
             defaultValue: false,
             defaultBindingMode: BindingMode.TwoWay
         );

        public bool ShowNumericStepperLabelText
        {
            get { return (bool)GetValue(ShowNumericStepperLabelTextProperty); }
            set { SetValue(ShowNumericStepperLabelTextProperty, value); }
        }

        public static BindableProperty NumericStepperEntryEnabledProperty = BindableProperty.Create(nameof(NumericStepperEntryEnabled), typeof(bool), typeof(Entry), defaultValue: true, defaultBindingMode: BindingMode.TwoWay);
        public bool NumericStepperEntryEnabled
        {
            get { return (bool)GetValue(NumericStepperEntryEnabledProperty); }
            set { SetValue(NumericStepperEntryEnabledProperty, value); }
        }
       
        public static BindableProperty NumericStepperEntryProperty =
            BindableProperty.Create(nameof(NumericStepperEntry),
                typeof(string), typeof(Entry),
                defaultValue: string.Empty, defaultBindingMode: BindingMode.TwoWay);

        public string NumericStepperEntry
        {
            get { return (string)GetValue(NumericStepperEntryProperty); }
            set { SetValue(NumericStepperEntryProperty, value); }
        }
        public static BindableProperty AllowDecimalProperty =
         BindableProperty.Create(
             nameof(AllowDecimal),
             typeof(bool),
             typeof(UpShop_TabletCard),
             defaultValue: false,
             defaultBindingMode: BindingMode.TwoWay);

        public bool AllowDecimal
        {
            get { return (bool)GetValue(AllowDecimalProperty); }
            set { SetValue(AllowDecimalProperty, value); }
        }
        public static BindableProperty ApplyNewStepperStyleProperty =
          BindableProperty.Create(
              nameof(ApplyNewStepperStyle),
              typeof(bool),
              typeof(Frame),
              defaultValue: default(bool),
              defaultBindingMode: BindingMode.TwoWay
          );
        public bool ApplyNewStepperStyle
        {
            get { return (bool)GetValue(ApplyNewStepperStyleProperty); }
            set { SetValue(ApplyNewStepperStyleProperty, value); }
        }
        public static BindableProperty EntryWidthRequestProperty =
       BindableProperty.Create(nameof(EntryWidthRequest),
           typeof(int), typeof(Entry),
           defaultValue: (int)70, defaultBindingMode: BindingMode.TwoWay);
        public int DecimalPoints
        {
            get { return (int)GetValue(DecimalPointsProperty); }
            set { SetValue(DecimalPointsProperty, value); }
        }
        public static BindableProperty DecimalPointsProperty =
        BindableProperty.Create(
            nameof(DecimalPoints),
            typeof(int),
            typeof(Label),
            defaultValue: 3,
            defaultBindingMode: BindingMode.TwoWay
        );
        
        public int EntryWidthRequest
        {
            get { return (int)GetValue(EntryWidthRequestProperty); }
            set { SetValue(EntryWidthRequestProperty, value); }
        }

        private void TapGestureRecognizer_Tapped_1(object sender, EventArgs e)
        {
            try
            {
                if(double.TryParse(NumericStepperEntry, NumberStyles.Float, CultureInfo.CurrentCulture, out double value)
                    && value != 0 && value <= 999)
                {
                    StepperEntry.Text = (--value).ToString(CultureInfo.CurrentCulture);
                }
            }
            catch (Exception)
            {
            }
        }

        private void TapGestureRecognizer_Tapped_2(object sender, EventArgs e)
        {
            try
            {
                if (double.TryParse(NumericStepperEntry, NumberStyles.Float, CultureInfo.CurrentCulture, out double value)
                    && value >= 0 && value < 999)
                {
                    StepperEntry.Text = (++value).ToString(CultureInfo.CurrentCulture);
                }
            }
            catch (Exception)
            {
            }
        }
        private void StepperEntry_TextChanged(object sender, TextChangedEventArgs e)
        {
            try
            {
                if (!string.IsNullOrEmpty(e.NewTextValue))
                {
                    var qty = e.NewTextValue;
                    if (AllowDecimal && e.NewTextValue.EndsWith("."))
                    {
                        qty = qty.Substring(0, qty.Length - 1) + CultureInfo.CurrentCulture.NumberFormat.NumberDecimalSeparator;
                        StepperEntry.Text = qty;
                        return;
                    }
                    else if (AllowDecimal && e.NewTextValue.EndsWith(","))
                    {
                        if (!double.TryParse(qty, NumberStyles.Float, CultureInfo.CurrentCulture, out double entryText))
                        {
                            StepperEntry.Text = e.NewTextValue.Remove(e.NewTextValue.Length - 1);
                            return;
                        }
                        return;
                    }
                    else if (!AllowDecimal && e.NewTextValue.EndsWith("."))
                    {
                        StepperEntry.Text = e.NewTextValue.Remove(e.NewTextValue.Length - 1);
                        return;
                    }
                    if (double.TryParse(qty, NumberStyles.Float, CultureInfo.CurrentCulture, out double value))
                    {
                        if (value <= 999 && value >= 0)
                        {
                            if (AllowDecimal)
                                StepperEntry.Text = value.ToString("0.###", CultureInfo.CurrentCulture);
                        }
                        else
                        {
                            StepperEntry.Text = e.NewTextValue.Remove(e.NewTextValue.Length - 1);
                        }
                    }
                    else StepperEntry.Text = e.NewTextValue.Remove(e.NewTextValue.Length - 1);
                }
            }
            catch (Exception)
            {
            }

        }
        private void StepperEntry_Unfocused(object sender, FocusEventArgs e)
        {
            KeyboardDismissed?.Invoke(this, EventArgs.Empty);
        }

        private void StepperEntry_Focused(object sender, FocusEventArgs e)
        {
            ShowKeyboard?.Invoke(this, EventArgs.Empty);
        }
    }
}