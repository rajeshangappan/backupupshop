using MobileUI2.Components.Controls;

namespace MobileUI2.Components
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class UpShop_NewCard : ContentView
    {
        public UpShop_NewCard()
        {
            InitializeComponent();
        }

        public static BindableProperty TitleProperty =
       BindableProperty.Create(
           nameof(Title),
           typeof(string),
           typeof(Label),
           defaultValue: default(string),
           defaultBindingMode: BindingMode.TwoWay
       );
        public string Title
        {
            get { return (string)GetValue(TitleProperty); }
            set { SetValue(TitleProperty, value); }
        }


        public static BindableProperty SubTitleProperty =
      BindableProperty.Create(
          nameof(SubTitle),
          typeof(string),
          typeof(Label),
          defaultValue: default(string),
          defaultBindingMode: BindingMode.TwoWay
      );
        public string SubTitle
        {
            get { return (string)GetValue(SubTitleProperty); }
            set { SetValue(SubTitleProperty, value); }
        }

        public static BindableProperty IconProperty =
    BindableProperty.Create(
        nameof(Icon),
        typeof(string),
        typeof(Label),
        defaultValue: default(string),
        defaultBindingMode: BindingMode.TwoWay
    );
        public string Icon
        {
            get { return (string)GetValue(IconProperty); }
            set { SetValue(IconProperty, value); }
        }
        public static BindableProperty TotalQuantityProperty =
   BindableProperty.Create(
       nameof(TotalQuantity),
       typeof(string),
       typeof(Label),
       defaultValue: default(string),
       defaultBindingMode: BindingMode.TwoWay
   );
        public string TotalQuantity
        {
            get { return (string)GetValue(TotalQuantityProperty); }
            set { SetValue(TotalQuantityProperty, value); }
        }

        public static BindableProperty ProgressProperty =
  BindableProperty.Create(
      nameof(Progress),
      typeof(decimal),
      typeof(CircularProgressRing),
      defaultValue: default(decimal),
      defaultBindingMode: BindingMode.TwoWay
  );
        public decimal Progress
        {
            get { return (decimal)GetValue(ProgressProperty); }
            set { SetValue(ProgressProperty, value); }
        }

        public static BindableProperty ProgressRingColorProperty =
        BindableProperty.Create(
            nameof(ProgressRingColor),
            typeof(Color),
            typeof(CircularProgressRing),
            defaultValue: Color.FromArgb("#D3D3D3"),
            defaultBindingMode: BindingMode.TwoWay
        );

        public Color ProgressRingColor
        {
            get { return (Color)GetValue(ProgressRingColorProperty); }
            set { SetValue(ProgressRingColorProperty, value); }
        }
        public static BindableProperty ProgressRingBackgroundColorProperty =
       BindableProperty.Create(
           nameof(ProgressRingBackgroundColor),
           typeof(Color),
           typeof(CircularProgressRing),
           defaultValue: Color.FromArgb("#00FFFFFF"),
           defaultBindingMode: BindingMode.TwoWay
       );

        public Color ProgressRingBackgroundColor
        {
            get { return (Color)GetValue(ProgressRingBackgroundColorProperty); }
            set { SetValue(ProgressRingBackgroundColorProperty, value); }
        }

        public static BindableProperty ShowCheckProperty =
     BindableProperty.Create(
         nameof(ShowCheck),
         typeof(bool),
         typeof(CircularProgressRing),
         defaultValue: false,
         defaultBindingMode: BindingMode.TwoWay
     );

        public bool ShowCheck
        {
            get { return (bool)GetValue(ShowCheckProperty); }
            set { SetValue(ShowCheckProperty, value); }
        }

        public static BindableProperty ShowIconProperty =
         BindableProperty.Create(
         nameof(ShowIcon),
         typeof(bool),
         typeof(bool),
         defaultValue: true,
         defaultBindingMode: BindingMode.TwoWay
     );

        public bool ShowIcon
        {
            get { return (bool)GetValue(ShowIconProperty); }
            set { SetValue(ShowIconProperty, value); }
        }

        public bool ShowFulfilled
        {
            get { return (bool)GetValue(ShowFulfilledProperty); }
            set { SetValue(ShowFulfilledProperty, value); }
        }

        public static BindableProperty ShowFulfilledProperty =
         BindableProperty.Create(
         nameof(ShowFulfilled),
         typeof(bool),
         typeof(bool),
         defaultValue: false,
         defaultBindingMode: BindingMode.TwoWay
     );

        public static readonly BindableProperty ProgressLabelProperty =
    BindableProperty.Create(
        nameof(ProgressLabel),
        typeof(string),
        typeof(Label),
        defaultValue: default(string),
        defaultBindingMode: BindingMode.TwoWay
    );

        public string ProgressLabel
        {
            get => (string)GetValue(ProgressLabelProperty);
            set => SetValue(ProgressLabelProperty, value);
        }

        public static readonly BindableProperty ProgressTextProperty =
            BindableProperty.Create(
                nameof(ProgressText),
                typeof(string),
                typeof(Label),
                defaultValue: default(string),
                defaultBindingMode: BindingMode.TwoWay
            );

        public string ProgressText
        {
            get => (string)GetValue(ProgressTextProperty);
            set => SetValue(ProgressTextProperty, value);
        }
    }
}