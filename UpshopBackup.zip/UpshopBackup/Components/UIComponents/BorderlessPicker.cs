﻿namespace MobileUI2.Components
{
    public class BorderlessPicker : Picker
    {
        public BorderlessPicker() : base()
        {

        }
    }
}
