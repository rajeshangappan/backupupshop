using System.Windows.Input;

namespace MobileUI2.Components;

[XamlCompilation(XamlCompilationOptions.Compile)]
public partial class UpShop_CardView : ContentView
{
	public UpShop_CardView()
	{
		InitializeComponent();
	}

    public static BindableProperty BottomTitleTextProperty =
        BindableProperty.Create(
            nameof(BottomTitleText),
            typeof(string),
            typeof(Label),
            defaultValue: default(string),
            defaultBindingMode: BindingMode.TwoWay
        );

    public string BottomTitleText
    {
        get { return (string)GetValue(BottomTitleTextProperty); }
        set { SetValue(BottomTitleTextProperty, value); }
    }

    public static BindableProperty ShowbottomTitleTextProperty =
        BindableProperty.Create(
            nameof(ShowbottomTitleText),
            typeof(bool),
            typeof(Label),
            defaultValue: false,
            defaultBindingMode: BindingMode.TwoWay
        );
    public bool ShowbottomTitleText
    {
        get { return (bool)GetValue(ShowbottomTitleTextProperty); }
        set { SetValue(ShowbottomTitleTextProperty, value); }
    }

    public static BindableProperty TitleDateTextProperty =
         BindableProperty.Create(
             nameof(TitleDateText),
             typeof(string),
             typeof(Label),
             defaultValue: default(string),
             defaultBindingMode: BindingMode.TwoWay
         );
    public string TitleDateText
    {
        get { return (string)GetValue(TitleDateTextProperty); }
        set { SetValue(TitleDateTextProperty, value); }
    }

    public static BindableProperty ShowTitleDateTextProperty =
         BindableProperty.Create(
             nameof(ShowTitleDateText),
             typeof(bool),
             typeof(Label),
             defaultValue: false,
             defaultBindingMode: BindingMode.TwoWay
         );
    public bool ShowTitleDateText
    {
        get { return (bool)GetValue(ShowTitleDateTextProperty); }
        set { SetValue(ShowTitleDateTextProperty, value); }
    }

    public static BindableProperty HeaderTextProperty =
           BindableProperty.Create(
               nameof(HeaderText),
               typeof(string),
               typeof(Label),
               defaultValue: default(string),
               defaultBindingMode: BindingMode.TwoWay
           );

    public string HeaderText
    {
        get { return (string)GetValue(HeaderTextProperty); }
        set { SetValue(HeaderTextProperty, value); }
    }

    public static BindableProperty ShowHeaderTextProperty =
          BindableProperty.Create(
              nameof(ShowHeaderText),
              typeof(bool),
              typeof(Label),
              defaultValue: false,
              defaultBindingMode: BindingMode.TwoWay
          );

    public bool ShowHeaderText
    {
        get { return (bool)GetValue(ShowHeaderTextProperty); }
        set { SetValue(ShowHeaderTextProperty, value); }
    }

    public static BindableProperty ShowCheckboxProperty =
          BindableProperty.Create(
          nameof(ShowCheckbox),
          typeof(bool),
          typeof(UpShop_Card),
          defaultValue: false,
          defaultBindingMode: BindingMode.TwoWay);

    public bool ShowCheckbox
    {
        get { return (bool)GetValue(ShowCheckboxProperty); }
        set { SetValue(ShowCheckboxProperty, value); }
    }
    //public static readonly BindableProperty FrameTapCommandProperty =
    //   BindableProperty.Create(nameof(FrameTapCommand), typeof(ICommand), typeof(Border), defaultValue: default(Command),
    //   defaultBindingMode: BindingMode.OneWay);
    //public ICommand FrameTapCommand
    //{
    //    get => (ICommand)GetValue(FrameTapCommandProperty);
    //    set => SetValue(FrameTapCommandProperty, value);
    //}
    public static BindableProperty RightBottomTextProperty =
        BindableProperty.Create(
            nameof(RightBottomText),
            typeof(string),
            typeof(Label),
            defaultValue: default(string),
            defaultBindingMode: BindingMode.TwoWay
        );

    public string RightBottomText
    {
        get { return (string)GetValue(RightBottomTextProperty); }
        set { SetValue(RightBottomTextProperty, value); }
    }

    public static BindableProperty ShowRightBottomTextProperty =
     BindableProperty.Create(
         nameof(ShowRightBottomText),
         typeof(bool),
         typeof(Label),
         defaultValue: false,
         defaultBindingMode: BindingMode.TwoWay
     );

    public bool ShowRightBottomText
    {
        get { return (bool)GetValue(ShowRightBottomTextProperty); }
        set { SetValue(ShowRightBottomTextProperty, value); }
    }

    public static BindableProperty ShowCompleteIconProperty =
      BindableProperty.Create(
          nameof(ShowCompleteIcon),
          typeof(bool),
          typeof(Label),
          defaultValue: false,
          defaultBindingMode: BindingMode.TwoWay
      );

    public bool ShowCompleteIcon
    {
        get { return (bool)GetValue(ShowCompleteIconProperty); }
        set { SetValue(ShowCompleteIconProperty, value); }
    }

    public static BindableProperty IsCheckedProperty =
           BindableProperty.Create(
           nameof(IsChecked),
           typeof(bool),
           typeof(UpShop_Card),
           defaultValue: false,
           defaultBindingMode: BindingMode.TwoWay);

    public bool IsChecked
    {
        get { return (bool)GetValue(IsCheckedProperty); }
        set { SetValue(IsCheckedProperty, value); }
    }

    public static BindableProperty ShowTitleTextProperty =
         BindableProperty.Create(
             nameof(ShowTitleText),
             typeof(bool),
             typeof(Label),
             defaultValue: false,
             defaultBindingMode: BindingMode.TwoWay
         );

    public bool ShowTitleText
    {
        get { return (bool)GetValue(ShowTitleTextProperty); }
        set { SetValue(ShowTitleTextProperty, value); }
    }
    public static BindableProperty TitleTextProperty =
         BindableProperty.Create(
             nameof(TitleText),
             typeof(string),
             typeof(Label),
             defaultValue: default(string),
             defaultBindingMode: BindingMode.TwoWay
         );

    public string TitleText
    {
        get { return (string)GetValue(TitleTextProperty); }
        set { SetValue(TitleTextProperty, value); }
    }

    public static BindableProperty CompleteIconProperty =
            BindableProperty.Create(
                nameof(CompleteIcon),
                typeof(string),
                typeof(Label),
                defaultValue: "\uf14a",
                defaultBindingMode: BindingMode.TwoWay
                );
    public string CompleteIcon
    {
        get { return (string)GetValue(CompleteIconProperty); }
        set { SetValue(CompleteIconProperty, value); }
    }

    public static BindableProperty CompleteIconColorProperty =
       BindableProperty.Create(
           nameof(CompleteIconColor),
           typeof(Color),
           typeof(ProgressBar),
           defaultValue: Color.FromArgb("#43B262"),
           defaultBindingMode: BindingMode.TwoWay
       );

    public Color CompleteIconColor
    {
        get { return (Color)GetValue(CompleteIconColorProperty); }
        set { SetValue(CompleteIconColorProperty, value); }
    }

    public static BindableProperty ShowSubTitleTextProperty =
         BindableProperty.Create(
             nameof(ShowSubTitleText),
             typeof(bool),
             typeof(Label),
             defaultValue: false,
             defaultBindingMode: BindingMode.TwoWay
         );

    public bool ShowSubTitleText
    {
        get { return (bool)GetValue(ShowSubTitleTextProperty); }
        set { SetValue(ShowSubTitleTextProperty, value); }
    }
    public static BindableProperty SubTitleTextProperty =
         BindableProperty.Create(
             nameof(SubTitleText),
             typeof(string),
             typeof(Label),
             defaultValue: default(string),
             defaultBindingMode: BindingMode.TwoWay
         );


    public string SubTitleText
    {
        get { return (string)GetValue(SubTitleTextProperty); }
        set { SetValue(SubTitleTextProperty, value); }
    }
    public bool ShowSignatureIcon
    {
        get { return (bool)GetValue(ShowSignatureIconProperty); }
        set { SetValue(ShowSignatureIconProperty, value); }
    }

    public static BindableProperty ShowSignatureIconProperty =
        BindableProperty.Create(
            nameof(ShowSignatureIcon),
            typeof(bool),
            typeof(Label),
            defaultValue: false,
            defaultBindingMode: BindingMode.TwoWay
            );
    public string SignatureIcon
    {
        get { return (string)GetValue(SignatureIconProperty); }
        set { SetValue(SignatureIconProperty, value); }
    }

    public static BindableProperty SignatureIconProperty =
        BindableProperty.Create(
            nameof(SignatureIcon),
            typeof(string),
            typeof(Label),
            defaultValue: string.Empty,
            defaultBindingMode: BindingMode.TwoWay);

    public static BindableProperty ShowArrowIconProperty =
          BindableProperty.Create(
              nameof(ShowArrowIcon),
              typeof(bool),
              typeof(Label),
              defaultValue: false,
              defaultBindingMode: BindingMode.TwoWay
          );

    public bool ShowArrowIcon
    {
        get { return (bool)GetValue(ShowArrowIconProperty); }
        set { SetValue(ShowArrowIconProperty, value); }
    }
}
