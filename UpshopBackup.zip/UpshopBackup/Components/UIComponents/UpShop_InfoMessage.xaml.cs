﻿namespace MobileUI2.Components
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class UpShop_InfoMessage : ContentView
    {
        public UpShop_InfoMessage()
        {
            InitializeComponent();
        }

        #region Bindable Properties

        public static BindableProperty FrameBgColorProperty =
      BindableProperty.Create(
          nameof(FrameBgColor),
          typeof(Color),
          typeof(Frame),
          defaultValue: Color.FromArgb("#c9d3e0"),
          defaultBindingMode: BindingMode.TwoWay
      );

        public Color FrameBgColor
        {
            get { return (Color)GetValue(FrameBgColorProperty); }
            set { SetValue(FrameBgColorProperty, value); }
        }

        public static BindableProperty LabelTextColorProperty =
    BindableProperty.Create(
        nameof(LabelTextColor),
        typeof(Color),
        typeof(Label),
        defaultValue: Color.FromArgb("#2b4c8b"),
        defaultBindingMode: BindingMode.TwoWay
    );

        public Color LabelTextColor
        {
            get { return (Color)GetValue(LabelTextColorProperty); }
            set { SetValue(LabelTextColorProperty, value); }
        }

        #region Text 
        public static BindableProperty TextProperty =
           BindableProperty.Create(
               nameof(Text),
               typeof(string),
               typeof(Label),
               defaultValue: default(string),
               defaultBindingMode: BindingMode.TwoWay
           );

        public string Text
        {
            get { return (string)GetValue(TextProperty); }
            set { SetValue(TextProperty, value); }
        }
        #endregion
        #endregion
    }
}