﻿namespace MobileUI2.Components
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class UpShop_ErrorMessage : ContentView
    {
        public UpShop_ErrorMessage()
        {
            InitializeComponent();
        }
        #region Properties 
        public static BindableProperty TextProperty =
           BindableProperty.Create(
               nameof(Text),
               typeof(string),
               typeof(Label),
               defaultValue: default(string),
               defaultBindingMode: BindingMode.TwoWay
           );

        public string Text
        {
            get { return (string)GetValue(TextProperty); }
            set { SetValue(TextProperty, value); }
        }

        public static BindableProperty IsVisibleMessageProperty =
        BindableProperty.Create(
            nameof(IsVisibleMessage),
            typeof(bool),
            typeof(StackLayout),
            defaultValue: default(bool),
            defaultBindingMode: BindingMode.TwoWay
        );

        public bool IsVisibleMessage
        {
            get { return (bool)GetValue(IsVisibleMessageProperty); }
            set { SetValue(IsVisibleMessageProperty, value); }
        }

        #endregion


    }
}