﻿namespace MobileUI2.Components
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class UpshopKeyboard : ContentView
    {
        public UpshopKeyboard()
        {
            InitializeComponent();
        }

        public static readonly BindableProperty MinimumValueProperty = BindableProperty.Create(nameof(MinimumValue), typeof(double), typeof(UpshopKeyboard), default(double));
        public static readonly BindableProperty MaximumValueProperty = BindableProperty.Create(nameof(MaximumValue), typeof(double), typeof(UpshopKeyboard), 999.99);
        public double MaximumValue
        {
            get => (double)GetValue(MaximumValueProperty);
            set => SetValue(MaximumValueProperty, value);
        }

        public double MinimumValue
        {
            get => (double)GetValue(MinimumValueProperty);
            set => SetValue(MinimumValueProperty, value);
        }
        public static readonly BindableProperty IgnoreDecimalSeperatorProperty =
        BindableProperty.Create(nameof(IgnoreDecimalSeperator),
            typeof(bool),
            typeof(Label),
            defaultValue: false,
            defaultBindingMode: BindingMode.TwoWay);

        public bool IgnoreDecimalSeperator
        {
            get => (bool)GetValue(IgnoreDecimalSeperatorProperty);
            set => SetValue(IgnoreDecimalSeperatorProperty, value);
        }
        public static readonly BindableProperty EnableButtonProperty =
              BindableProperty.Create(nameof(EnableButton),
                  typeof(bool),
                  typeof(UpShop_Button),
                  defaultValue: false,
                  defaultBindingMode: BindingMode.TwoWay);

        public bool EnableButton
        {
            get => (bool)GetValue(EnableButtonProperty);
            set => SetValue(EnableButtonProperty, value);
        }
        public static readonly BindableProperty IsPriceKeyboardProperty =
              BindableProperty.Create(nameof(IsPriceKeyboard),
                  typeof(bool),
                  typeof(UpShop_Button),
                  defaultValue: false,
                  defaultBindingMode: BindingMode.TwoWay);

        public bool IsPriceKeyboard
        {
            get => (bool)GetValue(IsPriceKeyboardProperty);
            set => SetValue(IsPriceKeyboardProperty, value);
        }

        public static readonly BindableProperty EntryTextProperty =
       BindableProperty.Create(nameof(EntryText),
           typeof(string),
           typeof(Entry),
           defaultValue: string.Empty,
           defaultBindingMode: BindingMode.TwoWay);

        public string EntryText
        {
            get => (string)GetValue(EntryTextProperty);
            set => SetValue(EntryTextProperty, value);
        }
        public static readonly BindableProperty DecimalSeparatorProperty =
         BindableProperty.Create(nameof(DecimalSeparator),
             typeof(string),
             typeof(Entry),
             defaultValue: string.Empty,
             defaultBindingMode: BindingMode.TwoWay);

        public string DecimalSeparator
        {
            get => (string)GetValue(DecimalSeparatorProperty);
            set => SetValue(DecimalSeparatorProperty, value);
        }


        private void TapGestureRecognizer_Tapped(object sender, EventArgs e)
        {
            try
            {
                var param = ((TappedEventArgs)e).Parameter;
                var data = param as string;
                if (data != null)
                {
                    if (data == "." && IgnoreDecimalSeperator)
                    {
                        entry.Text = string.Empty;
                        EnableButton = false;
                        return;
                    }
                    if (data == ".")
                    {
                        if (entry.Text.Contains(DecimalSeparator))
                        {
                            return;
                        }
                        else
                        {
                            entry.Text += DecimalSeparator;
                            return;
                        }
                    }
                    if (data == "delete")
                    {
                        if (string.IsNullOrEmpty(entry.Text))
                            return;
                        entry.Text = entry.Text.Remove(entry.Text.Length - 1);
                        if (string.IsNullOrEmpty(entry.Text))
                        {
                            EnableButton = false;
                        }
                        else if (decimal.TryParse(entry.Text, out decimal value))
                        {
                            if (value == 0)
                                EnableButton = false;
                        }
                        return;
                    }

                    if (!string.IsNullOrEmpty(entry.Text) && entry.Text.Contains(DecimalSeparator))
                    {
                        var text = entry.Text;
                        var decimalValue = text.Substring(text.IndexOf(DecimalSeparator));
                        if (decimalValue.Length > 2)
                            return;
                    }
                    entry.Text += data;
                    double oldvalue;
                    double.TryParse(entry.Text, out oldvalue);
                    if (oldvalue > MaximumValue)
                    {
                        entry.Text = entry.Text.Remove(entry.Text.Length - 1);
                    }

                    if (!IsPriceKeyboard)
                        EnableButton = true;
                    else if (decimal.TryParse(entry.Text, out decimal value))
                    {
                        if (value == 0 && IsPriceKeyboard)
                            EnableButton = false;
                        else EnableButton = true;
                    }
                    else EnableButton = true;
                }
            }
            catch (Exception)
            {
            }
        }
    }
}