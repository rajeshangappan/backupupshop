﻿namespace MobileUI2.Components
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class UpShop_ProgressBar : ContentView
    {
        public UpShop_ProgressBar()
        {
            InitializeComponent();
        }
        public static readonly BindableProperty FrameCornerRadiusProperty =
            BindableProperty.Create(nameof(FrameCornerRadius),
                typeof(int),
                typeof(Frame),
                defaultValue: 10,
                defaultBindingMode: BindingMode.OneWay);

        public int FrameCornerRadius
        {
            get => (int)GetValue(FrameCornerRadiusProperty);
            set => SetValue(FrameCornerRadiusProperty, value);
        }

        public static readonly BindableProperty FrameHeightRequestProperty =
            BindableProperty.Create(nameof(FrameHeightRequest),
                typeof(double),
                typeof(Frame),
                defaultValue: (double)20,
                defaultBindingMode: BindingMode.OneWay);

        public double FrameHeightRequest
        {
            get => (double)GetValue(FrameHeightRequestProperty);
            set => SetValue(FrameHeightRequestProperty, value);
        }

        public static readonly BindableProperty ProgressProperty =
            BindableProperty.Create(nameof(Progress),
                typeof(double),
                typeof(Frame),
                defaultValue: (double)0,
                defaultBindingMode: BindingMode.OneWay);

        public double Progress
        {
            get => (double)GetValue(ProgressProperty);
            set => SetValue(ProgressProperty, value);
        }

        public static readonly BindableProperty ProgressBarBackGroundColorProperty =
            BindableProperty.Create(nameof(ProgressBarBackGroundColor),
                typeof(Color),
                typeof(ProgressBar),
                defaultValue: default(Color),
                defaultBindingMode: BindingMode.OneWay);

        public Color ProgressBarBackGroundColor
        {
            get => (Color)GetValue(ProgressBarBackGroundColorProperty);
            set => SetValue(ProgressBarBackGroundColorProperty, value);
        }
        public static BindableProperty ApplyNewProgressStyleProperty =
           BindableProperty.Create(
               nameof(ApplyNewProgressStyle),
               typeof(bool),
               typeof(ProgressBar),
               defaultValue: default(bool),
               defaultBindingMode: BindingMode.TwoWay
           );
        public bool ApplyNewProgressStyle
        {
            get { return (bool)GetValue(ApplyNewProgressStyleProperty); }
            set { SetValue(ApplyNewProgressStyleProperty, value); }
        }
    }
}