﻿using CommunityToolkit.Maui.Views;
using CommunityToolkit.Maui.Core;
using System.Collections.ObjectModel;

namespace MobileUI2.Components
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class UpShop_SignatureForm : ContentView
    {
        public ObservableCollection<IDrawingLine> Lines { get; set; } = new ObservableCollection<IDrawingLine>();

        public UpShop_SignatureForm()
        {
            InitializeComponent();
            MessagingCenter.Subscribe<object>(this, "SignaturepadAppear", (x) => 
            { 
                if(signaturepad !=null)
                    Lines.Clear();
            });
        }

        private byte[] GetImageStreamAsBytes(Stream input)
        {
            var buffer = new byte[16 * 1024];
            using (MemoryStream ms = new MemoryStream())
            {
                int read;
                while ((read = input.Read(buffer, 0, buffer.Length)) > 0)
                {
                    ms.Write(buffer, 0, read);
                }
                return ms.ToArray();
            }
        }

        private async void signaturepad_StrokeCompleted(object sender, System.EventArgs e)
        {
            try
            {
                var stream = await DrawingView.GetImageStream(Lines, new Size(400, 200), Colors.Gray);
              //  var stream =  signaturepad.GetImageStream(image, strokeColor: Colors.Black, fillColor: Colors.White);
                if (stream != null)
                {
                    MessagingCenter.Send<object, byte[]>(this, "SignatureImage", GetImageStreamAsBytes(stream));
                    stream.Dispose();
                }
            }
            catch (Exception ex)
            {
            }
        }
        private async void DrawingView_DrawingLineCompleted(object sender, DrawingLineCompletedEventArgs e)
        {
            //var stream = await e.LastDrawingLine.GetImageStream(400, 200, Colors.Gray.AsPaint());
            //drawingImage.Source = ImageSource.FromStream(() => stream);
        }
    }
}