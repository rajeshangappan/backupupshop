using CommunityToolkit.Maui.Behaviors;

namespace MobileUI2.Components
{
    public partial class CustomButton : ContentView
    {

        public CustomButton()
        {
            InitializeComponent();
            var touchBehavior = new TouchBehavior
            {
                DefaultAnimationDuration = 250,
                DefaultAnimationEasing = Easing.CubicInOut,
                PressedOpacity = 1,
                PressedScale = 1
            };

           innerFrame.Behaviors.Add(touchBehavior);
        }
        #region Bindable Properties       

        #region Text 
        public static BindableProperty TextProperty =
           BindableProperty.Create(
               nameof(Text),
               typeof(string),
               typeof(Entry),
               defaultValue: default(string),
               defaultBindingMode: BindingMode.TwoWay
           );

        public string Text
        {
            get { return (string)GetValue(TextProperty); }
            set { SetValue(TextProperty, value); }
        }
        public static BindableProperty ApplyNewBtnStyleProperty =
           BindableProperty.Create(
               nameof(ApplyNewBtnStyle),
               typeof(bool),
               typeof(Label),
               defaultValue: default(bool),
               defaultBindingMode: BindingMode.TwoWay
           );
        public bool ApplyNewBtnStyle
        {
            get { return (bool)GetValue(ApplyNewBtnStyleProperty); }
            set { SetValue(ApplyNewBtnStyleProperty, value); }
        }
        #endregion

        #region Icon 
        public static BindableProperty IconProperty =
           BindableProperty.Create(
               nameof(Icon),
               typeof(string),
               typeof(Label),
               defaultValue: default(string),
               defaultBindingMode: BindingMode.TwoWay
           );

        public string Icon
        {
            get { return (string)GetValue(IconProperty); }
            set { SetValue(IconProperty, value); }
        }
        #endregion

        #region ButtonClickCommand 
        public static BindableProperty ButtonClickCommandProperty =
           BindableProperty.Create(
               nameof(ButtonClickCommand),
               typeof(Command),
               typeof(Frame),
               defaultValue: default(Command),
               defaultBindingMode: BindingMode.OneWay
           );

        public Command ButtonClickCommand
        {
            get { return (Command)GetValue(ButtonClickCommandProperty); }
            set { SetValue(ButtonClickCommandProperty, value); }
        }
        #endregion
        public static BindableProperty CloseCommandProperty =
               BindableProperty.Create(
                   nameof(CloseCommand),
                   typeof(Command),
                   typeof(Label),
                   defaultValue: default(Command),
                   defaultBindingMode: BindingMode.OneWay
               );

        public Command CloseCommand
        {
            get { return (Command)GetValue(CloseCommandProperty); }
            set { SetValue(CloseCommandProperty, value); }
        }
        public static readonly BindableProperty BackGroundColorProperty =
           BindableProperty.Create(nameof(BackGroundColor),
        typeof(Color),
        typeof(StackLayout),
        defaultValue: default(Color),
        defaultBindingMode: BindingMode.OneWay);

        public Color BackGroundColor
        {
            get => (Color)GetValue(BackGroundColorProperty);
            set => SetValue(BackGroundColorProperty, value);
        }

        public static readonly BindableProperty ButtonBackGroundColorProperty =
           BindableProperty.Create(nameof(ButtonBackGroundColor),
        typeof(Color),
        typeof(Frame),
        defaultValue: default(Color),
        defaultBindingMode: BindingMode.OneWay);

        public Color ButtonBackGroundColor
        {
            get => (Color)GetValue(ButtonBackGroundColorProperty);
            set => SetValue(ButtonBackGroundColorProperty, value);
        }

        public static readonly BindableProperty FrameFlowDirectionProperty =
         BindableProperty.Create(nameof(FrameFlowDirection),
         typeof(FlowDirection),
         typeof(Frame),
         defaultValue: default(FlowDirection),
         defaultBindingMode: BindingMode.TwoWay);

        public FlowDirection FrameFlowDirection
        {
            get => (FlowDirection)GetValue(FrameFlowDirectionProperty);
            set => SetValue(FrameFlowDirectionProperty, value);
        }

        public static readonly BindableProperty TextColorProperty =
               BindableProperty.Create(nameof(TextColor),
            typeof(Color),
            typeof(Label),
            defaultValue: default(Color),
            defaultBindingMode: BindingMode.OneWay);

        public Color TextColor
        {
            get => (Color)GetValue(TextColorProperty);
            set => SetValue(TextColorProperty, value);
        }

        public static readonly BindableProperty FramePaddingProperty =
              BindableProperty.Create(nameof(FramePadding),
           typeof(Thickness),
           typeof(Frame),
           defaultValue: new Thickness(0, 0, 0, 0),
           defaultBindingMode: BindingMode.OneWay);

        public Thickness FramePadding
        {
            get => (Thickness)GetValue(FramePaddingProperty);
            set => SetValue(FramePaddingProperty, value);
        }


        public static readonly BindableProperty BorderColorProperty =
                BindableProperty.Create(nameof(BorderColor),
                typeof(Color),
                typeof(Label),
                defaultValue: Colors.Transparent,
                defaultBindingMode: BindingMode.OneWay);

        public Color BorderColor
        {
            get => (Color)GetValue(BorderColorProperty);
            set => SetValue(BorderColorProperty, value);
        }

        public static readonly BindableProperty CornerRadiusProperty =
            BindableProperty.Create(nameof(CornerRadius),
                typeof(int),
                typeof(Frame),
                defaultValue: 20,
                defaultBindingMode: BindingMode.OneWay);

        public int CornerRadius
        {
            get => (int)GetValue(CornerRadiusProperty);
            set => SetValue(CornerRadiusProperty, value);
        }

        public static readonly BindableProperty ShowCloseIconProperty =
            BindableProperty.Create(nameof(ShowCloseIcon),
                typeof(bool),
                typeof(Label),
                defaultValue: false,
                defaultBindingMode: BindingMode.TwoWay);

        public bool ShowCloseIcon
        {
            get => (bool)GetValue(ShowCloseIconProperty);
            set => SetValue(ShowCloseIconProperty, value);
        }


        public static readonly BindableProperty EnableButtonProperty =
            BindableProperty.Create(nameof(EnableButton),
                typeof(bool),
                typeof(Frame),
                defaultValue: true,
                defaultBindingMode: BindingMode.TwoWay);

        public bool EnableButton
        {
            get => (bool)GetValue(EnableButtonProperty);
            set => SetValue(EnableButtonProperty, value);
        }
        public static readonly BindableProperty ShowSyncIconProperty =
          BindableProperty.Create(nameof(ShowSyncIcon),
              typeof(bool),
              typeof(Label),
              defaultValue: false,
              defaultBindingMode: BindingMode.TwoWay);

        public bool ShowSyncIcon
        {
            get => (bool)GetValue(ShowSyncIconProperty);
            set => SetValue(ShowSyncIconProperty, value);
        }

        public static BindableProperty SyncCommandProperty =
              BindableProperty.Create(
                  nameof(SyncCommand),
                  typeof(Command),
                  typeof(Label),
                  defaultValue: default(Command),
                  defaultBindingMode: BindingMode.OneWay
              );

        public Command SyncCommand
        {
            get { return (Command)GetValue(SyncCommandProperty); }
            set { SetValue(SyncCommandProperty, value); }
        }
        #endregion
        //public CustomButton()
        //{
        //	InitializeComponent();
        //}
    }
}