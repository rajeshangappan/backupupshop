﻿namespace MobileUI2.Components
{
    public partial class UpShop_TabletTableHeader : ContentView
    {
        public UpShop_TabletTableHeader()
        {
            InitializeComponent();
        }

        // Define the bindable property for CustomColumnDefinitions
        public static readonly BindableProperty CustomColumnDefinitionsProperty =
            BindableProperty.Create(
                nameof(CustomColumnDefinitions),
                typeof(ColumnDefinitionCollection),
                typeof(Grid),
                new ColumnDefinitionCollection
                {
                new ColumnDefinition { Width = new GridLength(0.4, GridUnitType.Star) },
                new ColumnDefinition { Width = new GridLength(0.3, GridUnitType.Star) },
                new ColumnDefinition { Width = new GridLength(0.3, GridUnitType.Star) }
                });

        // Property to access CustomColumnDefinitions
        public ColumnDefinitionCollection CustomColumnDefinitions
        {
            get => (ColumnDefinitionCollection)GetValue(CustomColumnDefinitionsProperty);
            set => SetValue(CustomColumnDefinitionsProperty, value);
        }

        //Primary Column
        public static BindableProperty PrimaryColumnHeaderTextProperty =
          BindableProperty.Create(
              nameof(PrimaryColumnHeaderText),
              typeof(string),
              typeof(Label),
              defaultValue: default(string),
              defaultBindingMode: BindingMode.TwoWay
          );
        public string PrimaryColumnHeaderText
        {
            get { return (string)GetValue(PrimaryColumnHeaderTextProperty); }
            set { SetValue(PrimaryColumnHeaderTextProperty, value); }
        }

        public static BindableProperty SecondColumnHeaderTextProperty =
         BindableProperty.Create(
             nameof(SecondColumnHeaderText),
             typeof(string),
             typeof(Label),
             defaultValue: default(string),
             defaultBindingMode: BindingMode.TwoWay
         );
        public string SecondColumnHeaderText
        {
            get { return (string)GetValue(SecondColumnHeaderTextProperty); }
            set { SetValue(SecondColumnHeaderTextProperty, value); }
        }

        public static BindableProperty ThirdColumnHeaderTextProperty =
       BindableProperty.Create(
           nameof(ThirdColumnHeaderText),
           typeof(string),
           typeof(Label),
           defaultValue: default(string),
           defaultBindingMode: BindingMode.TwoWay
       );
        public string ThirdColumnHeaderText
        {
            get { return (string)GetValue(ThirdColumnHeaderTextProperty); }
            set { SetValue(ThirdColumnHeaderTextProperty, value); }
        }

        public static BindableProperty ShowCheckboxColumnProperty =
        BindableProperty.Create(
            nameof(ShowCheckboxColumn),
            typeof(bool),
            typeof(Label),
            defaultValue: false,
            defaultBindingMode: BindingMode.TwoWay);

        public bool ShowCheckboxColumn
        {
            get { return (bool)GetValue(ShowCheckboxColumnProperty); }
            set { SetValue(ShowCheckboxColumnProperty, value); }
        }

        public static BindableProperty ShowSecondColumnHeaderProperty =
       BindableProperty.Create(
           nameof(ShowSecondColumnHeader),
           typeof(bool),
           typeof(Label),
           defaultValue: false,
           defaultBindingMode: BindingMode.TwoWay);

        public bool ShowSecondColumnHeader
        {
            get { return (bool)GetValue(ShowSecondColumnHeaderProperty); }
            set { SetValue(ShowSecondColumnHeaderProperty, value); }
        }

        public static BindableProperty SecondColumnHorizontalAlignmentProperty =
     BindableProperty.Create(
         nameof(SecondColumnHorizontalAlignment),
         typeof(LayoutOptions),
         typeof(Label),
         defaultValue: LayoutOptions.Center,
         defaultBindingMode: BindingMode.TwoWay);

        public LayoutOptions SecondColumnHorizontalAlignment
        {
            get { return (LayoutOptions)GetValue(SecondColumnHorizontalAlignmentProperty); }
            set { SetValue(SecondColumnHorizontalAlignmentProperty, value); }
        }

        public static BindableProperty Column1Property =
    BindableProperty.Create(
             nameof(Column1),
             typeof(GridLength),
             typeof(Grid),
             defaultValue: new GridLength(0),
             defaultBindingMode: BindingMode.TwoWay
         );

        public GridLength Column1
        {
            get { return (GridLength)GetValue(Column1Property); }
            set { SetValue(Column1Property, value); }
        }

        public static BindableProperty Column2Property =
    BindableProperty.Create(
             nameof(Column2),
             typeof(GridLength),
             typeof(Grid),
             defaultValue: new GridLength(0),
             defaultBindingMode: BindingMode.TwoWay
         );

        public GridLength Column2
        {
            get { return (GridLength)GetValue(Column2Property); }
            set { SetValue(Column2Property, value); }
        }

        public static BindableProperty Column3Property =
    BindableProperty.Create(
             nameof(Column3),
             typeof(GridLength),
             typeof(Grid),
             defaultValue: new GridLength(0),
             defaultBindingMode: BindingMode.TwoWay
         );
        private ColumnDefinitionCollection _customColumnDefinitions;

        public GridLength Column3
        {
            get { return (GridLength)GetValue(Column3Property); }
            set { SetValue(Column3Property, value); }
        }
    }
}