﻿using System.Globalization;
using System.Windows.Input;

namespace MobileUI2.Components
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class UpShop_TabletCard : ContentView
    {
        public UpShop_TabletCard()
        {
            InitializeComponent();
        }

        public static BindableProperty ShowIconsProperty =
        BindableProperty.Create(
            nameof(ShowIcons),
            typeof(bool),
            typeof(StackLayout),
            defaultValue: false,
            defaultBindingMode: BindingMode.TwoWay
            );
        public bool ShowIcons
        {
            get { return (bool)GetValue(ShowIconsProperty); }
            set { SetValue(ShowIconsProperty, value); }
        }

        public static BindableProperty ShowCoreIconProperty =
        BindableProperty.Create(
            nameof(ShowCoreIcon),
            typeof(bool),
            typeof(Label),
            defaultValue: false,
            defaultBindingMode: BindingMode.TwoWay
            );
        public bool ShowCoreIcon
        {
            get { return (bool)GetValue(ShowCoreIconProperty); }
            set { SetValue(ShowCoreIconProperty, value); }
        }

        public static BindableProperty ShowPromotionIconProperty =
        BindableProperty.Create(
            nameof(ShowPromotionIcon),
            typeof(bool),
            typeof(Label),
            defaultValue: false,
            defaultBindingMode: BindingMode.TwoWay
            );
        public bool ShowPromotionIcon
        {
            get { return (bool)GetValue(ShowPromotionIconProperty); }
            set { SetValue(ShowPromotionIconProperty, value); }
        }

        public static BindableProperty ShowThirdColumnTextProperty =
        BindableProperty.Create(
          nameof(ShowThirdColumnText),
          typeof(bool),
          typeof(UpShop_TabletCard),
          defaultValue: false,
          defaultBindingMode: BindingMode.TwoWay
        );

        public bool ShowThirdColumnText
        {
            get { return (bool)GetValue(ShowThirdColumnTextProperty); }
            set { SetValue(ShowThirdColumnTextProperty, value); }
        }

        public static BindableProperty ShowPrimarySubColumnTextProperty =
        BindableProperty.Create(
            nameof(ShowPrimarySubColumnText),
            typeof(bool),
            typeof(UpShop_TabletCard),
            defaultValue: false,
            defaultBindingMode: BindingMode.TwoWay
        );
        public bool ShowPrimarySubColumnText
        {
            get { return (bool)GetValue(ShowPrimarySubColumnTextProperty); }
            set { SetValue(ShowPrimarySubColumnTextProperty, value); }
        }

        public static BindableProperty PrimarySubColumnTextProperty =
        BindableProperty.Create(
            nameof(PrimarySubColumnText),
            typeof(string),
            typeof(Label),
            defaultValue: default(string),
            defaultBindingMode: BindingMode.TwoWay
        );
        public string PrimarySubColumnText
        {
            get { return (string)GetValue(PrimarySubColumnTextProperty); }
            set { SetValue(PrimarySubColumnTextProperty, value); }
        }
        public static BindableProperty ShowCheckboxProperty =
        BindableProperty.Create(
             nameof(ShowCheckbox),
             typeof(bool),
             typeof(Label),
             defaultValue: false,
             defaultBindingMode: BindingMode.TwoWay);

        public bool ShowCheckbox
        {
            get { return (bool)GetValue(ShowCheckboxProperty); }
            set { SetValue(ShowCheckboxProperty, value); }
        }

        public static BindableProperty CheckBoxCommandProperty =
           BindableProperty.Create(
               nameof(CheckBoxCommand),
               typeof(ICommand),
               typeof(Label),
               defaultBindingMode: BindingMode.TwoWay);

        public ICommand CheckBoxCommand
        {
            get { return (ICommand)GetValue(CheckBoxCommandProperty); }
            set { SetValue(CheckBoxCommandProperty, value); }
        }
        //Numeric Stepper Entry

        public static BindableProperty ShowNumericStepperEntryProperty = BindableProperty.Create(nameof(ShowNumericStepperEntry),
            typeof(bool),
            typeof(StackLayout),
            defaultValue: false, defaultBindingMode: BindingMode.TwoWay);
        public bool ShowNumericStepperEntry
        {
            get { return (bool)GetValue(ShowNumericStepperEntryProperty); }
            set { SetValue(ShowNumericStepperEntryProperty, value); }
        }
        public static BindableProperty NumericStepperEntryEnabledProperty = BindableProperty.Create(nameof(NumericStepperEntryEnabled), typeof(bool), typeof(Entry), defaultValue: true, defaultBindingMode: BindingMode.TwoWay);
        public bool NumericStepperEntryEnabled
        {
            get { return (bool)GetValue(NumericStepperEntryEnabledProperty); }
            set { SetValue(NumericStepperEntryEnabledProperty, value); }
        }
        public static BindableProperty NumericStepperEntryProperty =
                   BindableProperty.Create(nameof(NumericStepperEntry),
                       typeof(string), typeof(Entry),
                       defaultValue: string.Empty, defaultBindingMode: BindingMode.TwoWay);

        public string NumericStepperEntry
        {
            get { return (string)GetValue(NumericStepperEntryProperty); }
            set { SetValue(NumericStepperEntryProperty, value); }
        }


        public static BindableProperty EntryMaxLengthProperty =
         BindableProperty.Create(nameof(EntryMaxLength),
             typeof(int), typeof(Entry),
             defaultValue: (int)1000, defaultBindingMode: BindingMode.TwoWay);

        public int EntryMaxLength
        {
            get { return (int)GetValue(EntryMaxLengthProperty); }
            set { SetValue(EntryMaxLengthProperty, value); }
        }

        public static BindableProperty EntryWidthRequestProperty =
       BindableProperty.Create(nameof(EntryWidthRequest),
           typeof(int), typeof(Entry),
           defaultValue: (int)45, defaultBindingMode: BindingMode.TwoWay);

        public int EntryWidthRequest
        {
            get { return (int)GetValue(EntryWidthRequestProperty); }
            set { SetValue(EntryWidthRequestProperty, value); }
        }

        public static BindableProperty IsCheckedProperty =
          BindableProperty.Create(
              nameof(IsChecked),
              typeof(bool),
              typeof(UpShop_TabletCard),
              defaultValue: false,
              defaultBindingMode: BindingMode.TwoWay);

        public bool IsChecked
        {
            get { return (bool)GetValue(IsCheckedProperty); }
            set { SetValue(IsCheckedProperty, value); }
        }
        public static BindableProperty ShowNumericStepperLabelTextProperty =
        BindableProperty.Create(
            nameof(ShowNumericStepperLabelText),
            typeof(bool),
            typeof(Label),
            defaultValue: false,
            defaultBindingMode: BindingMode.TwoWay
        );
        public bool ShowNumericStepperLabelText
        {
            get { return (bool)GetValue(ShowNumericStepperLabelTextProperty); }
            set { SetValue(ShowNumericStepperLabelTextProperty, value); }
        }
        public static BindableProperty NumericStepperLabelTextProperty =
       BindableProperty.Create(
           nameof(NumericStepperLabelText),
           typeof(string),
           typeof(Label),
           defaultValue: default(string),
           defaultBindingMode: BindingMode.TwoWay
       );

        public string NumericStepperLabelText
        {
            get { return (string)GetValue(NumericStepperLabelTextProperty); }
            set { SetValue(NumericStepperLabelTextProperty, value); }
        }

        public static BindableProperty DisbledEntryTextProperty =
          BindableProperty.Create(
              nameof(DisbledEntryText),
              typeof(string),
              typeof(Label),
              defaultValue: default(string),
              defaultBindingMode: BindingMode.TwoWay
          );

        public string DisbledEntryText
        {
            get { return (string)GetValue(DisbledEntryTextProperty); }
            set { SetValue(DisbledEntryTextProperty, value); }
        }
        public static BindableProperty ShowDisbledEntryProperty =
          BindableProperty.Create(
              nameof(ShowDisbledEntry),
              typeof(bool),
              typeof(StackLayout),
              defaultValue: false,
              defaultBindingMode: BindingMode.TwoWay
          );

        public bool ShowDisbledEntry
        {
            get { return (bool)GetValue(ShowDisbledEntryProperty); }
            set { SetValue(ShowDisbledEntryProperty, value); }
        }
        //title text
        public static BindableProperty PrimaryColumnTextProperty =
          BindableProperty.Create(
              nameof(PrimaryColumnText),
              typeof(string),
              typeof(Label),
              defaultValue: default(string),
              defaultBindingMode: BindingMode.TwoWay
          );
        public string PrimaryColumnText
        {
            get { return (string)GetValue(PrimaryColumnTextProperty); }
            set { SetValue(PrimaryColumnTextProperty, value); }
        }

        public static BindableProperty SecondColumnTextProperty =
         BindableProperty.Create(
             nameof(SecondColumnText),
             typeof(string),
             typeof(Label),
             defaultValue: default(string),
             defaultBindingMode: BindingMode.TwoWay
         );
        public string SecondColumnText
        {
            get { return (string)GetValue(SecondColumnTextProperty); }
            set { SetValue(SecondColumnTextProperty, value); }
        }

        public static BindableProperty ThirdColumnTextProperty =
       BindableProperty.Create(
           nameof(ThirdColumnText),
           typeof(string),
           typeof(Label),
           defaultValue: default(string),
           defaultBindingMode: BindingMode.TwoWay
       );
        public string ThirdColumnText
        {
            get { return (string)GetValue(ThirdColumnTextProperty); }
            set { SetValue(ThirdColumnTextProperty, value); }
        }
        public static BindableProperty AllowDecimalProperty =
         BindableProperty.Create(
             nameof(AllowDecimal),
             typeof(bool),
             typeof(UpShop_TabletCard),
             defaultValue: false,
             defaultBindingMode: BindingMode.TwoWay);

        public bool AllowDecimal
        {
            get { return (bool)GetValue(AllowDecimalProperty); }
            set { SetValue(AllowDecimalProperty, value); }
        }

        private void TapGestureRecognizer_Tapped_1(object sender, EventArgs e)
        {
            try
            {
                if (double.TryParse(NumericStepperEntry, NumberStyles.Float, CultureInfo.CurrentCulture, out double value)
                    && value != 0 && value <= 999)
                {
                    StepperEntry.Text = (--value).ToString(CultureInfo.CurrentCulture);
                }
            }
            catch (Exception)
            {
            }
        }

        private void TapGestureRecognizer_Tapped_2(object sender, EventArgs e)
        {
            try
            {
                if (double.TryParse(NumericStepperEntry, NumberStyles.Float, CultureInfo.CurrentCulture, out double value)
                    && value >= 0 && value < 999)
                {
                    StepperEntry.Text = (++value).ToString(CultureInfo.CurrentCulture);
                }
            }
            catch (Exception)
            {
            }
        }

        private void TapGestureRecognizer_Tapped(object sender, EventArgs e)
        {
            if (IsChecked)
            {
                IsChecked = false;
                checkBox.Text = "\uf0c8";
                checkBox.SetDynamicResource(Label.TextColorProperty, "BackgroundColor");
                checkBox.SetDynamicResource(Label.StyleProperty, "FontAwesomeLightStyle");
            }
            else
            {
                IsChecked = true;
                checkBox.Text = "\uf14a";
                checkBox.SetDynamicResource(Label.TextColorProperty, "BackgroundColor");
                checkBox.SetDynamicResource(Label.StyleProperty, "FontAwesomeSolidStyle");
            }
            MessagingCenter.Send(this, "valueChanged", IsChecked);

        }

        public static BindableProperty SecondColumnHorizontalAlignmentProperty =
        BindableProperty.Create(
        nameof(SecondColumnHorizontalAlignment),
        typeof(LayoutOptions),
        typeof(Label),
        defaultValue: LayoutOptions.Center,
        defaultBindingMode: BindingMode.TwoWay);

        public LayoutOptions SecondColumnHorizontalAlignment
        {
            get { return (LayoutOptions)GetValue(SecondColumnHorizontalAlignmentProperty); }
            set { SetValue(SecondColumnHorizontalAlignmentProperty, value); }
        }
    }
}