﻿using Scandit.DataCapture.Barcode.Capture;
using Scandit.DataCapture.Core.Capture;
using System.Windows.Input;
using ZXing.Net.Maui.Controls;



namespace MobileUI2.Components
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class UpShop_Scanner : ContentView
    {
        public UpShop_Scanner()
        {
            InitializeComponent();
        }
        protected override void OnParentSet()
        {
            base.OnParentSet();

            scanner.Options = new ZXing.Net.Maui.BarcodeReaderOptions
            {
              Formats = ZXing.Net.Maui.BarcodeFormat.Ean13 | 
              ZXing.Net.Maui.BarcodeFormat.Code128 |
              ZXing.Net.Maui.BarcodeFormat.Code39 |
              ZXing.Net.Maui.BarcodeFormat.Code93 |
              ZXing.Net.Maui.BarcodeFormat.Code128 |
              ZXing.Net.Maui.BarcodeFormat.Code39 |
              ZXing.Net.Maui.BarcodeFormat.Code39 |
              ZXing.Net.Maui.BarcodeFormat.UpcA |
              ZXing.Net.Maui.BarcodeFormat.Code39 |
              ZXing.Net.Maui.BarcodeFormat.DataMatrix |
              ZXing.Net.Maui.BarcodeFormat.Code39 |
              ZXing.Net.Maui.BarcodeFormat.UpcEanExtension |
              ZXing.Net.Maui.BarcodeFormat.Pdf417 |
              ZXing.Net.Maui.BarcodeFormat.Code39 |
              ZXing.Net.Maui.BarcodeFormat.Aztec |
              ZXing.Net.Maui.BarcodeFormat.Code39 |
              ZXing.Net.Maui.BarcodeFormat.Code39 |
              ZXing.Net.Maui.BarcodeFormat.Itf |
              ZXing.Net.Maui.BarcodeFormat.Msi |
              ZXing.Net.Maui.BarcodeFormat.Code39 |
              ZXing.Net.Maui.BarcodeFormat.Rss14 |
              ZXing.Net.Maui.BarcodeFormat.UpcA,

                AutoRotate = true,
                Multiple = true,
                TryHarder = true,
                TryInverted = true
            };
        }

         void ScanPage_OnScanResult(ZXing.Result result)
        {
            try
            {
                MainThread.BeginInvokeOnMainThread(async() =>
                {
                    await SendScanResult(result.Text);

                });

            }
            catch (Exception)
            {

            }
        }

        public void SetScanner(bool ScanditEnabled)
        {
            if (ScanditEnabled)
            {
                ScannerGrid.Children.Remove(scanner);
                ScannerGrid.Children.Remove(topLeftUpperLine);
                ScannerGrid.Children.Remove(topLeftLowerLine);
                ScannerGrid.Children.Remove(topRightUpperLine);
                ScannerGrid.Children.Remove(topRightLowerLine);
                ScannerGrid.Children.Remove(bottomRightUpperLine);
                ScannerGrid.Children.Remove(bottomRightLowerLine);
                ScannerGrid.Children.Remove(bottomLeftUpperLine);
                ScannerGrid.Children.Remove(bottomLeftLowerLine);
            }
            else
            {
                ScannerGrid.Children.Remove(ScanditDataCaptureView);
            }
        }


        #region Bindable properties
        public static BindableProperty StartScanProperty =
          BindableProperty.Create(
              nameof(StartScan),
              typeof(bool),
              typeof(CameraBarcodeReaderView),
              defaultValue: false,
              defaultBindingMode: BindingMode.TwoWay
          );

        public bool StartScan
        {
            get { return (bool)GetValue(StartScanProperty); }
            set { SetValue(StartScanProperty, value); }
        }

        public static BindableProperty StartAnalyzingProperty =
         BindableProperty.Create(
             nameof(StartAnalyzing),
             typeof(bool),
             typeof(CameraBarcodeReaderView),
             defaultValue: false,
             defaultBindingMode: BindingMode.TwoWay
         );

        public bool StartAnalyzing
        {
            get { return (bool)GetValue(StartAnalyzingProperty); }
            set { SetValue(StartAnalyzingProperty, value); }
        }

        public static BindableProperty DataCaptureContextProperty = BindableProperty.Create(
            nameof(DataCaptureContext),
            typeof(DataCaptureContext),
            typeof(UpShop_Scanner),
            defaultBindingMode: BindingMode.TwoWay
            );

        public DataCaptureContext DataCaptureContext
        {
            get { return (DataCaptureContext)GetValue(DataCaptureContextProperty); }
            set { SetValue(DataCaptureContextProperty, value); }
        }

        public static BindableProperty BarcodeTrackingProperty = BindableProperty.Create(
            nameof(BarcodeTracking),
            typeof(BarcodeCapture),
            typeof(UpShop_Scanner),
            defaultBindingMode: BindingMode.TwoWay
            );

        public BarcodeCapture BarcodeTracking
        {
            get { return (BarcodeCapture)GetValue(BarcodeTrackingProperty); }
            set { SetValue(BarcodeTrackingProperty, value); }
        }


        public static BindableProperty ScanResultCommandProperty =
          BindableProperty.Create(
              nameof(ScanResultCommand),
              typeof(ICommand),
              typeof(UpShop_Scanner),
              defaultBindingMode: BindingMode.TwoWay);

        public ICommand ScanResultCommand
        {
            get { return (ICommand)GetValue(ScanResultCommandProperty); }
            set { SetValue(ScanResultCommandProperty, value); }
        }
        public static BindableProperty CloseCommandProperty =
         BindableProperty.Create(
             nameof(CloseCommand),
             typeof(ICommand),
             typeof(Label),
             defaultBindingMode: BindingMode.TwoWay);

        public ICommand CloseCommand
        {
            get { return (ICommand)GetValue(CloseCommandProperty); }
            set { SetValue(CloseCommandProperty, value); }
        }
        #endregion
        CancellationTokenSource cts = null;
        public async Task SendScanResult(string text)
        {
            try
            {
                if (ScanResultCommand != null)
                {
                    if (cts != null) cts.Cancel();
                    cts = new CancellationTokenSource();
                    var ctoken = cts.Token;

                    try
                    {
                        if (ctoken.IsCancellationRequested)
                            return;

                        if (ScanResultCommand.CanExecute(text))
                            ScanResultCommand?.Execute(text);
                    }
                    catch (OperationCanceledException)
                    {
                        // Expected
                    }
                }
            }
            catch (Exception ex)
            {

            }

        }

        private void scanner_BarcodesDetected(object sender, ZXing.Net.Maui.BarcodeDetectionEventArgs e)
        {

            try
            {

                var result = e.Results?.FirstOrDefault();
                if (result is null) return;

                Dispatcher.DispatchAsync(async () =>
                {
                    await SendScanResult(result.Value);
                });

                MainThread.BeginInvokeOnMainThread( () =>
                {

                });

            }
            catch (Exception)
            {

            }

        }
    }
}