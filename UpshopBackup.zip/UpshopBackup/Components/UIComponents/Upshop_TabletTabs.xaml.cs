﻿using Microsoft.Maui.Controls;
using System.Runtime.CompilerServices;

namespace MobileUI2.Components
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class Upshop_TabletTabs : ContentView
    {
        public Upshop_TabletTabs()
        {
            InitializeComponent();

        }
        public static BindableProperty Column1Property =
          BindableProperty.Create(
              nameof(Column1),
              typeof(GridLength),
              typeof(Grid),
              defaultValue: new GridLength(0),
              defaultBindingMode: BindingMode.TwoWay
          );

        public GridLength Column1
        {
            get { return (GridLength)GetValue(Column1Property); }
            set { SetValue(Column1Property, value); }
        }

        public static BindableProperty Column2Property =
         BindableProperty.Create(
             nameof(Column2),
             typeof(GridLength),
             typeof(Grid),
             defaultValue: new GridLength(0),
             defaultBindingMode: BindingMode.TwoWay
         );

        public GridLength Column2
        {
            get { return (GridLength)GetValue(Column2Property); }
            set { SetValue(Column2Property, value); }
        }
        public static BindableProperty Column3Property =
         BindableProperty.Create(
             nameof(Column3),
             typeof(GridLength),
             typeof(Grid),
             defaultValue: new GridLength(0),
             defaultBindingMode: BindingMode.TwoWay
         );

        public GridLength Column3
        {
            get { return (GridLength)GetValue(Column3Property); }
            set { SetValue(Column3Property, value); }
        }
        public static BindableProperty SelectedTabColorProperty =
       BindableProperty.Create(
           nameof(SelectedTabColor),
           typeof(Color),
           typeof(Grid),
           defaultValue: default(Color),
           defaultBindingMode: BindingMode.TwoWay
       );
        public Color SelectedTabColor
        {
            get { return (Color)GetValue(SelectedTabColorProperty); }
            set { SetValue(SelectedTabColorProperty, value); }
        }

        // Define the bindable property for CustomColumnDefinitions
        public static readonly BindableProperty CustomColumnDefinitionsProperty =
            BindableProperty.Create(
                nameof(CustomColumnDefinitions),
                typeof(ColumnDefinitionCollection),
                typeof(Grid),
                new ColumnDefinitionCollection
                {
                new ColumnDefinition { Width = GridLength.Star },
                new ColumnDefinition { Width = GridLength.Star },
                new ColumnDefinition { Width = GridLength.Auto }
                });

        // Property to access CustomColumnDefinitions
        public ColumnDefinitionCollection CustomColumnDefinitions
        {
            get => (ColumnDefinitionCollection)GetValue(CustomColumnDefinitionsProperty);
            set => SetValue(CustomColumnDefinitionsProperty, value);
        }

        public static BindableProperty ShowAllColumnProperty =
      BindableProperty.Create(
          nameof(ShowAllColumn),
          typeof(bool),
          typeof(Upshop_TabletTabs),
          defaultValue: false,
          defaultBindingMode: BindingMode.TwoWay
      );

        public bool ShowAllColumn
        {
            get { return (bool)GetValue(ShowAllColumnProperty); }
            set { SetValue(ShowAllColumnProperty, value); }
        }

        public static BindableProperty SwitchEnabledProperty =
       BindableProperty.Create(
           nameof(SwitchEnabled),
           typeof(bool),
           typeof(Upshop_TabletTabs),
           defaultValue: true,
           defaultBindingMode: BindingMode.TwoWay
       );

        public bool SwitchEnabled
        {
            get { return (bool)GetValue(SwitchEnabledProperty); }
            set { SetValue(SwitchEnabledProperty, value); }
        }
        public static BindableProperty TabBackGroundColorProperty =
        BindableProperty.Create(
            nameof(TabBackGroundColor),
            typeof(Color),
            typeof(Grid),
            defaultValue: default(Color),
            defaultBindingMode: BindingMode.TwoWay
        );
        public Color TabBackGroundColor
        {
            get { return (Color)GetValue(TabBackGroundColorProperty); }
            set { SetValue(TabBackGroundColorProperty, value); }
        }
        public static BindableProperty SwichBackGroundColorProperty =
      BindableProperty.Create(
          nameof(SwichBackGroundColor),
          typeof(Color),
          typeof(Grid),
          defaultValue: default(Color),
          defaultBindingMode: BindingMode.TwoWay
      );
        public Color SwichBackGroundColor
        {
            get { return (Color)GetValue(SwichBackGroundColorProperty); }
            set { SetValue(SwichBackGroundColorProperty, value); }
        }

        public static BindableProperty Tab1TextProperty =
          BindableProperty.Create(
              nameof(Tab1Text),
              typeof(string),
              typeof(Label),
              defaultValue: default(string),
              defaultBindingMode: BindingMode.TwoWay
          );

        public string Tab1Text
        {
            get { return (string)GetValue(Tab1TextProperty); }
            set { SetValue(Tab1TextProperty, value); }
        }

        public static BindableProperty Tab2TextProperty =
          BindableProperty.Create(
              nameof(Tab2Text),
              typeof(string),
              typeof(Label),
              defaultValue: default(string),
              defaultBindingMode: BindingMode.TwoWay
          );

        public string Tab2Text
        {
            get { return (string)GetValue(Tab2TextProperty); }
            set { SetValue(Tab2TextProperty, value); }
        }

        public static BindableProperty Tab3TextProperty =
          BindableProperty.Create(
              nameof(Tab3Text),
              typeof(string),
              typeof(Label),
              defaultValue: default(string),
              defaultBindingMode: BindingMode.TwoWay
          );

        public string Tab3Text
        {
            get { return (string)GetValue(Tab3TextProperty); }
            set { SetValue(Tab3TextProperty, value); }
        }

        public static BindableProperty SelectTabProperty =
          BindableProperty.Create(
              nameof(SelectTab),
              typeof(int),
              typeof(Label),
              defaultValue: 1,
              defaultBindingMode: BindingMode.TwoWay, propertyChanged: valueChange
          );

        public int RunningFrameColumn
        {
            get { return (int)GetValue(RunningFrameColumnProperty); }
            set { SetValue(RunningFrameColumnProperty, value); }
        }

        public static BindableProperty RunningFrameColumnProperty =
          BindableProperty.Create(
              nameof(RunningFrameColumn),
              typeof(int),
              typeof(Frame),
              defaultValue: 0,
              defaultBindingMode: BindingMode.TwoWay
          );

        public static BindableProperty TabBorderColorProperty =
        BindableProperty.Create(
            nameof(TabBorderColor),
            typeof(Color),
            typeof(Grid),
            defaultValue: default(Color),
            defaultBindingMode: BindingMode.TwoWay
        );
        public Color TabBorderColor
        {
            get { return (Color)GetValue(TabBorderColorProperty); }
            set { SetValue(TabBorderColorProperty, value); }
        }
        private static void valueChange(BindableObject bindable, object oldValue, object newValue)
        {
            int input = (int)newValue;
        }
        protected override void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            base.OnPropertyChanged(propertyName);
            if (propertyName == "SelectTab")
            {
                if (SelectTab == 1)
                {
                    OnText1Tapped(null, null);
                }
                if (SelectTab == 2)
                {
                    OnText2Tapped(null, null);
                }
                else if (SelectTab == 3)
                {
                    OnText3Tapped(null, null);
                }
            }
        }
        public int SelectTab
        {
            get
            {
                var tab = (int)GetValue(SelectTabProperty);
                if (tab == 1)
                {
                    OnText1Tapped(null, null);
                }
                if (tab == 2)
                {
                    OnText2Tapped(null, null);
                }
                else if (tab == 3)
                {
                    OnText3Tapped(null, null);
                }
                return tab;
            }
            set
            {
                SetValue(SelectTabProperty, value);
            }
        }

        public static BindableProperty TabChangedCommandProperty =
           BindableProperty.Create(
               nameof(TabChangedCommand),
               typeof(Command),
               typeof(TapGestureRecognizer),
               defaultValue: default(Command),
               defaultBindingMode: BindingMode.OneWay
           );

        public Command TabChangedCommand
        {
            get { return (Command)GetValue(TabChangedCommandProperty); }
            set { SetValue(TabChangedCommandProperty, value); }
        }


        private void OnText1Tapped(object sender, EventArgs e)
        {
            Tab1Lbl.SetDynamicResource(Label.TextColorProperty, "UpshopWhite");
            Tab1Lbl.Style = (Style)Application.Current.Resources["LabelBoldStyle"];
            Tab2Lbl.SetDynamicResource(Label.TextColorProperty, "TextColor");
            Tab2Lbl.Style = (Style)Application.Current.Resources["LabelLightStyle"];
            Tab3Lbl.SetDynamicResource(Label.TextColorProperty, "TextColor");
            Tab3Lbl.Style = (Style)Application.Current.Resources["LabelLightStyle"];
            var column = Grid.GetColumn(TabletTabRunningFrame);
            if(column != 0)
            {
                Grid.SetColumn(TabletTabRunningFrame, 0);
            }            
            TabletTabRunningFrame.TranslateTo(0, 0);
            ChangeTab(1);
        }

        private void OnText2Tapped(object sender, EventArgs e)
        {
            Tab2Lbl.SetDynamicResource(Label.TextColorProperty, "UpshopWhite");
            Tab2Lbl.Style = (Style)Application.Current.Resources["LabelBoldStyle"];
            Tab1Lbl.SetDynamicResource(Label.TextColorProperty, "TextColor");
            Tab1Lbl.Style = (Style)Application.Current.Resources["LabelLightStyle"];
            Tab3Lbl.SetDynamicResource(Label.TextColorProperty, "TextColor");
            Tab3Lbl.Style = (Style)Application.Current.Resources["LabelLightStyle"];
            if (RunningFrameColumn == 1)
            {
                TabletTabRunningFrame.TranslateTo(0, 0);
            }
            else
            {
                if (TabletTabRunningFrame.Width > 0)
                {
                    TabletTabRunningFrame.TranslateTo(TabletTabRunningFrame.Width + TabletTabRunningFrame.Margin.Left, 0);
                }
                else
                {
                    Grid.SetColumn(TabletTabRunningFrame, 1);
                }
            }

            ChangeTab(2);
        }

        private void OnText3Tapped(object sender, EventArgs e)
        {
            Tab3Lbl.SetDynamicResource(Label.TextColorProperty, "UpshopWhite");
            Tab3Lbl.Style = (Style)Application.Current.Resources["LabelBoldStyle"];
            Tab2Lbl.SetDynamicResource(Label.TextColorProperty, "TextColor");
            Tab2Lbl.Style = (Style)Application.Current.Resources["LabelLightStyle"];
            Tab1Lbl.SetDynamicResource(Label.TextColorProperty, "TextColor");
            Tab1Lbl.Style = (Style)Application.Current.Resources["LabelLightStyle"];
            if (RunningFrameColumn == 1)
            {
                TabletTabRunningFrame.TranslateTo(TabletTabRunningFrame.Width, 0);
            }
            else
            {
                if (TabletTabRunningFrame.Width > 0)
                    TabletTabRunningFrame.TranslateTo(TabletTabRunningFrame.Width * 2, 0);
                else
                {
                    Grid.SetColumn(TabletTabRunningFrame, 2);
                }
            }

            ChangeTab(3);
        }
        CancellationTokenSource cts = null;
        private async void ChangeTab(int tabnumber)
        {
            try
            {
                if (TabChangedCommand != null)
                {
                    if (cts != null) cts.Cancel();
                    cts = new CancellationTokenSource();
                    var ctoken = cts.Token;

                    try
                    {
                        await Task.Delay(350, ctoken);

                        if (ctoken.IsCancellationRequested)
                            return;

                        if (TabChangedCommand.CanExecute(tabnumber))
                            TabChangedCommand?.Execute(tabnumber);
                    }
                    catch (OperationCanceledException)
                    {
                        // Expected
                    }
                }
            }
            catch (Exception ex)
            {

            }
        }
    }
}