﻿using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace MobileUI2.Components
{
    public class TaskResponseValues : CompNotifyPropertyChanged
    {
        private bool _isSelected;

        public int Id { get; set; }
        public string Text { get; set; }
        public bool IsSelected { get => _isSelected; set => SetAndRaisePropertyChanged(ref _isSelected, value); }
    }

    public class CompNotifyPropertyChanged : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;
        protected void SetAndRaisePropertyChanged<TRef>(
            ref TRef field, TRef value, [CallerMemberName] string propertyName = null)
        {
            field = value;
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        protected void SetAndRaisePropertyChangedIfDifferentValues<TRef>(
            ref TRef field, TRef value, [CallerMemberName] string propertyName = null)
            where TRef : class
        {
            if (field == null || !field.Equals(value))
            {
                SetAndRaisePropertyChanged(ref field, value, propertyName);
            }
        }

        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
