﻿namespace MobileUI2.Components
{
    public partial class UpShop_Entry : ContentView
    {
        public UpShop_Entry()
        {
            InitializeComponent();
            MyEntry.BackgroundColor = Colors.Transparent;
            //MyEntry.BorderColor = Colors.Transparent;
        }

        #region Bindable Properties
        #region Placeholder 
        public static BindableProperty PlaceholderProperty =
           BindableProperty.Create(
               nameof(Placeholder),
               typeof(string),
               typeof(Entry),
               defaultValue: default(string),
               defaultBindingMode: BindingMode.OneWay
           );

        public string Placeholder
        {
            get { return (string)GetValue(PlaceholderProperty); }
            set { SetValue(PlaceholderProperty, value); }
        }
        public static BindableProperty PlaceholderColorProperty =
          BindableProperty.Create(
              nameof(PlaceholderColor),
              typeof(Color),
              typeof(Entry),
              defaultValue:Colors.LightGray,
              defaultBindingMode: BindingMode.TwoWay
          );

        public Color PlaceholderColor
        {
            get { return (Color)GetValue(PlaceholderColorProperty); }
            set { SetValue(PlaceholderColorProperty, value); }
        }
        #endregion

        #region Text 
        public static BindableProperty TextProperty =
           BindableProperty.Create(
               nameof(Text),
               typeof(string),
               typeof(Entry),
               defaultValue: default(string),
               defaultBindingMode: BindingMode.TwoWay
           );

        public string Text
        {
            get { return (string)GetValue(TextProperty); }
            set { SetValue(TextProperty, value); }
        }
        #endregion

        #region Icon 
        public static BindableProperty IconProperty =
           BindableProperty.Create(
               nameof(Icon),
               typeof(string),
               typeof(Label),
               defaultValue: default(string),
               defaultBindingMode: BindingMode.TwoWay
           );

        public string Icon
        {
            get { return (string)GetValue(IconProperty); }
            set { SetValue(IconProperty, value); }
        }
        
        public static BindableProperty IconColorProperty =
          BindableProperty.Create(
              nameof(IconColor),
              typeof(Color),
              typeof(Label),
              defaultValue: Color.FromArgb("#666666"),
              defaultBindingMode: BindingMode.TwoWay
          );

        public Color IconColor
        {
            get { return (Color)GetValue(IconColorProperty); }
            set { SetValue(IconColorProperty, value); }
        }
        #endregion

        #region Keyboard 
        public static BindableProperty KeyboardProperty =
           BindableProperty.Create(
               nameof(Keyboard),
               typeof(Keyboard),
               typeof(Entry),
               defaultValue: Keyboard.Text,
               defaultBindingMode: BindingMode.TwoWay
           );

        public Keyboard Keyboard
        {
            get { return (Keyboard)GetValue(KeyboardProperty); }
            set { SetValue(KeyboardProperty, value); }
        }
        #endregion


        #endregion
    }
}