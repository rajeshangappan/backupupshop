﻿using System.Windows.Input;

namespace MobileUI2.Components
{
    public partial class UpShop_SearchBar : ContentView
    {
        CancellationTokenSource cts = null;

        public UpShop_SearchBar()
        {
            InitializeComponent();
        }

        private int _textChangedDelay = 350;

        public int TextChangedDelay
        {
            get { return _textChangedDelay; }
            set { _textChangedDelay = value; }
        }

        public static BindableProperty HeaderTextProperty =
           BindableProperty.Create(
               nameof(HeaderText),
               typeof(string),
               typeof(Label),
               defaultValue: default(string),
               defaultBindingMode: BindingMode.OneWay
           );

        public string HeaderText
        {
            get { return (string)GetValue(HeaderTextProperty); }
            set { SetValue(HeaderTextProperty, value); }
        }

        public static BindableProperty PlaceholderProperty =
           BindableProperty.Create(
               nameof(Placeholder),
               typeof(string),
               typeof(SearchBar),
               defaultValue: default(string),
               defaultBindingMode: BindingMode.OneWay
           );

        public string Placeholder
        {
            get { return (string)GetValue(PlaceholderProperty); }
            set { SetValue(PlaceholderProperty, value); }
        }

        public static BindableProperty TextProperty =
           BindableProperty.Create(
               nameof(Text),
               typeof(string),
               typeof(SearchBar),
               defaultValue: default(string),
               defaultBindingMode: BindingMode.TwoWay
           );

        public string Text
        {
            get { return (string)GetValue(TextProperty); }
            set { SetValue(TextProperty, value); }
        }

        public static BindableProperty InfoTextProperty =
               BindableProperty.Create(
                   nameof(InfoText),
                   typeof(string),
                   typeof(ContentView),
                   defaultValue: default(string),
                   defaultBindingMode: BindingMode.TwoWay
               );

        public string InfoText
        {
            get { return (string)GetValue(InfoTextProperty); }
            set { SetValue(InfoTextProperty, value); }
        }

        public static BindableProperty ShowInfoTextProperty =
          BindableProperty.Create(
              nameof(ShowInfoText),
              typeof(bool),
              typeof(ContentView),
              defaultValue: false,
              defaultBindingMode: BindingMode.TwoWay
          );

        public bool ShowInfoText
        {
            get { return (bool)GetValue(ShowInfoTextProperty); }
            set { SetValue(ShowInfoTextProperty, value); }
        }

        public static BindableProperty ShowLoadingIndicatorProperty =
          BindableProperty.Create(
              nameof(ShowLoadingIndicator),
              typeof(bool),
              typeof(ActivityIndicator),
              defaultValue: false,
              defaultBindingMode: BindingMode.TwoWay
          );

        public bool ShowLoadingIndicator
        {
            get { return (bool)GetValue(ShowLoadingIndicatorProperty); }
            set { SetValue(ShowLoadingIndicatorProperty, value); }
        }

        public static BindableProperty TextChangedCommandProperty =
           BindableProperty.Create(
               nameof(TextChangedCommand),
               typeof(ICommand),
               typeof(SearchBar),
               defaultValue: default(ICommand),
               defaultBindingMode: BindingMode.OneWay
           );

        public ICommand TextChangedCommand
        {
            get { return (ICommand)GetValue(TextChangedCommandProperty); }
            set { SetValue(TextChangedCommandProperty, value); }
        }

        public static BindableProperty SearchCommandProperty =
           BindableProperty.Create(
               nameof(SearchCommand),
               typeof(ICommand),
               typeof(SearchBar),
               defaultValue: default(ICommand),
               defaultBindingMode: BindingMode.OneWay
           );

        public ICommand SearchCommand
        {
            get { return (ICommand)GetValue(SearchCommandProperty); }
            set { SetValue(SearchCommandProperty, value); }
        }

        public static BindableProperty ItemSelectedCommandProperty =
           BindableProperty.Create(
               nameof(ItemSelectedCommand),
               typeof(ICommand),
               typeof(ListView),
               defaultValue: default(ICommand),
               defaultBindingMode: BindingMode.OneWay
           );

        public ICommand ItemSelectedCommand
        {
            get { return (ICommand)GetValue(ItemSelectedCommandProperty); }
            set { SetValue(ItemSelectedCommandProperty, value); }
        }

        public static readonly BindableProperty ItemsProperty =
                BindableProperty.Create(nameof(Items),
                    typeof(IEnumerable<SearchData>),
                    typeof(ListView),
                    new List<SearchData>());

        public IEnumerable<SearchData> Items
        {
            get { return (IEnumerable<SearchData>)GetValue(ItemsProperty); }
            set { SetValue(ItemsProperty, value); }
        }

        public static BindableProperty IsSearchDataVisibleProperty =
           BindableProperty.Create(
               nameof(IsSearchDataVisible),
               typeof(bool),
               typeof(ListView),
               defaultValue: default(bool),
               defaultBindingMode: BindingMode.OneWay
           );

        public bool IsSearchDataVisible
        {
            get { return (bool)GetValue(IsSearchDataVisibleProperty); }
            set { SetValue(IsSearchDataVisibleProperty, value); }
        }

        public static BindableProperty CountProperty =
           BindableProperty.Create(
               nameof(Count),
               typeof(int),
               typeof(Label),
               defaultValue: default(int),
               defaultBindingMode: BindingMode.OneWay
           );

        public int Count
        {
            get { return (int)GetValue(CountProperty); }
            set { SetValue(CountProperty, value); }
        }

        private void OnSearchTextChanged(object sender, TextChangedEventArgs e)
        {
            try
            {
                // Update the bound Text property
                Text = e.NewTextValue;

                // Execute the debounced TextChangedCommand
                if (TextChangedCommand != null)
                {
                    if (cts != null)
                    {
                        cts.Cancel();
                        cts.Dispose();
                    }

                    cts = new CancellationTokenSource();

                    Task.Delay(TextChangedDelay, cts.Token)
                        .ContinueWith(t =>
                        {
                            if (!t.IsCanceled && TextChangedCommand.CanExecute(e.NewTextValue))
                            {
                                Dispatcher.Dispatch(() =>
                                {
                                    TextChangedCommand.Execute(e.NewTextValue);
                                });
                            }
                        }, TaskScheduler.FromCurrentSynchronizationContext());
                }
            }
            catch (Exception ex)
            {
                // Log error if needed
                System.Diagnostics.Debug.WriteLine($"Search text changed error: {ex.Message}");
            }
        }

        private void OnSearchButtonPressed(object sender, EventArgs e)
        {
            try
            {
                // Execute the SearchCommand when search button is pressed
                if (SearchCommand != null && SearchCommand.CanExecute(Text))
                {
                    SearchCommand.Execute(Text);
                }
            }
            catch (Exception ex)
            {
                // Log error if needed
                System.Diagnostics.Debug.WriteLine($"Search button pressed error: {ex.Message}");
            }
        }

        public void UnfocusSearchBar()
        {
            searchBar?.Unfocus();
        }
    }
}
