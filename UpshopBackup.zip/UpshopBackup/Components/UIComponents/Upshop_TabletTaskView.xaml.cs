﻿using System.Runtime.CompilerServices;
using CommunityToolkit.Maui.Views;
using MobileUI2.Models.TaskActivities;

namespace MobileUI2.Components
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class Upshop_TabletTaskView : ContentView
    {
        private MediaElement _media;
        public Upshop_TabletTaskView()
        {
            InitializeComponent();
            MediaElement mediaElement=new MediaElement();
            _media=new MediaElement();
        }
    public static readonly BindableProperty MediaVisibleProperty =
        BindableProperty.Create(nameof(MediaVisible), typeof(bool), typeof(Upshop_TabletTaskView), false);

    public bool MediaVisible
    {
        get => (bool)GetValue(MediaVisibleProperty);
        set => SetValue(MediaVisibleProperty, value);
    }

        public static readonly BindableProperty TaskResponseProperty =
         BindableProperty.Create(nameof(TaskResponse),
             typeof(IEnumerable<TaskResponseValues>),
             typeof(StackLayout),
            new List<TaskResponseValues>());

        public IEnumerable<TaskResponseValues> TaskResponse
        {
            get => (IEnumerable<TaskResponseValues>)GetValue(TaskResponseProperty);
            set => SetValue(TaskResponseProperty, value);
        }



        public static readonly BindableProperty EnableButtonProperty =
          BindableProperty.Create(nameof(EnableButton),
              typeof(bool),
              typeof(Frame),
              defaultValue: false,
              defaultBindingMode: BindingMode.TwoWay);

        public bool EnableButton
        {
            get => (bool)GetValue(EnableButtonProperty);
            set => SetValue(EnableButtonProperty, value);
        }

        public static readonly BindableProperty ShowYesOrNoTaskProperty =
          BindableProperty.Create(nameof(ShowYesOrNoTask),
              typeof(bool),
              typeof(Frame),
              defaultValue: false,
              defaultBindingMode: BindingMode.TwoWay);

        public bool ShowYesOrNoTask
        {
            get => (bool)GetValue(ShowYesOrNoTaskProperty);
            set => SetValue(ShowYesOrNoTaskProperty, value);
        }


        public static readonly BindableProperty ShowNumaricTaskProperty =
          BindableProperty.Create(nameof(ShowNumaricTask),
              typeof(bool),
              typeof(Frame),
              defaultValue: false,
              defaultBindingMode: BindingMode.TwoWay);

        public bool ShowNumaricTask
        {
            get => (bool)GetValue(ShowNumaricTaskProperty);
            set => SetValue(ShowNumaricTaskProperty, value);
        }

        public static readonly BindableProperty ShowCheckMarkTaskProperty =
             BindableProperty.Create(nameof(ShowCheckMarkTask),
              typeof(bool),
              typeof(Frame),
              defaultValue: false,
              defaultBindingMode: BindingMode.TwoWay);

        public bool ShowCheckMarkTask
        {
            get => (bool)GetValue(ShowCheckMarkTaskProperty);
            set => SetValue(ShowCheckMarkTaskProperty, value);
        }

        public static readonly BindableProperty ShowDropdownTaskProperty =
             BindableProperty.Create(nameof(ShowDropdownTask),
              typeof(bool),
              typeof(Frame),
              defaultValue: false,
              defaultBindingMode: BindingMode.TwoWay);

        public bool ShowDropdownTask
        {
            get => (bool)GetValue(ShowDropdownTaskProperty);
            set => SetValue(ShowDropdownTaskProperty, value);
        }
        public static readonly BindableProperty ShowMediaProperty =
            BindableProperty.Create(nameof(ShowMedia),
                typeof(bool),
                typeof(StackLayout),
                defaultValue: false,
                defaultBindingMode: BindingMode.TwoWay);

        public bool ShowMedia
        {
            get => (bool)GetValue(ShowMediaProperty);
            set => SetValue(ShowMediaProperty, value);
        }
        public static readonly BindableProperty StopMediaLoopProperty =
            BindableProperty.Create(nameof(StopMediaLoop),
                typeof(bool),
                typeof(CarouselView),
                defaultValue: false,
                defaultBindingMode: BindingMode.TwoWay);

        public bool StopMediaLoop
        {
            get => (bool)GetValue(StopMediaLoopProperty);
            set => SetValue(StopMediaLoopProperty, value);
        }
        public static readonly BindableProperty ShowSingleLineTaskProperty =
             BindableProperty.Create(nameof(ShowSingleLineTask),
              typeof(bool),
              typeof(StackLayout),
              defaultValue: false,
              defaultBindingMode: BindingMode.TwoWay);

        public bool ShowSingleLineTask
        {
            get => (bool)GetValue(ShowSingleLineTaskProperty);
            set => SetValue(ShowSingleLineTaskProperty, value);
        }

        public static readonly BindableProperty ShowMultiLineTaskProperty =
                   BindableProperty.Create(nameof(ShowMultiLineTask),
                    typeof(bool),
                    typeof(StackLayout),
                    defaultValue: false,
                    defaultBindingMode: BindingMode.TwoWay);

        public bool ShowMultiLineTask
        {
            get => (bool)GetValue(ShowMultiLineTaskProperty);
            set => SetValue(ShowMultiLineTaskProperty, value);
        }

        public static readonly BindableProperty ShowScaleTaskProperty =
                  BindableProperty.Create(nameof(ShowScaleTask),
                   typeof(bool),
                   typeof(StackLayout),
                   defaultValue: false,
                   defaultBindingMode: BindingMode.TwoWay);

        public bool ShowScaleTask
        {
            get => (bool)GetValue(ShowScaleTaskProperty);
            set => SetValue(ShowScaleTaskProperty, value);
        }

        public static readonly BindableProperty ShowPhotoTaskProperty =
                BindableProperty.Create(nameof(ShowPhotoTask),
                    typeof(bool),
                    typeof(StackLayout),
                    defaultValue: false,
                    defaultBindingMode: BindingMode.TwoWay);
        public bool ShowPhotoTask
        {
            get => (bool)GetValue(ShowPhotoTaskProperty);
            set => SetValue(ShowPhotoTaskProperty, value);
        }

        public static BindableProperty InProgressProperty =
            BindableProperty.Create(nameof(InProgress),
                typeof(bool),
                typeof(StackLayout),
                defaultValue: false,
                defaultBindingMode: BindingMode.TwoWay);

        public bool InProgress
        {
            get => (bool)GetValue(InProgressProperty);
            set => SetValue(InProgressProperty, value);
        }

        public static BindableProperty NumericStepperEntryProperty =
            BindableProperty.Create(nameof(NumericStepperEntry),
            typeof(double?), typeof(Entry),
            defaultBindingMode: BindingMode.TwoWay);

        public double? NumericStepperEntry
        {
            get { return (double?)GetValue(NumericStepperEntryProperty); }
            set
            {
                SetValue(NumericStepperEntryProperty, value);
                if (!string.IsNullOrEmpty(value.ToString()))
                    MessagingCenter.Send<object, double?>(this, "TaskAnswered", NumericStepperEntry);
            }
        }

        public static BindableProperty ShowDropDownCommandProperty =
               BindableProperty.Create(
                   nameof(ShowDropDownCommand),
                   typeof(Command),
                   typeof(Frame),
                   defaultValue: default(Command),
                   defaultBindingMode: BindingMode.OneWay
               );

        public Command ShowDropDownCommand
        {
            get { return (Command)GetValue(ShowDropDownCommandProperty); }
            set { SetValue(ShowDropDownCommandProperty, value); }
        }



        public static BindableProperty AnswerMaxProperty =
            BindableProperty.Create(nameof(AnswerMax),
                typeof(double), typeof(Slider), defaultValue: (double)100, defaultBindingMode: BindingMode.TwoWay);
        public double AnswerMax
        {
            get => (double)GetValue(AnswerMaxProperty);
            set => SetValue(AnswerMaxProperty, value);
        }

        public static readonly BindableProperty ShowYesOrNoForSWTaskProperty =
        BindableProperty.Create(nameof(ShowYesOrNoForSW),
            typeof(bool),
            typeof(Frame),
            defaultValue: false,
            defaultBindingMode: BindingMode.TwoWay);

        public bool ShowYesOrNoForSW
        {
            get => (bool)GetValue(ShowYesOrNoForSWTaskProperty);
            set => SetValue(ShowYesOrNoForSWTaskProperty, value);
        }

        public static BindableProperty SWRequireFollowUpProperty =
           BindableProperty.Create(nameof(SWRequireFollowUp),
               typeof(bool), typeof(Label), defaultValue: false, defaultBindingMode: BindingMode.TwoWay);
        public bool SWRequireFollowUp
        {
            get => (bool)GetValue(SWRequireFollowUpProperty);
            set => SetValue(SWRequireFollowUpProperty, value);
        }

        protected override void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            base.OnPropertyChanged(propertyName);
            if (propertyName == "NumericStepperEntry")
            {
                if (NumericStepperEntry.HasValue)
                {
                    if (NumericStepperEntry.Value <= AnswerMax || NumericStepperEntry.Value >= 0)
                    {
                        EnableButton = true;
                    }
                    else
                    {
                        EnableButton = false;
                    }
                }
            }
            else
            {
                if(!ShowNumaricTask && InProgress)
                    NumericStepperEntry = null;
            }
            if (ShowPhotoTask && !InProgress)
            {
                PhotoCollection.SelectionMode = SelectionMode.None;
            }
        }
        private void TapGestureRecognizer_Tapped_1(object sender, EventArgs e)
        {
            if (InProgress)
            {
                if (NumericStepperEntry.HasValue)
                {
                    if (ShowNumaricTask && NumericStepperEntry.Value != 0 && NumericStepperEntry.Value <= AnswerMax)
                    {
                        NumericStepperEntry--;
                    }
                }
            }
        }

        private void TapGestureRecognizer_Tapped_2(object sender, EventArgs e)
        {
            if (InProgress)
            {


                if (NumericStepperEntry.HasValue)
                {
                    if (ShowNumaricTask && NumericStepperEntry.Value >= 0 && NumericStepperEntry.Value < AnswerMax)
                    {
                        NumericStepperEntry++;
                    }
                }
                else
                {
                    NumericStepperEntry = 0;
                }
                EnableButton = true;
            }
        }

        private void TapGestureRecognizer_Tapped(object sender, EventArgs e)
        {
            try
            {
                if (InProgress)
                {
                    var param = ((TappedEventArgs)e).Parameter;
                    var seleteditem = param as TaskResponseValues;
                    seleteditem.IsSelected = !seleteditem.IsSelected;
                    if (TaskResponse.Any(x => x.IsSelected))
                        EnableButton = true;
                    else EnableButton = false;
                }
            }
            catch (Exception)
            {
            }
        }
        private void TextChanged(object sender, TextChangedEventArgs e)
        {
            try
            {
                if (InProgress)
                {

                    if (!string.IsNullOrWhiteSpace(e.NewTextValue)
                        && e.NewTextValue != "Select Option")
                        EnableButton = true;
                    else if (string.IsNullOrEmpty(e.NewTextValue))
                    { EnableButton = false; NumericStepperEntry = null; }
                }
                if (ShowSingleLineTask)
                    enteredChar.Text = SingleLineEntry.Text.Count(c => !char.IsWhiteSpace(c)).ToString();
                else if (ShowMultiLineTask)
                    enteredEditorChar.Text = Editor.Text.Count(c => !char.IsWhiteSpace(c)).ToString();
            }
            catch (Exception)
            {
            }
        }

        private async void VideoPlayer_OnMediaOpened(object sender, EventArgs e)
        {
            if(CarouselViewMedia.Position< 0 || _media != null)
            {
                return;
            }
            try
            {
                _media = ((MediaElement)sender);
                await Task.Delay(500);
                _media.Stop();
            }
            catch (Exception)
            {
            }
        }

        private void CarouselViewMedia_OnPositionChanged(object sender, PositionChangedEventArgs e)
        {
            try
            {
                if (e.CurrentPosition == 1 && _media != null)
                {
                    _media.Stop();
                }
            }
            catch (Exception)
            {

            }
        }

        private void VideoPlayer_OnSeekCompleted(object sender, EventArgs e)
        {
            try
            {
                if (_media != null)
                {
                    _media.Stop();
                }
            }
            catch (Exception)
            {

            }
        }

        private void MediaElement_Loaded(object sender, EventArgs e)
        {
            if(CarouselViewMedia.Position< 0 || _media != null)
            {
                return;
            }
            var media = (MediaElement)sender;
            media.IsVisible=true;
        }
    }
}