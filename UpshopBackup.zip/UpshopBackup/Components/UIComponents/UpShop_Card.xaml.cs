﻿using MobileUI2.Components.Controls;
using System.Globalization;
using System.Windows.Input;

namespace MobileUI2.Components
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class UpShop_Card : ContentView
    {
        public static double ScreenWidth { get; } = DeviceDisplay.MainDisplayInfo.Width / DeviceDisplay.MainDisplayInfo.Density;
        public static double ScreenHeight { get; } = DeviceDisplay.MainDisplayInfo.Height / DeviceDisplay.MainDisplayInfo.Density;
        public static bool IsSmallScreen { get; } = ScreenWidth <= 360;
        public UpShop_Card()
        {
            InitializeComponent();
        }
        #region Text 
        public static BindableProperty HeaderTextProperty =
           BindableProperty.Create(
               nameof(HeaderText),
               typeof(string),
               typeof(Label),
               defaultValue: default(string),
               defaultBindingMode: BindingMode.TwoWay
           );

        public string HeaderText
        {
            get { return (string)GetValue(HeaderTextProperty); }
            set { SetValue(HeaderTextProperty, value); }
        }

        public static BindableProperty ShowHeaderTextProperty =
          BindableProperty.Create(
              nameof(ShowHeaderText),
              typeof(bool),
              typeof(Label),
              defaultValue: false,
              defaultBindingMode: BindingMode.TwoWay
          );

        public bool ShowHeaderText
        {
            get { return (bool)GetValue(ShowHeaderTextProperty); }
            set { SetValue(ShowHeaderTextProperty, value); }
        }

        //title
        public static BindableProperty TitleTextProperty =
          BindableProperty.Create(
              nameof(TitleText),
              typeof(string),
              typeof(Label),
              defaultValue: default(string),
              defaultBindingMode: BindingMode.TwoWay
          );

        public string TitleText
        {
            get { return (string)GetValue(TitleTextProperty); }
            set { SetValue(TitleTextProperty, value); }
        }

        public static BindableProperty BottomTitleTextProperty =
         BindableProperty.Create(
             nameof(BottomTitleText),
             typeof(string),
             typeof(Label),
             defaultValue: default(string),
             defaultBindingMode: BindingMode.TwoWay
         );

        public string BottomTitleText
        {
            get { return (string)GetValue(BottomTitleTextProperty); }
            set { SetValue(BottomTitleTextProperty, value); }
        }

        public static BindableProperty ShowbottomTitleTextProperty =
        BindableProperty.Create(
            nameof(ShowbottomTitleText),
            typeof(bool),
            typeof(Label),
            defaultValue: false,
            defaultBindingMode: BindingMode.TwoWay
        );
        public bool ShowbottomTitleText
        {
            get { return (bool)GetValue(ShowbottomTitleTextProperty); }
            set { SetValue(ShowbottomTitleTextProperty, value); }
        }



        public static BindableProperty StatusTextProperty =
          BindableProperty.Create(
              nameof(StatusText),
              typeof(int),
              typeof(UpShop_Card),
              defaultValue: default(int),
              defaultBindingMode: BindingMode.TwoWay
          );

        public int StatusText
        {
            get { return (int)GetValue(StatusTextProperty); }
            set { SetValue(StatusTextProperty, value); }
        }


        public Style FontTitle
        {
            get { return (Style)GetValue(FontTitleProperty); }
            set { SetValue(FontTitleProperty, value); }
        }

        public static BindableProperty FontTitleProperty =
        BindableProperty.Create(
            nameof(FontTitle),
            typeof(Style),
            typeof(Label),
            defaultValue: default(Style),
            defaultBindingMode: BindingMode.TwoWay
        );
        public static BindableProperty ShowBottomTagProperty =
         BindableProperty.Create(
             nameof(ShowBottomTag),
             typeof(bool),
             typeof(Button),
             defaultValue: false,
             defaultBindingMode: BindingMode.TwoWay
         );

        public bool ShowBottomTag
        {
            get { return (bool)GetValue(ShowBottomTagProperty); }
            set { SetValue(ShowBottomTagProperty, value); }
        }
        public static BindableProperty ShowStatusBottomTagProperty =
         BindableProperty.Create(
             nameof(ShowStatusBottomTag),
             typeof(bool),
             typeof(Button),
             defaultValue: false,
             defaultBindingMode: BindingMode.TwoWay
         );

        public bool ShowStatusBottomTag
        {
            get { return (bool)GetValue(ShowStatusBottomTagProperty); }
            set { SetValue(ShowStatusBottomTagProperty, value); }
        }

        public static BindableProperty ShowTitleDateTextProperty =
         BindableProperty.Create(
             nameof(ShowTitleDateText),
             typeof(bool),
             typeof(Label),
             defaultValue: false,
             defaultBindingMode: BindingMode.TwoWay
         );
        public bool ShowTitleDateText
        {
            get { return (bool)GetValue(ShowTitleDateTextProperty); }
            set { SetValue(ShowTitleDateTextProperty, value); }
        }
        public static BindableProperty TitleDateTextProperty =
         BindableProperty.Create(
             nameof(TitleDateText),
             typeof(string),
             typeof(Label),
             defaultValue: default(string),
             defaultBindingMode: BindingMode.TwoWay
         );
        public string TitleDateText
        {
            get { return (string)GetValue(TitleDateTextProperty); }
            set { SetValue(TitleDateTextProperty, value); }
        }
        public static BindableProperty ShowTitleTextProperty =
          BindableProperty.Create(
              nameof(ShowTitleText),
              typeof(bool),
              typeof(Label),
              defaultValue: false,
              defaultBindingMode: BindingMode.TwoWay
          );

        public bool ShowTitleText
        {
            get { return (bool)GetValue(ShowTitleTextProperty); }
            set { SetValue(ShowTitleTextProperty, value); }
        }

        public static BindableProperty ShowCompleteIconProperty =
          BindableProperty.Create(
              nameof(ShowCompleteIcon),
              typeof(bool),
              typeof(Label),
              defaultValue: false,
              defaultBindingMode: BindingMode.TwoWay
          );

        public bool ShowCompleteIcon
        {
            get { return (bool)GetValue(ShowCompleteIconProperty); }
            set { SetValue(ShowCompleteIconProperty, value); }
        }

        public static BindableProperty CompleteIconProperty =
            BindableProperty.Create(
                nameof(CompleteIcon),
                typeof(string),
                typeof(Label),
                defaultValue: "\uf14a",
                defaultBindingMode: BindingMode.TwoWay
                );
        public string CompleteIcon
        {
            get { return (string)GetValue(CompleteIconProperty); }
            set { SetValue(CompleteIconProperty, value); }
        }

        public bool ShowSignatureIcon
        {
            get { return (bool)GetValue(ShowSignatureIconProperty); }
            set { SetValue(ShowSignatureIconProperty, value); }
        }

        public static BindableProperty ShowSignatureIconProperty =
            BindableProperty.Create(
                nameof(ShowSignatureIcon),
                typeof(bool),
                typeof(Label),
                defaultValue:false,
                defaultBindingMode: BindingMode.TwoWay
                );
        public string SignatureIcon
        {
            get { return (string)GetValue(SignatureIconProperty); }
            set { SetValue(SignatureIconProperty, value); }
        }

        public static BindableProperty SignatureIconProperty =
            BindableProperty.Create(
                nameof(SignatureIcon),
                typeof(string),
                typeof(Label),
                defaultValue: string.Empty,
                defaultBindingMode: BindingMode.TwoWay);


        public static BindableProperty CompleteIconColorProperty =
        BindableProperty.Create(
            nameof(CompleteIconColor),
            typeof(Color),
            typeof(ProgressBar),
            defaultValue: Color.FromArgb("#43B262"),
            defaultBindingMode: BindingMode.TwoWay
        );

        public Color CompleteIconColor
        {
            get { return (Color)GetValue(CompleteIconColorProperty); }
            set { SetValue(CompleteIconColorProperty, value); }
        }

        //subtitle
        public static BindableProperty SubTitleTextProperty =
          BindableProperty.Create(
              nameof(SubTitleText),
              typeof(string),
              typeof(Label),
              defaultValue: default(string),
              defaultBindingMode: BindingMode.TwoWay
          );


        public string SubTitleText
        {
            get { return (string)GetValue(SubTitleTextProperty); }
            set { SetValue(SubTitleTextProperty, value); }
        }

        public static BindableProperty ShowSubTitleTextProperty =
          BindableProperty.Create(
              nameof(ShowSubTitleText),
              typeof(bool),
              typeof(Label),
              defaultValue: false,
              defaultBindingMode: BindingMode.TwoWay
          );

        public bool ShowSubTitleText
        {
            get { return (bool)GetValue(ShowSubTitleTextProperty); }
            set { SetValue(ShowSubTitleTextProperty, value); }
        }


        //RightDate
        public static BindableProperty RightSideDateTextProperty =
          BindableProperty.Create(
              nameof(RightSideDateText),
              typeof(string),
              typeof(Label),
              defaultValue: default(string),
              defaultBindingMode: BindingMode.TwoWay
          );

        public string RightSideDateText
        {
            get { return (string)GetValue(RightSideDateTextProperty); }
            set { SetValue(RightSideDateTextProperty, value); }
        }
        public static BindableProperty RightSideTimeTextProperty =
         BindableProperty.Create(
             nameof(RightSideTimeText),
             typeof(string),
             typeof(Label),
             defaultValue: default(string),
             defaultBindingMode: BindingMode.TwoWay
         );

        public string RightSideTimeText
        {
            get { return (string)GetValue(RightSideTimeTextProperty); }
            set { SetValue(RightSideTimeTextProperty, value); }
        }

        public static BindableProperty ShowRightSideDateTextProperty =
          BindableProperty.Create(
              nameof(ShowRightSideDateText),
              typeof(bool),
              typeof(Label),
              defaultValue: false,
              defaultBindingMode: BindingMode.TwoWay
          );

        public bool ShowRightSideDateText
        {
            get { return (bool)GetValue(ShowRightSideDateTextProperty); }
            set { SetValue(ShowRightSideDateTextProperty, value); }
        }

        //BottomDate
        public static BindableProperty ShowBottomDateTimeTextProperty =
            BindableProperty.Create(
                nameof(ShowBottomDateTimeText),
                typeof(bool),
                typeof(Label),
                defaultValue: false,
                defaultBindingMode: BindingMode.TwoWay);
        public bool ShowBottomDateTimeText
        {
            get { return (bool)GetValue(ShowBottomDateTimeTextProperty); }
            set { SetValue(ShowBottomDateTimeTextProperty, value); }
        }

        public static BindableProperty BottomDateTextProperty =
          BindableProperty.Create(
              nameof(BottomDateText),
              typeof(string),
              typeof(Label),
              defaultValue: default(string),
              defaultBindingMode: BindingMode.TwoWay
          );

        public string BottomLabelText
        {
            get { return (string)GetValue(BottomLabelTextProperty); }
            set { SetValue(BottomLabelTextProperty, value); }
        }

        public static BindableProperty BottomLabelTextProperty =
        BindableProperty.Create(
            nameof(BottomLabelText),
            typeof(string),
            typeof(Label),
            defaultValue: default(string),
            defaultBindingMode: BindingMode.TwoWay
        );

        public string BottomDateText
        {
            get { return (string)GetValue(BottomDateTextProperty); }
            set { SetValue(BottomDateTextProperty, value); }
        }

        public static BindableProperty BottomTimeTextProperty =
         BindableProperty.Create(
             nameof(BottomTimeText),
             typeof(string),
             typeof(Label),
             defaultValue: default(string),
             defaultBindingMode: BindingMode.TwoWay
         );

        public string BottomTimeText
        {
            get { return (string)GetValue(BottomTimeTextProperty); }
            set { SetValue(BottomTimeTextProperty, value); }
        }
        public static BindableProperty ShowBottomDateIconProperty =
         BindableProperty.Create(
             nameof(ShowBottomDateIcon),
             typeof(bool),
             typeof(Label),
             defaultValue: false,
             defaultBindingMode: BindingMode.TwoWay
         );

        public bool ShowBottomDateIcon
        {
            get { return (bool)GetValue(ShowBottomDateIconProperty); }
            set { SetValue(ShowBottomDateIconProperty, value); }
        }


        public static BindableProperty ShowBottomDateTextProperty =
          BindableProperty.Create(
              nameof(ShowBottomDateText),
              typeof(bool),
              typeof(Label),
              defaultValue: false,
              defaultBindingMode: BindingMode.TwoWay
          );

        public bool ShowBottomDateText
        {
            get { return (bool)GetValue(ShowBottomDateTextProperty); }
            set { SetValue(ShowBottomDateTextProperty, value); }
        }
        public static BindableProperty ShowBottomLabelTextProperty =
        BindableProperty.Create(
            nameof(ShowBottomLabelText),
            typeof(bool),
            typeof(Label),
            defaultValue: false,
            defaultBindingMode: BindingMode.TwoWay
        );

        public bool ShowBottomLabelText
        {
            get { return (bool)GetValue(ShowBottomDateTextProperty); }
            set { SetValue(ShowBottomDateTextProperty, value); }
        }


        public static BindableProperty ShowBottomTimeTextProperty =
          BindableProperty.Create(
              nameof(ShowBottomTimeText),
              typeof(bool),
              typeof(Label),
              defaultValue: true,
              defaultBindingMode: BindingMode.TwoWay
          );

        public bool ShowBottomTimeText
        {
            get { return (bool)GetValue(ShowBottomTimeTextProperty); }
            set { SetValue(ShowBottomTimeTextProperty, value); }
        }
        //progress bar
        public static BindableProperty ProgressBarProgressProperty =
        BindableProperty.Create(
            nameof(ProgressBarProgress),
            typeof(double),
            typeof(ProgressBar),
            defaultValue: 0.0,
            defaultBindingMode: BindingMode.TwoWay
        );

        public double ProgressBarProgress
        {
            get { return (double)GetValue(ProgressBarProgressProperty); }
            set { SetValue(ProgressBarProgressProperty, value); }
        }
        public static BindableProperty ProgressBarColorProperty =
        BindableProperty.Create(
            nameof(ProgressBarColor),
            typeof(Color),
            typeof(ProgressBar),
            defaultValue: Colors.LightGray,
            defaultBindingMode: BindingMode.TwoWay
        );

        public Color ProgressBarColor
        {
            get { return (Color)GetValue(ProgressBarColorProperty); }
            set { SetValue(ProgressBarColorProperty, value); }
        }

        public static BindableProperty ShowProgressBarProperty =
          BindableProperty.Create(
              nameof(ShowProgressBar),
              typeof(bool),
              typeof(ProgressBar),
              defaultValue: false,
              defaultBindingMode: BindingMode.TwoWay
          );

        public bool ShowProgressBar
        {
            get { return (bool)GetValue(ShowProgressBarProperty); }
            set { SetValue(ShowProgressBarProperty, value); }
        }

        public static BindableProperty ShowTabletProgressBarProperty =
        BindableProperty.Create(
            nameof(ShowTabletProgressBar),
            typeof(bool),
            typeof(ProgressBar),
            defaultValue: false,
            defaultBindingMode: BindingMode.TwoWay
        );

        public bool ShowTabletProgressBar
        {
            get { return (bool)GetValue(ShowTabletProgressBarProperty); }
            set { SetValue(ShowTabletProgressBarProperty, value); }
        }

        public static BindableProperty ShowPastDateIconProperty =
          BindableProperty.Create(
              nameof(ShowPastDateIcon),
              typeof(bool),
              typeof(Label),
              defaultValue: false,
              defaultBindingMode: BindingMode.TwoWay
          );

        public bool ShowPastDateIcon
        {
            get { return (bool)GetValue(ShowPastDateIconProperty); }
            set { SetValue(ShowPastDateIconProperty, value); }
        }

        public static BindableProperty ShowTagProperty =
          BindableProperty.Create(
              nameof(ShowTag),
              typeof(bool),
              typeof(Button),
              defaultValue: false,
              defaultBindingMode: BindingMode.TwoWay
          );

        public bool ShowTag
        {
            get { return (bool)GetValue(ShowTagProperty); }
            set { SetValue(ShowTagProperty, value); }
        }


        public static BindableProperty ShowArrowIconProperty =
          BindableProperty.Create(
              nameof(ShowArrowIcon),
              typeof(bool),
              typeof(Label),
              defaultValue: false,
              defaultBindingMode: BindingMode.TwoWay
          );

        public bool ShowArrowIcon
        {
            get { return (bool)GetValue(ShowArrowIconProperty); }
            set { SetValue(ShowArrowIconProperty, value); }
        }


        public static BindableProperty RightBottomTextProperty =
        BindableProperty.Create(
            nameof(RightBottomText),
            typeof(string),
            typeof(Label),
            defaultValue: default(string),
            defaultBindingMode: BindingMode.TwoWay
        );

        public string RightBottomText
        {
            get { return (string)GetValue(RightBottomTextProperty); }
            set { SetValue(RightBottomTextProperty, value); }
        }

        public static BindableProperty ShowRightBottomTextProperty =
         BindableProperty.Create(
             nameof(ShowRightBottomText),
             typeof(bool),
             typeof(Label),
             defaultValue: false,
             defaultBindingMode: BindingMode.TwoWay
         );

        public bool ShowRightBottomText
        {
            get { return (bool)GetValue(ShowRightBottomTextProperty); }
            set { SetValue(ShowRightBottomTextProperty, value); }
        }


        public static BindableProperty RightBottomTabletTextProperty =
      BindableProperty.Create(
          nameof(RightBottomTabletText),
          typeof(string),
          typeof(Label),
          defaultValue: default(string),
          defaultBindingMode: BindingMode.TwoWay
      );

        public string RightBottomTabletText
        {
            get { return (string)GetValue(RightBottomTabletTextProperty); }
            set { SetValue(RightBottomTabletTextProperty, value); }
        }
        public static BindableProperty ShowRightBottomTabletTextProperty =
         BindableProperty.Create(
             nameof(ShowRightBottomTabletText),
             typeof(bool),
             typeof(Label),
             defaultValue: false,
             defaultBindingMode: BindingMode.TwoWay
         );

        public bool ShowRightBottomTabletText
        {
            get { return (bool)GetValue(ShowRightBottomTabletTextProperty); }
            set { SetValue(ShowRightBottomTabletTextProperty, value); }
        }






        public static BindableProperty DisbledEntryTextProperty =
           BindableProperty.Create(
               nameof(DisbledEntryText),
               typeof(string),
               typeof(Label),
               defaultValue: default(string),
               defaultBindingMode: BindingMode.TwoWay
           );

        public string DisbledEntryText
        {
            get { return (string)GetValue(DisbledEntryTextProperty); }
            set { SetValue(DisbledEntryTextProperty, value); }
        }

        public static BindableProperty ShowDisbledEntryProperty =
          BindableProperty.Create(
              nameof(ShowDisbledEntry),
              typeof(bool),
              typeof(StackLayout),
              defaultValue: false,
              defaultBindingMode: BindingMode.TwoWay
          );

        public bool ShowDisbledEntry
        {
            get { return (bool)GetValue(ShowDisbledEntryProperty); }
            set { SetValue(ShowDisbledEntryProperty, value); }
        }

        public static BindableProperty NumericStepperLabelTextProperty =
        BindableProperty.Create(
            nameof(NumericStepperLabelText),
            typeof(string),
            typeof(Label),
            defaultValue: default(string),
            defaultBindingMode: BindingMode.TwoWay
        );

        public string NumericStepperLabelText
        {
            get { return (string)GetValue(NumericStepperLabelTextProperty); }
            set { SetValue(NumericStepperLabelTextProperty, value); }
        }

        public static BindableProperty ShowNumericStepperLabelTextProperty =
         BindableProperty.Create(
             nameof(ShowNumericStepperLabelText),
             typeof(bool),
             typeof(Label),
             defaultValue: false,
             defaultBindingMode: BindingMode.TwoWay
         );

        public bool ShowNumericStepperLabelText
        {
            get { return (bool)GetValue(ShowNumericStepperLabelTextProperty); }
            set { SetValue(ShowNumericStepperLabelTextProperty, value); }
        }

        public static BindableProperty NumericStepperEntryEnabledProperty = BindableProperty.Create(nameof(NumericStepperEntryEnabled), typeof(bool), typeof(Entry), defaultValue: true, defaultBindingMode: BindingMode.TwoWay);
        public bool NumericStepperEntryEnabled
        {
            get { return (bool)GetValue(NumericStepperEntryEnabledProperty); }
            set { SetValue(ShowNumericStepperEntryProperty, value); }
        }
        public static BindableProperty ShowNumericStepperEntryProperty = BindableProperty.Create(nameof(ShowNumericStepperEntry), typeof(bool), typeof(StackLayout), defaultValue: false, defaultBindingMode: BindingMode.TwoWay);

        public bool ShowNumericStepperEntry
        {
            get { return (bool)GetValue(ShowNumericStepperEntryProperty); }
            set { SetValue(ShowNumericStepperEntryProperty, value); }
        }

        public static BindableProperty NumericStepperEntryProperty =
            BindableProperty.Create(nameof(NumericStepperEntry),
                typeof(string), typeof(Entry),
                defaultValue: string.Empty, defaultBindingMode: BindingMode.TwoWay);

        public string NumericStepperEntry
        {
            get { return (string)GetValue(NumericStepperEntryProperty); }
            set { SetValue(NumericStepperEntryProperty, value); }
        }

        public static BindableProperty AllowDecimalProperty =
            BindableProperty.Create(nameof(AllowDecimal),
            typeof(bool),
            typeof(UpShop_Card),
            defaultValue: false,
            defaultBindingMode: BindingMode.TwoWay);

        public bool AllowDecimal
        {
            get { return (bool)GetValue(AllowDecimalProperty); }
            set { SetValue(AllowDecimalProperty, value); }
        }

        double oldentryValue = 0;
        private static void valueChange(BindableObject bindable, object oldValue, object newValue)
        {
            double input = (double)newValue;
        }
        #endregion

        public static BindableProperty NumericStepperFocusedCommandProperty =
            BindableProperty.Create(
            nameof(NumericStepperFocusedCommand),
            typeof(ICommand),
            typeof(Entry),
            defaultBindingMode: BindingMode.TwoWay,
            defaultValue: null);


        public ICommand NumericStepperFocusedCommand
        {
            get { return (ICommand)GetValue(NumericStepperFocusedCommandProperty); }
            set { SetValue(NumericStepperFocusedCommandProperty, value); }
        }

        public static BindableProperty NumericStepperUnFocusedCommandProperty =
            BindableProperty.Create(
            nameof(NumericStepperUnFocusedCommand),
            typeof(ICommand),
            typeof(Entry),
            defaultBindingMode: BindingMode.TwoWay,
            defaultValue: null);


        public ICommand NumericStepperUnFocusedCommand
        {
            get { return (ICommand)GetValue(NumericStepperUnFocusedCommandProperty); }
            set { SetValue(NumericStepperUnFocusedCommandProperty, value); }
        }

        public static BindableProperty CheckBoxCommandProperty =
            BindableProperty.Create(
            nameof(CheckBoxCommand),
            typeof(ICommand),
            typeof(Label),
            defaultBindingMode: BindingMode.TwoWay);

        public ICommand CheckBoxCommand
        {
            get { return (ICommand)GetValue(CheckBoxCommandProperty); }
            set { SetValue(CheckBoxCommandProperty, value); }
        }

        public static BindableProperty IsCheckedProperty =
           BindableProperty.Create(
           nameof(IsChecked),
           typeof(bool),
           typeof(UpShop_Card),
           defaultValue: false,
           defaultBindingMode: BindingMode.TwoWay);

        public bool IsChecked
        {
            get { return (bool)GetValue(IsCheckedProperty); }
            set { SetValue(IsCheckedProperty, value); }
        }
        public static BindableProperty ShowCheckboxProperty =
           BindableProperty.Create(
           nameof(ShowCheckbox),
           typeof(bool),
           typeof(UpShop_Card),
           defaultValue: false,
           defaultBindingMode: BindingMode.TwoWay);

        public bool ShowCheckbox
        {
            get { return (bool)GetValue(ShowCheckboxProperty); }
            set { SetValue(ShowCheckboxProperty, value); }
        }

        public static BindableProperty ShowTopRightSideTextProperty =
            BindableProperty.Create(
            nameof(ShowTopRightSideText),
            typeof(bool),
            typeof(Label),
            defaultValue: false,
            defaultBindingMode: BindingMode.TwoWay
         );

        public bool ShowTopRightSideText
        {
            get { return (bool)GetValue(ShowTopRightSideTextProperty); }
            set { SetValue(ShowTopRightSideTextProperty, value); }
        }

        public static BindableProperty ShowBottomRightSideTextProperty =
            BindableProperty.Create(
            nameof(ShowBottomRightSideText),
            typeof(bool),
            typeof(Label),
            defaultValue: false,
            defaultBindingMode: BindingMode.TwoWay
         );

        public bool ShowBottomRightSideText
        {
            get { return (bool)GetValue(ShowBottomRightSideTextProperty); }
            set { SetValue(ShowBottomRightSideTextProperty, value); }
        }

        public static BindableProperty TopRightSideTextProperty =
           BindableProperty.Create(
           nameof(TopRightSideText),
           typeof(string),
           typeof(Label),
           defaultValue: default(string),
           defaultBindingMode: BindingMode.TwoWay
           );

        public string TopRightSideText
        {
            get { return (string)GetValue(TopRightSideTextProperty); }
            set { SetValue(TopRightSideTextProperty, value); }
        }

        public static BindableProperty BottomRightSideTextProperty =
           BindableProperty.Create(
           nameof(BottomRightSideText),
           typeof(string),
           typeof(Label),
           defaultValue: default(string),
           defaultBindingMode: BindingMode.TwoWay
       );

        public string BottomRightSideText
        {
            get { return (string)GetValue(BottomRightSideTextProperty); }
            set { SetValue(BottomRightSideTextProperty, value); }
        }

        //bool IsChecked = false;
        private void TapGestureRecognizer_Tapped(object sender, EventArgs e)
        {
            if (IsChecked)
            {
                IsChecked = false;
                checkBox.Text = "\uf0c8";
                ShowNumericStepperEntry = false;
                ShowDisbledEntry = true;
                frameCard.SetDynamicResource(Microsoft.Maui.Controls.Frame.BorderColorProperty, "UpshopWhite");
                titleText.SetDynamicResource(Label.TextColorProperty, "BackgroundColor");
                subTitleText.SetDynamicResource(Label.TextColorProperty, "UpshopGray");
                checkBox.SetDynamicResource(Label.TextColorProperty, "UpshopGray");
                checkBox.SetDynamicResource(Label.StyleProperty, "FontAwesomeLightStyle");
                StepperEntry.SetDynamicResource(Label.StyleProperty, "CardBackGroundColor");
                minusIcon.SetDynamicResource(Label.TextColorProperty, "UpshopWhite");
                minusIconBackground.SetDynamicResource(Label.TextColorProperty, "UpshopGray");
                plusIcon.SetDynamicResource(Label.TextColorProperty, "UpshopWhite");
                plusIconBackground.SetDynamicResource(Label.TextColorProperty, "UpshopGray");
            }
            else
            {
                IsChecked = true;
                ShowNumericStepperEntry = true;
                ShowDisbledEntry = false;
                checkBox.Text = "\uf14a";
                frameCard.SetDynamicResource(Microsoft.Maui.Controls.Frame.BorderColorProperty, "UpshopOrange");
                titleText.SetDynamicResource(Label.TextColorProperty, "UpshopOrange");
                subTitleText.SetDynamicResource(Label.TextColorProperty, "UpshopOrange");
                checkBox.SetDynamicResource(Label.TextColorProperty, "UpshopOrange");
                checkBox.SetDynamicResource(Label.StyleProperty, "FontAwesomeSolidStyle");
               // StepperEntry.SetDynamicResource(EntryProperties.BorderColorProperty, "UpshopOrange");
                minusIcon.SetDynamicResource(Label.TextColorProperty, "UpshopWhite");
                minusIconBackground.SetDynamicResource(Label.TextColorProperty, "UpshopOrange");
                plusIcon.SetDynamicResource(Label.TextColorProperty, "UpshopWhite");
                plusIconBackground.SetDynamicResource(Label.TextColorProperty, "UpshopOrange");
            }
            if (IsChecked && IsSmallScreen)
            {
                FrameGrid.ColumnDefinitions = new ColumnDefinitionCollection
                    {
                        new ColumnDefinition { Width = new GridLength(0.6,GridUnitType.Star) },
                        new ColumnDefinition { Width = new GridLength(0.4,GridUnitType.Star) }
                    };
            }
            else
            {
                FrameGrid.ColumnDefinitions = new ColumnDefinitionCollection
                    {
                        new ColumnDefinition { Width = new GridLength(0.65,GridUnitType.Star) },
                        new ColumnDefinition { Width = new GridLength(0.45,GridUnitType.Star) }
                    };
            }
            MessagingCenter.Send(this, "valueChanged", IsChecked);
        }

        private void TapGestureRecognizer_Tapped_1(object sender, EventArgs e)
        {
            try
            {
                if (ShowNumericStepperEntry && double.TryParse(NumericStepperEntry, NumberStyles.Float, CultureInfo.CurrentCulture, out double value)
                    && value != 0 && value <= 999)
                {
                    StepperEntry.Text = (--value).ToString(CultureInfo.CurrentCulture);
                }
            }
            catch (Exception ex)
            {
                
            }
        }

        private void TapGestureRecognizer_Tapped_2(object sender, EventArgs e)
        {
            try
            {
                if (ShowNumericStepperEntry && double.TryParse(NumericStepperEntry, NumberStyles.Float, CultureInfo.CurrentCulture, out double value)
                    && value >= 0 && value < 999)
                {
                    StepperEntry.Text = (++value).ToString(CultureInfo.CurrentCulture);
                }
            }
            catch (Exception)
            {
            }
        }

        protected override void OnParentSet()
        {
            base.OnParentSet();
            if (Parent == null)
                DisposeBindingContext();
        }

        protected void DisposeBindingContext()
        {
            try
            {
                if (BindingContext is IDisposable disposableBindingContext)
                {
                    disposableBindingContext.Dispose();
                    BindingContext = null;
                }
            }
            catch (Exception)
            {
            }           
        }

        ~UpShop_Card()
        {
            DisposeBindingContext();
        }
    }
}