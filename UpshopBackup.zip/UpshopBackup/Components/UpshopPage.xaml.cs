﻿using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace MobileUI2.Components
{
    [XamlCompilation(XamlCompilationOptions.Compile)]

    // ReSharper disable once RedundantExtendsListEntry
    public partial class UpshopPage : ContentPage, INotifyPropertyChanged
    {
        private bool isAlreadyInitialized;       
        public enum NavigationGlyph
        {
            ClosePopup,
            NavigateBack,
            Hamburger
        }
        // ReSharper disable once UnusedMember.Global
        public static readonly Dictionary<NavigationGlyph, string> GlyphMappings = new Dictionary<NavigationGlyph, string>
        {
            { NavigationGlyph.ClosePopup, "X" },
            { NavigationGlyph.NavigateBack, "\uf060" },
            { NavigationGlyph.Hamburger, "\uf0c9" }
        };

        public static readonly BindableProperty NavigationGlyphProperty = BindableProperty.Create(
            nameof(NavigationGlyphValue),
            typeof(NavigationGlyph),
            typeof(UpshopPage),
            default(NavigationGlyph));



#pragma warning disable CS0108 // Member hides inherited member; missing new keyword
        public static readonly BindableProperty TitleProperty = BindableProperty.Create(
#pragma warning restore CS0108 // Member hides inherited member; missing new keyword
            nameof(Title),
            typeof(string),
            typeof(UpshopPage));
        public static readonly BindableProperty DurationTextProperty = BindableProperty.Create(
            nameof(DurationText),
            typeof(string),
            typeof(UpshopPage));
        public static readonly BindableProperty IsSearchBarVisibleProperty = BindableProperty.Create(
            nameof(IsSearchBarVisible),
            typeof(bool),
            typeof(UpshopPage),
            default(bool));
        public static readonly BindableProperty ShowSearchbarPropery = BindableProperty.Create(
             nameof(ShowSearchbar),
            typeof(bool),
            typeof(UpshopPage),
            true);
        public static readonly BindableProperty ShowPersonaProperty = BindableProperty.Create(
            nameof(ShowPersona),
            typeof(bool),
            typeof(UpshopPage),
            default(bool));
        public static readonly BindableProperty ShowAlertsProperty = BindableProperty.Create(
            nameof(ShowAlerts),
            typeof(bool),
            typeof(UpshopPage),
            default(bool));
        public static readonly BindableProperty PrintProperty = BindableProperty.Create(
            nameof(Print),
            typeof(bool),
            typeof(UpshopPage),
            default(bool));
        public static readonly BindableProperty ConnectedProperty = BindableProperty.Create(
            nameof(Connected),
            typeof(bool),
            typeof(UpshopPage),
            default(bool));
        public static readonly BindableProperty AddLabelsProperty = BindableProperty.Create(
            nameof(AddLabels),
            typeof(bool),
            typeof(UpshopPage),
            default(bool));
        public static readonly BindableProperty ShoppingCartProperty = BindableProperty.Create(
            nameof(ShoppingCart),
            typeof(bool),
            typeof(UpshopPage),
            default(bool));
        public static readonly BindableProperty ScanProperty = BindableProperty.Create(
            nameof(Scan),
            typeof(bool),
            typeof(UpshopPage),
            default(bool));
        public static readonly BindableProperty ManualProperty = BindableProperty.Create(
            nameof(Manual),
            typeof(bool),
            typeof(UpshopPage),
            default(bool));
        public static readonly BindableProperty IsConnectedProperty = BindableProperty.Create(
            nameof(IsConnected),
            typeof(bool),
            typeof(UpshopPage),
            default(bool));
        public static readonly BindableProperty NewToolBarProperty = BindableProperty.Create(
           nameof(NewToolBar),
           typeof(bool),
           typeof(UpshopPage),
           default(bool));
        public static readonly BindableProperty IsTabletProperty = BindableProperty.Create(
           nameof(IsTablet),
           typeof(bool),
           typeof(UpshopPage),
           default(bool));




        public NavigationGlyph NavigationGlyphValue
        {
            get => (NavigationGlyph)GetValue(NavigationGlyphProperty);
            set => SetValue(NavigationGlyphProperty, value);
        }
#pragma warning disable CS0108 // Member hides inherited member; missing new keyword
        public string Title
#pragma warning restore CS0108 // Member hides inherited member; missing new keyword
        {
            get => (string)GetValue(TitleProperty);
            set => SetValue(TitleProperty, value);
        }
        public string DurationText
        {
            get => (string)GetValue(DurationTextProperty);
            set => SetValue(DurationTextProperty, value);
        }
        public bool IsSearchBarVisible
        {
            get => (bool)GetValue(IsSearchBarVisibleProperty);
            set => SetValue(IsSearchBarVisibleProperty, value);
        }
         public bool ShowSearchbar
        {
            get => (bool)GetValue(ShowSearchbarPropery);
            set => SetValue(ShowSearchbarPropery, value);
        }
        public bool ShowPersona
        {
            get => (bool)GetValue(ShowPersonaProperty);
            set => SetValue(ShowPersonaProperty, value);
        }
        public bool ShowAlerts
        {
            get => (bool)GetValue(ShowAlertsProperty);
            set => SetValue(ShowAlertsProperty, value);
        }
        public bool Print
        {
            get => (bool)GetValue(PrintProperty);
            set => SetValue(PrintProperty, value);
        }
        public bool Connected
        {
            get => (bool)GetValue(ConnectedProperty);
            set
            {
                SetValue(ConnectedProperty, value);
                OnPropertyChanged();
            }
        }
        public bool AddLabels
        {
            get => (bool)GetValue(AddLabelsProperty);
            set => SetValue(AddLabelsProperty, value);
        }
        public bool ShoppingCart
        {
            get => (bool)GetValue(ShoppingCartProperty);
            set => SetValue(ShoppingCartProperty, value);
        }
        public bool Scan
        {
            get => (bool)GetValue(ScanProperty);
            set => SetValue(ScanProperty, value);
        }
        public bool Manual
        {
            get => (bool)GetValue(ManualProperty);
            set => SetValue(ManualProperty, value);
        }
        public bool IsConnected
        {
            get => (bool)GetValue(IsConnectedProperty);
            set
            {
                SetValue(IsConnectedProperty, value);
                OnPropertyChanged();
            }
        }
        public bool NewToolBar
        {
            get => (bool)GetValue(NewToolBarProperty);
            set => SetValue(NewToolBarProperty, value);
        }
        public bool IsTablet
        {
            get => (bool)GetValue(IsTabletProperty);
            set => SetValue(IsTabletProperty, value);
        }



        public UpshopPage()
        {
            InitializeComponent();
            if (DeviceInfo.Idiom == DeviceIdiom.Tablet)
            {

              
                IsSearchBarVisible = true;
                IsTablet = true;
            }
        }
        protected override void OnAppearing()
        {
            var viewModel = BindingContext as BaseViewModel;
            viewModel.PropertyChanged += ViewModel_PropertyChanged;
            viewModel.connectivity.ConnectivityChanged += viewModel.Connectivity_ConnectivityChanged;
            if ((int)viewModel.connectivity.NetworkAccess == 4 || (int)viewModel.connectivity.NetworkAccess == 3)
            {
                viewModel.ShowOfflineIcon = false;
            }
            else
            {
                viewModel.ShowOfflineIcon = true;
            }
            if (!isAlreadyInitialized)
            {
                viewModel.InitializeAsync();
                isAlreadyInitialized = true;
            }
            else viewModel.ReBindDataAsync();

            viewModel.OnAppearing();
            base.OnAppearing();
        }
        protected override bool OnBackButtonPressed()
        {
            var vm = (BaseViewModel)this.BindingContext;
            vm.BackButtonCommand.Execute(null);
            return true;
        }
        private void ViewModel_PropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            //add value change logics based on property Change
        }
        protected override void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            base.OnPropertyChanged(propertyName);
        }

        void NewTitleBar_SizeChanged(System.Object sender, System.EventArgs e)
        {
            var grid = (Microsoft.Maui.Controls.Grid)sender;
            // Calculate the height of the first row dynamically
            GlobalSettings.NavigationBarRowHeight = grid.Height;
        }
    }
}