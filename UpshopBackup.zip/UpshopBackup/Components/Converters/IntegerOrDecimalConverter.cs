﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MobileUI2.Components.Converters
{
    public class IntegerOrDecimalConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value is double doubleValue)
            {
                // If there's no decimal part (whole number), show only the integer part
                if (doubleValue == Math.Floor(doubleValue))
                {
                    return doubleValue.ToString("F0");  // Return integer part only (no decimals)
                }
                else
                {
                    return Math.Round(doubleValue, 2).ToString("F2");  // Show 2 decimal places
                }
            }
            return value;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            return value;
        }
    }
}
