﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;

namespace MobileUI2.Converters
{
    public class IntToGridLengthConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (int.TryParse(parameter.ToString(), out var gridLength) && value is bool boolValue && boolValue)
                return new GridLength(gridLength, GridUnitType.Star);
            return new GridLength(0, GridUnitType.Star);
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
