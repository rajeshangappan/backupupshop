﻿using System.Globalization;

namespace MobileUI2.Components.Converters
{
    public class ImageSourceConverter : IValueConverter
    {
        private static readonly HttpClient _httpClient = new HttpClient();

        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value == null)
                return null;
            try
            {
                var imageUrl = value.ToString();
                var byteArray = _httpClient.GetByteArrayAsync(imageUrl).GetAwaiter().GetResult();
                return ImageSource.FromStream(() => new MemoryStream(byteArray));
            }
            catch (Exception)
            {
                return null;
            }
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            return null;
        }
    }
}
