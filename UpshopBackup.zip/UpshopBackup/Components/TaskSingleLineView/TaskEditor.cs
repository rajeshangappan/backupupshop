﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Maui.Controls.Compatibility;
using Microsoft.Maui.Controls;
using Microsoft.Maui;

namespace MobileUI2.Components.TaskSingleLineView
{
    public class TaskEditor : Editor
    {
        public static readonly BindableProperty IsUnderlineProperty =
            BindableProperty.Create(nameof(IsUnderline), typeof(bool), typeof(TaskEditor), true);

        public static readonly BindableProperty IsWordWrapProperty =
            BindableProperty.Create(nameof(IsWordWrap), typeof(bool), typeof(TaskEditor), false);

        public bool IsUnderline
        {
            get => (bool)GetValue(IsUnderlineProperty);
            set => SetValue(IsUnderlineProperty, value);
        }

        public bool IsWordWrap
        {
            get => (bool)GetValue(IsWordWrapProperty);
            set => SetValue(IsWordWrapProperty, value);
        }
    }
}
