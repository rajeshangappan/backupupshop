﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Components.TaskSingleLineView
{
    public interface ITaskSingleLineService
    {
        TaskSingleLineModel GetQuestion();
    }
}
