﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Components.TaskSingleLineView
{
    public class TaskSingleLineModel
    {
        public string QuestionTxt { get; set; }
        public string AnswerTxt { get; set; }
    }
}
