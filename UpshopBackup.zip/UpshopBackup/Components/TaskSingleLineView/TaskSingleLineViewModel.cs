﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace MobileUI2.Components.TaskSingleLineView
{
    public class TaskSingleLineViewModel : INotifyPropertyChanged
    {
        private TaskSingleLineModel _taskSingleLineModel;
        private IServiceProvider _serviceProvider;

        public TaskSingleLineViewModel(IServiceProvider  serviceProvider,ITaskSingleLineService service = null)
        {
            Initialize(service);
            _serviceProvider = serviceProvider;
        }

        public void Initialize(ITaskSingleLineService service)
        {
            try
            { 
                if (service == null)
                    service = _serviceProvider.GetService<ITaskSingleLineService>();

                _taskSingleLineModel = service?.GetQuestion() ?? throw new ArgumentNullException(nameof(service));
            }
            catch (Exception ex)
            {
            }
        }

        public string QuestionTitle
        {
            get { return _taskSingleLineModel?.QuestionTxt; }
            set
            {
                if (_taskSingleLineModel != null)
                {
                    _taskSingleLineModel.QuestionTxt = value;
                    OnPropertyChanged(nameof(QuestionTitle));
                }
            }
        }

        public string AnswerTxt
        {
            get { return _taskSingleLineModel?.AnswerTxt; }
            set
            {
                
                if (_taskSingleLineModel != null)
                {
                    var refactoredvalue = value?.Replace(System.Environment.NewLine, "");

                    _taskSingleLineModel.AnswerTxt = refactoredvalue;
                    OnPropertyChanged(nameof(AnswerTxt));
                }
            }
        }


        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
