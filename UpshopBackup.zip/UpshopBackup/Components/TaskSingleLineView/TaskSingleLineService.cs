﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Components.TaskSingleLineView
{
    public class TaskSingleLineService : ITaskSingleLineService
    {
        public TaskSingleLineModel GetQuestion()
        {
            var singleLineModel = new TaskSingleLineModel
            {
                QuestionTxt = "The question to be asked that prompts the response will go here?"
            };

            return singleLineModel;
        }
    }
}
