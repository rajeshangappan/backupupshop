﻿using MobileUI2.Components.TaskBool;
using MobileUI2.Models.Tasks;
using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Maui.Controls.Xaml;
using Microsoft.Maui.Controls.Compatibility;
using Microsoft.Maui.Controls;
using Microsoft.Maui;

namespace MobileUI2.Components.TaskSingleLineView
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class TaskSingleLineView : ContentView
    {
        public TaskSingleLineView()
        {
            InitializeComponent();
            txtAnswer.TextChanged += OnTextChanged;
        }

        public static readonly BindableProperty QuestionTextProperty =
            BindableProperty.Create(nameof(QuestionText), typeof(string), typeof(TaskSingleLineView), string.Empty, propertyChanged: OnTitlePropertyChanged);
        public static readonly BindableProperty AnswerTextProperty =
            BindableProperty.Create(nameof(AnswerText), typeof(string), typeof(TaskSingleLineView), string.Empty, propertyChanged: OnAnswerTextChanged);
        public static readonly BindableProperty IsAnswerRequiredProperty =
            BindableProperty.Create(nameof(IsAnswerRequired), typeof(bool), typeof(TaskSingleLineView), false);
        public static readonly BindableProperty AnswersProperty =
            BindableProperty.Create(nameof(QuestionText), typeof(List<string>), typeof(TaskSingleLineView), defaultValue: default(List<string>), defaultBindingMode: BindingMode.TwoWay, propertyChanged: SelectValues);
        public static readonly BindableProperty FormattedQuestionTextProperty =
          BindableProperty.Create(nameof(FormattedQuestionText), typeof(FormattedString), typeof(TaskSingleLineView), defaultValue: default(FormattedString), defaultBindingMode: BindingMode.TwoWay);

        public FormattedString FormattedQuestionText
        {
            get => (FormattedString)GetValue(FormattedQuestionTextProperty);
            set => SetValue(FormattedQuestionTextProperty, value);
        }
        private static void SelectValues(BindableObject bindable, object oldvalue, object newvalue)
        {
            if (newvalue == null)
                return;
            var customView = (TaskSingleLineView)bindable;
            customView.txtAnswer.IsReadOnly = true;
            var value = (List<string>)newvalue;
            if(!value.Any())
                return;
            customView.AnswerText = value[0];
        }

        public List<string> Answers
        {
            get => (List<string>)GetValue(AnswersProperty);
            set => SetValue(AnswersProperty, value);
        }
        public bool IsAnswerRequired
        {
            get => (bool)GetValue(IsAnswerRequiredProperty);
            set => SetValue(IsAnswerRequiredProperty, value);
        }
        public string QuestionText
        {
            get => (string)GetValue(QuestionTextProperty);
            set => SetValue(QuestionTextProperty, value);
        }

        public string AnswerText
        {
            get => (string)GetValue(AnswerTextProperty);
            set => SetValue(AnswerTextProperty, value);
        }
        public Command Command
        {
            get { return (Command)GetValue(CommandProperty); }
            set { SetValue(CommandProperty, value); }
        }

        public static BindableProperty CommandProperty =
            BindableProperty.Create(
                nameof(Command),
                typeof(Command),
                typeof(TaskSingleLineView),
                defaultBindingMode: BindingMode.TwoWay);

        public static BindableProperty CommandParameterProperty =
            BindableProperty.Create(
                nameof(CommandParameter),
                typeof(object),
                typeof(TaskSingleLineView),
                defaultBindingMode: BindingMode.TwoWay);

        public object CommandParameter
        {
            get => GetValue(CommandParameterProperty);
            set => SetValue(CommandParameterProperty, value);
        }
        private static void OnTitlePropertyChanged(BindableObject bindable, object oldValue, object newValue)
        {
            var customView = (TaskSingleLineView)bindable;
            customView.lblQuestion.Text = (string)newValue;
        }

        private static void OnAnswerTextChanged(BindableObject bindable, object oldValue, object newValue)
        {
            var customView = (TaskSingleLineView)bindable;
            customView.txtAnswer.Text = (string)newValue;
        }

        private void OnTextChanged(object sender, TextChangedEventArgs e)
        {
            try
            {
                const int maxLength = 100;
                if (string.IsNullOrEmpty(e.NewTextValue))
                {
                    UpdateCountText(0, maxLength);
                    if (!string.IsNullOrWhiteSpace(e.OldTextValue))
                        UpdateData("");
                    return;
                }
                
                if (e.NewTextValue.Length > maxLength)
                {
                    txtAnswer.Text = e.NewTextValue.Substring(0, maxLength);
                }
                UpdateData(txtAnswer.Text);
                UpdateCountText(txtAnswer.Text.Length, maxLength);
            }
            catch(Exception ex)
            {

            }
        }
        private void UpdateCountText(int currentLength, int maxLength)
        {
            countText.Text = $"({currentLength}/{maxLength})";
        }
        private void UpdateData(string answer)
        {
            if (CommandParameter is StoreWalkQuestionDetails)
            {
                var data = (StoreWalkQuestionDetails)CommandParameter;
                if (string.IsNullOrEmpty(answer))
                    data.Answer = new List<string>();
                else data.Answer = new List<string>() { answer };
                Command.Execute(CommandParameter);
            }
        }
    }
}
