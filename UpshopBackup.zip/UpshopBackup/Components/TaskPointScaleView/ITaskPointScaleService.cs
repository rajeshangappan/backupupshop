﻿using MobileUI2.Components.TaskBool;
using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Components.TaskPointScaleView
{
    public interface ITaskPointScaleService
    {
        TaskPointScaleModel GetPointScaleModel();
    }
}
