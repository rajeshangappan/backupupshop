﻿using MobileUI2.Components.TaskBool;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace MobileUI2.Components.TaskPointScaleView
{
    public class TaskPointScaleViewModel : INotifyPropertyChanged
    {
        private TaskPointScaleModel _taskPointScaleModel;
        private IServiceProvider _serviceProvider;
        
        public TaskPointScaleViewModel(IServiceProvider serviceProvider, TaskPointScaleService _taskPointScaleService = null)
        {
            Initialize(_taskPointScaleService);
            _serviceProvider = serviceProvider;
        }

        public void Initialize(ITaskPointScaleService _taskPointScaleService)
        {
            if (_taskPointScaleService == null)
                _taskPointScaleService = _serviceProvider.GetService<ITaskPointScaleService>();

            _taskPointScaleModel = _taskPointScaleService?.GetPointScaleModel() ?? throw new ArgumentNullException(nameof(_taskPointScaleService));
        }

        public string Title
        {
            get { return _taskPointScaleModel?.QuestionTxt; }
            set
            {
                if (_taskPointScaleModel != null)
                {
                    _taskPointScaleModel.QuestionTxt = value;
                    OnPropertyChanged(nameof(Title));
                }
            }
        }

        public int MaxValue
        {
            get { return _taskPointScaleModel.MaxValue; }
            set
            {
                if (_taskPointScaleModel != null)
                {
                    _taskPointScaleModel.MaxValue = value;
                    OnPropertyChanged(nameof(MaxValue));
                }
            }
        }

        public int MinValue
        {
            get { return _taskPointScaleModel.MinValue; }
            set
            {
                if (_taskPointScaleModel != null)
                {
                    _taskPointScaleModel.MinValue = value;
                    OnPropertyChanged(nameof(MinValue));
                }
            }
        }

        public int SelectedInputValue
        {
            get { return _taskPointScaleModel.SelectedPointInput; }
            set
            {
                if (_taskPointScaleModel != null)
                {
                    _taskPointScaleModel.SelectedPointInput = value;
                    OnPropertyChanged(nameof(SelectedInputValue));
                }
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;
        protected virtual void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
