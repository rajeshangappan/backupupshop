﻿using MobileUI2.Components.TaskBool;
using MobileUI2.Components.TaskMultipleSelectCheckboxView;
using MobileUI2.Components.TaskSingleSelectRadioButton;
using MobileUI2.Converters.HeightToFontSizeConverters;
using MobileUI2.Models.Tasks;
using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Maui.Controls.Xaml;
using Microsoft.Maui.Graphics;
using Microsoft.Maui.Controls.Compatibility;
using Microsoft.Maui.Controls;
using Microsoft.Maui;

namespace MobileUI2.Components.TaskPointScaleView
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class TaskPointScaleView : ContentView
    {
        Label numberLabel;
        Color labelTextColor;
        private Frame scaleFrame;
        private ContentView selectedLabelContainer;
        private bool IsCompletedTask;
        private IServiceProvider _serviceProvider;
        public static readonly BindableProperty QuestionTextProperty = BindableProperty.Create(nameof(QuestionText), typeof(string), typeof(TaskPointScaleView), string.Empty, propertyChanged: OnTitleChanged);
        public static readonly BindableProperty SelectedValueProperty = BindableProperty.Create(nameof(SelectedValue), typeof(int), typeof(TaskPointScaleView), defaultBindingMode: BindingMode.TwoWay);
        public static readonly BindableProperty ViewModelProperty = BindableProperty.Create(nameof(ViewModel), typeof(TaskPointScaleViewModel), typeof(TaskPointScaleView));
        public static readonly BindableProperty IsAnswerRequiredProperty = BindableProperty.Create(nameof(IsAnswerRequired), typeof(bool), typeof(TaskPointScaleView), false);
        public static BindableProperty CommandProperty = BindableProperty.Create(nameof(Command), typeof(Command), typeof(TaskPointScaleView), defaultBindingMode: BindingMode.TwoWay);
        public static BindableProperty CommandParameterProperty = BindableProperty.Create(nameof(CommandParameter), typeof(object), typeof(TaskPointScaleView), defaultBindingMode: BindingMode.TwoWay);
        public static readonly BindableProperty AnswersProperty = BindableProperty.Create(nameof(QuestionText), typeof(List<string>), typeof(TaskPointScaleView), defaultValue: default(List<string>), defaultBindingMode: BindingMode.TwoWay, propertyChanged: SelectValues);
       
        public List<string> Answers
        {
            get => (List<string>)GetValue(AnswersProperty);
            set => SetValue(AnswersProperty, value);
        }
        public bool IsAnswerRequired
        {
            get => (bool)GetValue(IsAnswerRequiredProperty);
            set => SetValue(IsAnswerRequiredProperty, value);
        }
        public TaskPointScaleViewModel ViewModel
        {
            get => (TaskPointScaleViewModel)GetValue(ViewModelProperty);
            set => SetValue(ViewModelProperty, value);
        }

        public int SelectedValue
        {
            get => (int)GetValue(SelectedValueProperty);
            set => SetValue(SelectedValueProperty, value);
        }

        public string QuestionText
        {
            get { return (string)GetValue(QuestionTextProperty); }
            set { SetValue(QuestionTextProperty, value); }
        }
        public Command Command
        {
            get { return (Command)GetValue(CommandProperty); }
            set { SetValue(CommandProperty, value); }
        }

        public object CommandParameter
        {
            get => GetValue(CommandParameterProperty);
            set => SetValue(CommandParameterProperty, value);
        }
        public static readonly BindableProperty FormattedQuestionTextProperty =
           BindableProperty.Create(nameof(FormattedQuestionText), typeof(FormattedString), typeof(TaskPointScaleView), defaultValue: default(FormattedString), defaultBindingMode: BindingMode.TwoWay);

        public FormattedString FormattedQuestionText
        {
            get => (FormattedString)GetValue(FormattedQuestionTextProperty);
            set => SetValue(FormattedQuestionTextProperty, value);
        }
        private static void OnTitleChanged(BindableObject bindable, object oldValue, object newValue)
        {
            var control = (TaskPointScaleView)bindable;
            control.ViewModel.Title = (string)newValue;
        }

        public TaskPointScaleView()
        {
            InitializeComponent();
            //_serviceProvider = serviceProvider;
            ViewModel = new TaskPointScaleViewModel(App._serviceProvider);
            CreateUI();
            
        }

        private void CreateUI()
        {
            try
            {
                buttonStackLayout.Spacing = 0;

                labelTextColor = (Color)Application.Current.Resources["UpshopLightTeal"];
                var borderColor = (Color)Application.Current.Resources["UpshopSlate"];
                var whiteColor = (Color)Application.Current.Resources["UpshopWhite"];
                scaleFrame = new Frame
                {
                    HorizontalOptions = LayoutOptions.FillAndExpand,
                    VerticalOptions = LayoutOptions.Start,
                    BorderColor = Colors.Transparent,
                    BackgroundColor = borderColor,
                    CornerRadius = 2, 
                    Padding = 0,
                    HasShadow = false,
                    HeightRequest = 50,
                    AutomationId = "frame_taskscalepoint",
                    Content = new Microsoft.Maui.Controls.StackLayout
                    {
                        Margin = new Thickness(2),
                        Orientation = StackOrientation.Horizontal,
                        Spacing = 0,  BackgroundColor = whiteColor,
                        HorizontalOptions = LayoutOptions.FillAndExpand,
                        VerticalOptions = LayoutOptions.Center,
                        HeightRequest = 50,
                        AutomationId = "stack_taskscalepoint",
                    }
                };

                for (int i = ViewModel.MinValue; i <= ViewModel.MaxValue; i++)
                {
                    ContentView labelContainer = new ContentView
                    {
                        HorizontalOptions = LayoutOptions.FillAndExpand,
                        VerticalOptions = LayoutOptions.FillAndExpand,
                        AutomationId = $"contentview_taskscalepoint_{i}"
                    };

                    numberLabel = new Label
                    {
                        Text = i.ToString(),
                        HorizontalOptions = LayoutOptions.FillAndExpand,
                        VerticalOptions = LayoutOptions.FillAndExpand,
                        TextColor = labelTextColor,
                        FontAttributes = FontAttributes.Bold,
                        HorizontalTextAlignment = TextAlignment.Center,
                        VerticalTextAlignment = TextAlignment.Center,
                        FontSize = 20,
                        AutomationId = $"lbl_taskscalepointnumber_{i}"
                    };

                    TapGestureRecognizer tapGestureRecognizer = new TapGestureRecognizer();
                    tapGestureRecognizer.Tapped += (s, e) => OnLabelTapped(labelContainer);
                    labelContainer.GestureRecognizers.Add(tapGestureRecognizer);

                    labelContainer.Content = numberLabel;
                    ((Microsoft.Maui.Controls.StackLayout)scaleFrame.Content)?.Children?.Add(labelContainer);

                    if (i < ViewModel.MaxValue)
                    {
                        BoxView separator = new BoxView
                        {
                            Color = Color.FromArgb("#CBD5E1"),
                            WidthRequest = 1,
                            VerticalOptions = LayoutOptions.FillAndExpand,
                            AutomationId = $"boxvw_taskscalepointseparator_{i}"
                        };

                        ((Microsoft.Maui.Controls.StackLayout)scaleFrame.Content)?.Children?.Add(separator);
                    }
                }

                buttonStackLayout?.Children?.Add(scaleFrame);
            }
            catch (Exception ex)
            {
            }
        }

        private void OnLabelTapped(ContentView labelContainer)
        {
            try
            {
                if(IsCompletedTask)
                    return;
                if(labelContainer == null)
                    return;

                var selectedLabelColor = (Color)Application.Current.Resources["UpshopDarkTeal"];
                
                if (selectedLabelContainer != null)
                {
                    selectedLabelContainer.BackgroundColor = Colors.Transparent;
                    ((Label)selectedLabelContainer.Content).TextColor = labelTextColor;
                }

                bool isDeselected = selectedLabelContainer == labelContainer;
                selectedLabelContainer = isDeselected ? null : labelContainer;

                if (!isDeselected)
                {
                    labelContainer.BackgroundColor = selectedLabelColor;
                    ((Label)labelContainer.Content).TextColor = Colors.White;

                    var selectedLabelText = ((Label)labelContainer.Content)?.Text ?? string.Empty;
                    SelectedValue = ViewModel.SelectedInputValue = Convert.ToInt32(selectedLabelText);
                }
                else
                {
                    SelectedValue = 0;
                    ViewModel.SelectedInputValue = 0;
                }
                UpdateData();
            }
            catch(Exception ex)
            {

            }
        }

        private void UpdateData()
        {
            if (CommandParameter is StoreWalkQuestionDetails)
            {
                var data = (StoreWalkQuestionDetails)CommandParameter;
                if (SelectedValue == 0)
                    data.Answer = new List<string>();
                else data.Answer = new List<string>() { SelectedValue.ToString() };
                Command.Execute(CommandParameter);
            }
        }

        private static void SelectValues(BindableObject bindable, object oldvalue, object newvalue)
        {
            if (newvalue == null)
                return;
            var customView = (TaskPointScaleView)bindable;
            var value = (List<string>)newvalue;
            if (!value.Any())
            {
                customView.IsCompletedTask = true;
                return;
            }
            customView.OnLabelTapped(customView.FindContentViewByLabelText(value[0]));
            customView.IsCompletedTask = true;
        }
        ContentView FindContentViewByLabelText(string searchText)
        {
            var enumerable = ((Microsoft.Maui.Controls.StackLayout)scaleFrame.Content)?.Children;
            if (enumerable != null)
                foreach (var child in enumerable)
                {
                    if (child is ContentView labelContainer && labelContainer.Content is Label label &&
                        label.Text == searchText)
                    {
                        return labelContainer;
                    }
                }

            return null;
        }
    }
}
