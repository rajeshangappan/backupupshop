﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Components.TaskPointScaleView
{
    public class TaskPointScaleModel
    {
        public string QuestionTxt { get; set; }
        public int SelectedPointInput { get; set; }
        public int MinValue { get; set; }
        public int MaxValue { get; set; }

    }
}
