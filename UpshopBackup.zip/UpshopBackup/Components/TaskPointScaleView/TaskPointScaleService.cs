﻿using MobileUI2.Components.TaskBool;
using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Components.TaskPointScaleView
{
    public class TaskPointScaleService : ITaskPointScaleService
    {
        public TaskPointScaleModel GetPointScaleModel()
        {
            var question = new TaskPointScaleModel
            {
                QuestionTxt = "On a scale from 1 to 5 (where 1 is Poor and 5 is Excellent) how would you rate the Meat Department conditions?",
                MinValue = 1,
                MaxValue = 5
            };

            return question;
        }
    }
}
