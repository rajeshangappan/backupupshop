﻿using MobileUI2.Models.Tasks;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using Microsoft.Maui.Controls.Xaml;
using Microsoft.Maui.Controls.Compatibility;
using Microsoft.Maui.Controls;
using Microsoft.Maui;
using CommunityToolkit.Maui.Behaviors;

namespace MobileUI2.Components.TaskUploadPictureView
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class TaskUploadPictureView
    {
        private TaskUploadPictureViewModel _viewModel;
        private IServiceProvider _serviceProvider;
        private bool _isCompletedTask;
        public static readonly BindableProperty TextProperty = BindableProperty.Create(nameof(Text), typeof(string), typeof(TaskUploadPictureView), string.Empty, propertyChanged: OnTitlePropertyChanged);
        public static readonly BindableProperty ViewModelProperty = BindableProperty.Create(nameof(ViewModel), typeof(TaskUploadPictureView), typeof(TaskUploadPictureViewModel));
        public static readonly BindableProperty AnswersProperty = BindableProperty.Create(nameof(Answers), typeof(List<string>), typeof(TaskUploadPictureView), defaultValue: default(List<string>), defaultBindingMode: BindingMode.TwoWay, propertyChanged: SelectValues);
        public static readonly BindableProperty FormattedQuestionTextProperty = BindableProperty.Create(nameof(FormattedQuestionText), typeof(FormattedString), typeof(TaskUploadPictureView), defaultValue: default(FormattedString), defaultBindingMode: BindingMode.TwoWay);
        public static readonly BindableProperty PhotoPathsProperty = BindableProperty.Create(nameof(PhotoPaths), typeof(ObservableCollection<TaskUploadPictureModel>), typeof(TaskUploadPictureView), defaultValue: default(ObservableCollection<TaskUploadPictureModel>), defaultBindingMode: BindingMode.TwoWay);
        public static readonly BindableProperty LongPressCommandProperty = BindableProperty.Create(nameof(LongPressCommand), typeof(Command), typeof(TaskUploadPictureView), defaultBindingMode: BindingMode.TwoWay);
        public static readonly BindableProperty LongPressCommandParameterProperty = BindableProperty.Create(nameof(LongPressCommandParameter), typeof(object), typeof(TaskUploadPictureView), defaultBindingMode: BindingMode.TwoWay);
        public static readonly BindableProperty SelectedPhotosProperty = BindableProperty.Create(nameof(SelectedPhotos), typeof(ObservableCollection<TaskUploadPictureModel>), typeof(TaskUploadPictureView), defaultValue: default(ObservableCollection<TaskUploadPictureModel>), defaultBindingMode: BindingMode.TwoWay);
        public static readonly BindableProperty CommandProperty = BindableProperty.Create(nameof(Command), typeof(Command), typeof(TaskUploadPictureView), defaultBindingMode: BindingMode.TwoWay);
        public static readonly BindableProperty CommandParameterProperty = BindableProperty.Create(nameof(CommandParameter), typeof(object), typeof(TaskUploadPictureView), defaultBindingMode: BindingMode.TwoWay);
        public static readonly BindableProperty TaskActivityStepIdProperty = BindableProperty.Create(nameof(TaskActivityStepId), typeof(int), typeof(TaskUploadPictureView), 0, defaultBindingMode: BindingMode.TwoWay);
        public static readonly BindableProperty ImagePressCommandProperty = BindableProperty.Create(nameof(ImagePressCommand), typeof(Command), typeof(TaskUploadPictureView), defaultBindingMode: BindingMode.TwoWay);
        public int TaskActivityStepId
        {
            get => (int)GetValue(TaskActivityStepIdProperty);
            set => SetValue(TaskActivityStepIdProperty, value);
        }
        public Command Command
        {
            get => (Command)GetValue(CommandProperty);
            set => SetValue(CommandProperty, value);
        }
        public object CommandParameter
        {
            get => GetValue(CommandParameterProperty);
            set => SetValue(CommandParameterProperty, value);
        }
        public object LongPressCommandParameter
        {
            get => GetValue(LongPressCommandParameterProperty);
            set => SetValue(LongPressCommandParameterProperty, value);
        }
        public Command LongPressCommand
        {
            get => (Command)GetValue(LongPressCommandProperty);
            set => SetValue(LongPressCommandProperty, value);
        }
        public Command ImagePressCommand
        {
            get => (Command)GetValue(ImagePressCommandProperty);
            set => SetValue(ImagePressCommandProperty, value);
        }
        public FormattedString FormattedQuestionText
        {
            get => (FormattedString)GetValue(FormattedQuestionTextProperty);
            set => SetValue(FormattedQuestionTextProperty, value);
        }
        public List<string> Answers
        {
            get => (List<string>)GetValue(AnswersProperty);
            set => SetValue(AnswersProperty, value);
        }

        public TaskUploadPictureViewModel ViewModel
        {
            get => (TaskUploadPictureViewModel)GetValue(ViewModelProperty);
            set => SetValue(ViewModelProperty, value);
        }
        public ObservableCollection<TaskUploadPictureModel> PhotoPaths
        {
            get => (ObservableCollection<TaskUploadPictureModel>)GetValue(PhotoPathsProperty);
            set => SetValue(PhotoPathsProperty, value);
        }
        public ObservableCollection<TaskUploadPictureModel> SelectedPhotos
        {
            get => (ObservableCollection<TaskUploadPictureModel>)GetValue(SelectedPhotosProperty);
            set => SetValue(SelectedPhotosProperty, value);
        }
        public string Text
        {
            get => (string)GetValue(TextProperty);
            set => SetValue(TextProperty, value);
        }

        private static void OnTitlePropertyChanged(BindableObject bindable, object oldValue, object newValue)
        {
            var customView = (TaskUploadPictureView)bindable;
        }
        public TaskUploadPictureView()
        {
            InitializeComponent();
            
            SelectedPhotos = new ObservableCollection<TaskUploadPictureModel>();
            //_serviceProvider = serviceProvider;
            if (_viewModel == null)
            {
                _viewModel = new TaskUploadPictureViewModel(App._serviceProvider, taskActivityStepId: TaskActivityStepId);
                LblName.Text = _viewModel.BtnName;
                PhotoCollectionView.HeightRequest = 0;
                PhotoCollectionView.SelectionMode = SelectionMode.Single;
            }

            LongPressCommand = new Command<TaskUploadPictureModel>((data) =>
            {
                if (_isCompletedTask)
                    return;

                _viewModel.LongPressCommand.Execute(data);
                data.IsSelected = true;
                SelectedPhotos.Add(data);
                PhotoCollectionView.SelectionMode = SelectionMode.Multiple;
                PhotoCollectionView.SelectedItems.Add(data);
                LblImage.IsVisible = false;
            });

            ImagePressCommand = new Command<TaskUploadPictureModel>((image) =>
            {
                if (_isCompletedTask)
                    return;

                if (!SelectedPhotos.Any())
                {
                    PhotoCollectionView.SelectedItem = null;
                    return;
                }

                ChangeImageSelection(image);
            });
        }

        private void ChangeImageSelection(TaskUploadPictureModel image)
        {
            if (image.IsSelected)
            {
                image.IsSelected = false;
                SelectedPhotos.Remove(image);
                PhotoCollectionView.SelectedItems.Remove(image);
                if (!SelectedPhotos.Any())
                {
                    PhotoCollectionView.SelectionMode = SelectionMode.Single;
                    SelectedPhotos = new ObservableCollection<TaskUploadPictureModel>();
                    PhotoCollectionView.SelectedItem = null;
                    LblImage.IsVisible = true;
                }
            }
            else
            {
                image.IsSelected = true;
                PhotoCollectionView.SelectedItems.Add(image);
                SelectedPhotos.Add(image);
            }

            _viewModel.SelectionChange(SelectedPhotos);
            LblName.Text = _viewModel.BtnName;
        }

        private static void SelectValues(BindableObject bindable, object oldvalue, object newvalue)
        {
            try
            {
                if (newvalue == null)
                    return;
                var view = (TaskUploadPictureView)bindable;
                var values = (List<string>)newvalue;
                view._isCompletedTask = true;
                if (!values.Any())
                    return;
                view.CameraButton.IsVisible = false;
                view.PhotoCollectionView.SelectionMode = SelectionMode.None;
                view.CreateDataForCompletedTask(values);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public List<TaskUploadPictureModel> CreateDataForCompletedTask(List<string> imageUrls)
        {
            var data = new List<TaskUploadPictureModel>();
            foreach (var image in imageUrls)
            {
                data.Add(new TaskUploadPictureModel()
                {
                    PhotoPath = image
                });
            }
            PhotoPaths = new ObservableCollection<TaskUploadPictureModel>(data);
            int baseHeight = (int)Math.Ceiling((double)PhotoPaths.Count / 2) * 160;
            PhotoCollectionView.HeightRequest = baseHeight;
            return data;
        }

        private void TapGestureRecognizer_OnTapped(object sender, EventArgs e)
        {
            if (_isCompletedTask)
                return;

            if (_viewModel == null)
                _viewModel = new TaskUploadPictureViewModel(_serviceProvider,taskActivityStepId: TaskActivityStepId);
            _viewModel._taskActivityStepId = TaskActivityStepId;
            _viewModel.BtnCommand.Execute(null);
            _viewModel.PropertyChanged += V1_PropertyChanged;
        }

        private void V1_PropertyChanged(object sender, System.ComponentModel.PropertyChangedEventArgs e)
        {
            if (_isCompletedTask)
                return;

            if (e.PropertyName == nameof(PhotoPaths))
            {
                PhotoPaths = _viewModel.PhotoPaths;
                PhotoCollectionView.ItemsLayout = new GridItemsLayout(2, ItemsLayoutOrientation.Vertical);
                UpdateData(PhotoPaths.Select(x => x.PhotoPath).ToList());
            }
            else if (e.PropertyName == nameof(_viewModel.ListHeight))
            {
                PhotoCollectionView.HeightRequest = _viewModel.ListHeight;
            }
            else if (e.PropertyName == nameof(_viewModel.ImgCameraVisibility))
            {
                LblName.Text = _viewModel.BtnName;
                LblImage.IsVisible = _viewModel.ImgCameraVisibility;
            }
        }

        private void PhotoCollectionView_OnSelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (_isCompletedTask)
                return;
            if (!SelectedPhotos.Any())
            {
                PhotoCollectionView.SelectedItem = null;
                return;
            }
        }
        private void UpdateData(List<string> answer)
        {
            if (CommandParameter is StoreWalkQuestionDetails data)
            {
                data.Answer = answer;
                Command.Execute(CommandParameter);
            }
        }
    }
}