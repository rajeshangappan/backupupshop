﻿using MobileUI2.Models.TaskActivities;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace MobileUI2.Components.TaskUploadPictureView
{
    public interface ITaskUploadPictureService
    {
        TaskUploadPictureModel GetModelData();
        Task<string> SavePictureTaskResponse(SaveTaskPhotoRequest req);
        Task<bool> DeleteTaskPhoto(List<DeleteTaskPhotoRequest> req);
    }
}
