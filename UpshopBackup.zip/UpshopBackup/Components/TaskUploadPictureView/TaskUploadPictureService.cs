﻿using MobileUI2.Models.TaskActivities;
using MobileUI2.Services;
using MobileUI2.Services.RequestProvider;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace MobileUI2.Components.TaskUploadPictureView
{
    public class TaskUploadPictureService : ITaskUploadPictureService
    {
        private readonly IRequestProvider _requestProvider;
        public TaskUploadPictureService(IRequestProvider reqProvider)
        {
            _requestProvider = reqProvider;
        }

        public TaskUploadPictureModel GetModelData()
        {
            var taskUploadPictureModel = new TaskUploadPictureModel
            {
                PictureText = "Take pictures of areas that do not meet company standards.", 
                
            };

            return taskUploadPictureModel;
        }

        public async Task<string> SavePictureTaskResponse(SaveTaskPhotoRequest req)
        {
            return await _requestProvider.PostAsync<SaveTaskPhotoRequest, string>(ConstantURLs.SavePhotoTaskStep, req);
        }

        public async Task<bool> DeleteTaskPhoto(List<DeleteTaskPhotoRequest> req)
        {
            return await _requestProvider.PostAsync<List<DeleteTaskPhotoRequest>, bool>(ConstantURLs.DeleteTaskPhotos, req);
        }
    }
}
