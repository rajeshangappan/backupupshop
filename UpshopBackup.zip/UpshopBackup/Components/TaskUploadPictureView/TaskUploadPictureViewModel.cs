﻿using MobileUI2.Controls;
using MobileUI2.Helpers.PermissionCheck;
using MobileUI2.Models.TaskActivities;
using System.Collections.ObjectModel;
using System.Windows.Input;

namespace MobileUI2.Components.TaskUploadPictureView
{
    public class TaskUploadPictureViewModel : BaseViewModel
    {
        private TaskUploadPictureModel taskUploadPictureModel;
        private ITaskUploadPictureService _taskUploadPictureService;
        private const int MaxPhotoCount = 20;
        internal string DeleteText = LiteralTranslator.GetValue("Delete");
        internal string TakePhotoText = LiteralTranslator.GetValue("TakeAPhoto");
        public int _taskActivityStepId;
        private IServiceProvider _serviceProvider;

        public TaskUploadPictureViewModel(IServiceProvider serviceProvider, ITaskUploadPictureService service = null,int taskActivityStepId = 0):base(serviceProvider)
        {
            _taskActivityStepId = taskActivityStepId;
            Initialize(service);
            UpdateBtnName();
            _serviceProvider = serviceProvider;
        }

        public void Initialize(ITaskUploadPictureService service)
        {
            try
            {
                if (service == null)
                    _taskUploadPictureService = _serviceProvider.GetService<ITaskUploadPictureService>();

                taskUploadPictureModel = service?.GetModelData() ?? throw new ArgumentNullException(nameof(service));
            }
            catch (Exception ex)
            {
            }
        }

        public string LblText
        {
            get { return taskUploadPictureModel.PictureText; }
            set
            {
                if (taskUploadPictureModel != null)
                {
                    taskUploadPictureModel.PictureText = value;
                    OnPropertyChanged(nameof(LblText));
                }
            }
        }

        public int GridLayoutSpan => CalculateGridLayoutSpan();

        private int CalculateGridLayoutSpan() =>
            Math.Min(2, PhotoPaths.Count > 0 ? (int)Math.Ceiling((double)PhotoPaths.Count / 5) : 2);

        private string _photoPath;

        public string PhotoPath
        {
            get => _photoPath;
            set => SetAndRaisePropertyChanged(ref _photoPath, value);
        }

        private bool _imgCameraVisibility;

        public bool ImgCameraVisibility
        {
            get => _imgCameraVisibility;
            set
            {
                _imgCameraVisibility = value;
                OnPropertyChanged("ImgCameraVisibility");
            }
        }

        private double _listHeight;

        public double ListHeight
        {
            get => _listHeight;
            set
            {
                _listHeight = value;
                OnPropertyChanged();
            }
        }

        private ObservableCollection<TaskUploadPictureModel> _photoPaths =
            new ObservableCollection<TaskUploadPictureModel>();

        public ObservableCollection<TaskUploadPictureModel> PhotoPaths
        {
            get => _photoPaths;
            set
            {
                OnPropertyChanged();
                UpdateCollectionViewHeight();
            }

        }

        private string _selectedPhotoPath;

        public string SelectedPhotoPath
        {
            get => _selectedPhotoPath;
            set => SetAndRaisePropertyChanged(ref _selectedPhotoPath, value);
        }

        private ObservableCollection<TaskUploadPictureModel> _selectedPhotos =
            new ObservableCollection<TaskUploadPictureModel>();

        public ObservableCollection<TaskUploadPictureModel> SelectedPhotos
        {
            get => _selectedPhotos;
            set
            {
                SetAndRaisePropertyChanged(ref _selectedPhotos, value);
                UpdateBtnName();
            }
        }

        private TaskUploadPictureModel _selectedPicture;

        public TaskUploadPictureModel SelectedPicture
        {
            get => _selectedPicture;
            set
            {
                if (_selectedPicture != null)
                {
                    _selectedPicture.IsSelected = false;
                }

                SetAndRaisePropertyChanged(ref _selectedPicture, value);

                if (_selectedPicture != null)
                {
                    _selectedPicture.IsSelected = true;
                }

                OnPropertyChanged(nameof(SelectedPicture));
            }
        }

        private SelectionMode _selectionMode = SelectionMode.None;
        public string SelectedItem { get; set; }

        public SelectionMode SelectionMode
        {
            get => _selectionMode;
            set => SetAndRaisePropertyChanged(ref _selectionMode, value);
        }

        private string _btnName;

        public string BtnName
        {
            get => _btnName;
            set => SetAndRaisePropertyChanged(ref _btnName, value);
        }
        public ICommand OpenCameraCommand => new Command(async () => await OnOpenCamera());

        private ICommand _pictureTappedCommand;

        public ICommand PictureTappedCommand => _pictureTappedCommand ??
                                                (_pictureTappedCommand =
                                                    new Command<TaskUploadPictureModel>(OnPictureTapped));

        private ICommand _deletePictureCommand;

        public ICommand DeletePictureCommand =>
            _deletePictureCommand ?? (_deletePictureCommand = new Command(async ()=> await OnDeleteSelectedPictures()));

        private ICommand _longPressCommand;

        public ICommand LongPressCommand =>
            (_longPressCommand ?? (_longPressCommand = new Command<TaskUploadPictureModel>(OnLongPress)));

        private ICommand _btnCommand;

        public ICommand BtnCommand
        {
            get => _btnCommand;
            set => SetAndRaisePropertyChanged(ref _btnCommand, value);
        }

        private async Task OnOpenCamera()
        {
            
                //var settings = new  StoreCameraMediaOptions()
                //{
                //    CompressionQuality = 60,
                //    DefaultCamera = CameraDevice.Rear,
                //    PhotoSize = PhotoSize.Medium,
                //    RotateImage = true,
                //    SaveToAlbum = false,
                //    SaveMetaData = true
                //};

            try
            {
                // Check if the number of photos has reached the max allowed
                if (PhotoPaths.Count == MaxPhotoCount)
                {
                    await Alert.ShowToast(string.Format(LiteralTranslator.GetValue("MaximumPhotoCount"), MaxPhotoCount), true);
                    return;
                }

                // Permissions check
                if (!await DevicePermissionsCheck.PhotosPermission() ||
                    !await DevicePermissionsCheck.CameraPermission() ||
                    !await DevicePermissionsCheck.StoragePermission())
                {
                    await Alert.OpenAlert(LiteralTranslator.GetValue("PermissionHeading"),
                                          LiteralTranslator.GetValue("PermissionBody"),
                                          new Command(() => AppInfo.ShowSettingsUI()), "Settings",
                                          "Cancel", new Command(async () => await Alert.CloseAlert()));
                    return;
                }

                // Set MediaPicker options (approximate options, MAUI doesn't have all settings)
                var photoOptions = new MediaPickerOptions
                {
                    
                    //PhotoSize = PhotoSize.Medium,  // Controls the photo size
                    //RotateImage = true,
                    //CompressionQuality = 60,
                    //DefaultCamera = CameraDevice.Rear,
                    //PhotoSize = PhotoSize.Medium,
                    //RotateImage = true,
                    //SaveToAlbum = false,
                    //SaveMetaData = true// Auto-rotate image if necessary
                };

                // Open the camera and take a photo
                var photo = await MediaPicker.CapturePhotoAsync(photoOptions);

                if (photo != null)
                {
                    // Load the captured photo
                    await LoadPhotoAsync(photo);
                }
            }
            catch (FeatureNotSupportedException fnsEx)
            {
                await Alert.OpenAlert("Error", "Camera not supported.");
            }
            catch (PermissionException pEx)
            {
                await Alert.OpenAlert(LiteralTranslator.GetValue("PermissionHeading"),
                                      LiteralTranslator.GetValue("PermissionBody"),
                                      new Command(() => AppInfo.ShowSettingsUI()), "Settings",
                                      "Cancel", new Command(async () => await Alert.CloseAlert()));
            }
            catch (Exception ex)
            {
                Console.WriteLine($"CapturePhotoAsync THREW: {ex.Message}");
            }
        }

     

       public async Task<string> LoadPhotoAsync(FileResult photo)
       {
            if (photo == null)
            {
                return null;
            }

            // Generate a new file name based on the current timestamp
            var fileName = "IMG_" + DateTime.Now.ToString("yyyyMMdd_HHmmss") + ".jpg";
            byte[] photoBytes;
            string newFilePath = string.Empty;

            // Read the file from the FileResult stream
            using (var stream = await photo.OpenReadAsync())  // OpenReadAsync replaces the GetStreamWithImageRotatedForExternalStorage() method
            {
                MemoryStream ms = new MemoryStream();
                await stream.CopyToAsync(ms); // Copy the photo stream to memory
                photoBytes = ms.ToArray();
            }

            // Create a request object to save the photo
            var request = new SaveTaskPhotoRequest
            {
                TaskActivityStepId = _taskActivityStepId,
                MediaData = photoBytes,
                FileName = fileName
            };

            // Call your method to save the photo (adjusted for the new API)
            var result = await TryExecuteWithLoadingIndicatorsAsync(_taskUploadPictureService.SavePictureTaskResponse(request));
            if (result.IsSuccess)
            {
                newFilePath = result.Value;
            }

            // Add the photo path to your collection if the maximum count hasn't been reached
            if (PhotoPaths.Count < MaxPhotoCount)
            {
                var pictureSelector = new TaskUploadPictureModel
                {
                    PhotoPath = newFilePath,
                    IsSelected = false,
                    ImageName = fileName,
                    TaskActivityStepId = _taskActivityStepId
                };

                PhotoPaths.Add(pictureSelector);
                OnPropertyChanged(nameof(PhotoPaths));
                UpdateCollectionViewHeight();  // Make sure to implement this method to adjust the UI as needed
            }
            else
            {
                // Handle the case when the maximum photo count is reached
                await Alert.ShowToast(string.Format(LiteralTranslator.GetValue("MaximumPhotoCount"), MaxPhotoCount), true);
            }

            return newFilePath;  // Return the new file path
        }


    private string ConvertImageToBase64String(string path)
        {
            byte[] imageArray = System.IO.File.ReadAllBytes(path);
            return Convert.ToBase64String(imageArray);
        }

        public ImageSource Base64ToImage(string base64String)
        {
            byte[] imageBytes = Convert.FromBase64String(base64String);
            return ImageSource.FromStream(() => new MemoryStream(imageBytes));
        }

        public void UpdateCollectionViewHeight()
        {
            try
            {
                int rowHeight = 160;
                int baseHeight = (int)Math.Ceiling((double)PhotoPaths.Count / 2) * rowHeight;
                ListHeight = baseHeight;
            }
            catch (Exception ex)
            {

            }
        }

        private void OnPictureTapped(TaskUploadPictureModel pictureSelectorModel)
        {
            if (SelectedPicture != null && SelectedPicture.PhotoPath == pictureSelectorModel.PhotoPath)
            {
                SelectedPicture = null;
            }
            else
            {
                SelectedPicture = pictureSelectorModel;
            }
        }

        private void UpdateBtnName()
        {
            BtnName = SelectedPhotos.Count > 0 ? DeleteText : TakePhotoText;
            BtnCommand = SelectedPhotos.Count > 0 ? DeletePictureCommand : OpenCameraCommand;

            ImgCameraVisibility = BtnName != DeleteText;
        }

        private async Task OnDeleteSelectedPictures()
        {
            var deleteRequest = new List<DeleteTaskPhotoRequest>();
            foreach (var selectedPhoto in SelectedPhotos.ToList())
            {
                PhotoPaths.Remove(selectedPhoto);
                OnPropertyChanged(nameof(PhotoPaths));
                if (File.Exists(selectedPhoto.ImageName))
                {
                    File.Delete(selectedPhoto.ImageName);
                }
                deleteRequest.Add(new DeleteTaskPhotoRequest()
                {
                    FileName = selectedPhoto.ImageName,
                    TaskActivityStepId = selectedPhoto.TaskActivityStepId
                });
            }
            await _taskUploadPictureService.DeleteTaskPhoto(deleteRequest);
            SelectedPhotos.Clear();
            UpdateCollectionViewHeight();
            UpdateBtnName();
        }

        private void OnLongPress(TaskUploadPictureModel photo)
        {
            if (_selectionMode == SelectionMode.None)
            {
                SelectionMode = SelectionMode.Multiple;
            }

            photo.IsSelected = !photo.IsSelected;

            if (photo.IsSelected)
            {
                SelectedPhotos.Add(photo);
            }
            else
            {
                SelectedPhotos.Remove(photo);
            }
            UpdateBtnName();
        }

        public void SelectionChange(ObservableCollection<TaskUploadPictureModel> photos)
        {
            if (photos == null || photos.Count == 0)
            {
                SelectedPhotos = new ObservableCollection<TaskUploadPictureModel>();
            }
            else
            {
                SelectedPhotos = photos;
            }
            UpdateBtnName();
        }

    }
}
