﻿using System.ComponentModel;
using Microsoft.Maui.Controls.Compatibility;
using Microsoft.Maui.Controls;
using Microsoft.Maui;

namespace MobileUI2.Components.TaskUploadPictureView
{
    public class TaskUploadPictureModel : INotifyPropertyChanged
    {
        public string PictureText { get; set; }
        public string PhotoPath { get; set; }
        public string ImageName { get; set; }
        public string ImageBase64String { get; set; }
        public ImageSource ImageSource { get; set; }
        public int TaskActivityStepId { get; set; }

        private bool _isSelected;

        public bool IsSelected
        {
            get => _isSelected;
            set
            {
                if (_isSelected != value)
                {
                    _isSelected = value;
                    OnPropertyChanged(nameof(IsSelected));
                }
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;
        protected virtual void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }

}

