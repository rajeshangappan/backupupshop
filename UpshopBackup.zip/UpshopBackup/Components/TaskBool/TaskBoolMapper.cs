﻿namespace MobileUI2.Components.TaskBool
{
    internal static class TaskBoolMapper
    {
    }
}
