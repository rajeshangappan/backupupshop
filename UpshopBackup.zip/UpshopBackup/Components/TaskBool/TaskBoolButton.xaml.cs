﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Maui.Controls.Xaml;
using Microsoft.Maui.Controls.Compatibility;
using Microsoft.Maui.Controls;
using Microsoft.Maui;
using CommunityToolkit.Maui.Behaviors;

namespace MobileUI2.Components.TaskBool
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class TaskBoolButton
    {
        public TaskBoolButton()
        {
            InitializeComponent();
        }
        public static readonly BindableProperty CornerRadiusProperty =
     BindableProperty.Create(
         nameof(CornerRadius),
         typeof(float),
         typeof(TaskBoolButton),
         26f); // default value

        public float CornerRadius
        {
            get => (float)GetValue(CornerRadiusProperty);
            set => SetValue(CornerRadiusProperty, value);
        }
        public static readonly BindableProperty BorderColorProperty =
            BindableProperty.Create(nameof(BorderColor), typeof(Color), typeof(TaskBoolButton), Colors.Transparent);

        public Color BorderColor
        {
            get => (Color)GetValue(BorderColorProperty);
            set => SetValue(BorderColorProperty, value);
        }

        public static readonly BindableProperty BorderWidthProperty =
            BindableProperty.Create(nameof(BorderWidth), typeof(double), typeof(TaskBoolButton), 0.0);

        public double BorderWidth
        {
            get => (double)GetValue(BorderWidthProperty);
            set => SetValue(BorderWidthProperty, value);
        }
        public static BindableProperty ButtonClickCommandProperty =
            BindableProperty.Create(
                nameof(ButtonClickCommand),
                typeof(Command),
                typeof(Frame),
                defaultValue: default(Command),
                defaultBindingMode: BindingMode.OneWay
            );

        public Command ButtonClickCommand
        {
            get { return (Command)GetValue(ButtonClickCommandProperty); }
            set { SetValue(ButtonClickCommandProperty, value); }
        }
        public static BindableProperty TextProperty =
            BindableProperty.Create(
                nameof(Text),
                typeof(string),
                typeof(Label),
                defaultValue: default(string),
                defaultBindingMode: BindingMode.TwoWay
            );

        public string Text
        {
            get { return (string)GetValue(TextProperty); }
            set { SetValue(TextProperty, value); }
        }
        public static readonly BindableProperty TextColorProperty =
            BindableProperty.Create(nameof(TextColor),
                typeof(Color),
                typeof(Label),
                defaultValue: default(Color),
                defaultBindingMode: BindingMode.TwoWay);

        public Color TextColor
        {
            get => (Color)GetValue(TextColorProperty);
            set => SetValue(TextColorProperty, value);
        }

        public static readonly BindableProperty ButtonBackgroundColorProperty =
            BindableProperty.Create(nameof(ButtonBackgroundColor),
                typeof(Color),
                typeof(TaskBoolButton),
                defaultValue: default(Color),
                defaultBindingMode: BindingMode.TwoWay);

        public Color ButtonBackgroundColor
        {
            get => (Color)GetValue(ButtonBackgroundColorProperty);
            set => SetValue(ButtonBackgroundColorProperty, value);
        }

    }
}