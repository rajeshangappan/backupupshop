﻿using MobileUI2.Services.Login;
using System;
using System.ComponentModel;
using MobileUI2.Models.StoreWalks;
using MobileUI2.ViewModels.StoreWalks;
using MobileUI2.Models.Tasks;
using Microsoft.Maui.Controls.Compatibility;
using Microsoft.Maui.Controls;
using Microsoft.Maui;
using CommunityToolkit.Maui.Converters;
using CommunityToolkit.Maui.ImageSources;
using CommunityToolkit.Maui;
using CommunityToolkit.Maui.Core;
using CommunityToolkit.Maui.Layouts;
using CommunityToolkit.Maui.Views;

namespace MobileUI2.Components.TaskBool
{
    public class TaskBoolViewModel : INotifyPropertyChanged
    {
        private TaskBoolModel _taskBoolModel;
        private bool _isYesButtonClicked;
        private bool _isNoButtonClicked;
        private bool _isStoreWalkMainQuestion;
        private ITaskBoolService _taskBoolService;
        private IServiceProvider _serviceProvider;
        public TaskBoolViewModel(IServiceProvider serviceProvider)
        {
            // Initialize(boolService);
            _serviceProvider = serviceProvider;
            _taskBoolService = _serviceProvider.GetService<ITaskBoolService>();
            YesCommand = new Command(OnBtnYesClicked);
            NoCommand = new Command(OnBtnNoClicked);
        }

        public string Title
        {
            get { return _taskBoolModel?.Title; }
            set
            {
                if (_taskBoolModel != null)
                {
                    _taskBoolModel.Title = value;
                    OnPropertyChanged(nameof(Title));
                }
            }
        }

        public bool IsStoreWalkMainQuestion
        {
            get { return _isStoreWalkMainQuestion; }
            set
            {
                _isStoreWalkMainQuestion = value;
                OnPropertyChanged(nameof(IsStoreWalkMainQuestion));
            }
        }

        public string BtnYesText
        {
            get { return _taskBoolModel?.BtnYesText; }
            set
            {
                if (_taskBoolModel != null)
                {
                    _taskBoolModel.BtnYesText = value;
                    OnPropertyChanged(nameof(BtnYesText));
                }
            }
        }

        public string BtnNoText
        {
            get { return _taskBoolModel?.BtnNoText; }
            set
            {
                if (_taskBoolModel != null)
                {
                    _taskBoolModel.BtnNoText = value;
                    OnPropertyChanged(nameof(BtnNoText));
                }
            }
        }

        public bool IsYesButtonClicked
        {
            get { return _isYesButtonClicked; }
            set
            {
                _isYesButtonClicked = value;
                OnPropertyChanged(nameof(IsYesButtonClicked));
            }
        }

        public bool IsNoButtonClicked
        {
            get { return _isNoButtonClicked; }
            set
            {
                _isNoButtonClicked = value;
                OnPropertyChanged(nameof(IsNoButtonClicked));
            }
        }

        public Command YesCommand { get;  set; }
        public Command NoCommand { get;  set; }

        private void OnBtnYesClicked(object obj)
        {
            IsYesButtonClicked = true;
            IsNoButtonClicked = false;
        }

        private void OnBtnNoClicked(object obj)
        {
            IsNoButtonClicked = true;
            IsYesButtonClicked = false;
        }

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
