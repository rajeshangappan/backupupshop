﻿using MobileUI2.Components.TaskMultipleSelectCheckboxView;
using MobileUI2.Models.StoreWalks;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using MobileUI2.Models.Tasks;
using MobileUI2.ViewModels.StoreWalks;
using Microsoft.Maui.Controls.Xaml;
using Microsoft.Maui.Controls.Compatibility;
using Microsoft.Maui.Controls;
using Microsoft.Maui;

namespace MobileUI2.Components.TaskBool
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class TaskBoolView : ContentView
    {
        public bool IsCompletedTask;
        public TaskBoolView()
        {
            InitializeComponent();
            IsYesButtonClicked = false;
            IsNoButtonClicked = false;
            StoreWalkEventManager.StoreWalkMainYesOrNoResetEvent += (sender, args) =>
            {
                if((Answers?.Any() ?? false) && IsStoreWalkMainQuestion)
                    return;
                IsYesButtonClicked = false;
                IsNoButtonClicked = false;
                IsCompletedTask = false;
            };
        }

        public static readonly BindableProperty AnswersProperty =
            BindableProperty.Create(nameof(QuestionText), typeof(List<string>), typeof(TaskBoolView), defaultValue: default(List<string>), defaultBindingMode: BindingMode.TwoWay,propertyChanged:SelectValues);

        private static void SelectValues(BindableObject bindable, object oldvalue, object newvalue)
        {
            if (newvalue == null)
                return;
            var customView = (TaskBoolView)bindable;
            var value = (List<string>)newvalue;
            if (!value.Any())
            {
                customView.IsCompletedTask = true;
                return;
            }
            if (value[0] == LiteralTranslator.GetValue("Yes"))
                customView.IsYesButtonClicked = true;
            else if (value[0] == LiteralTranslator.GetValue("No"))
                customView.IsNoButtonClicked = true;
            customView.IsCompletedTask = true;
        }

        public List<string> Answers
        {
            get => (List<string>)GetValue(AnswersProperty);
            set => SetValue(AnswersProperty, value);
        }

        public static readonly BindableProperty QuestionTextProperty =
            BindableProperty.Create(nameof(QuestionText), typeof(string), typeof(TaskBoolView),defaultValue:default(string),defaultBindingMode:BindingMode.TwoWay);

        public string QuestionText
        {
            get => (string)GetValue(QuestionTextProperty);
            set => SetValue(QuestionTextProperty, value);
        }

        public static readonly BindableProperty FormattedQuestionTextProperty =
            BindableProperty.Create(nameof(FormattedQuestionText), typeof(FormattedString), typeof(TaskBoolView), defaultValue: default(FormattedString), defaultBindingMode: BindingMode.TwoWay);

        public FormattedString FormattedQuestionText
        {
            get => (FormattedString)GetValue(FormattedQuestionTextProperty);
            set => SetValue(FormattedQuestionTextProperty, value);
        }

        public static readonly BindableProperty IsYesButtonClickedProperty =
            BindableProperty.Create(nameof(IsYesButtonClicked), typeof(bool), typeof(TaskBoolView), false);

        public bool IsYesButtonClicked
        {
            get => (bool)GetValue(IsYesButtonClickedProperty);
            set => SetValue(IsYesButtonClickedProperty, value);
        }

        public static readonly BindableProperty IsNoButtonClickedProperty =
            BindableProperty.Create(nameof(IsNoButtonClicked), typeof(bool), typeof(TaskBoolView), false);

        public bool IsNoButtonClicked
        {
            get => (bool)GetValue(IsNoButtonClickedProperty);
            set => SetValue(IsNoButtonClickedProperty, value);
        }

        public static BindableProperty IsStoreWalkMainQuestionProperty =
            BindableProperty.Create(
                nameof(IsStoreWalkMainQuestion),
                typeof(bool),
                typeof(TaskBoolView),
                defaultValue: default(bool),
                defaultBindingMode: BindingMode.TwoWay,
                propertyChanged: OnCustomValueChanged
            );
        public Command Command
        {
            get { return (Command)GetValue(CommandProperty); }
            set { SetValue(CommandProperty, value); }
        }

        public static BindableProperty CommandProperty =
            BindableProperty.Create(
                nameof(Command),
                typeof(Command),
                typeof(TaskBoolView),
                defaultBindingMode: BindingMode.TwoWay);

        public static BindableProperty CommandParameterProperty =
            BindableProperty.Create(
                nameof(CommandParameter),
                typeof(object),
                typeof(TaskBoolView),
                defaultBindingMode: BindingMode.TwoWay);

        public object CommandParameter
        {
            get => GetValue(CommandParameterProperty);
            set => SetValue(CommandParameterProperty, value);
        }

        private static void OnCustomValueChanged(BindableObject bindable, object oldvalue, object newvalue)
        {
            var customView = (TaskBoolView)bindable;
        }

        public bool IsStoreWalkMainQuestion
        {
            get { return (bool)GetValue(IsStoreWalkMainQuestionProperty); }
            set
            {
                SetValue(IsStoreWalkMainQuestionProperty, value);
            }
        }
        public static readonly BindableProperty IsAnswerRequiredProperty =
            BindableProperty.Create(nameof(IsAnswerRequired), typeof(bool), typeof(TaskBoolView), false);

        public bool IsAnswerRequired
        {
            get => (bool)GetValue(IsAnswerRequiredProperty);
            set => SetValue(IsAnswerRequiredProperty, value);
        }
        public Command YesCommand => new Command(YesClick);
        public Command NoCommand => new Command(NoClick);

        private void YesClick(object obj)
        {
            if (IsCompletedTask)
                return;
            IsYesButtonClicked = true;
            IsNoButtonClicked = false;
            if (CommandParameter is StoreWalkQuestionDetails)
            {
                var data = (StoreWalkQuestionDetails)CommandParameter;
                data.Answer = new List<string>() { "Yes" };
                Command.Execute(CommandParameter);
            }
            else Command.Execute(ResponseAppearsTypeEnum.Yes);
        }

        private void NoClick(object obj)
        {
            if (IsCompletedTask)
                return;
            IsYesButtonClicked = false;
            IsNoButtonClicked = true;
            if (CommandParameter is StoreWalkQuestionDetails)
            {
                var data = (StoreWalkQuestionDetails)CommandParameter;
                data.Answer = new List<string>() { "No" };
                Command.Execute(CommandParameter);
            }
            else Command.Execute(ResponseAppearsTypeEnum.No);
        }

    }
}