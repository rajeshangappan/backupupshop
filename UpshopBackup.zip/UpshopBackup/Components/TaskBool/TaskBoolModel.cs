﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Components.TaskBool
{
    public class TaskBoolModel
    {
        private string _title;
        private string _btnYesText;
        private string _btnNoText;

        public string Title
        {
            get { return _title; }
            set { _title = value; }
        }

        public string BtnYesText
        {
            get { return _btnYesText; }
            set { _btnYesText = value; }
        }

        public string BtnNoText
        {
            get { return _btnNoText; }
            set { _btnNoText = value; }
        }
    }
}
