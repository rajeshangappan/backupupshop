﻿using MobileUI2.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace MobileUI2.Components.TaskBool
{
    public interface ITaskBoolService
    {
        TaskBoolModel GetBoolModel();
    }
}
