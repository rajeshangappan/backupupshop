﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace MobileUI2.Components.TaskBool
{
    public class TaskBoolService : ITaskBoolService
    {
        public TaskBoolModel GetBoolModel()
        {
            var question = new TaskBoolModel
            {
                Title = "Sample Question ????",
                BtnYesText = "Yes",
                BtnNoText = "No"
            };

            return question;
        }
    }
}
