﻿namespace MobileUI2.Components
{
    public class SearchData
    {
        public int Id { get; set; }
        public string Text { get; set; }
        public required FormattedString FormattedText { get; set; }       
    }
}
