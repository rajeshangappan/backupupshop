﻿
using Acr.UserDialogs.Infrastructure;
using MobileUI2.Constants;
using MobileUI2.Controls;
using MobileUI2.Logging;
using MobileUI2.Models.PrintLabels;
using MobileUI2.Models.ProductionPlan;
using MobileUI2.Services;
using MobileUI2.Services.Navigation;
using MobileUI2.Services.PrintLabels.DaymarkPrinter;
using MobileUI2.ViewModels;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;
using Microsoft.Maui.Controls.Compatibility;
using Microsoft.Maui.Controls;
using Microsoft.Maui;
using Microsoft.Maui.Devices;
using Microsoft.Maui.ApplicationModel;

namespace MobileUI2.DayMark
{
    public interface IDayMarkService
    {
        Task<bool> InitForAutoRoute();
        Task<bool> ConnectUsingUuid(DayMarkPrinterDetails printer);
        DayMarkPrinterDetails FindAvailableDevice(List<DayMarkPrinterDetails> printers);
        Task<bool> Print(int printerId, string uuid, string zplData, bool isRetry = false);
        Task<bool> Disconnect(bool ignoreLoading = false);
        Task<GenerateSecretKeyResponse> AddCreditsScan(int printerId, string uuid);
        bool IsConnected();
        string GetDayMarkPrinterIdentifier(string dayMarkPrinterName);
        string GetPrinterUuid(string printerName);
        void StartScan();
    }
    public class DayMarkService : IDayMarkService
    {
        private readonly IDayMarkPrinterService _dayMarkPrinterService;
        private List<string> _deviceList = new List<string>();
        private readonly ILabelPrinterService _labelPrintService;
        private readonly INavigationService _navigationService;
        private readonly IDialogService _dialogService;
        private readonly ILoggingService _log;
        private readonly ILocalCacheService _cacheService;
        private TaskCompletionSource<bool> _printErrorPopupCompletionSource = new TaskCompletionSource<bool>();
        private IServiceProvider _iserviceProvider;

        public DayMarkService(ILabelPrinterService labelPrintService,
            INavigationService navigationService, IDialogService dialogService, ILocalCacheService localCache, ILoggingService loggingService,IDayMarkPrinterService dayMarkPrinterService)
        {
            //_iserviceProvider=serviceProvider;
            //#if __IOS__ && !SIMULATOR
            if (DeviceInfo.Platform == DevicePlatform.iOS)
            {
                _dayMarkPrinterService=dayMarkPrinterService;
                //_dayMarkPrinterService = _iserviceProvider.GetService<IDayMarkPrinterService>();
                GetDeviceList();
                InovkeEvents();
            }
            //#endif
            _labelPrintService = labelPrintService;
            _navigationService = navigationService;
            _dialogService = dialogService;
            _log = loggingService;
            _cacheService = localCache;
        }

        private void GetDeviceList()
        {
            _deviceList.Clear();
            DaymarkPrinterEventManager.DeviceFoundEvent += (sender, args) =>
            {
                if (sender is string printerName)
                {
                    _deviceList.Add(printerName);
                }
            };
        }

        private void InovkeEvents()
        {
            DaymarkPrinterEventManager.DayMarkPrinterErrorPopup += (sender, args) =>
            {
                _printErrorPopupCompletionSource?.TrySetResult(true);
            };
            DaymarkPrinterEventManager.PrinterDisConnected += (sender, args) =>
            {
                if(sender is string printerName)
                {
                    if (_deviceList.Contains(printerName))
                        _deviceList.Remove(printerName);
                }
            };
        }

        public void StartScan()
        {
            _deviceList.Clear();
            _dayMarkPrinterService.StartScan();
        }

        public DayMarkPrinterDetails FindAvailableDevice(List<DayMarkPrinterDetails> printers)
        {
            foreach (var printer in printers)
            {
                var deviceId = GetDayMarkPrinterIdentifier(printer.PrinterName);
                var device = _deviceList.FirstOrDefault(deviceName => deviceName.Contains(deviceId));
                if (device != null)
                {
                    printer.UUID = GetPrinterUuid(deviceId);
                    return printer;
                }
            }
            return new DayMarkPrinterDetails();
        }

        public string GetPrinterUuid(string deviceId)
        {
            var uuid = _dayMarkPrinterService.GetPrintUuid(deviceId);
            return uuid;
        }

        public async Task<bool> InitForAutoRoute()
        {
            var email = await GetUserEmail();

            if (string.IsNullOrWhiteSpace(email))
            {
                await _dialogService.HideLoading();
                await Alert.OpenAlert(LiteralTranslator.GetValue("Alert"), LiteralTranslator.GetValue("DaymarkEmailAddressNotFoundError"), GlobalSettings.IsTabletDevice);
                return false;
            }

            if (!_dayMarkPrinterService.CheckBluetoothAvailability())
            {
                await _dialogService.HideLoading();
                await Alert.OpenAlert(LiteralTranslator.GetValue("Alert"), "Please turn on Bluetooth to use this feature. You can enable Bluetooth in your device settings.", GlobalSettings.IsTabletDevice);
                return false;
            }
            _log.Log("Daymark InIt called");
            try
            {
                var isInitialized = _dayMarkPrinterService.InitForAutoRoute();//_iserviceProvider.GetService<IDayMarkPrinterService>().InitForAutoRoute();
                if (isInitialized)
                {
                    await _dialogService.HideLoading();
                    return true;
                }
            }
            catch (Exception ex)
            {
                _log.Error(ex);
            }

            await _dialogService.HideLoading();
            await Alert.OpenAlert(LiteralTranslator.GetValue("Alert"), LiteralTranslator.GetValue("DaymarkDeviceNotFoundError"), GlobalSettings.IsTabletDevice);
            return false;
        }

        public async Task<bool> ConnectUsingUuid(DayMarkPrinterDetails printer)
        {
            _log.Log("Connect method called");
            var connectedStatus = await _dayMarkPrinterService.ConnectUsingUuid(printer.UUID);
            if (connectedStatus is bool isConnected && isConnected)
            {
                if (string.IsNullOrEmpty(printer.UUID) || string.IsNullOrWhiteSpace(printer.ApprovedLabelSize) || string.IsNullOrWhiteSpace(printer.SecretKey))
                {
                    var keyDetails = await AddCreditsScan(printer.PrinterId, printer.UUID);
                    if (keyDetails != null && keyDetails.IsKeyLabelValid)
                        return true;
                    return false;
                }
                await SignIn(printer.ApprovedLabelSize, printer.SecretKey);
                return true;
            }
            await _dialogService.HideLoading();
            _printErrorPopupCompletionSource = new TaskCompletionSource<bool>();
            if (connectedStatus is string statusMessage && !string.IsNullOrEmpty(statusMessage))
            {
                await Alert.OpenAlert(LiteralTranslator.GetValue("Alert"), statusMessage, GlobalSettings.IsTabletDevice);
            }
            else
                await Alert.OpenAlert(LiteralTranslator.GetValue("Alert"), LiteralTranslator.GetValue("DaymarkDeviceConnectionError"), GlobalSettings.IsTabletDevice);
            await _printErrorPopupCompletionSource.Task;
            return false;
        }

        public async Task SignIn(string approvedLabelSize, string secretKey)
        {
            var email = await GetUserEmail();
            _log.Log($"Signing in with accountId:{email} : label size {approvedLabelSize} : secret key {secretKey}");
        
            _dayMarkPrinterService.SignIn(email,approvedLabelSize,secretKey);
        }

        public async Task<bool> Disconnect(bool ignoreLoading = false)
        {
            if (DeviceInfo.Platform != DevicePlatform.iOS)
                return true;

            _dayMarkPrinterService.SignOut();
            var result = _dayMarkPrinterService.Disconnect();
            if (!ignoreLoading)
                await _dialogService.HideLoading();
            if (!result && !ignoreLoading)
                await Alert.ShowToast(LiteralTranslator.GetValue("DaymarkCouldNotDisconnectPrinterError"), true);
            return result;
        }

        public async Task<GenerateSecretKeyResponse> AddCreditsScan(int printerId, string uuid)
        {
            try
            {
                _log.Log("Generate secret key api called");
                var secretKeyResponse = await GenerateSecretKey(printerId, uuid);

                if (secretKeyResponse != null && secretKeyResponse.IsSuccess && secretKeyResponse.IsKeyLabelValid)
                {
                    _log.Log("Generate secret key api successful");
                    await HandleSuccess(secretKeyResponse);
                    return secretKeyResponse;
                }
                _log.Log("Generate secret key api failed");
                await HandleFailure(secretKeyResponse);
                return new GenerateSecretKeyResponse();
            }
            catch (Exception ex)
            {
                await HandleException(ex);
                return new GenerateSecretKeyResponse();
            }
        }

        private async Task HandleSuccess(GenerateSecretKeyResponse secretKeyResponse)
        {
            await _dialogService.HideLoading();
            await SignIn(secretKeyResponse.ApprovedLabelSize, secretKeyResponse.LabelSecretKey);
        }

        private async Task HandleFailure(GenerateSecretKeyResponse secretKeyResponse)
        {
            string errorMessage = GetErrorMessage(secretKeyResponse);
            Acr.UserDialogs.UserDialogs.Instance.HideLoading();
            await _dialogService.HideLoading();
            _printErrorPopupCompletionSource = new TaskCompletionSource<bool>();
            await Alert.OpenAlert(LiteralTranslator.GetValue("Alert"), errorMessage, GlobalSettings.IsTabletDevice);
            await _printErrorPopupCompletionSource.Task;
        }

        private string GetErrorMessage(GenerateSecretKeyResponse secretKeyResponse)
        {
            string errorMessage = string.Empty;
            switch (secretKeyResponse.Message.ToLowerInvariant())
            {
                case DaymarkPrinterConstants.TotalScanCountExceeded:
                    errorMessage = LiteralTranslator.GetValue("DaymarkTotalScanCountExceeded");
                    break;
                case DaymarkPrinterConstants.UserNotFound:
                case DaymarkPrinterConstants.UsernameRequired:
                    errorMessage = LiteralTranslator.GetValue("DaymarkUserNotFound");
                    break;
                case DaymarkPrinterConstants.IncorrectPackageName:
                    errorMessage = LiteralTranslator.GetValue("DaymarkIncorrectPackageName");
                    break;
                case DaymarkPrinterConstants.InvalidKeyLabel:
                    errorMessage = LiteralTranslator.GetValue("InvalidKeyLabel");
                    break;
                default:
                    secretKeyResponse.Message = (string.IsNullOrEmpty(secretKeyResponse.Message) && !string.IsNullOrEmpty(secretKeyResponse.ErrorMessage))
                        ? "Something went wrong, from the server side, please try again after some time"
                        : secretKeyResponse.Message;
                    errorMessage = secretKeyResponse.Message;
                    break;
            }

            return errorMessage;
        }

        private async Task HandleException(Exception ex)
        {
            await _dialogService.HideLoading();
            await Alert.OpenAlert(LiteralTranslator.GetValue("Alert"), "Something went wrong, from the server side, please try again after some time", GlobalSettings.IsTabletDevice);
            _log.Equals(ex);
        }

        public async Task<bool> Print(int printerId, string uuid, string zplData, bool isRetry = false)
        {
            _log.Log("Sending Data to daymark sdk print method");
            var printResult = await _dayMarkPrinterService.Print(zplData);
            if (!printResult.IsSuccess)
            {
                _log.Log($"failed to print, Error: {printResult.Message}");
                if (!isRetry)
                {
                    var credits = await AddCreditsScan(printerId, uuid);
                    DaymarkPrinterEventManager.RaiseKeyLabelUpdatedEventType(credits);
                    return await Print(printerId, uuid, zplData, true);
                }
                var errorMessage = string.Empty;
                var message = printResult.Message.ToLowerInvariant();
                switch (message)
                {
                    case DaymarkPrinterConstants.InCorrectSDK:
                        errorMessage = LiteralTranslator.GetValue("DaymarkInCorrectSDK");
                        break;
                    case DaymarkPrinterConstants.IncorrectPackageName:
                        errorMessage = LiteralTranslator.GetValue("DaymarkIncorrectPackageName");
                        break;
                    case DaymarkPrinterConstants.UserNotFound:
                        errorMessage = LiteralTranslator.GetValue("DaymarkUserNotFound");
                        break;
                    case DaymarkPrinterConstants.LabelSecretKeyExpired:
                    case DaymarkPrinterConstants.IncorrectLabelSecretKey:
                        var credits = await AddCreditsScan(printerId, uuid);
                        DaymarkPrinterEventManager.RaiseKeyLabelUpdatedEventType(credits);
                        break;
                    case DaymarkPrinterConstants.LabelKeySizeMismatch:
                        errorMessage = LiteralTranslator.GetValue("DaymarkLabelKeySizeMismatch");
                        break;
                    case DaymarkPrinterConstants.PrinterAddressNotFound:
                        errorMessage = LiteralTranslator.GetValue("DaymarkPrinterAddressNotFound");
                        break;
                    case DaymarkPrinterConstants.TotalScanCountExceeded:
                        errorMessage = LiteralTranslator.GetValue("DaymarkTotalScanCountExceeded");
                        break;
                    default:
                        errorMessage = printResult.Message;
                        break;

                }
                await _dialogService.HideLoading();
                _printErrorPopupCompletionSource = new TaskCompletionSource<bool>();
                await Alert.OpenAlert(LiteralTranslator.GetValue("Alert"), errorMessage, GlobalSettings.IsTabletDevice);
                await _printErrorPopupCompletionSource.Task;
            }
            else
            {
                _log.Log("Printed");
            }
            return printResult.IsSuccess;
        }

        public bool IsConnected()
        {
            return !string.IsNullOrWhiteSpace(_dayMarkPrinterService.ConnectedDeviceName());
        }

        private async Task<string> GetUserEmail()
        {
            try
            {
                var daymarkId = await _cacheService.Get<string>(CacheQDTypes.DayMarkAccountId);
                if (string.IsNullOrEmpty(daymarkId))
                    daymarkId = await _labelPrintService.GetDayMarkUserId();
                return daymarkId;
            }
            catch (Exception ex)
            {
                _log.Error(ex);
            }
            return string.Empty;
        }

        public string GetDayMarkPrinterIdentifier(string dayMarkPrinterName)
        {
            var printerShortDescription = dayMarkPrinterName.Split('-');
            if (printerShortDescription.Length > 1)
            {
                return printerShortDescription[1];
            }
            return string.Empty;
        }
        private async Task<GenerateSecretKeyResponse> GenerateSecretKey(int selectedPrinterId, string uuid)
        {
            try
            {
                var email = await GetUserEmail();
                var deviceId = _dayMarkPrinterService.GetDeviceId();
                var firmeware = await _dayMarkPrinterService.GetPrinterFirmwareVersion();
                var secretKeyRequest = new GenerateSecretKeyRequest
                {
                    UserName = email,
                    PrinterId = selectedPrinterId,
                    DeviceId = string.IsNullOrWhiteSpace(uuid) ? deviceId : uuid,
                    FirmwareVersion = firmeware
                };
                var secretKeyResponse = await _labelPrintService.GetSecretKeyForDaymakrPrinter(secretKeyRequest);
                return secretKeyResponse;
            }
            catch (Exception e)
            {
                return new GenerateSecretKeyResponse()
                {
                    IsSuccess = false,
                    ErrorMessage = e.Message
                };
            }
        }
    }
}