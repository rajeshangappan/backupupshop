﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models.Recipes
{
    public class GetRecipeDetailsRequest
    {
        public int RecipeId { get; set; }
        public int ItemProductionBatchId { get; set; }
        public int? Qty { get; set; }
    }
}
