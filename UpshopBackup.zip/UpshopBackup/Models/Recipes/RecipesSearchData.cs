﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models.Recipes
{
    public class RecipesSearchData
    {
        public int RecipeId { get; set; }
        public int RecipeNumber { get; set; }
        public double? ItemNumber { get; set; }
        public string ItemDescription { get; set; }
        public int ItemProductionBatchId { get; set; }
        public string Text { get; set; }
    }
}
