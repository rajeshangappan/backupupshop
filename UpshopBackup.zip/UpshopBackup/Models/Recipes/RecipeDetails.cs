﻿using System;
using System.Collections.Generic;

namespace MobileUI2.Models.Recipes
{
    public class RecipeDetails : NotifyPropertyChanged
    {
        private List<BOM> _ingredients = new List<BOM>();
        public List<RecipeStepInstruction> _instructions = new List<RecipeStepInstruction>();
        public List<RecipeMedia> _media = new List<RecipeMedia>();
        public List<NutritionTypeDTO> _nutritionCollection = new List<NutritionTypeDTO>();
        public int RecipeId { get; set; }
        public int ItemProductionBatchId { get; set; }
        public string RecipeNumber { get; set; }
        public string RecipeDescription { get; set; }
        public ProductionItem ItemProductionBatch { get; set; }
        public int? DataTypeStateId { get; set; }
        public string ExtendedText { get; set; }
        public string DerivedText { get; set; }
        public string IngredientText { get; set; }
        public List<BOM> Ingredients
        {
            get=>_ingredients;
            set=>SetAndRaisePropertyChangedIfDifferentValues(ref _ingredients,value);
        }
        public List<RecipeStepInstruction> Instructions
        {
            get => _instructions;
            set => SetAndRaisePropertyChangedIfDifferentValues(ref _instructions, value);
        }
        public List<RecipeMedia> Media
        {
            get => _media;
            set => SetAndRaisePropertyChangedIfDifferentValues(ref _media, value);
        }
        public List<NutritionTypeDTO> NutritionCollection
        {
            get => _nutritionCollection;
            set => SetAndRaisePropertyChangedIfDifferentValues(ref _nutritionCollection, value);
        }
        public string CookingInstructions
        {
            get
            {
                return (ItemProductionBatch != null && !string.IsNullOrEmpty(ItemProductionBatch.CookingInstructions)) ? ItemProductionBatch.CookingInstructions : string.Empty;
            }
        }
        public string Allergens { get; set; }
    }
    public class BOM
    {
        public int BOMId { get; set; }
        public int VendorItemId { get; set; }
        public string VendorItemNumber { get; set; }
        public string VendorItemDescription { get; set; }
        public string VendorNumber { get; set; } // Vendor ID in UI
        public double CostQuantity { get; set; }
        public string CostQuantityUnits { get; set; }
        public double SizeInBaseUnit { get; set; }
        public string Type { get; set; }
        public string VendorItemImage { get=> (Type == "Ingredient" ? "\uf7fb" : (Type == "Recipe") ? "\uf1fd" : "\uf814"); }
        public string VendorItemDisplay { get => $"{VendorItemNumber}-{VendorItemDescription}"; }
        public string CostQtyDisplay { get => $"{Math.Round(CostQuantity, 3)} {CostQuantityUnits}"; }
        public CookedLineItem CookedItem { get; set; }
        public string ValidTypes { get; set; }
    }
    public class RecipeStepInstruction : NotifyPropertyChanged
    {
        private string _description;       
        public int StepId { get; set; }
        public int Step { get; set; }
        public string StepName { get; set; }
        public string Description
        {
            get => _description;
            set => SetAndRaisePropertyChanged(ref _description, value);
        }      
        public string ImageName { get; set; }
        public string ImageUrl { get; set; }
        public bool IsSelectedStep { get; set; }
        public string ItemDescription { get; set; }
        public string InstructionImage
        {
            get
            {
                return string.IsNullOrEmpty(ImageUrl) ? "notfound.jpg" : ImageUrl;
            }
        }
    }
    public class RecipeMedia
    {
        public int RecipeMediaId { get; set; }
        public string FileName { get; set; }
        public string FilePath { get; set; }
        public string MediaType { get; set; }
    }
    public class CookedLineItem
    {
        public int? CookedVendorItemId { get; set; }
        public string CookedLineItemVendorItemNumber { get; set; }
        public string CookedLineItemVendorItemDescription { get; set; }
        public double? CookedQuantity { get; set; }
        public string CookedQuantityUnits { get; set; }
        public double CookedSizeInBaseUnit { get; set; }
        public string Type { get; set; }
    }
    public class VendorItemNutrition
    {
        public short RegulationID { get; set; }
        public byte SourceTypeID { get; set; }
        public List<NutritionTypeDTO> Nutrients { get; set; }
    }
    public class ProductionItem
    {
        public int ItemProductionBatchId { get; set; }
        public int ItemId { get; set; }
        public double SizeInBaseUnit { get; set; }
        public string CookingInstructions { get; set; }
    }
    public class NutritionTypeDTO
    {
        public byte NutrientTypeGroupID { get; set; }
        public short NutrientTypeID { get; set; }
        public string NutrientTypeName { get; set; }
        public byte? DisplaySequence { get; set; }
        public bool NutrientTypeRequired { get; set; }
        public decimal? NutrientValue { get; set; }
        public decimal? PercentDailyValue { get; set; }
        public short RegulationID { get; set; }
        public byte SourceTypeID { get; set; }
        public string UnitTypeValue { get; set; }
        public bool Disabled { get; set; }
        public string LblNutrientValue
        {
            get
            {
                if (NutrientValue == null)
                    return string.Empty;
                else
                {
                    return NutrientValue?.ToString("0.#");
                }
            }
        }

        public string LblPercentDailyValue
        {
            get
            {
                if (PercentDailyValue == null || ((NutrientTypeID == 14 || NutrientTypeID == 6 || NutrientTypeID == 17 || NutrientTypeID == 1 )&& (RegulationID == 2 || RegulationID == 1)))
                    return string.Empty;
                else
                {
                    return $"{PercentDailyValue?.ToString("0.#")}%";
                }
            }
        }
    }
}
