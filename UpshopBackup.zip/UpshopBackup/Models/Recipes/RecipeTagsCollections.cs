﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models.Recipes
{
    public class RecipeTagsCollections
    {
        public List<int> TopLevelTags { get; set; }
        public List<ItemTagDTO> Tags { get; set; }
        public List<RecipeSearchDTO> Recipes { get; set; }
    }
}
