﻿using System.Collections.Generic;

namespace MobileUI2.Models.Recipes
{
    public class RecipesByFCC
    {
        public string FCC { get; set; }
#pragma warning disable CA2227 // Collection properties should be read only
        public List<RecipeSearch> Recipes { get; set; } = new List<RecipeSearch>();
#pragma warning restore CA2227 // Collection properties should be read only
    }

    public class RecipeSearch : NotifyPropertyChanged
    {
        private string _recipeDescription;
        private string _itemDescription;
        public int RecipeId { get; set; }
        public long RecipeNumber { get; set; }
        public string RecipeDescription { get => _recipeDescription;
            set => SetAndRaisePropertyChangedIfDifferentValues(ref _recipeDescription, value); }
        public string StateName { get; set; }
        public bool IsDeleted { get; set; }
        public int? ItemId { get; set; }
        public double? ItemNumber { get; set; }
        public string ItemDescription
        {
            get => _itemDescription;
            set => SetAndRaisePropertyChangedIfDifferentValues(ref _itemDescription, value);
        }
        public int ItemProductionBatchId { get; set; }

        public string VideoFileName { get; set; }

        public string Text { get; set; }
    }
}
