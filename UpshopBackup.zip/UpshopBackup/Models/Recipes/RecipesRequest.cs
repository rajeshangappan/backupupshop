﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models.Recipes
{
    public class RecipesRequest
    {
        public string SearchByValue { get; set; }
        public bool IncludeItems { get; set; } = false;
    }
}
