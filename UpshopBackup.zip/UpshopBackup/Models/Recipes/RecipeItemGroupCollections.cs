﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Maui.Controls.Compatibility;
using Microsoft.Maui.Controls;
using Microsoft.Maui;

namespace MobileUI2.Models.Recipes
{
    public class RecipeItemGroupCollections
    {
        public List<CategoryDTO> Categories { get; set; }
        public List<RecipeSearchDTO> Items { get; set; }
    }
    public class RecipeSearchDTO : NotifyPropertyChanged
    {
        public bool IsDeleted { get; set; }
        private string _recipeDescription;
        private string _itemDescription;
        public int RecipeId { get; set; }
        public long RecipeNumber { get; set; }
        public string RecipeDescription
        {
            get => _recipeDescription;
            set => SetAndRaisePropertyChangedIfDifferentValues(ref _recipeDescription, value);
        }
        public string DisplayDescription
        {
            get => _itemDescription;
            set => SetAndRaisePropertyChangedIfDifferentValues(ref _itemDescription, value);
        }
        public string SearchDisplayDescription
        {
            get => $"{DisplayNumber}-{DisplayDescription}";
        }
        public int? ItemId { get; set; }
        public int ItemProductionBatchId { get; set; }
        public string ItemImageURL { get; set; }
        public int ItemOrderGroupId { get; set; }
        public long? DisplayNumber { get; set; }
        public string VideoFileName { get; set; }
        public int? ItemTagId { get; set; }
        public bool ShowCore
        {
            get => ItemTagId == 1 ? true : false;
        }
    }

    public class RecipeSearchGroup: List<RecipeSearchDTO>
    {
        public string Name { get; private set; }
        public Style StyleAttribute { get; private set; }

        public RecipeSearchGroup(string name, List<RecipeSearchDTO> items) : base(items)
        {
            Name = name;
            if (Name == "\uf005")
                StyleAttribute = Application.Current != null ? (Style)Application.Current.Resources["FontAwesomeSolidStyle"] : null;
            else
                StyleAttribute = Application.Current != null ? (Style)Application.Current.Resources["LabelBoldStyle"] : null;
        }

    }
}
