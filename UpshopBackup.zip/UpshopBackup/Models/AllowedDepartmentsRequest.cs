﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models
{
    public class AllowedDepartmentsRequest
    {
        public string Action { get; set; }
        public string PermissionCode { get; set; }
    }
}
