﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Maui.Devices;
using Microsoft.Maui.ApplicationModel;

namespace MobileUI2.Models.PushNotification
{
    public class DeviceRegistrationRequest
    {
        public int UserId { get; set; }
        public string DeviceRegistrationToken { get; set; }
        public int DeviceType => DeviceInfo.Platform == DevicePlatform.Android ? (int)Device.Android : (int)Device.iOS;
    }
    public enum Device
    {
        Android,
        iOS,
    }
}
