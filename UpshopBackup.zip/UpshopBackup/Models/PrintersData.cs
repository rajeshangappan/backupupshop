﻿using MobileUI2.Constants;
using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models
{
    public class PrintersData
    {
        public int PrinterId { get; set; }
        public string PrinterDescription { get; set; }
        public string PrinterName { get; set; }
        public string IpAddress { get; set; }
        public string SecretKey { get; set; }
        public string ApprovedLabelSize { get; set; }
        public int IpPort { get; set; }
        public TopOfLabelDetectionMode TopOfLabelDetection { get; set; }
        public int PrinterType { get; set; }
        public string PrinterShortHandDescription
        {
            get
            {
                if (string.IsNullOrEmpty(PrinterDescription))
                    return "";
                if (PrinterDescription.Length <= 15)
                    return PrinterDescription;
                else
                    return $"{PrinterDescription.Substring(0, 15)}...";
            }
        }
    }
}
