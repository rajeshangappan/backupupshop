﻿using MobileUI2.Constants;
using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models.Ordering
{
    public class UpdateOrderOnHandRequest
    {
        public int OrderId { get; set; }
        public int DepartmentNumber { get; set; }
        public int VendorItemId { get; set; }
        public double UpdatedQty { get; set; }
        public string UpdateType { get; set; }
        public CountType CountType { get; set; }
    }

    public class UpdateQtysRequest
    {
        public int OrderId { get; set; }
        public int DepartmentNumber { get; set; }
        public List<UpdateOrderOnHandRequest> UpdatedQuantities { get; set; } = new List<UpdateOrderOnHandRequest>();
    }
}
