﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models
{
    public class UpdateOrderQtysRequest
    {
        public int OrderId { get; set; }
        public bool IsOnHandUpdate { get; set; }
        public List<UpdateOrderQtyInfo> UpdatedQuantities { get; set; }
    }

    public class UpdateOrderQtyInfo
    {
        public int OrderId { get; set; }
        public int DepartmentNumber { get; set; }
        public int VendorItemId { get; set; }
        public double UpdatedQty { get; set; }
        public string UpdateType { get; set; }
    }
}
