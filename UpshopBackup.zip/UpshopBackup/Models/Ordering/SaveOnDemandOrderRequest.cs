﻿namespace MobileUI2.Models.Ordering
{
    public class SaveOnDemandOrderRequest
    {
        public string SupplierId { get; set; }
        public int DepartmentId { get; set; }
        public string DeliveryDate { get; set; }
        public string NextDeliveryDate { get; set; }
    }
}
