﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models.Ordering
{
    public class UpdateOrderStatusRequest
    {
        public int OrderId { get; set; }
        public int DepartmentNumber { get; set; }
        public string OldStatus { get; set; }
        public int NewStatus { get; set; }
    }
}
