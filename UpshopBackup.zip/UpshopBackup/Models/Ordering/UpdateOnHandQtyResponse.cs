﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models.Ordering
{
    public class UpdateOnHandQtyResponse
    {
        public List<UpdatedOrderQty> Quantities { get; set; }
    }
    public class UpdatedOrderQty
    {
        public int OrderId { get; set; }
        public int VendorItemId { get; set; }
        public double? Ordered { get; set; }
        public double? Suggested { get; set; }
    }
}
