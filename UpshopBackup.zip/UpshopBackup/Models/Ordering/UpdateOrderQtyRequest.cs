﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models.Ordering
{
    public class UpdateOrderQtyRequest
    {
        public int OrderId { get; set; }
        public int DepartmentNumber { get; set; }
        public List<UpdateQty> UpdateOrdersQty = new List<UpdateQty>();
    }
    public class UpdateQty
    {
        public int OrderId { get; set; }
        public int DepartmentNumber { get; set; }
        public int VendorItemId { get; set; }
        public double UpdatedQty { get; set; }
    }

}
