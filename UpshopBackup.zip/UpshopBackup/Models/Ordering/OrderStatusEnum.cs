﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models.Ordering
{
    public enum OrderStatusEnum
    {
        None = 0,
        Created = 1,
        InProgress = 2,
        Submitted = 4,
        Approved = 8,
        Received = 16,
        Complete = 32,
        Cancelled = 64,
        Closed = Complete | Cancelled,
        StoreEditable = Created | InProgress,
        CorpEditable = Created | InProgress | Submitted
    }
}
