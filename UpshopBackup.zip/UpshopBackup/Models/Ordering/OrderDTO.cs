﻿using MobileUI2.Constants;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Runtime.Serialization;
using Microsoft.Maui.Controls.Compatibility;
using Microsoft.Maui.Controls;
using Microsoft.Maui;

namespace MobileUI2.Models
{
    public class OrderDTO
    {
        public List<DepartmentOrders> OpenOrders { get; set; } = new List<DepartmentOrders>();
        public List<DepartmentOrders> CompletedOrders { get; set; } = new List<DepartmentOrders>();
    }
    public class DepartmentOrders
    {
        public string DepartmentDisplay { get; set; }
        public IList<OrderRow> Orders = new List<OrderRow>();
    }
    public class OrderRow : NotifyPropertyChanged
    {
        public int OrderId { get; set; }
        public string StoreDisplay { get; set; }
        public int DepartmentId { get; set; }
        public int DepartmentNumber { get; set; }
        public string SupplierDisplay { get; set; }
        public DateTime DeliveryDate { get; set; }
        public DateTime DeliveryDateStore { get; set; }
        public string DeliveryDateDisplay { get; set; }
        public string DeliveryDateText { get; set; }
        public bool? PastDue { get; set; }
        public string PastDueImage { get; set; }
        public int Status { get; set; }
        public string StatusDisplay { get; set; }
        public string DepartmentDisplay { get; set; }
        public string DepartmentName { get; set; }
        public string OrderStatus { get; set; }
        public string Name { get; set; }
        int statusId;
        public int StatusId
        {
            get
            {
                if (StatusDisplay == "In Progress")
                    StatusDisplay = "InProgress";
                if (!string.IsNullOrEmpty(StatusDisplay))
                {
                    statusId = (int)Enum.Parse(typeof(StatusEnum), StatusDisplay);
                }
                return statusId;
            }
            set => SetAndRaisePropertyChanged(ref statusId, value);
        }
        public TimeSpan SubmissionTime { get; set; }
        public DayOfWeek SubmissionDayOfWeek { get; set; }
        public DateTime? SubmissionDateTimeUTC { get; set; }
        public DateTime? SubmissionDateStore { get; set; }
        public string SubmitbyDateLabel { get; set; }
        public string SubmitByDate { get; set; }
        public List<OrderDataItem> Items { get; set; } = new List<OrderDataItem>();
        public IEnumerable<int> TopLevelTags { get; set; }
        public IList<ItemTagData> Tags { get; set; } = new List<ItemTagData>();
        public List<FilterDTO> Filters { get; set; } = new List<FilterDTO>();
    }

    public class OrderDataItem : NotifyPropertyChanged
    {
        private bool _isSelected;
        public bool IsSelected { get => _isSelected; set => SetAndRaisePropertyChanged(ref _isSelected, value); }
        public int VendorItemId { get; set; }
        public int? ItemTagId { get; set; }
        public int CoreTag
        {
            get
            {
                return ItemTagId.GetValueOrDefault();
            }
        }
        public InventoryType InventoryType {get;set;}
        public ObservableCollection<CountTypeModel> CountTypes
        {
            get
            {
                if (InventoryType == InventoryType.ByWeight)
                {
                    return new ObservableCollection<CountTypeModel> { new CountTypeModel { DisplayName = LiteralTranslator.GetValue("Case"), CountType = CountType.Case } };
                }

                else
                    {
                    if(CaseSize.GetValueOrDefault() > 0)
                    {
                        return new ObservableCollection<CountTypeModel> { new CountTypeModel { DisplayName = LiteralTranslator.GetValue("Case"), CountType = CountType.Case }, new CountTypeModel { DisplayName = LiteralTranslator.GetValue("Each"), CountType = CountType.Each } };

                    }
                    else
                        return new ObservableCollection<CountTypeModel> { new CountTypeModel { DisplayName = LiteralTranslator.GetValue("Each"), CountType = CountType.Each } };
                    }
            }
        }
            
        public CountTypeModel DefaultCountType => InventoryType == InventoryType.ByWeight ? new CountTypeModel { DisplayName = LiteralTranslator.GetValue("Case"), CountType = CountType.Case } : new CountTypeModel { DisplayName = LiteralTranslator.GetValue("Each"), CountType = CountType.Each };
        public CountTypeModel SelectedCountType { get; set; }
        public bool OnPromotion { get; set; }
        public int? DepartmentId { get; set; }
        public int DepartmentNumber { get; set; }
        public string VendorItemNumber { get; set; }
        public string VendorItemDescription { get; set; }
        public string VendorItemDisplay { get; set; }
        public string LblVendorItemNumber { get => $"VendorItem #{VendorItemNumber}"; }
        public double? ApprovedOrderQuantity { get; set; }
        double? _onhand;
        double _ordered;
        double _received;
        public bool OnHandEdited { get; set; }
        public bool OrderedEdited { get; set; }
        public bool ReceivedEdited { get; set; }
        public double? OnHand
        {
            get => _onhand;
            set
            {
                if (oldOnHand !=null && oldOnHand != value)
                    OnHandEdited = true;
                else OnHandEdited = false;
                SetAndRaisePropertyChanged(ref _onhand, value);
            }
        }
        public double Suggested { get; set; }
        public double Ordered
        {
            get => _ordered;
            set
            {
                if (oldOrdered != value)
                    OrderedEdited = true;
                else OrderedEdited = false;
                _ordered = value; 
                OnPropertyChanged();
                if (Suggested == Ordered)
                { 
                    SuggestedMinusOrderedValue = null;
                    ShowSuggestedMinusOrderedValue = false;
                }
                else if (Suggested > Ordered)
                {
                    SuggestedMinusOrderedValue = $"{Suggested - Ordered}";
                    ArrowIcon = "\uf354";
                    ShowSuggestedMinusOrderedValue = true;
                }
                else
                {
                    SuggestedMinusOrderedValue = $"{ Ordered - Suggested}";
                    ArrowIcon = "\uf357";
                    ShowSuggestedMinusOrderedValue = true;
                }
            }
        }

        private string _arrowIcon;
        public string ArrowIcon
        {
            get => _arrowIcon;
            set => SetAndRaisePropertyChanged(ref _arrowIcon, value);
        }

        private string _suggestedMinusOrderedValue;
        public string SuggestedMinusOrderedValue
        {
            get => _suggestedMinusOrderedValue;
            set => SetAndRaisePropertyChanged(ref _suggestedMinusOrderedValue, value);
        }

        private bool _showSuggestedMinusOrderedValue;
        public bool ShowSuggestedMinusOrderedValue
        {
            get => _showSuggestedMinusOrderedValue;
            set => SetAndRaisePropertyChanged(ref _showSuggestedMinusOrderedValue, value);
        }
        public double Received
        {
            get => _received;
            set
            {
                if (oldReceived != value)
                    ReceivedEdited = true;
                else ReceivedEdited = false;
                SetAndRaisePropertyChanged(ref _received, value);
            }
        }
        public int? ItemId { get; set; }
        public long? ItemNumber { get; set; }
        public string ItemDescription { get; set; }
        public string ItemUom { get; set; }
        [IgnoreDataMember]
        public double? oldOnHand { get; set; }
        [IgnoreDataMember]
        public double oldSuggested { get; set; }

        private double _oldOdered;
        public double oldOrdered
        {
            get => _oldOdered;
            set => SetAndRaisePropertyChanged(ref _oldOdered, value);
        }
        [IgnoreDataMember]
        public double oldReceived { get; set; }
        private string _lblsuggesedValue;
        public string LblSuggesedValue
        {
            get
            {
                if (Status == 1 || Status == 2)
                {
                    if (!string.IsNullOrEmpty(Uom))
                    {
                        return $"{Suggested} {Uom.ToLowerInvariant()} suggested";
                    }
                    else
                    {
                        return $"{Suggested} suggested";
                    }
                }
                else if (Status == 16)
                {
                    if (!string.IsNullOrEmpty(Uom))
                    {
                        return $"{Ordered} {Uom.ToLowerInvariant()} ordered";
                    }
                    else
                    {
                        return $"{Ordered} ordered";
                    }
                }
                else
                {
                    if (!string.IsNullOrEmpty(Uom))
                    {
                        return Uom.ToLowerInvariant();
                    }
                    else
                    {
                        return string.Empty;
                    }
                }
            }
            set => SetAndRaisePropertyChanged(ref _lblsuggesedValue, value);
        }
        public double? CaseSize { get; set; }
        public double Cost { get; set; }
        public string Uom { get; set; }
        public int Status { get; set; }
        public bool? CanAdd { get; set; }
        public bool? CanSave { get; set; }
        public bool? CanDelete { get; set; }
        public bool IsOnHandReadOnly { get; set; }
        public bool IsOrderedReadOnly { get; set; }
        public bool IsReceivedReadOnly { get; set; }
        bool _showOnhand;
        public bool ShowOnhand
        {
            get => _showOnhand;
            set => SetAndRaisePropertyChanged(ref _showOnhand, value);
        }
        bool _showOrdered;
        public bool ShowOrdered
        {
            get => _showOrdered;
            set => SetAndRaisePropertyChanged(ref _showOrdered, value);
        }
        bool _showReceived;
        public bool ShowReceived
        {
            get => _showReceived;
            set => SetAndRaisePropertyChanged(ref _showReceived, value);
        }
        bool _disableEditOption;
        public bool DisableEditOption
        {
            get => _disableEditOption;
            set => SetAndRaisePropertyChanged(ref _disableEditOption, value);
        }
        public double? NumaricEntryMinValue
        {
            get
            {
                return 0;
            }
        }
        public bool AllowDecimalValue => InventoryType == InventoryType.ByCount ? false : true;
    }

    public enum StatusEnum
    {
        None = 0,
        Created = 1,
        InProgress = 1,
        Submitted = 3,//4
        Approved = 4,//8
        Received = 5,//16
        Complete = 6, //32
        Cancelled = 7, //64
        Clean = 8,
        NoClean = 9,
        NoCleanInProgress = 10
    }
}
