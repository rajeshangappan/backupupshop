﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models
{
    public class SaveUserWorkStationRequest
    {
        public int UserInfoId { get; set; }
        public int WorkstationId { get; set; }
    }
}
