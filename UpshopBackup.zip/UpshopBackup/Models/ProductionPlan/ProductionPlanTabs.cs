﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models.ProductionPlan
{
    public enum ProductionPlanTabs
    {
        Prep,
        Today,
        ProductionOrder,
        None
    }
}
