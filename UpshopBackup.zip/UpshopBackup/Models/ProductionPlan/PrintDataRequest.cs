﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models.ProductionPlan
{
    public class PrintDataRequest
    {
        public int LabelPrinterId { get; set; }
        public long? ItemNumber { get; set; }
        public int OrgUnitId { get; set; }      
        public int LabelQuantity { get; set; }
        public int ItemId { get; set; }
        public int PluNumber { get; set; }
        public decimal? Price { get; set; }
        public int DepartmentId { get; set; }
        public DateTime? PackedOn { get; set; }
        public int PrinterType { get; set; }
    }
}
