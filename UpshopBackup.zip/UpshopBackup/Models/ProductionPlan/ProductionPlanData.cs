﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;

namespace MobileUI2.Models
{
    public class ProductionPlanData  //used for SignalR message processing
    {
        public int ItemId { get; set; }
        public PlanData Data { get; set; }
    }
    public class PlanData
    { 
        public int PlanId { get; set; }
        public string ProductionAreaLabel { get; set; }
        public string ProductionAreaName { get; set; }
        public int ProductionAreaId { get; set; }
        public int StoreId { get; set; }
        public int StoreNumber { get; set; }
        public string StoreLabel { get; set; }
        public DateTime ReadyBy { get; set; }
        public int Status { get; set; }
        public string Description { get; set; }
        public IList<PlanItem> Items = new List<PlanItem>();
    }

    public class PlanItem
    {
        public int ItemId { get; set; }
        public int DepartmentId { get; set; }
        public double RemainingQuantity { get; set; }
        public double ForecastQuantity { get; set; }
        public int LabelQuantity { get; set; }
    }
}
