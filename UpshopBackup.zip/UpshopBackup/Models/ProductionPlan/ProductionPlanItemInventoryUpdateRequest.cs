﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models
{
    public class ProductionPlanItemInventoryUpdateRequest
    {
        public int PlanId { get; set; }
        public List<UpdateInventory> Inventories { get; set; } = new List<UpdateInventory>();
    }
    public class UpdateInventory
    {
        public int ItemId { get; set; }
        public int DepartmentId { get; set; }
        public int OrgUnitId { get; set; }
        public double OnHandQuantity { get; set; }
        public int? InventoryState { get; set; }
    }
}
