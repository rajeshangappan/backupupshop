﻿using MobileUI2.Constants;
using MobileUI2.Models.TaskActivities;
using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Maui.Controls.Compatibility;
using Microsoft.Maui.Controls;
using Microsoft.Maui;
using TaskStatus = MobileUI2.Constants.TaskStatus;

namespace MobileUI2.Models
{
    public class TodaysTask : BindableObject
    {
        private decimal _progressData;
        private string _menuIcon;
        private string _statusColor;
        private bool _isVisibleSignatureIcon;
        private string _completeIcon;
        private string _completeIconColor;
        public string Name { get; set; }

        public TaskStatus Status { get; set; }
        public string Code { get; set; }
        public TaskActivityStatusType? TaskActivityStatus { get; set; }
        public string Signature { get; set; }
        public int Completed
        {
            get; set;
        }
        public int InProgress
        {
            get; set;
        }
        public int Total
        {
            get; set;
        }
        public bool IsVisibleProgressBar { get; set; }
        private string _signatureIcon;
        public decimal ProgressData
        {
            get { return _progressData; }
            set { _progressData = value; OnPropertyChanged(); }
        }

        public string StatusColor
        {
            get { return _statusColor; }
            set { _statusColor = value; OnPropertyChanged(); }
        }
        public bool IsVisibleSignatureIcon
        {
            get { return _isVisibleSignatureIcon; }
            set { _isVisibleSignatureIcon = value; OnPropertyChanged(); }
        }
        public string SignatureIcon
        {
            get { return _signatureIcon; }
            set { _signatureIcon = value; OnPropertyChanged(); }
        }
        public string CompleteIcon
        {
            get { return _completeIcon; }
            set { _completeIcon = value; OnPropertyChanged(); }
        }
        public string CompleteIconColor
        {
            get { return _completeIconColor; }
            set { _completeIconColor = value; OnPropertyChanged(); }
        }
        public bool IsVisibleProductionTaskIcon { get; set; }

        public bool IsVisibleTaskIcon
        {
            get; set;
        }
        public string CountText
        {
            get
            {
                return $"{Completed}/{Total}";
            }
        }
        public string _progressBarText;
        public string ProgressBarText
        {
            get { return _progressBarText; }
            set { _progressBarText = value; OnPropertyChanged(); }
        }
        public string MenuIcon
        {
            get { return _menuIcon; }
            set { _menuIcon = value; OnPropertyChanged(); }
        }
        public bool IsPastDueVisible { get; set; }
        public string Type { get; set; }
        public DateTime StartDateTime { get; set; }
        public DateTime? ExpectedCompleteDateTime { get; set; }
        public bool IsManager { get; set; }
        public bool SignOffPending { get; set; }
        public string SignedOffComment { get; set; }
        public int? Duration { get; set; }
        public string TaskDurationTime { get; set; }
        public bool IsVisibleDurationTime { get; set; }
        public string SubTitle { get; set; }
        public bool IsVisibleSubTitle { get; set; }
        public TaskProgressDetails TaskDetails { get; set; } = new TaskProgressDetails();
        public int Id { get; set; }
        public int SortedId { get; set; } //this ID used for sorting when DisplayDate is null
        public string DisplayTime { get; set; }
        public string TabletDisplayTime { get; set; }
        public string PlanStatus { get; set; }
        public string DurationAndTime { get; set; }
        public bool IsVisibleDurationAndTime
        {
            get
            {
                return string.IsNullOrEmpty(DurationAndTime) ? false : true;
            }
        }
        public ProductionOrdersDTO productionOrder = new ProductionOrdersDTO();
        public Productionplan productionplan { get; set; } = new Productionplan();
        public ProductionPlanPrepStep presteps { get; set; } = new ProductionPlanPrepStep();
        public DateTime? DisplayDate { get; set; }
        public DateTime? TaskCompleteDateTime { get; set; }
        public bool IsPrepCompleted { get; set; }
        public bool RequireSignOff { get; set; }
        public int DepartmentNumber { get; set; }
        public List<TaskActivityStep> TaskActivitySteps = new List<TaskActivityStep>();

        public List<TaskStepsByCategory> TaskStepsByCategorys = new List<TaskStepsByCategory>();
        public InvoiceDTO invoice { get; set; } = new InvoiceDTO();
        public bool IsPastDueInvoice { get; set; }
        public int SupplierInvoiceStatus { get; set; }
        public DateTime? InvoiceDate { get; set; }
        public bool IsUpComing { get; set; }
    }
    public class TaskProgressDetails : BindableObject
    {
        public int Completed { get; set; }
        public int InProgress { get; set; }
        public int Total { get; set; }
    }
    public class TaskStepsByCategory
    {
        public string CategoryName { get; set; }
        public List<TaskActivityStep> TaskActivitySteps = new List<TaskActivityStep>();
    }
    public enum TaskActivityStatusType
    {
        NotStarted,
        InProgress,
        Completed,
        SignOffPending,
        SignOffAccepted,
        SignOffUnaccepted,
        Late,
        Incomplete
    }
}
