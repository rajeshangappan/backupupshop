﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models.ProductionPlan
{
    public class ProductionPlanPickListWithItemTags
    {
        public IEnumerable<ProductionPlanPickList> ProductionPlanItemsPickList { get; set; } = new List<ProductionPlanPickList>();
        public IEnumerable<int> TopLevelTags { get; set; } = new List<int>();
        public IEnumerable<ItemTagData> Tags { get; set; } = new List<ItemTagData>();
        public List<FilterDTO> Filters { get; set; } = new List<FilterDTO>();
    }
    public class ProductionPlanPickList
    {
        public int? ItemId { get; set; }
        public string ItemDescription { get; set; }
        public string UnitOfMeasure { get; set; }
        public int DepartmentNumber { get; set; }
        public int DepartmentId { get; set; }
        public int? PLUNumber { get; set; }
        public string PLULabel { get; set; }
        public string DepartmentLabel { get; set; }
        public string FCCLabel { get; set; }
        public double? PickUnitsQuantity { get; set; }
        public string VendorItemNumber { get; set; }
        public int? ItemTagId { get; set; }
        public string ItemTagName { get; set; }
        public bool Primal { get; set; }
        public string PickUnit { get; set;}
    }
}
