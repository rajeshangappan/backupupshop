﻿namespace MobileUI2.Models.ProductionPlan
{
    public class PrintPlanReportRequest
    {
        public int PlanId { get; set; }
        public int LabelPrinterId { get; set; }
    }
}
