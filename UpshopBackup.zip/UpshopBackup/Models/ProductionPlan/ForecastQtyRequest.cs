﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models
{
    public class ForecastQtyRequest
    {
        public int PlanId { get; set; }
        public List<UpdateForecastQty> ForecastQty { get; set; } = new List<UpdateForecastQty>();
    }
    public class UpdateForecastQty
    {
        public int? PlanId { get; set; }
        public int? OrgUnitId { get; set; }
        public long ItemNumber { get; set; }
        public double? NewForecastQty { get; set; }
    }
}
