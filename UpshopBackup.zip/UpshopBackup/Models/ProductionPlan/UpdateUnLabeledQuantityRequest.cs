﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models
{
    public class UpdateUnLabeledQuantityRequest
    {
        public int PlanId { get; set; }
        public long ItemId { get; set; }
        public double? UnlabeledQuantity { get; set; }
    }
}
