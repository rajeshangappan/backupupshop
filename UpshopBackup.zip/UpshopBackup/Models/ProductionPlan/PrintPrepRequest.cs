﻿namespace MobileUI2.Models.ProductionPlan
{
    public class PrintPrepRequest
    {
        public int LabelPrinterId { get; set; }
    }
}
