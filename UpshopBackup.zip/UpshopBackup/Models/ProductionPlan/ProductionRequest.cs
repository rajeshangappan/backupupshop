﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models
{
    public class ProductionRequest
    {
        public int StoreId { get; set; }
        public DateTime PlanDate { get; set; }
        public bool? ApplyPlanGrouping { get; set; }
    }
}
