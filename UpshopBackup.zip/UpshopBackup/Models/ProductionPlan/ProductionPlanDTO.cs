﻿using MobileUI2.Constants;
using MobileUI2.ViewModels;
using Shiny;
using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using Microsoft.Maui.Controls.Compatibility;
using Microsoft.Maui.Controls;
using Microsoft.Maui;

namespace MobileUI2.Models
{
    public class ProductionPlanDTO
    {
        public string ProductionAreaName { get; set; }
        public List<Productionplan> ProductionPlans { get; set; } = new List<Productionplan>();
    }

    public class Productionplan : NotifyPropertyChanged
    {
        private int _completedItems;
        private int _totalItems;
        bool _isToDayPlans;
        string _planDurationTime;
        bool _isPrintPage;
        PrintOption _printOption;
        int? _planStatusId;
        public bool IsPrintPage
        {
            get => _isPrintPage;
            set => SetAndRaisePropertyChanged(ref _isPrintPage, value);
        }
        public string PlanStatus { get; set; }
        public int PlanId { get; set; }
        public int ProductionAreaId { get; set; }
        public string ProductionAreaName { get; set; }
        public DateTime ScheduledDateTime { get; set; }
        public string PlanDescription { get; set; }
        public bool IsDaymarkPrinting { get; set; }
        public int? PlanStatusId
        {
            get => _planStatusId;
            set => SetAndRaisePropertyChanged(ref _planStatusId, value);
        }
        public string Status { get; set; }
        public int? OrgId { get; set; }
        public int? OrgUnitNumber { get; set; }
        public string OrgUnitName { get; set; }
        public bool ShowInventoryOnHand { get; set; }
        public bool ShowAverageItemWeight { get; set; }
        public bool ShowReasonPrompt { get; set; }
        public bool CanStart { get; set; }
        public bool GroupByDate { get; set; }
        public bool CanFinalize { get; set; }
        public bool CanViewReports { get; set; }
        public bool CanUpdateOnHand { get; set; }
        public bool CanUpdateForecast { get; set; }
        public bool CanPrintLabels { get; set; }
        public decimal? CompletionProgress { get; set; }
        public List<FilterDTO> Filters { get; set; }
        public List<ProductionPlanItem> ProductionPlanItems { get; set; } = new List<ProductionPlanItem>();
        public List<ItemOrderGroupResponse> Groups { get; set; } = new List<ItemOrderGroupResponse>();
        public List<int> TopLevelTags { get; set; }
        public List<ItemTagDTO> Tags { get; set; }
        public decimal PlanCompletionProgress
        {
            get
            {
                return CompletionProgress == null ? 0 : (decimal)CompletionProgress;
            }
        }
        public bool? PastDue { get; set; }
        private bool _pastDueVisible;
        public bool PastDueVisible
        {
            get => _pastDueVisible;
            set => SetAndRaisePropertyChanged(ref _pastDueVisible, value);
            //get
            //{
            //    if (PlanStatusId == 3)
            //        return false;
            //    return PastDue == null ? false : (bool)PastDue;
            //}
        }
        public bool IncludesMultipleStoreProduction { get; set; }
        public bool CanRemainingProductionQuantity { get; set; }
        public bool CanReopen { get; set; }
        public string PlanTime { get; set; }
        public int TotalPlanDurationMinutes { get; set; }
        public int CompletedItems
        {
            get => _completedItems;
            set => SetAndRaisePropertyChanged(ref _completedItems, value);
        }
        public int TotalItems
        {
            get => _totalItems;
            set => SetAndRaisePropertyChanged(ref _totalItems, value);
        }
        private string _countText;
        public string CountText
        {
            get => _countText;
            set => SetAndRaisePropertyChanged(ref _countText, value);
            //get
            //{
            //    return $"{CompletedItems}/{TotalItems} Completed";
            //}
        }
        public bool IsVisblePlanStatus
        {
            get
            {
                return PlanCompletionProgress.Equals(0) ? true : false;
            }
        }
        public string UpComingDayOfWeek { get; set; }

        public string PlanProgressColor
        {
            get
            {
                return PlanCompletionProgress.Equals(0) ? "#cb3e2c" : PlanCompletionProgress <= 0.40M ? "#cb3e2c" : (PlanCompletionProgress > 0.40M && PlanCompletionProgress <= 0.79M ? "#edbc37" : "#2CCB79");
            }
        }
        public bool IsPreviousDate { get; set; }
        public bool IsToDayPlans
        {
            get => _isToDayPlans;
            set => SetAndRaisePropertyChanged(ref _isToDayPlans, value);
        }
        public string PlanDurationTime
        {
            get => _planDurationTime;
            set => SetAndRaisePropertyChanged(ref _planDurationTime, value);
        }
        private string _progressBarText;
        public string ProgressBarText
        {
            get => _progressBarText;
            set => SetAndRaisePropertyChanged(ref _progressBarText, value);
            //get
            //{
            //    return $"{CompletedItems} of {TotalItems}";
            //}
        }
        public string TabletDisplayTime { get; set; }
        public string DurationAndTime
        {
            get
            {
                if (string.IsNullOrEmpty(PlanDurationTime))
                    return TabletDisplayTime;
                else if (!string.IsNullOrEmpty(PlanDurationTime) && string.IsNullOrEmpty(TabletDisplayTime))
                    return PlanDurationTime;
                else if (!string.IsNullOrEmpty(PlanDurationTime) && !string.IsNullOrEmpty(TabletDisplayTime))
                    return $"{PlanDurationTime}  /  {TabletDisplayTime}";
                else
                    return string.Empty;
            }
        }
        public double PlanProgress
        {
            get
            {
                return (double)PlanCompletionProgress;
            }
        }
        public bool IsDurationVisible { get; set; }
        public int ItemsCount { get; set; }

        public PrintOption PrintOption
        {
            get => _printOption;
            set => SetAndRaisePropertyChanged(ref _printOption, value);
        }
        public PrintersData SelectedPrinter { get; set; }
    }
    public class ProductionPlanList
    {
        public List<ProductionPlanDTO> ProductionsList = new List<ProductionPlanDTO>();
        public bool ShowFinalizedPlans { get; set; }
        public bool IsTodaysPlans { get; set; } = false;
    }
    public class ProductionPlanItem : NotifyPropertyChanged
    {
        private string _inventoryQuantityDisplay;
        private string _modifiedQuantityDisplay;
        private string _labelQuantityDisplay;
        private string _unLabeledQuantityDisplay;
        private bool _isCreatedPlan;
        private bool _isPlanStatusChange;
        private bool _isOnHandEdited;
        private bool _isForecastEdited;
        private bool _isChecked = false;
        private bool _isOnHandVisible;
        private bool _isPrinterIconVisible;
        private bool _isSaleableUnlabeledIconVisible;
        private bool _isSaleableUnlabeledItem;
        private double _totalProduceQuantity;
        private Color _lblQtyTextColor;
        public int? PlanStatusId { get; set; }
        public static string PlanDescription { get; set; }
        public bool IsChecked
        {
            get => _isChecked;
            set
            {
                SetAndRaisePropertyChanged(ref _isChecked, value);

            }
        }
        public bool OnPromotion { get; set; } = false;
        public int? PlanId { get; set; }
        public bool? RecipeProductionItem { get; set; }
        public int? ItemId { get; set; }
        public long ItemNumber { get; set; }
        public string ItemDescription { get; set; }
        public double? ModifiedQuantity { get; set; }
        public double? CurrentQuantity { get; set; }
        public double? InventoryQuantity { get; set; }
        public double? LabelQuantity { get; set; }
        public double? UnlabeledQuantity { get; set; }
        public int FilterId { get => GlobalSettings.ShowItemTags ? ItemTagId.GetValueOrDefault() : GroupId.GetValueOrDefault(); }
        public int? GroupId { get; set; }
        public int? ItemTagId { get; set; }
        private double? _remainingQuantity;
        public double? RemainingQuantity
        {
            get => _remainingQuantity;
            set
            {
                SetAndRaisePropertyChanged(ref _remainingQuantity, value);
            }
        }
        public string UnitOfMeasure { get; set; }
        public double? AverageItemWeight { get; set; }
        public string AverageItemWeightUnitOfMeasure { get; set; }
        public int? OrgUnitNumber { get; set; }
        public int DepartmentNumber { get; set; }
        public int DepartmentId { get; set; }
        public bool? ShowItemWeight { get; set; }
        public bool ShowOnHand { get; set; }
        public bool ItemInventoryUpdateable { get; set; }
        public bool TrackLabeledInventory { get; set; }
        public bool IgnorePerpetualInventory { get; set; }
        public IList<ProductionPlanItem> Children { get; set; }
        public bool isCommissaryItem { get => !Children.IsNullOrDefault() && Children.Count > 0 ? true : false; }
        public int? OrgunitNumReceiving { get; set; }
        public string OrgunitNameReceiving { get; set; }
        public int? InventoryState { get; set; }
        public bool IsRecipeExists { get; set; }
        public DateTime? EndDateTime { get; set; }
        public int RecipeId { get; set; }
        public int ItemProductionBatchId { get; set; }
        public int? Priority { get; set; }
        public string ItemNumberDescription
        {
            get
            {
                return $"SKU #{ItemNumber}";
            }
        }
        public double? _forecastQuantity;
        public double? ForecastQuantity
        {
            get => _forecastQuantity;
            set
            {
                SetAndRaisePropertyChanged(ref _forecastQuantity, value);
            }
        }
        public string InventoryQuantityDisplay
        {
            get => _inventoryQuantityDisplay;
            set
            {
                if (double.TryParse(value, out double inventoryQty))
                {
                    if (InventoryQuantity.GetValueOrDefault() != inventoryQty)
                    {
                        IsOnHandEdited = true;
                    }
                    else
                    {
                        if (!IsOnHandEdited)
                            IsOnHandEdited = false;
                    }
                }
                SetAndRaisePropertyChanged(ref _inventoryQuantityDisplay, value);
            }
        }
        public string ModifiedQuantityDisplay
        {
            get => _modifiedQuantityDisplay;
            set
            {
                if (double.TryParse(value, out double modifiedQty))
                {
                    if (ForecastQuantity.GetValueOrDefault() != modifiedQty)
                    {
                        IsForecastEdited = true;
                    }
                    else
                    {
                        if (!IsForecastEdited)
                            IsForecastEdited = false;
                    }
                }
                SetAndRaisePropertyChanged(ref _modifiedQuantityDisplay, value);
            }
        }
        private int _printLabelQty = 0;
        public int PrintLabelQty
        {
            get
            {
                return _printLabelQty;
            }
            set
            {
                SetAndRaisePropertyChanged(ref _printLabelQty, value);
            }
        }
        public bool IsCreatedPlan
        {
            get => _isCreatedPlan;
            set => SetAndRaisePropertyChanged(ref _isCreatedPlan, value);
        }
        public bool IsOnHandEdited
        {
            get => _isOnHandEdited;
            set => SetAndRaisePropertyChanged(ref _isOnHandEdited, value);
        }
        public bool IsForecastEdited
        {
            get => _isForecastEdited;
            set => SetAndRaisePropertyChanged(ref _isForecastEdited, value);
        }
        public bool ItemTrackInventory { get; set; }
        public int? ItemDuration { get; set; }
        public string PlanItemDurationDisplay { get; set; }
        string _itemProgressBarText;
        public string ItemProgressBarText 
        {
            get => _itemProgressBarText; 
            set => SetAndRaisePropertyChanged(ref _itemProgressBarText, value);
        }
        public float PlanItemCompletionProgress { get; set; }
        public string PlanCompletionProgressColor
        {
            get
            {
                return PlanItemCompletionProgress.Equals(0) ? "#cb3e2c" : PlanItemCompletionProgress <= 0.40 ? "#cb3e2c" : (PlanItemCompletionProgress > 0.40 && PlanItemCompletionProgress <= 0.79 ? "#edbc37" : "#2CCB79");
            }
        }
        public double ItemCompletionProgress
        {
            get
            {
                return (double)PlanItemCompletionProgress;
            }
        }
        public int ItemMaxQuantity { get; set; }
        public bool AllowDecimal => (bool)(ShowItemWeight == null ? false : ShowItemWeight) && !AverageItemWeight.HasValue;
        public bool IsPlanStatusChange
        {
            get => _isPlanStatusChange;
            set => SetAndRaisePropertyChanged(ref _isPlanStatusChange, value);
        }
        public string AverageItemWeightString
        {
            get
            {
                var showAvgItemWeight = (bool)(ShowItemWeight == null ? false : ShowItemWeight) && AverageItemWeight != null && GlobalSettings.ShowWeightedItemsWithAverageItemWeightAsPacks;
                return showAvgItemWeight ? AverageItemWeight + " " + LiteralTranslator.GetValue(AverageItemWeightUnitOfMeasure) : string.Empty;
            }
        }
        public string UoMString
        {
            get
            {
                string unitOfMeasure = string.Empty;
                var weightedItem = (bool)(ShowItemWeight == null ? false : ShowItemWeight);
                if (weightedItem)
                {
                    if (string.Equals(GlobalSettings.Instance.TenantCultureInfo.Name, "en-US") || string.Equals(GlobalSettings.Instance.TenantCultureInfo.Name, "es-US"))
                    {
                        unitOfMeasure = "lb";
                    }
                    else
                    {
                        unitOfMeasure = "kg";
                    }
                    if (GlobalSettings.ShowWeightedItemsWithAverageItemWeightAsPacks && (UnitOfMeasure == "Packs" || UnitOfMeasure == "PK"))
                    {
                        unitOfMeasure = LiteralTranslator.GetValue("PK");
                    }
                } else
                {
                    unitOfMeasure = LiteralTranslator.GetValue("EA");
                }
                return unitOfMeasure;
            }
        }
        public bool IsOnHandVisible
        {
            get => _isOnHandVisible;
            set => SetAndRaisePropertyChanged(ref _isOnHandVisible, value);
        }
        public Color LblQtyTextColor
        {
            get => _lblQtyTextColor;
            set => SetAndRaisePropertyChanged(ref _lblQtyTextColor, value);
        }
        public bool IsPrinterIconVisible
        {
            get => _isPrinterIconVisible;
            set => SetAndRaisePropertyChanged(ref _isPrinterIconVisible, value);
        }
        public bool IsSaleableUnlabeledIconVisible
        {
            get => _isSaleableUnlabeledIconVisible;
            set => SetAndRaisePropertyChanged(ref _isSaleableUnlabeledIconVisible, value);
        }
        public string LabelQuantityDisplay
        {
            get => _labelQuantityDisplay;
            set => SetAndRaisePropertyChanged(ref _labelQuantityDisplay, value);
        }
        public string UnLabeledQuantityDisplay
        {
            get => _unLabeledQuantityDisplay;
            set => SetAndRaisePropertyChanged(ref _unLabeledQuantityDisplay, value);
        }
        public bool IsSaleableUnlabeledItem
        {
            get => _isSaleableUnlabeledItem;
            set => SetAndRaisePropertyChanged(ref _isSaleableUnlabeledItem, value);
        }
        public double TotalProduceQuantity
        {
            get => _totalProduceQuantity;
            set => SetAndRaisePropertyChanged(ref _totalProduceQuantity, value);
        }
        public bool DoesProducingStoreExist { get; set; }
        public double? TotalWeight { get; set; }
    }



    public class ItemOrderGroupResponse : FilterDTO
    {
        private string _groupColor;
        private string _framebgColor;
        public int ItemOrderGroupId { get; set; }
        public string ItemOrderGroupName { get; set; }
        public string GroupColor
        {
            get => _groupColor;
            set => SetAndRaisePropertyChanged(ref _groupColor, value);
        }
        public string FramebgColor
        {
            get => _framebgColor;
            set => SetAndRaisePropertyChanged(ref _framebgColor, value);
        }
    }
}
