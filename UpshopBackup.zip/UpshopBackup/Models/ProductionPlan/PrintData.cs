﻿using MobileUI2.Constants;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Text;

namespace MobileUI2.Models.ProductionPlan
{
    public class PrintData
    {
        public string IpAddress { get; set; }
        public int Port { get; set; }
        public string Data { get; set; }
        public int UsePrinterCutter { get; set; }
        public bool ReceiptResolution { get; set; }
        public PrinterCutterMode CutMode { get; set; }
        public TotalRecordData TotalRecord { get; set; }
        public MarkdownLabelPrint MarkdownData { get; set; }
        public Collection<byte> BinaryData { get; set; }
        public List<DayMarkPrinterDetails> DayMarkPrinters { get; set; }
    }

    public class DayMarkPrinterDetails
    {
        public int PrinterId { get; set; }
        public string PrinterName { get; set; }
        public string UUID { get; set; }
        public string ApprovedLabelSize { get; set; }
        public string SecretKey { get; set; }
    }

    public class TotalRecordData
    {
        public int DepartmentId { get; set; }
        public int OrgUnitId { get; set; }
        public int? ItemId { get; set; }
        public int InventoryStateId { get; set; }
        public int LabelPrinterId { get; set; }
        public int LabelQuantity { get; set; }
        public int? ProductionPlanId { get; set; }
        public decimal? RetailPrice { get; set; }
        public List<int> FailedProductionPlanIds { get; set; } = new List<int>();
    }
}
