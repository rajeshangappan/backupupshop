﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using Microsoft.Maui.Controls.Compatibility;
using Microsoft.Maui.Controls;
using Microsoft.Maui;

namespace MobileUI2.Models
{
    public class PrepStepsDTO
    {
        public string ProudctionAreaName { get; set; }
        public IEnumerable<ProductionPlanPrepStep> productionPlans { get; set; }
    }
    public class ProductionPlanPrepStep : NotifyPropertyChanged
    {
        public List<ProductionPlanPrepStep> Steps { get; set; } = new List<ProductionPlanPrepStep>();
        public bool IsNeededEnable { get; set; }
        public bool InverseIsNeededEnable { get; set; }
        public int ProductionPlanPrepStepId { get; set; }
        public int PlanId { get; set; }
        public int PlanOrgUnitId { get; set; }
        public int ItemId { get; set; }
        public int OrgUnitId { get; set; }
        public int ItemProductionProcessId { get; set; }
        public int ProductionAreaId { get; set; }
        public string ProductionAreaName { get; set; }
        public string ItemLabel { get; set; }
        public int? DepartmentId { get; set; }
        public string Activity { get; set; }
        public DateTime StartBy { get; set; }
        public DateTime CompletedBy { get; set; }
        public DateTime? CompletedDateTime { get; set; }
        public double QuantityOrWeight { get; set; }
        public string ProductionWeightCode { get; set; }
        public bool FinishedItemsExist { get; set; }
        public int StatusId { get; set; }
        public int Batch { get; set; }
        public int? SequenceNumber { get; set; }
        public string StartTime { get; set; }
        public string ReadyByTime { get; set; }
        public string CompletedTime { get; set; }
        public string Status
        {
            get
            {
                switch (StatusId)
                {
                    case 0:
                        return "Start";
                    case 1:
                        return "Finish";
                    case 2:
                        return "Complete";
                    default:
                        return string.Empty;
                }
            }
            set { }
        }
        public bool IsvisibleAreaName { set; get; }
        public List<PlanItemsWithSemiFinishedArticles> ProducedItems { get; set; } = new List<PlanItemsWithSemiFinishedArticles>();
        public List<GroupPlanItemsWithSemiFinishedArticles> ConsolidatedProducedItems { get; set; } = new List<GroupPlanItemsWithSemiFinishedArticles>();
        public List<ProductionOrderReceivingItemInfo> ProductionOrderItemsOutgoingToDepartment { get; set; }
        public List<int> ConsolidatedProductionPlanPrepStepIds { get; set; }
        public double? ProductionOrderTotalQuantity { get; set; }
        public double TempQuantityOrWeight { get; set; }
        public double TotalPrepQty { get => QuantityOrWeight + ProductionOrderTotalQuantity.GetValueOrDefault(); }
        public int CompletedItems { get; set; }
        public int TotalItems { get; set; }
        public bool ShowProgressbar { get; set; }
        public decimal? CompletionProgress { get; set; }
        public string ProgressColor { get; set; }
        public bool AllowDecimalValue { get; set; }
        public int? WorkstationId { get; set; }
        public string WorkstationName { get; set; }
        public int? WorkstationTypeId { get; set; }
        public string WorkstationTypeDescription { get; set; }
        public int DurationMinutes { get; set; }
        public string PrepStepDurationTime { get; set; }
        public int? ItemTag { get; set; }
        public string ItemTagName { get; set; }
        public bool OnPromotion { get; set; }
        private bool _showStatus;
        public bool ShowStatus
        {
            get => _showStatus;
            set => SetAndRaisePropertyChanged(ref _showStatus, value);
        }
        public bool IsVisibleProduceQty => (ProductionOrderTotalQuantity.HasValue && ProductionOrderTotalQuantity.Value != 0);
        private int _displayStepStatusId;
        public int DisplayStepStatusId
        {
            get => _displayStepStatusId;
            set => SetAndRaisePropertyChanged(ref _displayStepStatusId, value);
        }
        public string PlanDescription { get; set; }


    }
    public class PrepStepList
    {
        public List<ProductionPlanPrepStep> PrepStepsList = new List<ProductionPlanPrepStep>();
    }
    public class PlanItemsWithSemiFinishedArticles : NotifyPropertyChanged
    {
        int _prepQuantity;
        bool _isNeeded;
        public int ProductionOrderId { get; set; }
        public int? ProductionPlanPrepStepId { get; set; }
        public int? ItemId { get; set; }
        public int PlanID { get; set; }
        public string ItemLabel { get; set; }
        public string ItemDescription { get; set; }
        public string DepartmentDescription { get; set; }
        public string ProductionWeightCode { get; set; }
        public int ItemProductionProcessId { get; set; }
        public int OrgUnitId { get; set; }
        public double? Quantity { get; set; }
        public bool AllowDecimalValue { get; set; }
        public int ConsolidatedItemID { get; set; }
        public bool IsNeeded
        {
            get => _isNeeded;
            set => SetAndRaisePropertyChanged(ref _isNeeded, value);
        }
        public bool ShowItemLabel { get; set; }
        public bool IsProductionOrderItem { get; set; }
        public double? TempQuantity { get; set; }
        public bool IsNonSemiFinishedItem { get; set; }
        public int PrepQuantity
        {
            get => _prepQuantity;
            set
            {
                if (_prepQuantity != 0 && _prepQuantity != value)
                {
                    IsNeeded = true;
                }
                else
                {
                    if (!IsNeeded)
                        IsNeeded = false;
                }
                SetAndRaisePropertyChanged(ref _prepQuantity, value);
            }
        }

    }
    public class ProductionOrderReceivingItemInfo
    {
        public string ReceivingProductionAreaLabel { get; set; }
        public int ProductionOrderId { get; set; }
        public string ProducedItemLabel { get; set; }
        public double? QuantityTransferredToDepartment { get; set; }
        public int ProducingPlanId { get; set; }
        public int ReceivingPlanId { get; set; }
        public int ItemId { get; set; }
        public string UnitOfMeasure { get; set; }
    }
    public class GroupPlanItemsWithSemiFinishedArticles
    {
        public int PlanId { get; set; }
        public int ConsolidatedItemID { get; set; }
        public int ProductionPlanPrepStepId { get; set; }
        public string PlanDescription { get; set; }
        public List<PlanItemsWithSemiFinishedArticles> CombinedProducedItems { get; set; }
        public List<ProductionOrderReceivingItemInfo> CombinedProductionOrderItemsOutgoingToDepartment { get; set; }
        public double TotalQuantity { get; set; }
        public DateTime CompletedBy { get; set; }
    }
    public class PrepItemDetailsGroup : ObservableCollection<PlanItemsWithSemiFinishedArticles>
    {
        public int PlanId { get; set; }
        public string PlanDescription { get; set; }
        public string TotalQuantity { get; set; }
        public DateTime CompletedBy { get; set; }

        public PrepItemDetailsGroup(int planID, string planDescription, double totalQuantity,DateTime completedBy, ObservableCollection<PlanItemsWithSemiFinishedArticles> items) : base(items)
        {
            PlanId = planID;
            PlanDescription = planDescription;
            TotalQuantity = $"Total: " + totalQuantity;
            CompletedBy = completedBy;
        }
        public ObservableCollection<PlanItemsWithSemiFinishedArticles > GetAllItems()
        {
            return new ObservableCollection<PlanItemsWithSemiFinishedArticles>(this);
        }
    }
}
