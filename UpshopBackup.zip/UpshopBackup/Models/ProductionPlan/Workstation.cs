﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Maui.Controls.Compatibility;
using Microsoft.Maui.Controls;
using Microsoft.Maui;

namespace MobileUI2.Models
{
    public class Workstation : NotifyPropertyChanged
    {
        private string _backgroundColor = "#FFFFFF";
        public int WorkstationId { get; set; }
        public string WorkstationName { get; set; }
        public string WorkstationTypeDescription { get; set; }
        public int ProductionAreaId { get; set; }
        public string ProductionAreaDescription { get; set; }
        public string BackgroundColor 
        {
            get => _backgroundColor;
            set => SetAndRaisePropertyChanged(ref _backgroundColor, value);
        } 

    }
}
