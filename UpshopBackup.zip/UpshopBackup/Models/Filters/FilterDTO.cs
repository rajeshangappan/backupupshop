﻿using MobileUI2.Models.ProductionPlan;
using MobileUI2.Models.Recipes;
using System.Collections.Generic;
using System.Runtime.Serialization;
using Microsoft.Maui.Controls.Compatibility;
using Microsoft.Maui.Controls;
using Microsoft.Maui;

namespace MobileUI2.Models
{
    public class FilterDTO : NotifyPropertyChanged
    {
        private bool _isSelectGroup;
        private bool _showDepartmentLevelPipeIcon;
        public bool? TrackLabeledInventory { get; set; }
        public string FilterDescription { get; set; }
        private string _textColor;
        private string _backgroundColor;
        public int FilterID { get; set; }
        public FilterDTO Parent { get; set; }
        public bool IsDepartmentLevelFilter { get; set; }
        public bool ShowDepartmentLevelPipeIcon
        {
            get => _showDepartmentLevelPipeIcon;
            set => SetAndRaisePropertyChanged(ref _showDepartmentLevelPipeIcon, value);
        }
        public int? ParentTagId { get; set; }
        public List<int> Children { get; set; } = new List<int>();
        public List<ProductionPlanItem> FiltersProductionPlanItems { get; set; } = new List<ProductionPlanItem>();
        public List<OrderDataItem> FiltersOrderItems { get; set; } = new List<OrderDataItem>();
        public List<ProductionPlanPickList> FiltersPickList { get; set; } = new List<ProductionPlanPickList>();
        public ItemGroup FiltersItems { get; set; }
        public List<PrepStepsByItemTag> FiltersPrep { get; set; } = new List<PrepStepsByItemTag>();
        public RecipeSearchGroup FiltersRecipes {get;set;}
        [IgnoreDataMember]
        private Style _styleAttribute = Application.Current != null ? (Style)Application.Current.Resources["LabelLightStyle"] : null;

        public bool IsSelectGroup
        {
            get => _isSelectGroup;
            set => SetAndRaisePropertyChanged(ref _isSelectGroup, value);
        }
        public string TextColor
        {
            get => _textColor;
            set => SetAndRaisePropertyChanged(ref _textColor, value);
        }
        public string BackgroundColor
        {
            get => _backgroundColor;
            set => SetAndRaisePropertyChanged(ref _backgroundColor, value);
        }
        [IgnoreDataMember]
        public Style StyleAttribute
        {
            get => _styleAttribute;
            set => SetAndRaisePropertyChanged(ref _styleAttribute, value);
        }
    }
    public class ItemTagDTO : FilterDTO
    {
        public int ItemTagId { get; set; }
        public string ItemTagName { get; set; }
    }
}
