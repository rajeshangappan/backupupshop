﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.Text;
using Microsoft.Maui.Controls.Compatibility;
using Microsoft.Maui.Controls;
using Microsoft.Maui;

namespace MobileUI2.Models
{
    public class CategoryDTO : FilterDTO
    {
        public int ItemOrderGroupId { get; set; }
        public string ItemOrderGroupName { get; set; }
    }
}
