﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models
{
    public class TaskSignOffRequest
    {
        public int TaskActivityId { get; set; }
        public bool IsSignOffAccepted { get; set; }
        public string Comment { get; set; }
        public byte[] Signature { get; set; }
    }
}
