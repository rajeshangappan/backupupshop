﻿namespace MobileUI2.Models
{
    public class GetTemperatureCheckTaskStepsRequest
    {
        public int TaskActivityId { get; set; }
    }
}
