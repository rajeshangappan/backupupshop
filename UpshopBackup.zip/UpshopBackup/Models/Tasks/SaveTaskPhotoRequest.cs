﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models.TaskActivities
{
    public class SaveTaskPhotoRequest
    {
        public byte[] MediaData { get; set; }
        public int TaskActivityStepId { get; set; }
        public string FileName { get; set; }
    }
}
