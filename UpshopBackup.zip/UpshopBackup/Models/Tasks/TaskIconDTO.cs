﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models
{
   public class TaskIconDTO
    {
        public bool IsVisibleProgressBar { get; set; }
        public string TaskIcon { get; set; }
    }
}
