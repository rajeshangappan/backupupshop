﻿using MobileUI2.Models.TaskActivities;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace MobileUI2.Models
{
    public class TemperatureTaskStep : INotifyPropertyChanged
    {
        public int TaskActivityStepId { get; set; }
        public int TaskActivityId { get; set; }
        public int StoreId { get; set; }
        public int TaskStepId { get; set; }
        public int CategoryId { get; set; }
        public string CategoryName { get; set; }
        public int Priority { get; set; }
        public int? ItemId { get; set; }
        public int? TaskLaborProcessId { get; set; }
        public int? Duration { get; set; }
        public int? TaskTemperatureType { get; set; }
        public string ItemDisplay { get; set; }
        public string TemperatureRange { get; set; }
        public string TempType { get; set; }
        public string LastUpdatedBy { get; set; }
        public string NavigationIcon
        {
            get => "\uf054";
            set => throw new NotImplementedException();
        }

        public bool IsEnteredTemperatureAvailable => Status == TaskStepStatus.Completed;
        public bool IsTemperatureInRange => (IsEnteredTemperatureAvailable && MinimumTemperature <= EnteredTemperature && MaximumTemperature >= EnteredTemperature);
        public decimal MinimumTemperature { get; set; }
        public decimal MaximumTemperature { get; set; }
        public decimal EnteredTemperature { get; set; }
        public string DisplayEnteredTemperature { get; set; }
        public TaskStepStatus Status { get; set; }
        public List<string> UserResponse { get; set; } = new List<string>();
        public DateTime? LastUpdatedUTC { get; set; }
        private bool _isSelected;
        public bool IsSelected
        {
            get => _isSelected;
            set
            {
                _isSelected = value;
                OnPropertyChanged();
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
        public bool? ExampleMedia { get; set; }
        public bool IsMediaDisplay
        {
            get
            {
                return ExampleMedia ?? false;
            }
        }
        public List<TaskStepMedia> Media { get; set; } = new List<TaskStepMedia>();
    }
}
