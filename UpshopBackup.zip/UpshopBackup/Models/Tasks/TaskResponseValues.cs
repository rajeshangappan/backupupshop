﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models.Tasks
{
    public class TaskResponseValues2 : NotifyPropertyChanged
    {
        private bool _isSelected;

        public int Id { get; set; }
        public string Text { get; set; }
        public bool IsSelected { get => _isSelected; set=> SetAndRaisePropertyChanged(ref _isSelected,value); }
    }
}
