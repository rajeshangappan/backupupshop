﻿using MobileUI2.Models.TaskActivities;
using System.Collections.Generic;
using Microsoft.Maui.Controls.Compatibility;
using Microsoft.Maui.Controls;
using Microsoft.Maui;

namespace MobileUI2.Models.Tasks
{
    public class StoreWalkQuestionDetails
    {
        public int TaskAdditionalResponseId { get; set; }
        public string Question { get; set; }
        public FormattedString FormattedQuestion { get; set; }
        public int ResponseType { get; set; }
        public bool IsAnswerRequired { get; set; }
        public ResponseTypeEnum ResponseTypeId { get; set; }
        public List<string> ResponseTypeValue { get; set; } = new List<string>();
        public List<string> Answer { get; set; } = new List<string>();
    }

}
