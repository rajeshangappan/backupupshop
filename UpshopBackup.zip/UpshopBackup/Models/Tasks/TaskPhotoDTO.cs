﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Maui.Controls.Compatibility;
using Microsoft.Maui.Controls;
using Microsoft.Maui;

namespace MobileUI2.Models
{
    public class TaskPhotoDTO : BindableObject
    {
        public string FileName;
        private string _url;

        public string Url 
        {
            get => _url;
            set { _url = value; OnPropertyChanged(); }
        }
        private int _rotation = 0;
        public int Rotation
        {
            get => _rotation;
            set { _rotation = value; OnPropertyChanged(); }
        }
    }
}
