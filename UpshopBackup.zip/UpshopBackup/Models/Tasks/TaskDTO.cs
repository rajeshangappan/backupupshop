﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Maui.Controls.Compatibility;
using Microsoft.Maui.Controls;
using Microsoft.Maui;

namespace MobileUI2.Models
{
    public class TaskDTO : BindableObject
    {
        public string Name { get; set; }
        public double ProgressData { get; set; }
        public double Completed { get; set; }
        public double InProgress { get; set; }
        public double Total { get; set; }
        public string StatusColor { get; set; }
        public bool IsVisibleProgressBar { get; set; }
    }
}
