﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models
{
    public class TaskCacheDTO
    {
        public List<TodaysTask> InProgressTaskList = new List<TodaysTask>();
        public List<TodaysTask> CompletedTaskList = new List<TodaysTask>();
    }
}
