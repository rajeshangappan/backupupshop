﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models.StoreWalks
{
    public class GetAdditionalQuestionsRequest
    {
        public int TaskActivityId { get; set; }
        public int TaskStepId { get; set; }
        public ResponseAppearsTypeEnum ResponseAppearsType { get; set; }
    }
}
