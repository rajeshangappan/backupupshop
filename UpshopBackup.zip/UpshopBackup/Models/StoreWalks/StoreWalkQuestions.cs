﻿using MobileUI2.Models.TaskActivities;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Text;

namespace MobileUI2.Models.StoreWalks
{
    public class StoreWalkQuestions : INotifyPropertyChanged
    {
        public int TaskActivityId { get; set; }
        public int TaskStepId { get; set; }
        public string MainTaskName { get; set; }
        public int TaskActivityStepId { get; set; }
        public string TaskName { get; set; }
        public string Question { get; set; }
        public TaskStepStatus Status { get; set; }
        public int CategoryId { get; set; }
        public string CategoryName { get; set; }
        public int ResponseTypeId { get; set; }
        public int? Duration { get; set; }
        public bool IsDurationVisible { get; set; }
        public string LblDuration { get; set; }
        public int Priority { get; set; }
        public DateTime? TaskStartDateTimeUtc { get; set; }
        public DateTime? TaskStepStartDateTimeUtc { get; set; }
        public List<TaskStepMedia> Media { get; set; } = new List<TaskStepMedia>();
        private bool _isSelected;
        public bool IsSelected
        {
            get => _isSelected;
            set
            {
                _isSelected = value;
                OnPropertyChanged();
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
