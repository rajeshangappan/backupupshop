﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models.StoreWalks
{
    public class StoreWalkQuestionsRequest
    {
        public StoreWalkQuestionsRequest(int taskId)
        {
            TaskActivityId = taskId;
        }
        public int TaskActivityId { get; set; }
    }
}
