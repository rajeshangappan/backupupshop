﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models.StoreWalks
{
    public class AdditionalQuestionsDetails
    {
        public int TaskAdditionalResponseId { get; set; }
        public int? AdditionalResponseTypeId { get; set; }
        public string AdditionalResponseQuestion { get; set; }
        public bool? RequireResponse { get; set; } = false;
        public int? ResponseAppears { get; set; }
        public List<string> AdditionalResponseTypeValue { get; set; } = new List<string>();
        public List<string> Answer { get; set; }
        public int Priority { get; set; }
    }
}
