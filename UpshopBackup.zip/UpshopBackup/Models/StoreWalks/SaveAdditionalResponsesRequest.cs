﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models.StoreWalks
{
    public class SaveAdditionalResponsesRequest
    {
        public int TaskActivityStepId { get; set; }
        public int TaskActivityId { get; set; }
        public ResponseAppearsTypeEnum ResponseAppearsType { get; set; }
        public List<TaskAdditionalResponseList> AdditionalResponseList { get; set; } = new List<TaskAdditionalResponseList>();
        public DateTime? TaskStartDateTimeUTC { get; set; }
        public DateTime? TaskStepStartDateTimeUTC { get; set; }
    }
    public class TaskAdditionalResponseList
    {
        public int TaskAdditionalResponseId { get; set; }
        public List<string> Answer { get; set; } = new List<string>();

    }
}
