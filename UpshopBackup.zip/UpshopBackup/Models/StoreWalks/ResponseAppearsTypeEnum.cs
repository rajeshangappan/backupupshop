﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models.StoreWalks
{
    public enum ResponseAppearsTypeEnum
    {
        Yes = 1,
        No = 2,
        Always = 3
    }
}
