﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Text;

namespace MobileUI2.Models
{
    public class Grouping<K, T> : ObservableCollection<T>
    {
        public K Key { get; set; }
        public string ShortKey { get; set; }
        public Grouping(K key, string sKey, IEnumerable<T> items)
        {
            Key = key;
            ShortKey = sKey;
            foreach (var item in items)
            {
                this.Items.Add(item);
            }
        }
        public Grouping(K key, IEnumerable<T> items)
        {
            Key = key;
            foreach (var item in items)
            {
                this.Items.Add(item);
            }
        }
    }
}
