﻿using System;
using System.Collections.Generic;
using System.Text;
using MobileUI2.Models.DSDReceiving;

namespace MobileUI2.Models
{
    public class SaveSupplierInvoiceRequest
    {
        public int SupplierInvoiceId { get; set; }
        public int SupplierId { get; set; }
        public int InvoiceSelectType { get; set; }
        public int InvoiceMethodType { get; set; }
        public string InvoiceNumber { get; set; }
        public string PurchaseOrderNumber { get; set; }
        public int MajorDepartmentId { get; set; }
        public double TotalQuantity { get; set; }
        public double TotalCost { get; set; }
        public DateTime InvoiceDate { get; set; }
        public bool IsReturnInvoice { get; set; }
        public double? Charges { get; set; }
        public double? Allowances { get; set; }
        public int? ReasonCode { get; set; }
        public string Authorization { get; set; }
        public string TemperatureSymbol { get; set; }
        public double? TemperatureValue { get; set; }
        public string Comment { get; set; }
        public double SubTotal { get; set; }
        public List<ReceivingTaxesDTO> ReceivingTaxes { get; set; } = new List<ReceivingTaxesDTO>();

    }
}
