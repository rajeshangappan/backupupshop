namespace MobileUI2.Models.DSDReceiving;

public class ReceivingTaxesDTO
{
	public int ReceivingTaxId { get; set; }
	public string TaxId { get; set; }
	public string TaxDesc { get; set; }
	public double? TaxRate { get; set; }
	public int TaxRounding { get; set; }
	public string TaxRoundingDisplay { get; set; }
	public string TaxEntryPlaceHolderName { get; set; }
	public string CurrencySymbol { get; set; }
	public double TaxValue { get; set; }
	public string TaxValueDisplay { get; set; }
}