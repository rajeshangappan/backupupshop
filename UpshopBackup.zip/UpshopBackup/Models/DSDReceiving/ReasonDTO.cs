﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models
{
    public class ReasonDTO
    {
        public int AdjustmentTypeId { get; set; }
        public int AdjustmentTypeNumber { get; set; }
        public string Description { get; set; }
        public bool IncludedInShrink { get; set; }
        public bool Increase { get; set; }
        public bool Returns { get; set; }
        public bool Invoice { get; set; }
        public bool Disposal { get; set; }
        public bool NoDSD { get; set; }
        public bool Reclaim { get; set; }
    }
}
