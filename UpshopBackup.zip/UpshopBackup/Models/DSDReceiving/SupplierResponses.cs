﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models
{
    public class SupplierResponses
    {
        public int VendorId { get; set; }
        public string VendorNumber { get; set; } // supplierid
        public string Name { get; set; }
        public int? MajorDepartmentId { get; set; }
        public int? MajorDepartmentNumber { get; set; }
        public string MajorDepartmentName { get; set; }
        public int? PrintInvoiceCopies { get; set; }
        public bool AllowTotalOnly { get; set; }
        public bool AllowTotalAccept { get; set; }
        public bool AllowTotalCount { get; set; }
        public bool AutoReceive { get; set; }
        public bool AggregateCount { get; set; }
        public int? AuditContainerPercent { get; set; }
        public int? AuditInvoicePercent { get; set; }
        public bool UseSupplierCost { get; set; }
        public bool RoundLineItemExtendedCost { get; set; }
        public bool RoundEachCost { get; set; }
        public bool COD { get; set; }
        public bool MiscCharge { get; set; }
        public bool MiscAllowance { get; set; }
        public bool ProductReturnsAccepted { get; set; }
        public bool ReasonCodeRequired { get; set; }
        public bool ReturnAuthorizationNumberRequired { get; set; }
        public int SupplierReturnType { get; set; }
        public int SupplierMethodType { get; set; }
        public bool IsStoreCanOrder { get; set; }
        public bool? TemperatureCheck { get; set; }
        public bool IsDSDVendor { get; set; }
        public bool? TotalOnlyReturn { get; set; }
    }
}
