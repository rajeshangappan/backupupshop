﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models
{
    public class MajorDepartmentDTO
    {
        public int MajorDepartmentId { get; set; }
        public int Number { get; set; }
        public string Name { get; set; }
    }
}
