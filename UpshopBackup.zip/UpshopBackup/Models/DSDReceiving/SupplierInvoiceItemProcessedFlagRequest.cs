﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models
{
    public class SupplierInvoiceItemProcessedFlagRequest
    {
        public int SupplierInvoiceId { get; set; }
        public int ItemId { get; set; }
        public string BarcodeNumber { get; set; }
        public double Quantity { get; set; }
        public string UnitOfMeasure { get; set; }
        public bool IsForcedQuantity { get; set; }
        public string LotCode { get; set; }
        public string ScannedBarcode { get; set; }
        public bool IsHighRiskWorkflowEnabled { get; set; }
    }
}
