﻿using MobileUI2.Constants;
using MobileUI2.Models.DSDReceiving;
using System;
using System.Collections.Generic;

namespace MobileUI2.Models
{
    public class InvoiceDTO
    {
        public int SupplierInvoiceId { get; set; }
        public int SupplierId { get; set; }
        public int BusinessUnitId { get; set; }
        public string SupplierName { get; set; }
        public int InvoiceSelectType { get; set; }
        public int InvoiceMethodType { get; set; }
        public string InvoiceSelectTypeName { get; set; }
        public string InvoiceMethodTypeName { get; set; }
        public string InvoiceNumber { get; set; }
        public string InvoiceNumberDisplay { get; set; }
        public string PurchaseOrderNumber { get; set; }
        public int MajorDepartmentId { get; set; }
        public int MajorDepartmentNumber { get; set; }
        public string MajorDepartmentName { get; set; }
        public double SupplierTotalQuantity { get; set; }
        public double SupplierTotalCost { get; set; }
        public DateTime InvoiceDate { get; set; }
        public DateTime? CompletedTimestamp { get; set; }
        public DateTime? DeliveryTimestamp { get; set; }
        public DateTime? VoidTimestamp { get; set; }
        public int Status { get; set; }
        public bool IsUpComing { get; set; }
        public bool IsToday { get; set; }
        public string InvoiceDateDisplay { get; set; }
        public int? SupplierMajorDepartmentId { get; set; }
        public bool? AllowTotalAccept { get; set; }
        public bool? AllowTotalCount { get; set; }
        public string VendorImage { get; set; }

        public InvoiceStatus InvoiceStatus => (InvoiceStatus)Status;
        public string StatusDisplay => InvoiceStatus.ToString();
        public bool IsUnprocessedInvoice { get; set; }
        public bool? CanView { get; set; }
        public bool? CanAdd { get; set; }
        public bool? CanVoid { get; set; }
        public bool Processed { get; set; }
        public bool ShowInvoiceReview { get; set; }
        public bool IsReturnInvoice { get; set; }
        public double? Charges { get; set; }
        public double? Allowances { get; set; }
        public int? ReasonCode { get; set; }
        public string ReasonCodeDescription { get; set; }
        public string Authorization { get; set; }
        public bool MiscCharge { get; set; }
        public bool MiscAllowance { get; set; }
        public bool ReasonCodeRequired { get; set; }
        public bool ReturnAuthorizationNumberRequired { get; set; }
        public bool IsCreatedInvoice { get; set; }
        public int ProcessedItems { get; set; }
        public int TotalItemsCount { get; set; }
        public decimal ProcessCompletionItems { get; set; }
        public bool TotalAccept { get; set; }
        public bool TotalCount { get; set; }
        public bool ShowInvoiceExceptionItems { get; set; }
        public bool ShowHighRiskItems { get; set; }
        public bool IsForceClose { get; set; }
        public string InvoiceProgressColor
        {
            get
            {
                return ProcessCompletionItems.Equals(0) ? "#cb3e2c" : ProcessCompletionItems <= 0.40M ? "#cb3e2c" : (ProcessCompletionItems > 0.40M && ProcessCompletionItems <= 0.79M ? "#edbc37" : "#2CCB79");
            }
        }
        public List<SupplierInvoiceItem> Items { get; set; } = new List<SupplierInvoiceItem>();
        public List<ReceivingTaxesDTO> ReceivingTaxes { get; set; } = new List<ReceivingTaxesDTO>();
        public double SubTotal { get; set; }
        public HighRisk? HighRiskWorkFlow { get; set; }
        public MissingHighRisk? MissingHighRiskInformation { get; set; }
        public bool IsStoreCanOrder { get; set; }
        public bool IsInvoiceImported { get; set; }
        public string TemperatureSymbol { get; set; }
        public double? TemperatureValue { get; set; }
        public string Comment { get; set; }
        public bool? TemperatureCheck { get; set; }
        public bool IsDSDVendor { get; set; }
    }
    public enum HighRisk
    {
        ScanByCase = 1,
        ScanEveryCase = 2
    }
    public enum MissingHighRisk
    {
        Capture = 1,
        Reject = 2
    }
    public class SupplierInvoiceItem
    {
        private static int _lastAssignedId = 0;
        public SupplierInvoiceItem()
        {
            ID = ++_lastAssignedId;
        }
        public int ID { get; set; }
        public string BarcodeNumber { get; set; }
        public string ScannedBarcode { get; set; }
        public string OrderCode { get; set; }
        public string Description { get; set; }
        public int ReasonCode { get; set; }
        public string LotCode { get; set; }
        public int? Exception { get; set; }
        public string ExceptionDescription { get; set; }
        public bool Processed { get; set; }
        public int SupplierInvoiceId { get; set; }
        public double RetailPrice { get; set; }
        public double FinalQuantity { get; set; }
        public double ScannedQuantity { get; set; }
        public string FinalUnitOfMeasure { get; set; }
        public int FinalPackQuantity { get; set; }
        public double FinalCost { get; set; }
        public int BarcodeId { get; set; }
        public double? SupplierQuantity { get; set; }
        public string SupplierUnitOfMeasure { get; set; }
        public int? SupplierPackQuantity { get; set; }
        public int? StorePackQuantity { get; set; }
        public double? SupplierCost { get; set; }
        public double? StoreCost { get; set; }
        public double? SupplierAllowance { get; set; }
        public double? StoreAllowance { get; set; }
        public double FinalAllowance { get; set; }
        public int ItemId { get; set; }
        public double FinalQuantityInUnits { get; set; }
        public double FinalExtendedNetCost { get; set; }
        public bool IsPackDiscrepency { get; set; }
        public bool IsUpdatedExceptionQty { get; set; }
        public bool HighRisk { get; set; }
        public bool IsRestrictZeroQuantity { get; set; }
        public string Uom { get; set; }
        public bool IsWeighted { get; set; }
        public double FinalCalculatedCost
        {
            get
            {
                return (FinalCost - FinalAllowance);
            }
        }
        public SupplierInvoiceItem(SupplierInvoiceItem other)
        {
            ID = ++_lastAssignedId;
            BarcodeNumber = other.BarcodeNumber;
            ScannedBarcode = other.ScannedBarcode;
            OrderCode = other.OrderCode;
            Description = other.Description;
            ReasonCode = other.ReasonCode;
            LotCode = other.LotCode;
            Exception = other.Exception;
            ExceptionDescription = other.ExceptionDescription;
            Processed = other.Processed;
            SupplierInvoiceId = other.SupplierInvoiceId;
            RetailPrice = other.RetailPrice;
            FinalQuantity = other.FinalQuantity;
            ScannedQuantity = other.ScannedQuantity;
            FinalUnitOfMeasure = other.FinalUnitOfMeasure;
            FinalPackQuantity = other.FinalPackQuantity;
            FinalCost = other.FinalCost;
            BarcodeId = other.BarcodeId;
            SupplierQuantity = other.SupplierQuantity;
            SupplierUnitOfMeasure = other.SupplierUnitOfMeasure;
            SupplierPackQuantity = other.SupplierPackQuantity;
            StorePackQuantity = other.StorePackQuantity;
            SupplierCost = other.SupplierCost;
            StoreCost = other.StoreCost;
            SupplierAllowance = other.SupplierAllowance;
            StoreAllowance = other.StoreAllowance;
            FinalAllowance = other.FinalAllowance;
            ItemId = other.ItemId;
            FinalQuantityInUnits = other.FinalQuantityInUnits;
            FinalExtendedNetCost = other.FinalExtendedNetCost;
            IsPackDiscrepency = other.IsPackDiscrepency;
            IsUpdatedExceptionQty = other.IsUpdatedExceptionQty;
            HighRisk = other.HighRisk;
            IsRestrictZeroQuantity = other.IsRestrictZeroQuantity;
            Uom=other.Uom;
            IsWeighted=other.IsWeighted;
        }
    }
}
