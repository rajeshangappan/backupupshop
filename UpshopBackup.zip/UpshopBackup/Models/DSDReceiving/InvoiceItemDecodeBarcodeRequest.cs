﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models
{
    public class InvoiceItemDecodeBarcodeRequest
    {
        public int SupplierInvoiceId { set; get; }
        public string BarcodeNumber { get; set; }
    }
}
