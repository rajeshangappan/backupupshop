﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models
{
    public class SupplierInvoiceRequest
    {
        public int SupplierInvoiceId { get; set; }
        public int BusinessUnitId { get; set; }
    }
}
