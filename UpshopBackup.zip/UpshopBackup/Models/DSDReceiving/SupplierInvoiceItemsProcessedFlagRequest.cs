﻿using MobileUI2.Constants;
using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2
{
    public class SupplierInvoiceItemsProcessedFlagRequest
    {
        public int SupplierInvoiceId { get; set; }
        public double SupplierTotalQuantity { get; set; }
        public SupplierInvoiceAction InvoiceAction { get; set; }
    }
}
