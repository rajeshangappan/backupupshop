﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models
{
    public class SettingRequest
    {
        public string Name { get; set; }
        public object Value { get; set; }
    }
}
