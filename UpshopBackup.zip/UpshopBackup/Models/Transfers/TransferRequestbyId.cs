﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models
{
    public class TransferRequestbyId
    {
        public int TransferId { get; set; }
    }
}
