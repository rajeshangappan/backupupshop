﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models
{
    public class TransferRules
    {
        public int TransferRuleId { get; set; }
        public int FromStoreId { get; set; }
        public string FromStoreName { get; set; }
        public int FromDepartmentId { get; set; }
        public string FromDepartmentName { get; set; }
        public int ToStoreId { get; set; }
        public string ToStoreName { get; set; }
        public int ToDepartmentId { get; set; }
        public string ToDepartmentName { get; set; }
        public bool IsInStoreTransfer { get { return FromStoreId == ToStoreId; } }
    }
}
