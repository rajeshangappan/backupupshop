﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models
{
    public class TransfersScanBarcodeRequest
    {
        public int TransferId { get; set; }
        public int FromDepartmentId { get; set; }
        public int ToDepartmentId { get; set; }
        public int FromStoreId { get; set; }
        public int ToStoreId { get; set; }
        public string Barcode { get; set; }
        public TransferDetails Item { get; set; } = new TransferDetails();
    }    
}
