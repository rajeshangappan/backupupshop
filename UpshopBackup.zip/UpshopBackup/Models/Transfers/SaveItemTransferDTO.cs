﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models
{
    public class SaveItemTransferDTO
    {
        public int TransferId { get; set; }
        public TransferDetails Item { get; set; }
    }
}
