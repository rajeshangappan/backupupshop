﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models
{
    public class OpenTransfers
    {
        public int TransferId { get; set; }
        public int FromDepartmentId { get; set; }
        public string FromDepartmentName { get; set; }
        public int ToDepartmentId { get; set; }
        public string ToDepartmentName { get; set; }
        public int FromStoreId { get; set; }
        public string FromStoreName { get; set; }
        public int ToStoreId { get; set; }
        public string ToStoreName { get; set; }
        public string ToStoreNameDisplay => string.IsNullOrEmpty(ToStoreName) ? string.Empty : ToStoreName;
        public DateTime StartDateTime { get; set; }
        public DateTime? ReceivedDateTime { get; set; }
        public DateTime? InitiatedDateTime { get; set; }
        public DateTime? RejectedDateTime { get; set; }
        public DateTime selectedTransferDateTime { get; set; }
        public int StatusId { get; set; }
        public int TransferType { get; set; }
        public string Barcode { get; set; }
        public string StatusName { get; set; }
        public string StatusColor => (StatusId == 1 || StatusId==0) ? "#FF7800" : (StatusId == 2) ? "#F43F5E" : "#43B262";

        public string StatusLabel { get; set; }
        public string StatusIcon { get; set; }
        public TransferDetails Item { get; set; }
        public string TransferDay => (StartDateTime.Date == DateTime.Now.Date) ? LiteralTranslator.GetValue("Today") : StartDateTime.Date.ToShortDateString();
        public string TabletDisplayDayTime { get; set; }
        public string Status { get; set; }

        public string TransferTime { get; set; }
        public bool CanDelete => StatusId < 2;    
    }


    public class TransferDetails
    {        
        public int TransferDetailId { get; set; }
        public int ItemId { get; set; }
        public long ItemNumber { get; set; }
        public string ItemDescription { get; set; }
        public string Barcode { get; set; }
        public double Retail { get; set; }
        public double Quantity { get; set; }
        public string InventoryType { get; set; }
        public int? InventoryStateId { get; set; }
        public double? Cost { get; set; }
        public string UOM { get; set; }       
        public short? TypeOfInventory { get; set; }
        public bool AllowDecimalValue => TypeOfInventory != 3;
    }
}
