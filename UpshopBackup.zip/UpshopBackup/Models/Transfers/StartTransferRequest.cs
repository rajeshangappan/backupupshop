﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models
{
    public class StartTransferRequest
    {
        public int TransferId { get; set; }
        public int FromDepartmentId { get; set; }
        public int ToDepartmentId { get; set; }
        public int FromStoreId { get; set; }
        public int ToStoreId { get; set; }
        public MobileTransferType Type { get; set; }
        public string Barcode { get; set; }
    }
    public enum MobileTransferType
    {
        InStore=1,
        StoreToStore=2
    }
}
