﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models
{
    public class OpenTransferDTO
    {
        public string QDType { get; set; }
        public int TransferId { get; set; }
        public int FromDepartmentId { get; set; }
        public string FromDepartmentName { get; set; }
        public int ToDepartmentId { get; set; }
        public string ToDepartmentName { get; set; }
        public int FromStoreId { get; set; }
        public string FromStoreName { get; set; }
        public int ToStoreId { get; set; }
        public string ToStoreName { get; set; }
        public DateTime StartDateTime { get; set; }
        public DateTime? ReceivedDateTime { get; set; }
        public int StatusId { get; set; }
        public int TransferType { get; set; }
        public string Barcode { get; set; }       
        public string StatusIcon { get; set; }
        public TransferDetails Item { get; set; }     
        public string TransferTime { get; set; }       
    }
}
