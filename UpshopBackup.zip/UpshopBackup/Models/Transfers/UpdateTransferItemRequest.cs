﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models
{
    public class UpdateTransferItemRequest
    {
        public int TransferId { get; set; }
        public int ItemId { get; set; }
        public double Quantity { get; set; }
    }
}
