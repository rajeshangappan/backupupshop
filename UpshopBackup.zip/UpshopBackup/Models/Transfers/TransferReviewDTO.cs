﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models
{
    public class TransferReviewDTO 
    {       
        public int TransferDetailId { get; set; }
        public int ItemId { get; set; }
        public string ItemDisplay { get; set; }
        public long ItemNumber { get; set; }
        public string ItemDescription { get; set; }
        public string Barcode { get; set; }
        public double? Retail { get; set; }
        public double Quantity { get; set; }
        public string QuantityLbl { get; set; }
        public string InventoryType { get; set; }
        public int TransferId { get; set; }
        public int? ReceviedItemID { get; set; }
        public double? ReceivedQuantity { get; set; }
        public bool IsVisibleFinalize { get; set; }
        public double TempQty { get; set; }
        public string UOM { get; set; }
        public int TypeOfInventory { get; set; }
        public bool AllowDecimalValue => TypeOfInventory != 3;
        public bool DisableQuantityField { get; set; }
        public bool CanDelete { get; set; }
    }
}
