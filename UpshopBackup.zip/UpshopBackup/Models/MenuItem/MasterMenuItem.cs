﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models
{
   public class MasterMenuItem
    {
        public string Code { get; set; }      
        public string Color { get; set; }
        public string MenuText { get; set; }
        public string MenuIcon { get; set; }
        public Type ViewModelToLoad { get; set; }
        public string ItemNumber { get; set; }
        public bool IsVisibleIndicator { get; set; }      

    }
}
