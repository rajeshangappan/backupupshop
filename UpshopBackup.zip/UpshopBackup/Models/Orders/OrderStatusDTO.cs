﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.Text;
using Microsoft.Maui.Controls.Compatibility;
using Microsoft.Maui.Controls;
using Microsoft.Maui;

namespace MobileUI2.Models.Orders
{
    public class OrderStatusDTO : NotifyPropertyChanged
    {
        private bool _isSelectGroup;
     
        [IgnoreDataMember]
        private Style _styleAttribute = Application.Current != null ? (Style)Application.Current.Resources["LabelLightStyle"] : null;
        public string StatusName { get; set; }
        public int StatusId { get; set; }
        public bool IsSelectGroup
        {
            get => _isSelectGroup;
            set => SetAndRaisePropertyChanged(ref _isSelectGroup, value);
        }
       
        [IgnoreDataMember]
        public Style StyleAttribute
        {
            get => _styleAttribute;
            set => SetAndRaisePropertyChanged(ref _styleAttribute, value);
        }
    }
}
