﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models
{
    public class OrderItemInfoDetailsDTO
    {
        public string ItemDescription { get; set; }
        public int OrderId { get; set; }
        public string SKU { get; set; }
        public string PackQuantity { get; set; }
        public string Size { get; set; }
        public string RegularPrice { get; set; }
        public string CurrentPrice { get; set; }
        public double? EstimatedBackroomOnHandUnits { get; set; }
        public double? EstimatedBackroomOnHandCases { get; set; }
        public double? OnHandUnits { get; set; }
        public double? OnHandCases { get; set; }
        public double? OnOrderUnits { get; set; }
        public double? OnOrderCases { get; set; }
        public string CurrencySymbol { get; set; }
        public string OrderCode { get; set; }
    }
}
