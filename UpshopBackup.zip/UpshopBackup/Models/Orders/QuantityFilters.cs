﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models.Orders
{
    public class QuantityFilters : NotifyPropertyChanged
    {
        private bool _isSelected;
        private bool _showSubName;
        private string _fieldSubName;
        public QuantityFieldType FieldType { get; set; }
        public string FieldName => GetFieldNameFromResources();
        public string FieldSubName
        {
            get => _fieldSubName;
            set => SetAndRaisePropertyChanged(ref _fieldSubName, value);
        }
        public bool ShowSubName
        {
            get => _showSubName;
            set => SetAndRaisePropertyChanged(ref _showSubName, value);
        }
        public bool IsSelected
        {
            get => _isSelected;
            set => SetAndRaisePropertyChanged(ref _isSelected, value);
        }
        private string GetFieldNameFromResources()
        {
            string resourceKey = $"{FieldType}";
            return LiteralTranslator.GetValue(resourceKey) ?? FieldType.ToString();
        }
    }
    public class SelectedQuantityFilter
    {
        public QuantityFieldType FieldType { get; set; }
        public string PropertyName { get; set; } = string.Empty;
        public double? Value { get; set; }
        public string Operator { get; set; }
    }
    public enum QuantityFieldType
    {
        None = 1,
        AdjustmentQuantity,
        DemandQuantity,
        OnHandQuantity,
        OnOrderQuantity,
        OrderQuantity
    }
}
