﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models.Orders
{
    public class SupplierDTO
    {
        public int VendorId { get; set; }
        public string VendorNumber { get; set; } // supplierid
        public string Name { get; set; }
        public string SupplierDisplay { get; set; }
    }
}
