﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models
{
    public class OrderDetailsInfoTab : NotifyPropertyChanged
    {
        private bool _isSelected;
        public int Id { get; set; }
        public string Name { get; set; }
        public bool IsSelected
        {
            get => _isSelected;
            set => SetAndRaisePropertyChanged(ref _isSelected, value);
        }
    }
}
