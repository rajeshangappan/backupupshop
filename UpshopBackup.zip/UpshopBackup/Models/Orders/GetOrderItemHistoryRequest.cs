﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2
{
    public class GetOrderItemHistoryRequest
    {
        public int VendorItemId { get; set; }
        public int OrderId { get; set; }
    }
}
