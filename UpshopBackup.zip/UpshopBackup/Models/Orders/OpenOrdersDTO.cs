﻿using MobileUI2.Constants;
using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Maui.Controls.Compatibility;
using Microsoft.Maui.Controls;
using Microsoft.Maui;

namespace MobileUI2.Models.Orders
{
    public class OpenOrdersDTO
    {
      public List<OpenOrders> Orders=new List<OpenOrders>();
    }

    public class OpenOrders : NotifyPropertyChanged
    {
        private Color _statusColor;
        private Color _statusBackGroundColor;
        public int OrderId { get; set; }
        public int DepartmentNumber { get; set; }
        public string SupplierDisplay { get; set; }
        public string SupplierName { get; set; }
        public DateTime DeliveryDateStore { get; set; }
        public DateTime? NextDeliveryDate { get; set; }
        public DateTime? SubmissionDateStore { get; set; }
        public TimeSpan DueTime { get; set; }
        public string DueTimeDisplay { get; set; }
        public int Status { get; set; }
        public string StatusDisplay { get; set; }
        public string DeliveryDateStoreDisplay { get; set; }
        public string SubmissionDateStoreDisplay { get; set; }
        public bool IsTodayOrder { get; set; }
        public bool IsPastDue { get; set; } 
        public string PastDueTextDisplay { get; set; } 
        public bool IsVisibleSubmissionDateTime { get; set; }
        public string DepartmentDisplay { get; set; }
        public string DeliveryDayDisplay { get; set; }
        public string SubmittedBy { get; set; }
        public DateTime DeliveryDate { get; set; }
        public Color StatuColor
        {
            get => _statusColor;
            set => SetAndRaisePropertyChanged(ref _statusColor, value);
        }
        public Color StatuBackGroundColor
        {
            get => _statusBackGroundColor;
            set => SetAndRaisePropertyChanged(ref _statusBackGroundColor, value);
        }
    }
}
