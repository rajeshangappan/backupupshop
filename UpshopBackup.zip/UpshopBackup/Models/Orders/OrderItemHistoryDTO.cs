﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models.Orders
{
    public class OrderItemHistoryDTO
    {
        public string VendorItemDescription { get; set; }
        public DateTime? OrderDate { get; set; }
        public double? QuantityOrdered { get; set; }
        public double? PackSizeOrdered { get; set; }
        public double? QuantityReceived { get; set; }
        public DateTime? DateReceived { get; set; }
        public string OrderDateDisplay { get; set; }
        public string ReceivedDateDisplay { get; set; }
        public string Uom { get; set; }
        public double? UnitsReceived { get; set; } 
    }
}
