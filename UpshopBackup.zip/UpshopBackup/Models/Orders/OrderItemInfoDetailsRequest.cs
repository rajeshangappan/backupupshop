﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models
{
    public class OrderItemInfoDetailsRequest
    {
        public int OrderId { get; set; }
        public int DepartmentNumber { get; set; }
        public int? VendorItemId { get; set; }
    }
}
