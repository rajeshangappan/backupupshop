﻿using MobileUI2.Constants;
using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models.Orders
{
    public class OpenOrderRequest
    {
        public OpenOrdersType OrdersType { get; set; }
    }
}
