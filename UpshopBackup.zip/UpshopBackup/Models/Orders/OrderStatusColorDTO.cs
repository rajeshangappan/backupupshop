﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Text;
using Color = Microsoft.Maui.Graphics.Color;


namespace MobileUI2.Models.Orders
{
    public class OrderStatusColorDTO
    {
        public  Color StatusColor;
        public  Color StatusBackGroundColor;
    }
}
