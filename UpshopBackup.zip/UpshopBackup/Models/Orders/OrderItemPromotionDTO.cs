﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models
{
    public class OrderItemPromotionDTO
    {
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public string PromotionDescription { get; set; }
        public double? RetailPrice { get; set; }
        public double? CaseSold { get; set; }
        public double? UnitsSold { get; set; }
        public string PromotionDateDisplay { get; set; }
        public string Uom { get; set; }
        public string RetailPriceDisplay { get; set; }
        public int NumberOfDays { get; set; }
        public int PromoType { get; set; }
        public string DisplayType { get; set; }
        public string ReductionPricePercentage { get; set; }
        public string ReductionPricePercentageDisplay { get; set; }
        public bool IsEvenRow { get; set; }
        public string DisplayTypeDisplay { get; set; }
        public string PromoTypeDescription { get; set; }
    }
}
