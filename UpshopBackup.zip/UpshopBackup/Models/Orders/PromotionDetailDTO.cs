﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models
{
    public class PromotionDetailDTO
    {
        public string PromotionCode { get; set; }
        public string PromotionType { get; set; }
        public string DisplayType { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public double? Price { get; set; }
        public string ReductionPricePercentage { get; set; }
        public string StartDateDisplay { get; set; }
        public string EndDateDisplay { get; set; }
        public string DisplayTypeDisplay { get; set; }
        public string ReductionPricePercentageDisplay { get; set; }
    }
}
