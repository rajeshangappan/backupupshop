﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models
{
    public class OrderItemMovementHistoryDTO
    {
        public string Day { get; set; }
        public string Date { get; set; }
        public string MovementDate { get; set; }
        public double? Cases { get; set; }
        public double? Units { get; set; }
        public bool IsEvenRow { get; set; }
    }
}
