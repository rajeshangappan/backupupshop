﻿using System;
using System.Collections.Generic;
using System.Text;
using MobileUI2.Components.ItemTagsComponent;

namespace MobileUI2.Models.Orders
{
    public class ItemTagsResponse
    {
        public List<int> TopLevelTags { get; set; }
        public List<ItemTags> Tags { get; set; }
    }
}
