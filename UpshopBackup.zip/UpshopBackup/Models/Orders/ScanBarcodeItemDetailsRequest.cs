﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models.Orders
{
    public class ScanBarcodeItemDetailsRequest
    {
        public int OrderId { get; set; }
        public int DepartmentId { get; set; }
        public string BarcodeNumber { get; set; }
    }
}
