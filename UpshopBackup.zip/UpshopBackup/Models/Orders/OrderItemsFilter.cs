﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace MobileUI2.Models
{
    public class OrderItemsFilter: NotifyPropertyChanged
    {
        private bool _adjustedProductsToggledSelected;
        private bool _checkCaseSizeSelected;
        private bool _isSelected;

        public int FilterSelectionID { get; set; }
        public string FilterName { get; set; }

        public bool AdjustedProductsToggledSelected
        {
            get => _adjustedProductsToggledSelected;
            set => SetAndRaisePropertyChanged(ref _adjustedProductsToggledSelected, value);
        }
        public bool CheckCaseSizeSelected
        {
            get => _checkCaseSizeSelected;
            set => SetAndRaisePropertyChanged(ref _checkCaseSizeSelected, value);
        }
        public bool IsSelected
        {
            get => _isSelected;
            set
            {
                SetAndRaisePropertyChanged(ref _isSelected, value);
                OnPropertyChanged(nameof(IsSelectedIcon));
            }
        }
        public string IsSelectedIcon => IsSelected ? "SelectedIcon.svg" : string.Empty;
    }
}
