﻿

using System.Collections.Generic;

namespace MobileUI2.Models.Orders
{
    public class OrderItemDetailsDTO : NotifyPropertyChanged
    {
        public int DepartmentId { get; set; }
        public int DepartmentNumber { get; set; }
        public int VendorItemId { get; set; }
        public string VendorItemNumber { get; set; }
        public string VendorItemDisplay { get; set; }
        public double? Pack { get; set; }
        public double? Cost { get; set; }
        public double Forecast { get; set; }
        public double? ForecastUnit { get; set; }
        public double? OnHandQuantityAsReceived { get; set; }
        private double? _onHand;
        public double? OnHand
        {
            get => _onHand;
            set => SetAndRaisePropertyChanged(ref _onHand, value);
        }
        public double? PreviousOrder { get; set; }
        public double? OnOrder { get; set; }
        public double Suggested { get; set; }
        public double? OrderQuantityAsReceived { get; set; }
        private double? _orderQuantity;
        public double? OrderQuantity
        {
            get => _orderQuantity;
            set => SetAndRaisePropertyChanged(ref _orderQuantity, value);
        }
        public string Uom { get; set; }
        public int OrderId { get; set; }
        public int? ItemId { get; set; }
        public long? ItemNumber { get; set; }
        public string ItemDescription { get; set; }
        public bool OnPromotion { get; set; }
        public string SKU { get; set; }
        private double? _adjustment = 0;
        private string _adjustmentDisplay;
        public int ItemTagId { get; set; }
        public string AjdustmentDisplay
        {
            get => _adjustmentDisplay;
            set => SetAndRaisePropertyChanged(ref _adjustmentDisplay, value);
        }
        public double? Adjustment
        {
            get => _adjustment;
            set => SetAndRaisePropertyChanged(ref _adjustment, value);
        }
        private string _adjustmentIcon;
        public string AdjustmentIcon
        {
            get => _adjustmentIcon;
            set => SetAndRaisePropertyChanged(ref _adjustmentIcon, value);
        }
        private Color _adjustmentColor;
        public Color AdjustmentColor
        {
            get => _adjustmentColor;
            set => SetAndRaisePropertyChanged(ref _adjustmentColor, value);
        }
        private bool _isOnHandOperatorsEnabled = true;
        public bool IsOnHandOperatorsEnabled
        {
            get => _isOnHandOperatorsEnabled;
            set => SetAndRaisePropertyChanged(ref _isOnHandOperatorsEnabled, value);
        }
        private Color _itemBackgroundColor;
        public Color ItemBackgroundColor
        {
            get => _itemBackgroundColor;
            set => SetAndRaisePropertyChanged(ref _itemBackgroundColor, value);
        }
        private bool _isHighlighted;
        public bool IsHighlighted
        {
            get => _isHighlighted;
            set => SetAndRaisePropertyChanged(ref _isHighlighted, value);
        }
        public string BarcodeDisplayName { get; set; }
        public string BarcodeNumber { get; set; }
        public List<string> BarCodes { get; set; }
        public bool IsFrequentlyAdjusted { get; set; }
        public bool CanEditOrderQuantity { get; set; }
    }
}
