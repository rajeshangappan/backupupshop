﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models
{
     public class ItemMovementForecastDTO
    {
        public string Day { get; set; }
        public string Date { get; set; }
        public string FullDate { get; set; }
        public double? MovementCases { get; set; }
        public double? MovementUnits { get; set; }
        public bool IsEvenRow { get; set; }
    }
}
