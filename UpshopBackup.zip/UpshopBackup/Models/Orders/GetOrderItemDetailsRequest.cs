﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models
{
    public class GetOrderItemDetailsRequest
    {
        public int OrderId { get; set; }
        public int DepartmentNumber { get; set; }
    }
}
