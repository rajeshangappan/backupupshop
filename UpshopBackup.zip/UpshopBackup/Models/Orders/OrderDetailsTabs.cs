﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models.Orders
{
    public enum OrderDetailsTabs
    {
        General = 0,
        PromotionDetails = 1,
        PromotionHistory = 2,
        HistoricalDailyMovement = 3,
        ForecastedDailyMovement = 4
    }
}
