﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models
{
    public class ItemBarcodeRequest
    {
        public string BarcodeNumber { get; set; }
        public int? ItemId { get; set; }
    }
}
