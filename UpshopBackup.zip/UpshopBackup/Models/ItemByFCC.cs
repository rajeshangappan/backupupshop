﻿using MobileUI2.Constants;
using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models
{
    public class ItemByFCC
    {
        public string FCC { get; set; }
        public IList<ItemCollection> Items { get; set; } = new List<ItemCollection>();
    }
    public class ItemCollection
    {
        public long? ItemNumber { get; set; }
        public string ItemDescription { get; set; }
        public int? ItemId { get; set; }
        public int? DepartmentId { get; set; }
        public bool IsDeleted { get; set; }
        public string Text { get; set; }
        public string UoM { get; set; }
        public int? OrgUnitId { get; set; }
        public InventoryType InventoryType { get; set; }
        public bool TrackLabeledInventory { get; set; }
        public bool TrackUnlabeledInventory { get; set; }
        public bool TrackUnsaleableUnlabeledInventory { get; set; }
        public bool TrackBackroomInventory { get; set; }
        public bool Weighted { get; set; }        
        public string ItemNumerDescription
        {
            get
            {
                return $"{ItemNumber} {ItemDescription}";
            }
        }
    }
}
