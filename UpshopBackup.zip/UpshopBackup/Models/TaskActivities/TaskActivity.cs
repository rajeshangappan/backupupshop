﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models.TaskActivities
{
    public class TaskActivity
    {
        public int TaskActivityId { get; set; }
        public int TaskActivityScheduleId { get; set; }
        public string Name { get; set; }
        public int? DepartmentId { get; set; }
        public int RecurrenceId { get; set; }
        public List<int> Roles { get; set; }
        public int StoreId { get; set; }
        public int? OrgUnitNumber { get; set; }
        public string StoreName { get; set; }
        public bool RequireSignOff { get; set; }
        public string CompletedBy { get; set; }
        public DateTime StartDateTime { get; set; }
        public DateTime? ExpectedCompleteDateTime { get; set; }
        public int? Duration { get; set; }
        public DateTime? CompletedDateTime { get; set; }
        public int? TasksPossible { get; set; }
        public int? TasksCompleted { get; set; }
        public int? TasksCompletedWithYes { get; set; }
        public DateTime? TaskStartedDateTime { get; set; }
    }
}
