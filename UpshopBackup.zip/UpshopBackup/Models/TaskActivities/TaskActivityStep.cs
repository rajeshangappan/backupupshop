﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using Microsoft.Maui.Controls.Compatibility;
using Microsoft.Maui.Controls;
using Microsoft.Maui;

namespace MobileUI2.Models.TaskActivities
{
    public class TaskActivityStep : NotifyPropertyChanged
    {
        private bool _isSelected;
        private Color _textColor = Color.FromArgb("#067386");
        public int TaskActivityStepId { get; set; }
        public int TaskActivityId { get; set; }
        public int StoreId { get; set; }
        public int TaskStepId { get; set; }
        public string Question { get; set; }
        public string TaskName { get; set; }
        public string TaskNameLbl => string.IsNullOrWhiteSpace(TaskName) ? Question : TaskName;
        public int CategoryId { get; set; }
        public ResponseTypeEnum ResponseTypeId { get; set; }
        public List<string> ResponseTypeValue { get; set; } = new List<string>();
        public List<string> UserResponse { get; set; } = new List<string>();
        public int? TaskLaborProcessId { get; set; }
        public int? Duration { get; set; }
        public bool IsDurationVisible { get => Duration.HasValue; }
        [IgnoreDataMember]
        public bool IsSelected
        {
            get => _isSelected;
            set
            {
                _isSelected = value;
                if (IsSelected)
                {
                    TextColor = Color.FromArgb("#FF7800");
                }
                else TextColor = Color.FromArgb("#067386");
            }
        }
        [IgnoreDataMember]
        public Color TextColor
        {
            get => _textColor;
            set => SetAndRaisePropertyChanged(ref _textColor, value);
        }
        public string LblDuration
        {
            get
            {
                if (Duration.HasValue)
                {
                    var mints = Duration.Value;
                    int hours = (mints - mints % 60) / 60;
                    int min = mints - hours * 60;
                    string hour = hours > 0 ? $"{hours}h" : "";
                    string mint = min > 0 ? $"{min}m" : "";
                    return $"{hour}{mint}";
                }
                return string.Empty;
            }
        }
        public int Priority { get; set; }
        public TaskStepStatus Status { get; set; }
        public bool? ExampleMedia { get; set; }
        public bool IsMediaDisplay
        {
            get
            {
                return ExampleMedia ?? false;
            }
        }
        public List<TaskStepMedia> Media { get; set; } = new List<TaskStepMedia>();
    }
    public enum TaskStepStatus
    {
        Created,
        InProgress,
        Completed,
        Failed
    }
    public enum ResponseTypeEnum
    {
        YesNo = 1,
        Scale = 2,
        Checkmark = 3,
        Dropdown = 4,
        Picture = 5,
        NumericResponse = 6,
        SingleLineResponse = 7,
        ParagraphResponse = 8,
    }

}