﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models.TaskActivities
{
    public class StartTaskActivityRequest
    {
        public int TaskActivityId { get; set; }
        public int TaskActivityStepId { get; set; }
    }
}
