﻿using System;
using System.Collections.Generic;

namespace MobileUI2.Models.TaskActivities
{
    public class SaveTaskResponseRequest
    {
        public int TaskActivityId { get; set; }
        public int TaskActivityStepId { get; set; }
        public decimal EnteredTemperature { get; set; }
        public bool TaskCompletedWithYes { get; set; }
        public DateTime? TaskStartDateTimeUTC { get; set; }
        public DateTime? TaskStepStartDateTimeUTC { get; set; }
        public List<string> UserResponse { get; set; } = new List<string>();
        public EntryTypeEnum EntryType { get; set; }
    }

    public enum EntryTypeEnum
    {
        ManualEntry,
        TemperatureProbe
    }
}
