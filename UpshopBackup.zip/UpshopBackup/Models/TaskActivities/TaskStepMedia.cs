﻿

using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Maui.Controls.Compatibility;
using Microsoft.Maui.Controls;
using Microsoft.Maui;

namespace MobileUI2.Models.TaskActivities
{
    public class TaskStepMedia : NotifyPropertyChanged
    {
        public int TaskStepMediaId { get; set; }
        public string FileName { get; set; }
        public string FilePath { get; set; }

        public string MediaType { get; set; }
        public string icon { get; set; }
        public bool IsImage
        {
            get
            {
                return MediaType == "Image";
            }
        }
        public string VideoPath
        {
            get
            {
                return IsImage ? "" : FilePath;
            }
        }

        public string ImagePath
        {
            get
            {
                return IsImage ? FilePath : "notfound.jpg";
            }
        }
        bool _isDisplayVideo;
        public bool IsDisplayVideo
        {
            get => _isDisplayVideo;
            set => SetAndRaisePropertyChanged(ref _isDisplayVideo, value);
        }
    }
}