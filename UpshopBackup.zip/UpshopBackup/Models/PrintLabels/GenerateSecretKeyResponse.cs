﻿using System;
namespace MobileUI2.Models.PrintLabels
{
    public class GenerateSecretKeyResponse
    {
        public bool IsKeyLabelValid { get; set; }
        public string LabelSecretKey { get; set; }
        public string ApprovedLabelSize { get; set; }
        public bool IsSuccess { get; set; }
        public int StatusCode { get; set; }
        public string HttpStatus { get; set; }
        public string Message { get; set; }
        public string ErrorMessage { get; set; }
    }
}

