﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.Text;
using Microsoft.Maui.Controls.Compatibility;
using Microsoft.Maui.Controls;
using Microsoft.Maui;

namespace MobileUI2.Models
{
    public class PLUItemGroupCollections
    {
        public List<CategoryDTO> Categories { get; set; }
        public List<ItemsById> Items { get; set; }
    }

    public class ItemsById : BindableObject
    {
        public int PluNumber { get; set; }
        public long? ItemNumber { get; set; }
        public int ItemId { get; set; }
        public string PluDescription { get; set; }
        public string ImageUrl { get; set; }
        public decimal RetailPrice { get; set; }
        public string PriceString { get; set; }
        public string Currency { get; set; }
        public int? OrgUnitId { get; set; }
        public int DepartmentId { get; set; }
        public int ItemOrderGroupId { get; set; }
        public int? ItemTagId { get; set; }
        public int? RecipeID { get; set; }
        public int? ItemProductionBatchId { get; set; }
        public bool IsPrepItem { get; set; }
        public string DisplayDescription
        {
            get => PluDescription.Split(separator: new char[] {'-'}, count: 2)[1];
        }
        public string DisplayText
        {
            get => $"{PluNumber} {PluDescription.Split(separator:new char[] {'-'}, count:2)[1]}";

        }
        int _labelNumber = 1;
        public int LabelNumber
        {
            get => _labelNumber;
            set { _labelNumber = value; OnPropertyChanged(); }
        }
        public bool ShowCore
        {
            get => ItemTagId == 1 ? true : false;
        }
    }

    public class ItemGroup: List<ItemsById>
    {
        public string Name { get; private set; }
        [IgnoreDataMember]
        public Style StyleAttribute { get; private set; }
        public ItemGroup(string name, List<ItemsById> items) : base(items)
        {
            Name = name;
            if(Name == "\uf005")
                StyleAttribute = Application.Current != null ? (Style)Application.Current.Resources["FontAwesomeSolidStyle"] : null;
            else
                StyleAttribute = Application.Current != null ? (Style)Application.Current.Resources["LabelBoldStyle"] : null;
        }
    }
}
