﻿using System;
using Microsoft.Maui.Devices;
using Microsoft.Maui.ApplicationModel;

namespace MobileUI2.Models.PrintLabels
{
	public class GenerateSecretKeyRequest
	{
        public int PrinterId { get; set; }
        public string UserName { get; set; }
        public string KeyLabel { get; set; }
        public string AppVersion { get; set; } = AppInfo.VersionString;
        public string AppPackage { get; set; } = AppInfo.PackageName;
        public string DeviceId { get; set; }
        public string OSType { get; set; } = DeviceInfo.Platform.ToString();
        public string DataToPrint { get; set; }
        public string FirmwareVersion { get; set; }
        public string BluetoothVersion { get; set; }
    }
}

