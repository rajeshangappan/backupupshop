﻿using System;
namespace MobileUI2.Models.PrintLabels
{
	public class PrintLabelRequest
	{
		public string DataToPrint { get; set; }
		public string SecretKey { get; set; }
		public string ApprovedLabelSize { get; set; }
	}
}

