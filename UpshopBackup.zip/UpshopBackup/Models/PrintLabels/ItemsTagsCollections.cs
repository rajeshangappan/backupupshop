﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.Text;
using Microsoft.Maui.Controls.Compatibility;
using Microsoft.Maui.Controls;
using Microsoft.Maui;

namespace MobileUI2.Models
{
    public class ItemsTagsCollections
    {
        public List<int> TopLevelTags { get; set; }
        public List<ItemTagDTO> Tags { get; set; }
        public List<ItemsById> Items { get; set; }
    }

}
