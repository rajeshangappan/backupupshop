﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models
{
    public class LabelPrintPLURequest
    {
        public int DepartmentId { get; set; }
        public int PluNumber { get; set; }
    }
}
