﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models.PrintLabels
{
    public class PLUDetailsResponse
    {
        public string FCC { get; set; }
        public IList<PluDetails> Items { get; set; } = new List<PluDetails>();
    }
    public class PluDetails
    {
        public int PluNumber { get; set; }
        public long? ItemNumber { get; set; }
        public string Pludescription { get; set; }
        public int? OrgUnitId { get; set; }
        public int DepartmentId { get; set; }
        public int? GroupId { get; set; }

        public string DisplayText
        {
            get => $"{PluNumber} {Pludescription.Split('-')[1]}";
        }
    }
}
