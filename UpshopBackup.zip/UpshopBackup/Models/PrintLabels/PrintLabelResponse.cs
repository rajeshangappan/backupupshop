﻿using System;
namespace MobileUI2.Models.PrintLabels
{
	public class PrintLabelResponse
	{
		public bool IsSuccess { get; set; }
		public string Message { get; set; }
	}
}

