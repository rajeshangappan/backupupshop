﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models
{
    public class OrgUnitResponse
    {
        public int OrgUnitId { get; set; }
        public int OrgUnitNumber { get; set; }
        public string OrgUnitName { get; set; }
        public bool IsActive { get; set; }
        public string OrgUnitType { get; set; }
    }
}
