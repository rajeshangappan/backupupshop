﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models
{
    public class DepartmentDTO
    {
        public int DepartmentId { get; set; }
        public int DepartmentNumber { get; set; }
        public string DepartmentName { get; set; }
        public string DepartmentDisplay { get; set; }
        public bool PromptForEventOnPluSave { get; set; }
    }
}
