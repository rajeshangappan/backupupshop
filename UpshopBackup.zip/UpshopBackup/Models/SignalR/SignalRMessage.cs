﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.SignalR
{
    public class SignalRMessage
    {
        public string TenantCode { get; set; }
        public string UserSignon { get; set; }
        public string TypeName { get; set; }
        public int ItemId { get; set; }
        public string Operation { get; set; }
        public DateTime UTCTime { get; set; }
        public object Data { get; set; }
        public List<MessageDelta> Deltas { get; set; }
    }

    public class MessageDelta
    {
        public string Prop { get; set; }
        public string Old { get; set; }
        public string New { get; set; }
    }
}
