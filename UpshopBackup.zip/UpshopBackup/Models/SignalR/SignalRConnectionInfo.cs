﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.SignalR
{
    public class SignalRConnectionInfo
    {
        public string url;

        public string accessToken;
    }
}
