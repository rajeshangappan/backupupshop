﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.SignalR
{
    class SignalRGroupRequest
    {
        public string UserId;
        public string GroupName;
    }
}
