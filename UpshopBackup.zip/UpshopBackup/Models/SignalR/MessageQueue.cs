﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.SignalR
{
    public class MessageQueue
    {
        public string type;
        public List<object> messages;
    }
}
