﻿using MobileUI2.Constants;

namespace MobileUI2.Models
{
    public class CountTypeModel
    {
        public CountType CountType {get;set;}
        public string DisplayName { get; set; }
    }
}