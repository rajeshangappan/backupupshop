﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models
{
    public class UpdateProdcutionOrderRequest
    {
        public int ProductionOrderId { get; set; }
        public List<OrderItem> Items { get; set; } = new List<OrderItem>();
    }
    public class OrderItem
    {
        public int ItemId { get; set; }
        public double ModifiedQuantity { get; set; }
    }
}
