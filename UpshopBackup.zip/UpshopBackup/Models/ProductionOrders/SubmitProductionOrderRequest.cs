﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models
{
    public class SubmitProductionOrderRequest
    {
        public int ProductionOrderId { get; set; }
    }
}
