﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models
{
   public class ProductionOrdersDTO
    {    
        public int ProductionOrderId { get; set; }
        public int ProducingPlanId { get; set; }
        public int? ProducingScheduleId { get; set; }
        public DateTime ProducingReadyBy { get; set; }
        public string ProducingDescription { get; set; }
        public int ProducingProductionAreaId { get; set; }
        public string ProducingProductionAreaName { get; set; }
        public string ProducingProductionAreaLabel { get; set; }
        public int ProducingStoreId { get; set; }
        public int ProducingStoreNumber { get; set; }
        public string ProducingStoreLabel { get; set; }
        public int ReceivingPlanId { get; set; }
        public int? ReceivingScheduleId { get; set; }
        public DateTime ReceivingReadyBy { get; set; }
        public string ReceivingDescription { get; set; }
        public int ReceivingProductionAreaId { get; set; }
        public string ReceivingProductionAreaName { get; set; }
        public string ReceivingProductionAreaLabel { get; set; }
        public int ReceivingStoreId { get; set; }
        public int ReceivingStoreNumber { get; set; }
        public string ReceivingStoreLabel { get; set; }
        public DateTime SubmitBy { get; set; }
        public int DepartmentId { get; set; }
        public ProductionOrderStatus Status { get; set; }        
        public string DepartmentName { get; set; }
        public string OrderTime { get; set; }
        public List<ProductionOrderItem> Items { get; set; }      
        public List<ItemOrderGroupResponse> Groups { get; set; } = new List<ItemOrderGroupResponse>();
    }   
    public class ProductionOrderItem :NotifyPropertyChanged
    {
        double _modifiedQuantityDisplay;
        public int ItemId { get; set; }
        public long? ItemNumber { get; set; }
        public string ItemLabel { get; set; }
        public int? DepartmentId { get; set; }
        public string DeptLabel { get; set; }
        public string UnitOfMeasure { get; set; }
        public double? ForecastQuantity { get; set; }
        public double? ModifiedQuantity { get; set; }       
        public int GroupId { get; set; }
        public double TempModifiedQty { get; set; }
        public string DisplaySuggestedQty { get; set; }
        public bool IsSubmitedOrder { get; set; }
        public double ModifiedQuantityDisplay
        {
            get => _modifiedQuantityDisplay;
            set
            {
                SetAndRaisePropertyChanged(ref _modifiedQuantityDisplay, value);

            }
        }
    }
    public enum ProductionOrderStatus
    {
        Created = 1,
        Submitted = 2
    }
}
