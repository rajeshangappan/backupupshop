﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2
{
    public class UpdatePrepStepQtyRequest
    {
        public double Quantity { get; set; }
        public int ProductionPlanPrepStepId { get; set; }
    }
}
