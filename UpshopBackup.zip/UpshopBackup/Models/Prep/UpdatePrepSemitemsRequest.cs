﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2
{
    public class UpdatePrepSemitemsRequest
    {
        public double Quantity { get; set; }
        public int ProductionPlanPrepStepId { get; set; }
        public int ItemProductionProcessId { get; set; }
        public int ItemId { get; set; }
        public int PlanId { get; set; }
        public int OrgUnitId { get; set; }
    }
}
