﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models
{
    public class PrepStepsWithItemTags
    {
        public IEnumerable<PrepStepsByItemTag> PrepSteps { get; set; } = new List<PrepStepsByItemTag>();
        public IEnumerable<int> TopLevelTags { get; set; } = new List<int>();
        public IEnumerable<ItemTagData> Tags { get; set; } = new List<ItemTagData>();
        public List<FilterDTO> Filters { get; set; } = new List<FilterDTO>();
    }
    public class PrepStepsByItemTag : NotifyPropertyChanged
    {
        public IEnumerable<ProductionPlanPrepStep> Steps { get; set; } = new List<ProductionPlanPrepStep>();
        ProductionPlanPrepStep _currentStep = new ProductionPlanPrepStep();
        public ProductionPlanPrepStep CurrentStep
        {
            get => _currentStep;
            set => SetAndRaisePropertyChanged(ref _currentStep, value);
        }

    }
    public class ItemTagData : FilterDTO
    {
        public int ItemTagId { get; set; }
        public string ItemTagName { get; set; }
    }
}
