﻿using MobileUI2.Constants;
using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models
{
    public class RetailPriceDTO
    {
        //public bool IsDeleted { get; set; }
        //public int RetailPriceId { get; set; }
        //public int BarcodeId { get; set; }
        public int? PLUId { get; set; }
        //public int OrgUnitId { get; set; }
        //public int DepartmentId { get; set; }
        //public int? StoreGroupId { get; set; }
        //public string OrgUnitDisplay { get; set; }
        //public string OrgUnitStoreGroupDisplay { get; set; }
        public int CustomerQualificationId { get; set; }
        //public int PriceTypeId { get; set; }
        //public RetailPriceIn PriceInId { get; set; }
        public double PriceValue { get; set; }
        //public double RetailValue { get; set; }
        //public string RetailValueDisplay { get; set; }
        //public DateTime EffectiveDate { get; set; }
        //public DateTime? ExpirationDate { get; set; }
        //public List<int> AncestryOrganizations { get; set; }
        //public bool ReadOnly { get; set; }
    }
}
