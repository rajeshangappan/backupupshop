﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models
{
    public class RetailPricesByBarcodeRequest
    {
        public List<int> BarcodeIds { get; set; }
        public int OrgUnitId { get; set; }
        public DateTime AsOfDate { get; set; }
    }
}
