﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models.Login
{
    public class Token
    {
        public string jwt { get; set; }
        public string ipAddress { get; set; }
        public string rt { get; set; }
    }
}
