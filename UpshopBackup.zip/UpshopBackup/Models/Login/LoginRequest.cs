﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models.Login
{
    public class LoginRequest
    {
        public string tenantId { get; set; }
        public string UserSignon { get; set; }
        public string Password { get; set; }
        public string IPAddress { get; set; }
        public string DeviceType { get; set; }
        public string MacAddress { get; set; }
        public string DeviceId { get; set; }
        public string DeviceOS { get; set; }
        public double? Latitude { get; set; }
        public double? Longitude { get; set; }
        public double? Altitude { get; set; }
        public string VersionNumber { get; set; }
    }
}
