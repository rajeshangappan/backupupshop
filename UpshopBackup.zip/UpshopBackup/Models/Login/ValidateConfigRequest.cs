﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models.Login
{
    public class ValidateConfigRequest
    {
        public string TenantId { get; set; }
    }
}
