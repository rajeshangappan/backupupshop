﻿using MobileUI2.Models.Waste;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;
using Microsoft.Maui.Controls.Compatibility;
using Microsoft.Maui.Controls;
using Microsoft.Maui;

namespace MobileUI2.Models.Login
{
    public class MobileTenantInfo : BindableObject 
    {
        public bool EnableBiometrics { get; set; }
        public SSODTO SSO { get; set; }
        public bool ShowFinalizedPlans { get; set; }
        public bool EnableRecipeIngredientStateTracking { get; set; }
        public List<BarcodeType> BarcodeTypes { get; set; }
        public bool BarcodeStripCheckDigit { get; set; }
        public bool EnableScandIt { get; set; }
        public string ScandItLicenseKey { get; set; }
        public string ShopperKitScheme { get; set; }
        public bool EnablePrintByGroup { get; set; }
        public CultureInfo TenantCultureInfo { get; set; }
        public bool UseProdWalkMeKeys { get; set; }
        public bool PromptTotalWeightGrind { get; set; }
        public bool EnablePartialLugUsage { get; set; }
        public bool ProductionWorkstationsEnabled { get; set; }
        public bool ForcePriceOnMarkdown { get; set; }
        public bool ItemTags { get; set; }
        public bool ProductionTransfers { get; set; }
        public bool MarkdownReasonCodes { get; set; }
        public int MobilePlanPrint { get; set; }
        public bool AllowPlanModification { get; set; }
        public bool ShowInProgressFeatures { get; set; }
        public bool EnableMobileLogging { get; set; }
        public bool MobilePrepPrint { get; set; }
        public bool ShowWeightedItemsWithAverageItemWeightAsPacks { get; set; }
        public bool ShowPlanItemsAlphabeticallyInMobile { get; set; }
        public bool ImprovedProductionPlanWorkFlow { get; set; }
        public bool AllowPlanRecalculationOnPlanOpening { get; set; }
        public bool IsNewOrderingUX { get; set; }
        public bool PrepStepConsolidation { get; set; }
        public int AddCaseItemMode { get; set; }
        public bool EnableMockDataForAllModules { get; set; } = true;
    }
}
