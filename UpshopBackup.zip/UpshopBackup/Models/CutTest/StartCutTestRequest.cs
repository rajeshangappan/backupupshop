﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models
{
    public class StartCutTestRequest
    {
        public int CutTestId { get; set; }
        public string Ean { get; set; }
        public double? Weight { get; set; }
        public int VendorId { get; set; }
        public int VendorItemId { get; set; }
    }
}
