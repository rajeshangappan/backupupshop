﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models
{
    public class ScanBarcodeForCutTestRequest
    {
        public int CutTestId { get; set; }
        public string Barcode { get; set; }
        public bool ManuallyEnterWeight { get; set; }
        public int PrimalId { get; set; }
    }
}
