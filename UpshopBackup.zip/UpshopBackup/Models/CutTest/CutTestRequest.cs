﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models
{
    public class CutTestRequest
    {
        public int CutTestId { get; set; }
    }
}
