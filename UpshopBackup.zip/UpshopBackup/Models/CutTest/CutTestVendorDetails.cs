﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models
{
    public class CutTestVendorDetails
    {
        public int PrimalId { get; set; }
        public string PrimalDisplay { get; set; }
        public int VendorId { get; set; }
        public string VendorDisplay { get; set; }
    }
}
