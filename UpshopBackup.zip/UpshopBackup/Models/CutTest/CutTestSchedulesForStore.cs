﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;
using System.Threading.Tasks;

namespace MobileUI2.Models
{
    public class CutTestSchedulesForStore
    {
        public int CutTestId { get; set; }
        public DateTime ScheduleDateTime { get; set; }
        public int ItemId { get; set; }
        public string CutTemplateDescription { get; set; }
        public string VendorNumber { get; set; }
        public string VendorName { get; set; }
        public string Item { get; set; }
        public string Primal { get; set; }
        public string Department { get; set; }
        public string Status { get; set; }
        public bool IsPastCutTest { get; set; }
        public DateTime? CutTestStartDateTime { get; set; }
        public bool IsScheduleByItem { get; set; }
        public int LinkedPrimalItemId { get; set; }
        public string LinkedPrimalItemDisplay { get; set; }
        public string Uom { get; set; }
        public int StatusId { get; set; }
        public int PrimalId { get; set; }      
    }
}
