﻿using System;

namespace MobileUI2.Models
{
    public class CutTestReviewDetails 
    {
        public int CutTestId { get; set; }
        public string CutTestDetailId { get; set; }
        public int CutTestDetailListId { get; set; }
        public int PrimalId { get; set; }
        public string PrimalNumber { get; set; }
        public string PrimalDescription { get; set; }
        public int VendorId { get; set; }
        public string VendorNumber { get; set; }
        public string VendorName { get; set; }
        public double ItemNumber { get; set; }
        public string ItemDescription { get; set; }
        public double? Weight { get; set; }
        public double? Retail { get; set; }
        public string Barcode { get; set; }
        public DateTime? SellByDate { get; set; }
        public int? PackCount { get; set; }
        public double? GrossMargin { get; set; }    
        public double? Cost { get; set; }
        public bool IsVisibleUpdate { get; set; }
        public string Uom { get; set; }
        public string BarcodeNumber { get; set; }
        public string WeightDisplay { get; set; }
        public int OrgUnitId { get; set; }      
    }
}
