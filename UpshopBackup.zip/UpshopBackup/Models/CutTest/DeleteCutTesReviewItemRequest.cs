﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models
{
    public class DeleteCutTesReviewItemRequest
    {
        public int CutTestId { get; set; }
        public string CutTestDetailId { get; set; }
        public int CutTestDetailListId { get; set; }
        public string Barcode { get; set; }
    }
}
