﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models
{
    public class CutTestReViewDetailRequest
    {
        public int CutTestId { get; set; }
        public string CutTestDetailId { get; set; }
    }
}
