﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models
{
    public class SSODTO
    {
        public string IdpCert { get; set; }
        public string IdpLoginUrl { get; set; }
        public string IdpLogoutUrl { get; set; }
        public string OrgUnitAttribute { get; set; }
        public string RoleAttribute { get; set; }
        public bool SsoEnabled { get; set; }
        public string Tenant { get; set; }
        public string BaseProxyUrl { get; set; }
        public string SamlMiddleUrl { get; set; }
        public int SSOSetting { get; set; }
    }
}
