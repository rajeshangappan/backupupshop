﻿using MobileUI2.Models.Recipes;
using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models
{
    public class ItemDetailsDTO
    {
        public int DepartmentId { get; set; }
        public int ItemId { get; set; }
        public int OrgUnitId { get; set; }
        public long ItemNumber { get; set; }
        public string ItemDescription { get; set; }
        public DateTime? ItemLastUpdated { get; set; }
        public string ItemLastUpdatedBy { get; set; }
        public ItemRecipeData RecipeData { get; set; }
        public List<NutritionTypeDTO> Nutritions { get; set; } = new List<NutritionTypeDTO>();
        public List<Inventory> Inventories { get; set; } = new List<Inventory>();
    }

    public class Inventory 
    {
        public string Type { get; set; }
        public int InventoryStateId { get; set; }
        public double? Value { get; set; }
        public string UOM { get; set; }
        public double? OnHandQty { get; set; }
        public double? MinCaseQty { get; set; }
    }
}
