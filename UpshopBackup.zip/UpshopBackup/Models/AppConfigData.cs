﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models
{
    public class AppConfigData
    {
#pragma warning disable CA1056 // Uri properties should not be strings
        public string serverProxyUrl { get; set; }
#pragma warning restore CA1056 // Uri properties should not be strings
        public string tenantCode { get; set; }
        public bool? Is2XTenant { get; set; }
    }
}
