﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models
{
    public class CheckSSOUser
    {
        public bool IsSSOUser { get; set; }
    }
}
