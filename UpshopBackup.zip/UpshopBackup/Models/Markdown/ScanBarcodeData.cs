﻿using MobileUI2.Constants;
using MobileUI2.Models.Markdown;
using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Maui.Controls.Compatibility;
using Microsoft.Maui.Controls;
using Microsoft.Maui;

namespace MobileUI2.Models
{
    public class ScanBarcodeData: BindableObject
    {
        public int LabelPrinterId { get; set; }
        public long? ItemNumber { get; set; }
        public int OrgUnitId { get; set; }
        public int DepartmentId { get; set; }
        public int PluNumber { get; set; }
        public DateTime? PackedOn { get; set; }
        public decimal? Price { get; set; }
        private int labelQuantity;
        public int LabelQuantity 
        {
            get => labelQuantity;
            set { labelQuantity = value; OnPropertyChanged(); } 
        }
        public int? LotNumber { get; set; }
        public bool ManualDataChanged { get; set; }
        public short? Modifier { get; set; }
        public double? NetWeight { get; set; }
        public int? LabelFormatNumber { get; set; }
        public int? CouponPlu { get; set; }
        public decimal? MarkdownPrice { get; set; }
        public int MarkdownTypeId { get; set; }
        public int MarkdownRuleID { get; set; }
        public MarkdownTypeEnum? MarkdownType { get; set; }
        public decimal? FromRetailValue { get; set; }
        public decimal? ToRetailValue { get; set; }
        public decimal? PriceReduction { get; set; }
        public int? ItemId { get; set; }
        public string ItemDescription { get; set; }
        public string BarcodeNumber { get; set; }
        public int? ItemType { get; set; }
        public string ItemBarcode { get; set; }
        public bool ForcePriceOnMarkdown { get; set; }
        public double? SubmittedPrice { get; set; }
        public string CurrencySymbol { get; set; }
        public string SubmittedPricelbl { get; set; }
        public string SubmittedPriceText { get => $"{LiteralTranslator.GetValue("SubmittedPrice")} {SubmittedPricelbl}"; }

        public string SubmittedPriceTextForTablet { get => $"{SubmittedPricelbl}"; }
        public int? ReasonCodeId { get; set; }
        public string ReasonCode { get; set; }
        public string ReasonCodeAndPriceReduction { get => $"{ReasonCode} / {PriceReduction}%"; }
        public string ReasonCodeLabel { get => $"{LiteralTranslator.GetValue("ReasonCode")} : {ReasonCode}"; }
        public string PriceReductionLabel { get => $"{LiteralTranslator.GetValue("PriceReduction")} : {PriceReduction}%"; }
        public bool IsMarkdownReasonCodesEnabled { get; set; }
        public List<MarkdownReasonCode> MarkdownReasonCodes { get; set; }
        public string UOM  { get; set; }
    }
}
