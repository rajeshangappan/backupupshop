﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models
{
    public class MarkdownPrinter
    {
        public int PrinterId { get; set; }
        public string PrinterDescription { get; set; }
        public string IpAddress { get; set; }
        public int IpPort { get; set; }
        public int PrintBy { get; set; }
        public string PrinterShortHandDescription
        {
            get { if (PrinterDescription.Length <= 15)
                    return PrinterDescription;
                else
                    return $"{PrinterDescription.Substring(0, 15)}...";
            }
        }
    }
}
