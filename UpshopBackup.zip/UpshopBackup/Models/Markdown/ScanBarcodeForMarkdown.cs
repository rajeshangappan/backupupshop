﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models
{
    public class ScanBarcodeForMarkdown
    {
        public string BarcodeNumber { get; set; }
        public short? MarkdownTypeId { get; set; }
        public short? MarkdownDepartmentId { get; set; }
        public int LabelPrinterId { get; set; }
        public double? Price { get; set; }
    }
}
