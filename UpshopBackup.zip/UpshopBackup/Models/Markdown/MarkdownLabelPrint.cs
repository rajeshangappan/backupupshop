﻿using MobileUI2.Constants;
using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models
{
    public class MarkdownLabelPrint
    {
        public int? LabelPrinterId { get; set; }
        public long MarkdownId { get; set; } //unique id for this data
        public int? MarkdownRuleID { get; set; }
        public int ItemId { get; set; }
        public string ItemDescription { get;set; }
        public long? ItemNumber { get; set; }
        public string BarcodeNumber { get; set; }
        public string ScannedBarcode { get; set; }
        public int StoreId { get; set; }
        public int OrgUnitNumber { get; set; }
        public int? DepartmentId { get; set; }
        public int? PluNumber { get; set; }
        public DateTime MarkdownDateTime { get; set; }
        public DateTime? PackedOn { get; set; }
        public decimal? MarkdownPrice { get; set; }
        public double? OriginalPrice { get; set; }
        public int? LabelFormatNumber { get; set; }
        public int LabelQuantity { get; set; }        
        public MarkdownTypeEnum? MarkdownType { get; set; }
        public decimal? FromRetailValue { get; set; }
        public decimal? ToRetailValue { get; set; }
        public decimal? PriceReduction { get; set; }
        public int? CouponPLU { get; set; }
        public string UserSignon { get; set; }
        public string PartitionKey { get; set; }
        public string RowKey { get; set; }
        public int Quantity { get; set; }
        public int? MarkdownReasonCodeId { get; set; }
        public string MarkdownReasonCode { get; set; }
    }
}
