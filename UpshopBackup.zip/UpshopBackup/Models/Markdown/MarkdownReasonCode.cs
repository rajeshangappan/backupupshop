﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models.Markdown
{
    public class MarkdownReasonCode
    {
        public int? MarkdownRuleId { get; set; }
        public int ReasonCodeId { get; set; }
        public string ReasonCode { get; set; }
        public double? PriceReduction { get; set; }
    }
}
