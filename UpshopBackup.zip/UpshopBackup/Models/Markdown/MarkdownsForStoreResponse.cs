﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models
{
    public class MarkdownsForStoreResponse
    {
        public long MarkdownId { get; set; }
        public int ItemId { get; set; }
        public string ItemName { get; set; }
        public DateTime MarkdownDateTime { get; set; }
        public decimal? MarkdownPrice { get; set; }
        public double? OriginalPrice { get; set; }
        public int Quantity { get; set; }
        public string QuantityString { get; set; }
        public string PriceComparisonString { get; set; }
    }
}
