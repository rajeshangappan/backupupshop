﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models
{
    public class SSOTokenResult
    {
        public bool Islogged { get; set; }
        public string Message { get; set; }
        public string Name_id { get; set; }
        public string Session_index { get; set; }
        public ResponseResult Response { get; set; }
    }
    public class ResponseResult
    {
        public string jwt { get; set; }
        public string rt { get; set; }
    }
}
