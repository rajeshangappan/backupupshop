﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace MobileUI2.Models
{  
    public class SyncList
    {
        public string ModuleName { get; set; }
        public List<OfflineSyncRequest> UpdateSyncs { get; set; } = new List<OfflineSyncRequest>();
    }
}
