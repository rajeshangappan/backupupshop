﻿using System.Collections.ObjectModel;
using System.ComponentModel;

namespace MobileUI2.Models
{
    public class ItemModel : INotifyPropertyChanged
    {
        public string Title { get; set; }
        public string Description { get; set; }
        private string _quantity;

        public string DefaultCountType { get; set; }
        public string Quantity
        {
            get { return _quantity; }
            set
            {
                if (_quantity != value)
                {
                    _quantity = value;
                    OnPropertyChanged(nameof(Quantity));
                }
            }
        }
        public ObservableCollection<CountTypeModel> CountTypes { get; set; }

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}