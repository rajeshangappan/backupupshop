﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models
{
    public class UserInfo
    {
        public string TenantCode { get; set; }
        public string UserSignon { get; set; }
        public string UserName { get; set; }
        public int? OrgUnit { get; set; }
        public int? OrgUnitNumber { get; set; }
        public string Email { get; set; }
        public string OrgUnitName { get; set; }
        public string LanguageCode { get; set; }
        public bool IsStoreUser { get; set; }
        public string DataWedgeProfile { get; set; }
        public UserType UserType { get; set; }
        public bool IsTestOnly { get; set; }
        public int? StoreTimeZone { get; set; }
        public Dictionary<string, object> Settings { get; set; } = new Dictionary<string, object>();
        public List<UserNavCategory> NavCategories { get; set; } = new List<UserNavCategory>();
        public List<PickListEntry> timeZones { get; set; }
        public List<SoftLiteral> SoftLiterals { get; set; } = new List<SoftLiteral>();
        public List<LicenseModule> Licenses { get; set; }
        public int TimeZoneValue { get; set; }
        public List<int> RoleId { get; set; }
        public int? UserId { get; set; }
        public bool AllowMultipleLocationsPerUser { get; set; }
        public List<UserMultiOrgUnit> UserOrgUnits { get; set; }
        public int? WorkstationId { get; set; }
        public string TemperatureSymbol { get; set; }
        public string SalesForceAcctId { get; set; }
        public string UserUniqueId { get; set; }

    }
    public class SoftLiteral
    {
        public int Code { get; set; }
        public string Key { get; set; }
        public string Value { get; set; }
    }
    public class UserMultiOrgUnit
    {
        public int? OrgUnitId { get; set; }
        public int? OrgUnitNumber { get; set; }
        public string OrgUnitName { get; set; }
    }
    public enum UserType
    {
        Corporate = 0,
        Intermediate = 1,
        Store = 2
    }
    public class PickListEntry
    {
        public int Value { get; set; }
        public string Label { get; set; }
    }

    public class UserNavCategory : NotifyPropertyChanged
    {
        private string _selectedImageName;
        public string Code { get; set; }
        public string ParentCode { get; set; }
        public string Name { get; set; }
        public List<string> Icon { get; set; }
        public string RouterLink { get; set; }
        public List<UserNavMenuItem> MenuItems { get; set; } = new List<UserNavMenuItem>();
        public string ImageName { get; set; }
        public string TabletImageName { get; set; }
        public string SelectedImageName
        {
            get => _selectedImageName;
            set
            {
                SetAndRaisePropertyChanged(ref _selectedImageName, value);

            }
        }
    }

    public class UserNavMenuItem
    {
        public string MenuName { get; set; }
        public string RouteName { get; set; }
    }
}
