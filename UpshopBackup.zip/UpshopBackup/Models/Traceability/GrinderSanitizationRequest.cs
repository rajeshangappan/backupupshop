﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models.Traceability
{
    public class GrinderSanitizationRequest
    {
        public int EquipmentId { get; set; }
        public int GrindId { get; set; }
        public bool IsEndOfDay { get; set; }
        public int SanitizationType { get; set; }
        public bool IsForced { get; set; }
    }
}
