﻿using MobileUI2.Constants;
using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models.Traceability
{
    public class LeanPointItems : NotifyPropertyChanged
    {
        bool _isChecked;
        public int? LeanPointId { get; set; }
        public long? ItemNumber { get; set; }
        public string Description { get; set; }
        public int ItemId { get; set; }
        public string BarcodeNumber { get; set; }
        public string LblItemDescription { get => $"{ItemNumber} - {Description}"; }
        public bool IsChecked
        {
            get => _isChecked;
            set => SetAndRaisePropertyChanged(ref _isChecked, value);
        }
        public GrinderCleanEnum? Cleaning { get; set; }
        public bool GrindTypeLug { get; set; }
        public bool GrindTypeTube { get; set; }
        public bool GrindTypeCustomerRequest { get; set; }
    }
}
