﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models.Traceability.CustomerRequestGrind
{
    public class SubmitCustomerRequestModel
    {
        public int GrinderId { get; set; }
        public string Barcode { get; set; }
        public DateTime SellByDate { get; set; }
        public double? GrindItemWeight { get; set; }
        public int? ProducingStoreNumber { get; set; }
    }
}
