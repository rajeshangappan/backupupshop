﻿namespace MobileUI2.Models.Traceability.CustomerRequestGrind
{
    public class GrinderInfo
    {
        public int GrinderId { get; set; }
        public string GrinderName { get; set; }
    }
}