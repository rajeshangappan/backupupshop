﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models.Traceability
{
    public class Equipment
    {
        public int EquipmentId { get; set; }
        public int OrgUnitId { get; set; }
        public int EquipmentType { get; set; }
        public string EquipmentName { get; set; }
    }
}