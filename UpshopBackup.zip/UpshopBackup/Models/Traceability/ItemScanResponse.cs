﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models
{
    public class ItemScanResponse
    {
        public VendorItemScanResponse EANDetails { get; set; }
        public TrimCaseItemUPCScanResponse UPCDetails { get; set; }
    }
    public class VendorItemScanResponse
    {
        public int? VendorItemId { get; set; }
        public string VendorItemNum { get; set; }
        public string VendorItemDesc { get; set; }
        public string VendorItemNumDesc { get; set; }
        public string ScannedBarcode { get; set; }
        public string EstablishmentId { get; set; }
        public string EstablishmentLabel { get; set; }
        public string SerialNumber { get; set; }
        public DateTime? ProductionDate { get; set; }
        public decimal? ProductNetWeight { get; set; }
        public bool? ProductionNetWeightKG { get; set; }
        public int? VendorLocationId { get; set; }
        public DateTime? ExpirationDate { get; set; }
        public int? VendorItemRecallId { get; set; }
        public string VendorNum { get; set; }
        public int? VendorId { get; set; }
        public string VendorName { get; set; }
        public string VendorNumDesc { get; set; }
        public bool IsPromptSellByDate { get; set; }
        public int OrgUnitId { get; set; }
        public string EquipmentName { get; set; }
    }
    public class TrimCaseItemUPCScanResponse
    {
        public int OrgUnitId { get; set; }
        public string ScannedBarcode { get; set; }
        public int ItemId { get; set; }
        public long ItemNumber { get; set; }
        public string ItemDescription { get; set; }
        public int PLUId { get; set; }
        public string PLUDescription { get; set; }
        public int? PLUNumber { get; set; }
        public int? DepartmentId { get; set; }
        public bool IsPromptSellByDate { get; set; }
        public double? Price { get; set; }
        public double Weight { get; set; }
    }
}
