﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models
{
    public class SubmitLugForGrindLugRequest
    {
        public DateTime GrindSubmitTime { get; set; }
        public DateTime CleanSubmitTime { get; set; }
        public int GrinderId { get; set; }
        public int? LeanPointId { get; set; }
        public List<int> LeanPointItemIds { get; set; }
        public List<int> TrimIds { get; set; }           
        public bool? IsClean { get; set; }
        public int SanitizationType { get; set; }
        public double GrindWeight { get; set; }
        public bool UseEntireLug { get; set; }

    }
}
