﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models
{
    public class TrimLugDTO
    {
        public int LugId { get; set; } //LugId
        public string LugName { get; set; }
        public string LugLabel { get; set; }
        public int OrgUnitId { get; set; }
        public int OrgUnitNumber { get; set; }
        public string OrgUnitLabel { get; set; }
        public int EquipmentType { get; set; }
        public string TypeDesc { get; set; }
        public int TrimId { get; set; }
        public bool IsEntriedLug { get; set; }
        public bool IsCaseItem { get; set; }
        public bool IsChecked { get; set; }
    }
}
