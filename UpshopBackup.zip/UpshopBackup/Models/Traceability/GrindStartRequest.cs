﻿using MobileUI2.Constants;
using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models.Traceability
{
    public class GrindStartRequest
    {
        public int GrinderId { get; set; }
        public int GrindId { get; set; }
        public int? LeanPointId { get; set; }
        public int LugId { get; set; } 
        public int TrimId { get; set; }
        public string EquipmentName { get; set; }
        public List<int> LeanPointItems { get; set; } = new List<int>();
        public List<int> TrimIds { get; set; } = new List<int>();
        public int VendorLocationId { get; set; }
        public string EstablishmentId { get; set; }
        public GrinderCleanEnum GrinderClean { get; set; }
        public string UOM { get; set; }
    }
}
