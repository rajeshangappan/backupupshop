﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models
{
    public class Trim
    {
        public int TrimId { get; set; }
        public int LugId { get; set; }
        public string LugName { get; set; }
        public int OrgUnitId { get; set; }
        public DateTime? TrimDateTime { get; set; }
        public List<TrimItem> TrimItems { get; set; } = new List<TrimItem>();
    }
    public class TrimItem
    {
        public int TrimItemId { get; set; }
        public int VendorId { get; set; }
        public string VendorNum { get; set; }
        public string VendorName { get; set; }
        public string VendorLabel { get; set; }

        public int VendorLocationId { get; set; }
        public string EstablishmentId { get; set; }
        public string EstablishmentLabel { get; set; }

        public int VendorItemId { get; set; }
        public string VendorItemNum { get; set; }
        public string VendorItemDesc { get; set; }
        public string VendorItemLabel { get; set; }

        public bool IsManualEntry { get; set; }
        public DateTime TransactionDate { get; set; }
        public DateTime ProductionDate { get; set; }
        public string SerialNumber { get; set; }
        public string ScannedBarcode { get; set; }
        public double? Weight { get; set; }
        public DateTime? SellByDate { get; set; }
        public int ItemId { get; set; }
        public long ItemNumber { get; set; }
        public string ItemDescription { get; set; }
    }

}
