﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models
{
    public class GetAllEstablishmentsRequest
    {
        public List<int> VendorIds { get; set; }
    }
}
