﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models
{
    public class VendorItemScanInfo
    {
        #region Public Properties

        public string ScannedBarcode
        {
            get; set;
        }

        public int VendorId { get; set; }
        public string VendorNum { get; set; }

        public string VendorName
        {
            get; set;
        }

        public DateTime? ProductionDate { get; set; }

        public double? ProductionLineNum { get; set; }

        public decimal? ProductNetWeight { get; set; }

        public string InBarcodeEstablishmentID { get; set; }

        public string EstablishmentID
        {
            get; set;
        }

        public string VendorLocationDescription
        {
            get; set;
        }

        public string SSCC { get; set; }

        public DateTime? SellByDate { get; set; }
        public int? VendorItemID { get; set; }
        public DateTime ScanDateTime { get; set; }
        public bool? ProductionNetWeightKG { get; set; }

        public int? VendorLocationID { get; set; }

        public DateTime? ExpirationDate { get; set; }

        public string SerialNumber { get; set; }

        public string VendorItemNum { get; set; }

        public string VendorItemDesc { get; set; }

        public double? RetailPrice { get; set; }

        public string LabelSerialNumber { get; set; }

        public int? GPCAutoID { get; set; }

        public int? VendorItemRecallAutoID { get; set; }

        public string UserSignOn { get; set; }

        public int? OrgUnitNum { get; set; }

        public string OrgUnitName { get; set; }

        public DateTime ScanDateTimeInUserLocale { get; set; }

        public string BatchLotNumber { get; set; }

        #endregion

        #region Derived Public Properties

        public string ProductionDateValue
        {
            get { return ProductionDate.HasValue ? ProductionDate.Value.ToString() : String.Empty; }
        }

        public double ProductionLineNumValue
        {
            get { return ProductionLineNum ?? 0; }
        }

        public string EstablishmentLabel
        {
            get
            {
                if (!String.IsNullOrEmpty(EstablishmentID))
                    return String.Format("{0} - {1}", EstablishmentID, VendorLocationDescription);
                return String.Empty;
            }
        }

        public string VendorLabel
        {
            get
            {
                if (!string.IsNullOrEmpty(VendorNum))
                    return String.Format("{0} - {1}", VendorNum, VendorName);
                return String.Empty;
            }
        }

        public string VendorItemLabel
        {
            get
            {
                if (!string.IsNullOrEmpty(VendorItemNum) && !string.IsNullOrEmpty(VendorItemDesc))
                    return String.Format("{0} - {1}", VendorItemNum, VendorItemDesc);
                else if (!string.IsNullOrEmpty(VendorItemNum))
                    return VendorItemNum;
                else return string.Empty;
            }
        }

        public string OrgUnitLabel
        {
            get
            {
                if (OrgUnitNum.HasValue)
                    return String.Format("{0} - {1}", OrgUnitNum.Value, OrgUnitName);
                else
                    return String.Empty;
            }
        }

        #endregion
    }
}
