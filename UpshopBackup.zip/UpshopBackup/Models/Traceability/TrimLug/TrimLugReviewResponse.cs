﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models
{
    public class TrimLugReviewResponse
    {
        public List<TrimItemResponse> TrimItem { get; set; }
        public List<TrimCaseItemResponse> TrimCaseItem { get; set; }
    }
    public class TrimItemResponse
    {

        public int OrgUnitId { get; set; }
        public int TrimId { get; set; }
        public int TrimItemId { get; set; }
        public int LugId { get; set; }
        public string LugName { get; set; }
        public string LugLabel { get; set; }
        public int VendorId { get; set; }
        public string VendorNum { get; set; }
        public string VendorName { get; set; }
        public string VendorLabel { get; set; }
        public int VendorLocationId { get; set; }
        public string EstablishmentId { get; set; }
        public string EstablishmentLabel { get; set; }
        public int VendorItemId { get; set; }
        public string VendorItemNum { get; set; }
        public string VendorItemDesc { get; set; }
        public string VendorItemLabel { get; set; }

        public bool IsOfflineSubmission { get; set; }
        public bool IsManualEntry { get; set; }
        public DateTime TransactionDate { get; set; }
        public DateTime ProductionDate { get; set; }
        public string SerialNumber { get; set; }
        public string ScannedBarcode { get; set; }
        public double? Weight { get; set; }
        public int TempTrimId { get; set; }
        public string ProductionDateLabel
        {
            get
            {
                return ProductionDate.ToString("MM/dd/yyyy", GlobalSettings.Userlanguagecode);
            }
        }

        public void CopyFrom(TrimItem item, Trim trim)
        {
            if (trim == null || item == null)
                return;
            EstablishmentId = item.EstablishmentId;
            IsManualEntry = item.IsManualEntry; 
            EstablishmentLabel = item.EstablishmentLabel; 
            LugId = trim.LugId; 
            LugName = trim.LugName; 
            OrgUnitId = trim.OrgUnitId; 
            ProductionDate = item.ProductionDate; 
            ScannedBarcode = item.ScannedBarcode; 
            SerialNumber = item.SerialNumber; 
            TransactionDate = item.TransactionDate; 
            TrimId = trim.TrimId; 
            TrimItemId = item.TrimItemId; 
            VendorId = item.VendorId; 
            VendorItemDesc = item.VendorItemDesc; 
            VendorItemId = item.VendorItemId; 
            VendorItemLabel = item.VendorItemLabel; 
            VendorItemNum = item.VendorItemNum; 
            VendorLabel = item.VendorLabel;
            VendorLocationId = item.VendorLocationId; 
            VendorName = item.VendorName; 
            VendorNum = item.VendorNum;
            Weight = item.Weight;
        }
    }
    public class TrimCaseItemResponse
    {
        public int OrgUnitId { get; set; }
        public int TrimId { get; set; }
        public int TrimItemId { get; set; }
        public int LugId { get; set; }
        public string LugName { get; set; }
        public string LugLabel { get; set; }
        public int ItemId { get; set; }
        public long ItemNumber { get; set; }
        public string ItemDescription { get; set; }
        public string ScannedBarcode { get; set; }
        public string ScannedBarcodeLabel { get; set; }
        public DateTime? SellByDate { get; set; }
        public double? Weight { get; set; }
    }
    public class TrimLugReviews
    {
        public  int TrimId { get; set; }
        public List<TrimItemResponse> TrimItem { get; set; } = new List<TrimItemResponse>();
    }
}
