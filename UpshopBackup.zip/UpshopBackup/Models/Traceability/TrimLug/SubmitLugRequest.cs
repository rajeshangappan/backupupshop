﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models
{
    public class SubmitLugRequest
    {
        public string VendorId { get; set; }
        public string VendorNum { get; set; }
        public string VendorName { get; set; }
        public string VendorLabel { get; set; }
        public string EstablishmentId { get; set; }
        public string EstablishmentLabel { get; set; }
        public int VendorLocationId { get; set; }
        public int? VendorItemId { get; set; }
        public string VendorItemDesc { get; set; }
        public string VendorItemNum { get; set; }
        public DateTime TransactionDate { get; set; }
        public bool IsManualEntry { get; set; }
        public DateTime ProductionDate { get; set; }
        public int? TrimId { get; set; }
        public string SerialNumber { get; set; }
        public decimal Weight { get; internal set; }
        public string ScannedBarcode { get; set; }
        public string LugName { get; set; }
        public int LugId { get; set; }
        public int OfflineResponseAutoID { get; set; }
        public bool IsOfflineSubmission { get; set; }
    }
}
