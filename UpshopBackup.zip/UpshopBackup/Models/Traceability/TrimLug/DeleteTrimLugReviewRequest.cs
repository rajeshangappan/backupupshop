﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models
{
    public class DeleteTrimLugReviewRequest
    {
        public int TrimId { get; set; }
        public int TrimItemId { get; set; }
    }
}
