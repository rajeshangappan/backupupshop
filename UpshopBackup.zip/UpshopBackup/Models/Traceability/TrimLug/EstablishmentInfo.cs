﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models
{
    public class EstablishmentInfo
    {
        public string EstablishmentId { get; set; }
        public int VendorLocationId { get; set; }
        public string LocationDescription { get; set; }
        public string EstablishmentLabel { get; set; }
        public int? LengthOfSerialNumber { get; set; }
        public string BarCodeEstablishmentId { get; set; }
    }
}
