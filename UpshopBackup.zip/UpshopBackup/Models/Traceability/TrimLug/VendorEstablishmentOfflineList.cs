﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2
{
    public class VendorEstablishmentOfflineList
    {
        public List<VendorDetails> packersList { get; set; }
        public string uomCode { get; set; }
    }
    public class VendorDetails
    {
        public int? MaxBarCodeLength { get; set; }
        public bool Supplier { get; set; }
        public bool Packer { get; set; }
        public int VendorId { get; set; }
        public string VendorNumber { get; set; }
        public string Name { get; set; }
        public List<VendorLocation> establishmentList { get; set; }
        public List<VendorItemScanDTO> vendorItemList { get; set; }
    }  
}
