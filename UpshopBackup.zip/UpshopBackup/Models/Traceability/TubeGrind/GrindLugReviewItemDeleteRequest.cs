﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models
{
    public class GrindLugReviewItemDeleteRequest
    {
        public int GrindId { get; set; }
        public int GrindItemId { get; set; }
    }
}
