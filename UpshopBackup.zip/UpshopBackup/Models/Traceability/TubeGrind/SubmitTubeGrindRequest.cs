﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models
{
    public class SubmitTubeGrindRequest
    {
        public int VendorId { get; set; }
        public int? VendorItemId { get; set; }
        public int VendorLocationId { get; set; }
        public DateTime? TransactionDate { get; set; }
        public string VendorName { get; set; }
        public string VendorNum { get; set; }
        public string VendorLabel { get; set; }
        public string EstablishmentId { get; set; }
        public string EstabalishmentDesc { get; set; }
        public bool IsManualEntry { get; set; }
        public string VendorItemNum { get; set; }
        public string VendorItemDesc { get; set; }
        public DateTime ProductionDate { get; set; }
        public int GrindId { get; set; }
        public string SerialNumber { get; set; }
        public decimal? Weight { get; set; }
        public int? LeanPointId { get; set; }
        public int GrinderItemId { get; set; }
        public List<int> LeanPointItemIds { get; set; }
        public string Barcode { get; set; }
        public int OfflineResponseAutoID { get; set; }
        public bool IsOfflineSubmission { get; set; }
        public int? EquipmentId { get; set; }
    }

}
