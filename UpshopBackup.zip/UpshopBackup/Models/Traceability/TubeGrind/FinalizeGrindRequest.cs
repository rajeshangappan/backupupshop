﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models
{
    public class FinalizeGrindRequest
    {
        public DateTime GrindSubmitTime { get; set; }
        public DateTime CleanSubmitTime { get; set; }
        public int GrindId { get; set; }
        public int SanitizationType { get; set; }
        public double GrindWeight { get; set; }
    }
}
