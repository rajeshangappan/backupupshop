﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models
{
    public class ItemCleanResponse
    {
        public bool IsCleaningRequired { get; set; }
        public bool IsCleaningOptional { get; set; }
    }
}
