﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models
{
    public class GrindVendorItemResponse
    {
        public int OrgUnitId { get; set; }
        public int GrindId { get; set; }
        public int GrindItemId { get; set; }
        public int LugId { get; set; }
        public string LugName { get; set; }
        public string LugLabel { get; set; }
        public int GrindTypeSourceId { get; set; }
        public string GrindTypeSourceName { get; set; }
        public int? GrindType { get; set; }
        public int VendorId { get; set; }
        public string VendorNum { get; set; }
        public string VendorName { get; set; }
        public string VendorLabel { get; set; }
        public int VendorLocationId { get; set; }
        public string EstablishmentId { get; set; }
        public string EstablishmentLabel { get; set; }
        public int VendorItemId { get; set; }
        public string VendorItemNum { get; set; }
        public string VendorItemDesc { get; set; }
        public string VendorItemLabel { get; set; }
        public bool IsManualEntry { get; set; }
        public DateTime TransactionDate { get; set; }
        public DateTime ProductionDate { get; set; }
        public string SerialNumber { get; set; }
        public string ScannedBarcode { get; set; }
        public double? Weight { get; set; }
        public string GrinderName { get; set; }
        public bool IsCaseItem { get; set; }
        public string GrindCaseItemSellByDateLabel { get; set; }
        public string GrindCaseItemScannedBarcodeLabel { get; set; }
        public string WeightLabel { get; set; }
        public bool IsOfflineSubmission { get; set; }
        public int TempGrindItemId { get; set; }
        public string PackDate
        {
            get
            {
                return ProductionDate.ToString("MM/dd/yyyy", GlobalSettings.Userlanguagecode);
            }
        }
    }
    public class GrindReviewItems
    {
        public int GrindId { get; set; }
        public List<GrindVendorItemResponse> grindVendorItem { get; set; } = new List<GrindVendorItemResponse>();
    }
}
