﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models
{
    public class SubmitGrindResponse
    {
        public int ResponseAutoID { get; set; }
        public string ResponseID { get; set; }
        public int? NullableResponseAutoID { get; set; }
        public string Url { get; set; }
        public bool IsOfflineSubmission { get; set; }
        public int OfflineResponseAutoID { get; set; }
        public int TrimId { get; set; }
        public int GrindId { get; set; }
    }
}
