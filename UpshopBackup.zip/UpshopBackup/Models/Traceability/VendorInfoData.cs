﻿using MobileUI2.ViewModels;
using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2
{
    public class VendorInfoData
    {
        public List<Vendor> packersList { get; set; }
        public string uomCode { get; set; }
    }
    public class Vendor
    {
        public int? MaxBarCodeLength { get; set; }
        public bool Supplier { get; set; }
        public bool Packer { get; set; }
        public int VendorId { get; set; }
        public string VendorNumber { get; set; }
        public string Name { get; set; }
        public List<VendorLocation> establishmentList { get; set; }
        public List<VendorItemScanDTO> vendorItemList { get; set; }
    }
    public class VendorLocation
    {
        public string EstablishmentId { get; set; }
        public string EstablishmentLabel { get; set; }
        public string LocationDescription { get; set; }
        public int VendorLocationId { get; set; }
        public int VendorId { get; set; }
        public int? LengthOfSerialNumber { get; set; }
        public string BarCodeEstablishmentId { get; set; }
        public string Name { get; set; }
        public bool Enabled { get; set; }
    }
    public class VendorItemScanDTO
    {
        public int VendorId { get; set; }
        public int VendorItemId { get; set; }
        public string VendorItemNum { get; set; }
        public string VendorItemDesc { get; set; }
        public string VendorItemLabel { get; set; }
        public bool AllowTubeGrind { get; set; }
        public bool AllowLugGrind { get; set; }
        public bool AllowCaseReadyLog { get; set; }
    }
}
