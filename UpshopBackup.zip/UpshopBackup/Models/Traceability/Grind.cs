﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Data;
using System.Text;

namespace MobileUI2.Models.Traceability
{
    public class Grind
    {
        public int GrindId { get; set; }
        public int? GrindType { get; set; }
        public int EquipmentId { get; set; }
        public double GrindWeight { get; set; }
        public int GrindStatusId { get; set; }
        public int ReasonId { get; set; }
        public DateTime? StartedDateTime { get; set; }
        public DateTime? FinalizedDate { get; set; }
        public string FinalizedByUser { get; set; }
        public DateTime? SanitizedDateTime { get; set; }
        public int SanitizationType { get; set; }
        public bool IsForced { get; set; }
        public string SanitizedByUser { get; set; }
        public int? LeanPointId { get; set; }
        public List<int> LeanPointItems { get; set; }
        public bool SanitizationRequired { get; set; }
        public int OrgUnitId { get; set; }
        public List<GrindVendorItemResponse> GrindItems { get; set; }
    }

}
