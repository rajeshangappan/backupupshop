﻿using MobileUI2.Constants;
using System;
using System.Collections.Generic;

namespace MobileUI2.Models.Traceability
{
    public class StoreGrindersDetails
    {
        public List<GridMenu> MenuDetails { get; set; } = new List<GridMenu>();
        public List<GrinderDetails> GrindDetails { get; set; } = new List<GrinderDetails>();
        public List<Grinder> Grinders = new List<Grinder>();
        public List<Lug> Lugs = new List<Lug>();
        public List<LeanPointData> LeanPoints = new List<LeanPointData>();
        public bool GrindersWithNoEODCleaningPreviousDay { get; set; }
        public string SanitizationMessage { get; set; }
    }

    public class Grinder : NotifyPropertyChanged
    {
        private bool _isChecked;
        public bool IsChecked { get => _isChecked; set => SetAndRaisePropertyChanged(ref _isChecked, value); }
        public int GrinderID { get; set; }
        public string GrinderName { get; set; }
        public int? GrindId { get; set; }
        public int? GrindType { get; set; }
        public bool IsOpen { get; set; }
        public string UOMCode { get;set; }
        public GrinderCleanEnum? GrinderClean { get; set; }
    }

    public class Lug : NotifyPropertyChanged
    {
        private bool _isChecked;
        public bool IsChecked { get => _isChecked; set => SetAndRaisePropertyChanged(ref _isChecked, value); }
        public int LugId { get; set; }
        public string LugName { get; set; }
        public bool IsOpen { get; set; }
        public int? TrimId { get; set; }
    }
    public class LeanPointData : NotifyPropertyChanged
    {
        private bool _isChecked;
        public bool IsChecked { get => _isChecked; set => SetAndRaisePropertyChanged(ref _isChecked, value); }
        public int? LeanPointId { get; set; }
        public string LeanPointDescription { get; set; }
        public bool GrindTypeLug { get; set; }
        public bool GrindTypeTube { get; set; }
        public bool GrindTypeCustomerRequest { get; set; }
        public List<LeanPointItems> LeanPointItems { get; set; } = new List<LeanPointItems>();
    }

    public class GrinderDetails
    {
        public int GroupId { get; set; }
        public string GroupName { get; set; }
        public List<GrinderStatus> GrindDetails { get; set; } = new List<GrinderStatus>();
    }
    public class GridMenu
    {
        public int Id { get; set; }
        public string MenuName { get; set; }
    }
    public class GrinderStatus : NotifyPropertyChanged
    {
        string _grinderName;
        DateTime? _startDateTime;
        string _grindCleanTimeText;
        string _grindType;
        bool _showDateTime;
        bool _showLastCleanedText;
        public int GrinderId { get; set; }
        public int GrindId { get; set; }
        public string GrinderName { get => _grinderName; set => SetAndRaisePropertyChanged(ref _grinderName, value); }
        public string GrindType { get => _grindType; set => SetAndRaisePropertyChanged(ref _grindType, value); }
        public GrinderCleanEnum GrinderClean { get; set; }
        public string Status { get; set; }
        public DateTime? GrindDateTime { get; set; }
        public bool IsClean { get; set; }
        public bool ShowCleanTag { get; set; }
        public bool ShowLastCleanedText { get => _showLastCleanedText; set => SetAndRaisePropertyChanged(ref _showLastCleanedText, value); }
        public string GrindCleanTimeText { get => _grindCleanTimeText; set => SetAndRaisePropertyChanged(ref _grindCleanTimeText, value); }
        public DateTime? StartedDateTime { get => _startDateTime; set => SetAndRaisePropertyChanged(ref _startDateTime, value); }
        public bool ShowDateTime { get => _showDateTime; set => SetAndRaisePropertyChanged(ref _showDateTime, value); }
        public int GrindStatusId { get; set; }
    }
}
