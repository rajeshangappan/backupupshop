﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models
{
    public class ScanBarcodeParamRequest
    {
        public string BarCode { get; set; }
        public bool IsCustomerRequest { get; set; }
        public BarcodeGrindType BarcodeGrindType { get; set; }
        public bool IsDecodeBarcodeEAN { get; set; }
    }
    public enum BarcodeGrindType
    {
        AllowTubeGrind,
        AllowLugGrind,
        AllowCaseReadyLog
    }
}
