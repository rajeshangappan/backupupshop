﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models
{
    public class UpdateInventoriesRequest
    {
        public List<ItemUpdateInventoryRequest> Inventories = new List<ItemUpdateInventoryRequest>();
    }
    public class ItemUpdateInventoryRequest
    {
        public int ItemId { get; set; }
        public int DepartmentId { get; set; }
        public int OrgUnitId { get; set; }
        public int InventoryStateId { get; set; }
        public double OnHandQuantity { get; set; }
    }
}
