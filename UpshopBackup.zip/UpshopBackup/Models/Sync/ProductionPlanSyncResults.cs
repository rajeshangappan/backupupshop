﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models
{
    public class ProductionPlanSyncResults
    {
        public int PlanId { get; set; }
        public int ItemId { get; set; }
        public int OrgUnitId { get; set; }
        public int? DepartmentId { get; set; }
        public string Status { get; set; }
    }
    public class ProductionPlanSyncResultsList
    {
        public int PlanId { get; set; }
        public List<ProductionPlanSyncResults> productionPlanSyncResults { get; set; } = new List<ProductionPlanSyncResults>();
    }
    public class ProcResultStatus
    {
        public int ItemId { get; set; }
        public int DepartmentId { get; set; }
        public int OrgUnitId { get; set; }
        public long ItemNumber { get; set; }
        public string StatusMsg { get; set; }
    }
    public class ProcResultStatusList
    {
        public List<ProcResultStatus> procResultStatuses { get; set; } = new List<ProcResultStatus>();
    }
    public class ProcSyncResultList
    {
        public int PlanId { get; set; }
        public string ActionName { get; set; }
        public ProcResultStatusList procResultStatusLists { get; set; } = new ProcResultStatusList();
    }
    public class SyncResultLists
    {
        public List<ProcSyncResultList> procSyncResultLists { get; set; } = new List<ProcSyncResultList>();
    }
}
