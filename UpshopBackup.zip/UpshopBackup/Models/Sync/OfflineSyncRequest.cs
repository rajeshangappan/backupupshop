﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models
{
    public class OfflineSyncRequest
    {
        public object DynamicObject { get; set; }
        public string ActionName { get; set; }
    }
    public class OfflineSyncReqList
    {    
        public List<OfflineSyncRequest> UpdateSyncs { get; set; } = new List<OfflineSyncRequest>();
    }
}
