﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Maui.Controls.Compatibility;
using Microsoft.Maui.Controls;
using Microsoft.Maui;

namespace MobileUI2.Models
{
    public class AdjustmentItemRequest : BindableObject
    {
        public bool OfflineCreateAdjustmentSubmission { get; set; }
        public int AdjustmentID { get; set; }
        public int AdjustmentTypeID { get; set; }
        public string AdjustmentTypeDesc { get; set; }
        public int DepartmentId { get; set; }
        public int DepartmentNumber { get; set; }
        public string DepartmentName { get; set; }
        public AdjustmentItems ItemData { get; set; } = new AdjustmentItems();
        public string UPCNum { get; set; }
        public string BarCodeNumber { get; set; }
        public double? Price { get; set; }
        public double? Weight { get; set; }
        public double? Count { get; set; }
        public double? ExtendedRetail { get; set; }
        public string BarcodeType { get; set; }
        public bool IsType2WithPrice { get; set; }
        public bool IsType25WithWeight { get; set; }
        public bool PromptForInventoryState { get; set; }
        public bool PromptForExtendedRetail { get; set; }
        public bool PromptForCount { get; set; }
        public bool DisplayServiceAreaWarning { get; set; }
        public byte? InventoryStateId { get; set; }
        public byte ItemType { get; set; }
        public string PreCountLabel { get; set; }
        public string PostCountLabel { get; set; }
        public byte? SelectedWeightCode { get; set; }
        public IList<UnitOfMeasure> PreCountWeightCodes { get; set; }
        public AdjustmentResponse ResponseData { get; set; }
        public long AdjustmentDetailId { get; set; }
        public string SerialNumber { get; set; }
        public DateTime? ExpirationDate { get; set; }
        public DateTime AdjustmentDateTime { get; set; }

        public int? MaxCount { get; set; }
    }
    public class UnitOfMeasure
    {
        public byte UOMId { get; set; }
        public string UOMCode { get; set; }
    }

    public class AdjustmentResponse
    {
        public string DataType { get; set; }
        public double? MaxValue { get; set; }
        public string ResponseType { get; set; }
    }
}
