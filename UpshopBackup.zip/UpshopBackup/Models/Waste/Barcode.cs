﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models.Waste
{
    public class Barcode
    {
        //public bool IsMetric { get; set; }
        //public int ItemId { get; set; }
        public int BarcodeId { get; set; }
        public long? ItemNumber { get; set; }
        //public int? OrgUnitId { get; set; }
        //public string Description { get; set; }
        //public int? DepartmentId { get; set; }
        public int BarcodeType { get; set; }
        public string BarcodeNumber { get; set; }
        //public string BarcodeTypeDescription { get; set; }
        //public string BarcodeTypeLabel => $"{BarcodeNumber}-{BarcodeTypeDescription}";
        //public decimal? MinWeightLb { get; set; }
        //public decimal? MaxWeightLb { get; set; }
        //public decimal? MinWeightOz { get; set; }
        //public decimal? MaxWeightOz { get; set; }
        //public string MarkdownBarcodeNumber { get; set; }
        //public decimal? MinWeightGrams { get; set; }
        //public decimal? MaxWeightGrams { get; set; }
        public List<BarcodePLU> PLUNumbers { get; set; } = new List<BarcodePLU>();
    }

    public class BarcodePLU
    {
        public int? PLUId { get; set; }
        public int? PLUNumber { get; set; }
        public string PLUDescription { get; set; }
        //public string PLUDescriptionTwo { get; set; }
        //public string PLUDescriptionThree { get; set; }
        //public string PLUDescriptionFour { get; set; }
    }
}
