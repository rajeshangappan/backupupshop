﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models
{
    public class BarcodeType
    {
        public int BarcodeNumber { get; set; }
        public string BarcodeDescription { get; set; }
        public int TypeEnum { get; set; }
        public string Mask { get; set; }
    }
}
