﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models
{
    public class AdjustmentItemResponse
    {
        public bool OfflineCreateAdjustmentSubmission { get; set; }
        public string DataType { get; set; }
        public double? MaxValue { get; set; }
        public string ResponseType { get; set; }
        public int AdjustmentID { get; set; }
        public int AdjustmentDetailID { get; set; }
    }
}
