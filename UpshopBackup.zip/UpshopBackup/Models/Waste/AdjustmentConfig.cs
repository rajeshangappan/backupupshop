﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models
{
    public class AdjustmentConfig
    {
        public int? MaxAllowedCount { get; set; }
        public bool Error { get; set; }
        public bool Warn { get; set; }
    }
}
