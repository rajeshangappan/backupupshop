﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Text;

namespace MobileUI2.Models
{
    public class AdjustmentItems
    {
        public int ItemId { get; set; }
        public long ItemNumber { get; set; }
        public string ItemDescription { get; set; }
        public short? DepartmentNumber { get; set; }
        public DateTime? ItemLastUpdated { get; set; }
        public string ItemLastUpdatedBy { get; set; }
        public ItemRecipeData RecipeData { get; set; }
        public IEnumerable<AdjInventory> Inventories { get; set; }
        public bool TrackLabeledInventory { get; set; }
        public bool TrackUnlabeledInventory { get; set; }
        public bool TrackBackroomInventory { get; set; }
        public string ProductionWeightCode { get; set; }
        public short? TypeOfInventory { get; set; }
        public bool? HasCaseData { get; set; }
        public bool? ItemWeighted { get; set; }
        public double? CaseSize { get; set; }
        public int? DepartmentId { get; set; }
        public bool TrackUnsaleableUnlabeledInventory { get; set; }
        public string ContainerUoM { get; set; }
        public string Barcode { get; set; }
        public string InventoryTypeDescription { get; set; }
        public int PLUId { get; set; }
        public int? OrgUnitId { get; set; }
        public string PluDescription { get; set; }
        public int? PluNum { get; set; }
        public int? BarcodeId { get; set; }
        public bool AllowDecimalValue => TypeOfInventory != 3;
        public ObservableCollection<InventoryState> InventoryStates { get; set; } = new ObservableCollection<InventoryState>();
    }
    public class ItemRecipeData
    {
        public string RecipeImagePath { get; set; }
        public string DerivedIngredientText { get; set; }
        public string DerivedAllergens { get; set; }
    }
    public class AdjInventory
    {
        public string Type { get; set; }
        public byte? InventoryStateId { get; set; }
        public decimal Value { get; set; }
        public string UOM { get; set; }
    }
    public class InventoryState
    {
        public short InventoryStateId { get; set; }
        public string InventoryStateDescription { get; set; }
    }
}
