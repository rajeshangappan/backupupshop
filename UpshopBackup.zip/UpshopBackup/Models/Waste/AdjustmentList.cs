﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models
{
    public class AdjustmentList
    {
        public List<InventoryAdjustment> OpenAdjustments { get; set; } = new List<InventoryAdjustment>();
        public List<InventoryAdjustment> CompletedAdjustments { get; set; } = new List<InventoryAdjustment>();
    }
    public class InventoryAdjustment
    {
        public bool OfflineSubmission { get; set; }
        public int AdjustmentID { get; set; }
        public string AdjustmentDescription { get; set; }
        public int OrgUnitId { get; set; }
        public int OrgUnitNum { get; set; }
        public DateTime AdjustmentDateTime { get; set; }
        public string TabletDisplayTime { get; set; }
        public int AdjustmentTypeID { get; set; }
        public string AdjustmentTypeDesc { get; set; }
        public int AdjustmentStatus { get; set; }
        public string AdjustmentStatusDescription { get; set; }
        public int DepartmentId { get; set; }
        public int DepartmentNumber { get; set; }
        public string DepartmentName { get; set; }
        public string DepartmentDisplay => $"{DepartmentNumber} - {DepartmentName}";
        public int? InventoryStateId { get; set; }
        public string FinalizedBy { get; set; }
        public DateTime? FinalizedDateTime { get; set; }
    }

}
