﻿namespace MobileUI2.Models.Waste
{
    public class AdjustmentTypeRef
    {
        public int AdjustmentTypeId { get; set; }
        public string Name { get; set; }
        public string Type { get; set; }
    }
}