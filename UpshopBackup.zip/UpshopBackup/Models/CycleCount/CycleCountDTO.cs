﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MobileUI2.Models
{
    public class CycleCountDTO
    {
        public int CycleCountId { get; set; }
        public string Description { get; set; }
        public int DepartmentId { get; set; }
        public string DepartmentDescription { get; set; }
        public int CyCleCountType { get; set; }
        public string CyCleCountTypeDescription { get; set; }
        public int TotalItems { get; set; }
        public int CountedItems { get; set; }
        public int Status { get; set; }
        public string DescriptionDisplay => $"{DepartmentDescription}, {CyCleCountTypeDescription}";
        public bool IsCompleted => Status == 1;
        public decimal ProgressData => (TotalItems == 0) ? 0 : ((decimal)CountedItems / TotalItems);
        public string ProgressColor => ProgressData == 0 ? "#EBEBEB" : ProgressData > 0 && ProgressData <= 0.99m ? "#FF7800" : ProgressData > 1 ? "#01462c" : "#00905B";
        public string ProgressBackgroundColor =>  "#EBEBEB";
        
    }
}
