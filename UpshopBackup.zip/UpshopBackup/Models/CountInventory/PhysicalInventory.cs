﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models
{
    public class PhysicalInventory
    {

        public int PhysicalInventoryId { get; set; }
        public int ScheduleId { get; set; }
        public int OrgUnitId { get; set; }
        public int OrgUnitNumber { get; set; }
        public string OrgUnitLabel { get; set; }
        public int DepartmentId { get; set; }
        public int DepartmentNumber { get; set; }
        public string DepartmentLabel { get; set; }
        public DateTime InventoryDate { get; set; }
        public short StatusNum { get; set; }
        public string StatusDesc { get; set; }
        public string Signature1Label { get; set; }
        public string Signature2Label { get; set; }     
        public DateTime? FirstScanDateTime { get; set; }

    }
}
