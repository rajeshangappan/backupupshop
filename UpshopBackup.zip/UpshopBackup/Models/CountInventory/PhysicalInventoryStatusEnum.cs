﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models.CountInventory
{
    public enum PhysicalInventoryStatusEnum
    {
        Initiated,
        InventoryStarted,
        Finalized
    }
}
