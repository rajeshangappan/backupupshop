﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models
{
    public class DecodeBarcodeRequest
    {
        public int InventoryId { get; set; }
        public string Barcode { get; set; }
        public bool QuickScanEnabled { get; set; }
        public int DepartmentID { get; set; }
    }
}
