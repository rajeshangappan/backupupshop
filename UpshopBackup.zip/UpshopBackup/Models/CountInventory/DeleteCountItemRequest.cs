﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models
{
    public class DeleteCountItemRequest
    {
        public int InventoryId { get; set; }
        public double ItemNum { get; set; }
        public byte? InventoryStateId { get; set; }
        public double? InventoryCount { get; set; }
    }
}
