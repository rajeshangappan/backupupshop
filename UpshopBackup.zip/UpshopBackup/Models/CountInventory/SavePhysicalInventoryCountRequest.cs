﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models
{
    public class SavePhysicalInventoryCountRequest
    {
        public int InventoryId { get; set; }
        public int ItemId { get; set; }
        public string Barcode { get; set; }
        public byte? InventoryStateId { get; set; }
        public byte ItemType { get; set; }
        public double Count { get; set; }
        public byte? WeightCode { get; set; }
        public double? Packages { get; set; }
        public double? Price { get; set; }
        public bool IsType2WithPrice { get; set; }
        public string InventoryStateDesc { get; set; }
        public short? TypeOfInventory { get; set; }
        public string ItemDescription { get; set; }
        public double ItemNumber { get; set; }
        public string UOM { get; set; }
    }
}
