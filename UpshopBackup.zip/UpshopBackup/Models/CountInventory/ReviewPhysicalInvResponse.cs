﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models
{
    public class ReviewPhysicalInvResponse : NotifyPropertyChanged
    {
        public int InventoryId { get; set; }
        public double ItemNumber { get; set; }
        public double ItemId { get; set; }
        public string ItemDesc { get; set; }
        public double? Count { get; set; }
        public string ProdWgtCode { get; set; }
        public double? PackagesQuantity { get; set; }
        public int InventoryType { get; set; }
        public bool AllowDecimalValue => InventoryType != 3;
        public byte? InventoryStateId { get; set; }
        public string InventoryStateDesc { get; set; }
        public bool CountEditable { get; set; }
        public bool PackagesVisible { get; set; }
        public bool PackagesEditable { get; set; }
        public string InventoryTypeDescription { get; set; }
        public DateTime? ItemInsertedDateTime { get; set; }
        public string ItemDescLbl { get { return $"{ItemNumber} - {ItemDesc}"; } }
        public double? qty;
        public double? Quantitylbl
        {
            get => qty;
            set => SetAndRaisePropertyChanged(ref qty, value);
        }
        public double TempQty { get; set; }
        public double? NumaricEntryMinValue
        {
            get
            {
                return 0;
            }
        }
    }
}
