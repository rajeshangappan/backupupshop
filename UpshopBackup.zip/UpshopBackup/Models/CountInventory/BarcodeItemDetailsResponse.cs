﻿using MobileUI2.Constants;
using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models
{   
    public class BarcodeItemDetailsResponse
    {
        public int ItemId { get; set; }
        public int InventoryID { get; set; }
        public double ItemNumber { get; set; }
        public short? DepartmentNumber { get; set; }
        public string ItemDescription { get; set; }
        public DateTime? ItemLastUpdated { get; set; }
        public string ItemLastUpdatedBy { get; set; }
        public bool TrackLabeledInventory { get; set; }
        public bool TrackBackroomInventory { get; set; }
        public bool TrackUnlabeledInventory { get; set; }
        public string ProductionWeightCode { get; set; }
        public short? TypeOfInventory { get; set; }
        public bool AllowDecimalValue => TypeOfInventory==null?false: TypeOfInventory != 3;
        public bool HasCaseData { get; set; }
        public bool? ItemWeighted { get; set; }
        public string ContainerUoM { get; set; }
        public byte ItemType { get; set; }
        public double Price { get; set; }
        public string Barcode { get; set; }
        public string PreCountLabel { get; set; }
        public string postCountLbl { get; set; }
        public string PostCountLabel
        {
            get { return postCountLbl; }
            set
            {
                if (value is null || value == "(null)")
                {
                    postCountLbl = ContainerUoM;
                }
                else
                {
                    postCountLbl = value;
                };
            }
        }
        public double? Count { get; set; }
        public bool PromptForCount { get; set; }
        public bool PromptForPackages { get; set; }
        public bool IsType2WithPrice { get; set; }
        public int? PLUNum { get; set; }
        public string PLUDescription { get; set; }
        public List<InventoryState> inventoryStates { get; set; } = new List<InventoryState>();
        public List<UnitOfMeasure> WeightCodes { get; set; } = new List<UnitOfMeasure>();
        public int InventoryId { get; set; }
        public bool PromptForInventoryState { get => inventoryStates.Count > 1; }
        public bool ShowPluDetails { get { return (PLUNum is null || string.IsNullOrEmpty(PLUDescription)) ? false : true; } }
    }     
}
