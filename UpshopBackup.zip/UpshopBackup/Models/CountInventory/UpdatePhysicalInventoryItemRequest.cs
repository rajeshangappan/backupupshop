﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models
{
    public class UpdatePhysicalInventoryItemRequest
    {
        public int InventoryId { get; set; }        
        public IEnumerable<PhysicalInventoryScansData> InventoryList { get; set; }
    }
    public class PhysicalInventoryScansData
    {
        public double ItemId { get; set; }
        public double? OldCount { get; set; }
        public double? NewCount { get; set; }
        public double? OldPackagesQuantity { get; set; }
        public double? NewPackagesQuantity { get; set; }
        public short? InventoryType { get; set; }
        public byte? InventoryStateId { get; set; }
    }
}
