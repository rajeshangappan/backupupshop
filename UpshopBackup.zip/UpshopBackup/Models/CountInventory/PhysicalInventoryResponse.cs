﻿using System;
using System.Collections.Generic;
using System.Text;
using MobileUI2.Models.CountInventory;

namespace MobileUI2.Models
{
    public class PhysicalInventoryResponse
    {
        public List<CountInv> InprogressInventories { get; set; } = new List<CountInv>();
        public List<CountInv> CompletedInventories { get; set; } = new List<CountInv>();
    }
    public class CountInv : NotifyPropertyChanged
    {
        public int InventoryID { get; set; }
        public short DepartmentNumber { get; set; }
        public string DepartmentName { get; set; }
        public string DepartmentLabel { get; set; }
        public DateTime InventoryDate { get; set; }
        public DateTime? FinalizedDateTime { get; set; }
        public string InventoryStatusDescription { get; set; }
        public string Signature1Label { get; set; }
        public string Signature2Label { get; set; }
        public int DepartmentID { get; set; }
        public PhysicalInventoryStatusEnum Status { get; set; }
        int _statusId;
        public int StatusId
        {
            get => Status == PhysicalInventoryStatusEnum.Initiated ? 10 : Status == PhysicalInventoryStatusEnum.InventoryStarted ? 11:12;
            set => SetAndRaisePropertyChanged(ref _statusId, value);
        }
        public List<ReviewPhysicalInvResponse> ReviewItems { get; set; } = new List<ReviewPhysicalInvResponse>();
    }
}
