using System;
using System.Collections.Generic;

namespace MobileUI2.Models
{
    public class DistributionDetailsModel
    {
        // Common properties
        public int Id { get; set; }
        public string Description { get; set; }
        public string Number { get; set; }
        public int TotalQuantity { get; set; }
        public int PackedQuantity { get; set; }
        public double TotalWeight { get; set; }
        public double PackedWeight { get; set; }
        public int Status { get; set; }
        public string UnitOfMeasure { get; set; }
        public int PackType { get; set; }
        public List<int> ToteNumbers { get; set; }

        // Store-specific properties
        public int StoreId { get; set; }
        public string StoreDescription { get; set; }
        public string StoreNumber { get; set; }

        // Computed properties
        public string TotalQtyOrWeight => GetFormattedString();
        public bool IsCatchWeightedItem => (ItemPackType)PackType == ItemPackType.CatchWeight;
        public string CatchWeight => IsCatchWeightedItem ? $"({TotalWeight} {UnitOfMeasure})" : string.Empty;
        public decimal ProgressPercentage => GetProgressPercentage();
        public bool ShowCheck => Status == 2;
        public string ProgressColor => GetProgressColor();
        public string ProgressBackgroundColor => ProgressPercentage <= 1 ? "#EBEBEB" : "#00905B";
        public decimal ProgressData => ProgressPercentage <= 1 ? ProgressPercentage : ProgressPercentage - 1;

        private string GetFormattedString()
        {
            switch ((ItemPackType)PackType)
            {
                case ItemPackType.Count:
                    return $"{TotalQuantity} {UnitOfMeasure}";
                case ItemPackType.CatchWeight:
                    return $"{TotalQuantity}";
                case ItemPackType.Weight:
                    return $"{TotalWeight} {UnitOfMeasure}";
                default:
                    return string.Empty;
            }
        }

        private decimal GetProgressPercentage()
        {
            if (TotalQuantity == 0 && TotalWeight == 0) return 0;
            
            if (IsCatchWeightedItem || (ItemPackType)PackType == ItemPackType.Weight)
            {
                return TotalWeight == 0 ? 0 : (decimal)(PackedWeight / TotalWeight);
            }
            
            return TotalQuantity == 0 ? 0 : (decimal)PackedQuantity / TotalQuantity;
        }

        private string GetProgressColor()
        {
            if (ProgressPercentage == 0) return "#EBEBEB";
            if (ProgressPercentage > 0 && ProgressPercentage <= 0.99m) return "#FF7800";
            if (ProgressPercentage > 1) return "#01462c";
            return "#00905B";
        }
    }
} 