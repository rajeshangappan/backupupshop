using System.Collections.Generic;
using System.Linq;

namespace MobileUI2.Models
{
    public static class DistributionDetailsMapper
    {
        public static DistributionDetailsModel ToViewModel(this DistributionItemDetails item)
        {
            return new DistributionDetailsModel
            {
                Id = item.StoreId,
                Description = string.IsNullOrEmpty(item.StoreDescription) ? item.ItemDescription : item.StoreDescription,
                Number = item.StoreNumber == 0 ? item.BarcodeNumber : item.StoreNumber.ToString(),
                ToteNumbers = item.ToteNumbers,
                TotalQuantity = item.OrderedQty,
                PackedQuantity = item.PackedQty,
                TotalWeight = item.OrderedWeight,
                PackedWeight = item.PackedWeight,
                Status = item.Status,
                UnitOfMeasure = item.UnitOfMeasure,
                PackType = item.PackType
            };
        }

        public static SelectedItemModel ToSelectedItemViewModel(this ItemStoreDTO item)
        {
            return new SelectedItemModel
            {
                ItemId = item.ItemId,
                ItemDescription = item.ItemDescription,
                BarcodeNumber = item.BarcodeNumber,
                StoreId = item.StoreId,
                StoreDescription = item.StoreDescription,
                StoreNumber = item.StoreNumber.ToString()
            };
        }

        public static IEnumerable<DistributionDetailsModel> ToViewModels(this IEnumerable<DistributionItemDetails> items)
        {
            return items.Select(item => item.ToViewModel());
        }

    }
} 