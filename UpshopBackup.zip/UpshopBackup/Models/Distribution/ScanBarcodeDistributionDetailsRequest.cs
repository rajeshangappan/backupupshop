﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models
{
    public class ScanBarcodeDistributionDetailsRequest
    {
        public string BarcodeNumber { get; set; }
    }
}
