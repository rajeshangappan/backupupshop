﻿using Newtonsoft.Json;
using System;

namespace MobileUI2.Models
{
    public class ItemDistribution
    {
        public int ItemId { get; set; }
        public string ItemDescription { get; set; }
        public string BarcodeNumber { get; set; }
        public int TotalStores { get; set; }
        public int PackedStores { get; set; }
        public int Status { get; set; }
        public string TotalStoresString => $"{TotalStores}";
        public decimal ProgressPercentage => (TotalStores == 0) ? 0 : ((decimal)PackedStores / TotalStores);
        public bool ShowCheck => Status == 2;
        public string ProgressColor => ProgressPercentage == 0 ? "#EBEBEB" : ProgressPercentage > 0 && ProgressPercentage <= 0.99m ? "#FF7800" : ProgressPercentage > 1 ? "#01462c" : "#00905B";
        public string ProgressBackgroundColor => ProgressPercentage <= 1 ? "#EBEBEB" : "#00905B";
        public decimal ProgressData => ProgressPercentage <= 1 ? ProgressPercentage : ProgressPercentage - 1;
    }

    public class StoreDistribution
    {
        public int DistributionId { get; set; }
        public int StoreId { get; set; }
        public int StoreNumber { get; set; }
        public string StoreDescription { get; set; }
        public int ItemsOrdered { get; set; }
        public int ItemsPacked { get; set; }
        public int Status { get; set; }
        public string TotalItemsOrderedString => $"{ItemsOrdered}";
        public decimal ProgressPercentage => (ItemsOrdered == 0) ? 0 : ((decimal)ItemsPacked / ItemsOrdered);
        public bool ShowCheck => Status == 2;
        public string ProgressColor => ProgressPercentage == 0 ? "#EBEBEB" : ProgressPercentage > 0 && ProgressPercentage <= 0.99m ? "#FF7800" : ProgressPercentage > 1 ? "#01462c" : "#00905B";
        public string ProgressBackgroundColor => ProgressPercentage <= 1 ? "#EBEBEB" : "#00905B";
        public decimal ProgressData => ProgressPercentage <= 1 ? ProgressPercentage : ProgressPercentage - 1;
    }

    public class ItemStoreDTO
    {
        public int DistributionId { get; set; }
        public int ItemId { get; set; }
        public string ItemDescription { get; set; }
        public string BarcodeNumber { get; set; }
        public int StoreId { get; set; }
        public int StoreNumber { get; set; }
        public string StoreDescription { get; set; }
    }
}
