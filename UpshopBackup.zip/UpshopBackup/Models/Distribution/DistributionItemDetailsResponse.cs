﻿using Acr.UserDialogs;
using System;
using System.Collections.Generic;
using System.Security.Cryptography.X509Certificates;
using System.Text;

namespace MobileUI2.Models
{
    public class DistributionItemDetails
    {
        public int DistributionId { get; set; }
        public int DistributionItemId { get; set; }
        public int StoreId { get; set; }
        public List<int> ToteNumbers { get; set; }
        public int StoreNumber { get; set; }
        public int ItemId { get; set; }
        public string ItemDescription { get; set; }
        public string BarcodeNumber { get; set; }
        public string StoreDescription { get; set; }
        public int OrderedQty { get; set; }
        public double OrderedWeight { get; set; }
        public int PackedQty { get; set; }
        public double PackedWeight { get; set; }
        public int PackType { get; set; }
        public string UnitOfMeasure { get; set; }
        public int Status { get; set; }
        public string TotalQtyOrWeight => GetFormattedString();
        public bool IsCatchWeightedItem => (ItemPackType)PackType == ItemPackType.CatchWeight;
        public string CatchWeight => IsCatchWeightedItem ? $"({OrderedWeight} {UnitOfMeasure})" : string.Empty;
        public decimal ProgressPercentage => GetProgressPercentage();
        public bool ShowCheck => Status == 2;
        public string ProgressColor => ProgressPercentage == 0 ? "#EBEBEB" : ProgressPercentage > 0 && ProgressPercentage <= 0.99m ? "#FF7800" : ProgressPercentage > 1 ? "#01462c" : "#00905B";
        public string ProgressBackgroundColor => ProgressPercentage <= 1 ? "#EBEBEB" : "#00905B";
        public decimal ProgressData => ProgressPercentage <= 1 ? ProgressPercentage : ProgressPercentage - 1;
        public string GetFormattedString()
        {
            switch ((ItemPackType)PackType)
            {
                case ItemPackType.Count:
                    return $"{OrderedQty} {UnitOfMeasure}";

                case ItemPackType.Weight:
                    return $"{OrderedWeight} {UnitOfMeasure}";

                case ItemPackType.CatchWeight:
                    return $"{OrderedQty} ea";

                default:
                    return string.Empty;
            }
        }
        public decimal GetProgressPercentage()
        {
            switch ((ItemPackType)PackType)
            {
                case ItemPackType.Count:
                case ItemPackType.CatchWeight:
                    return OrderedQty > 0 ? (decimal)PackedQty / OrderedQty : 0;

                case ItemPackType.Weight:
                    return OrderedWeight > 0 ? (decimal)PackedWeight / (decimal)OrderedWeight : 0;

                default:
                    return 0;
            }
        }
    }
    public enum ItemPackType
    {
        Count = 0,
        Weight = 1,
        CatchWeight = 2
    }

    public class SelectedItemOrStoreDistribution
    {
        public int DistributionId { get; set; }
        public int DistributionItemId { get; set; }
        public string ToteNumber {  get; set; }
        public int StoreId { get; set; }
        public int StoreNumber { get; set; }
        public string StoreDescription { get; set; }
        public int OrderedQty { get; set; }
        public double OrderedWeight { get; set; }
        public int PackedQty { get; set; }
        public double PackedWeight { get; set; }
        public int PackType { get; set; }
        public string UnitOfMeasure { get; set; }
        public int Status { get; set; }
    }
}
