using System;

namespace MobileUI2.Models
{
    public class SelectedItemModel
    {
        public int ItemId { get; set; }
        public string ItemDescription { get; set; }
        public string BarcodeNumber { get; set; }
        public int StoreId { get; set; }
        public string StoreDescription { get; set; }
        public string StoreNumber { get; set; }

        // Computed properties for display
        public string Title => StoreId != 0 ? StoreDescription : ItemDescription;
        public string SubTitle => StoreId != 0 ? StoreNumber : BarcodeNumber;
        public string StoreInfo => StoreId > 0 ? $"{StoreNumber} - {StoreDescription}" : string.Empty;
    }
} 