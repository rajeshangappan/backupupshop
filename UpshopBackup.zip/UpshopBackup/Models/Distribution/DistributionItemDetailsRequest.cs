﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models
{
    public class DistributionItemDetailsRequest
    {
        public int DistributionId { get; set; }
        public int StoreId { get; set; }
        public int ItemId { get; set; }
    }
}
