﻿namespace MobileUI2.Models
{
    public class ScanBarcodeDistributionDetailsResponse
    {
        public Item ItemData { get; set; }
    }
    public class ScanToteBarcodeDistributionDetailsResponse
    {
        public string ToteNumber { get; set; }
        public int? StoreId { get; set; }
    }

    public class Item
    {
        public int ItemId { get; set; }
        public long ItemNumber { get; set; }
        public long BarcodeNumber { get; set; }
        public string ItemDescription { get; set; }
        /** nice to have may be in the future
        public int StoreId { get; set; }
        public long StoreNumber { get; set; }
        public string StoreDescription { get; set; }
        **/
    }
}
