﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.Text;
using Microsoft.Maui.Controls.Compatibility;
using Microsoft.Maui.Controls;
using Microsoft.Maui;

namespace MobileUI2.Models
{
    public class CategoryData : BindableObject
    {
        Color categoryColor;
        Color _frameBgColor;
        [IgnoreDataMember]
        private Style _styleAttribute = Application.Current != null ? (Style)Application.Current.Resources["LabelLightStyle"] : null;

        public int ItemOrderGroupId { get; set; }
        public string ItemOrderGroupName { get; set; }
        bool boxVisible;
        public Color CategoryColor
        {
            get => categoryColor;
            set { categoryColor = value; OnPropertyChanged(); }
        }

        public bool BoxVisible
        {
            get => boxVisible;
            set { boxVisible = value; OnPropertyChanged(); }
        }

        public Color FrameBgColor
        {
            get => _frameBgColor;
            set
            {
                _frameBgColor = value;
                OnPropertyChanged();
            }
        }
        [IgnoreDataMember]
        public Style StyleAttribute
        {
            get => _styleAttribute;
            set
            {
                _styleAttribute = value;
                OnPropertyChanged();
            }

        }
    }
}
