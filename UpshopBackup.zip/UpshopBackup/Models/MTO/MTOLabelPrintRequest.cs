﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models.MTO
{
    public class MTOLabelPrintRequest
    {
        public int LabelPrinterId { get; set; }
        public int OrderId { get; set; }
    }
}
