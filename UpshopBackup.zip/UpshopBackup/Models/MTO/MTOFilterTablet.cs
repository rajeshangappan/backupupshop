﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.Text;
using Microsoft.Maui.Controls.Compatibility;
using Microsoft.Maui.Controls;
using Microsoft.Maui;

namespace MobileUI2.Models
{
    public class MTOFilterTablet : NotifyPropertyChanged
    {
        public int FilterId { get; set; }
        public bool IsSelected { get; set; }
        [IgnoreDataMember]
        private Style _styleAttribute = Application.Current != null ? (Style)Application.Current.Resources["LabelLightStyle"] : null;
        [IgnoreDataMember]
        public Style StyleAttribute
        {
            get => _styleAttribute;
            set => SetAndRaisePropertyChanged(ref _styleAttribute, value);
        }
        private string _statusColor;
        public string StatusColor
        {
            get => _statusColor;
            set => SetAndRaisePropertyChanged(ref _statusColor, value);
        }
        private string _textColor;
        public string TextColor
        {
            get => _textColor;
            set => SetAndRaisePropertyChanged(ref _textColor, value);
        }
        private string _backgroundColor;
        public string BackgroundColor
        {
            get => _backgroundColor;
            set => SetAndRaisePropertyChanged(ref _backgroundColor, value);
        }
        private int _filterCount;
        public int FilterCount
        {
            get => _filterCount;
            set => SetAndRaisePropertyChanged(ref _filterCount, value);
        }
        private string _filterDescription;
        public string FilterDescription 
        {
            get => _filterDescription;
            set => SetAndRaisePropertyChanged(ref _filterDescription, value);
        }
    }
}
