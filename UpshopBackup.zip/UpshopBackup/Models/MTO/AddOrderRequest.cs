﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Text;

namespace MobileUI2.Models
{
    public class AddOrderRequest
    {

        public List<SelectOrderDetails> OrderItemDetails { get; set; } = new List<SelectOrderDetails>();
        public DateTime OrderDateTime { get; set; }
        public DateTime PickUpDateTimeUTC { get; set; }
        public string Notes { get; set; }
        public decimal? TotalCost { get; set; }
    }
    public class SelectOrderDetails : INotifyPropertyChanged
    {
        public int CartID;
        int _quantity;
        public int ItemOrderId { get; set; }
        public int ItemId { get; set; }
        public string ItemName { get; set; }
        public double Cost { get; set; }
        public double ItemCost { get; set; }
        public byte OrderStatus { get; set; }
        public int ItemCategoryId { get; set; }
        public string CurrencySymbolLabel { get; set; }
        public List<IngredientSelection> IngredientDetails { get; set; } = new List<IngredientSelection>();
        public int Qty
        {
            get => _quantity;
            set => SetAndRaisePropertyChanged(ref _quantity, value);
        }
        public event PropertyChangedEventHandler PropertyChanged;
        protected void SetAndRaisePropertyChanged<TRef>(
           ref TRef field, TRef value, [CallerMemberName] string propertyName = null)
        {
            field = value;
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
    public class IngredientSelection
    {
        public int IngredientId { get; set; }
        public bool IsHalf { get; set; }
        public bool Left { get; set; }
        public bool Right { get; set; }
        public bool Whole { get; set; }
        public decimal? ExtraCost { get; set; }
        public int ItemCategoryId { get; set; }
    }
}
