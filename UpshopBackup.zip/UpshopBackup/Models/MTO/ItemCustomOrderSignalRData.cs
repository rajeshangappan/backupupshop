﻿using MobileUI2.Constants;
using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models
{
    public class ItemCustomOrderSignalRData
    {
        public int ItemCustomOrderId { get; set; }
        public int OrderNumber { get; set; }
        public DateTime OrderDateTime { get; set; }
        public DateTime? PickupDateTimeUTC { get; set; }
        public string Notes { get; set; }
        public decimal? TotalCost { get; set; }
        public OrderStatus OrderStatus { get; set; }
        public int StoreId { get; set; }
        public DateTime? CompleteDate { get; set; }
        public DateTime? PrintTime { get; set; }
        public int? PrepTime { get; set; }
        public int? ItemWithLongestPrepTime { get; set; }
        public bool IsPrinted { get; set; }
        public int? PlanId { get; set; }
        public List<CustomOrderItemResponse> OrderitemDetails { get; set; }
    }
}
