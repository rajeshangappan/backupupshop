﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Text;
using Microsoft.Maui.Controls.Compatibility;
using Microsoft.Maui.Controls;
using Microsoft.Maui;

namespace MobileUI2.Models
{
    public class CategoryItemData : BindableObject
    {
        public int ItemOrderId { get; set; }
        public int ItemId { get; set; }
        public string ItemName { get; set; }
        public int? Group { get; set; }
        public string ItemDescription { get; set; }
        public double Cost { get; set; }
        public string ImageUrl { get; set; }
        public bool AllowCustomization { get; set; }
        public bool AllowHalves { get; set; }
        public string CurrencySymbol { get; set; }
        public string CostLabel { get; set; }
        int _LabelQty = 1;
        public int LabelQuantity
        {
            get => _LabelQty;
            set { _LabelQty = value; OnPropertyChanged(); }
        }

        private bool _isDescriptionVisible;
        public bool IsDescriptionVisible
        {
            get => _isDescriptionVisible;
            set { _isDescriptionVisible = value; OnPropertyChanged(); }
        }
        public List<SelectOrderDetails> CartDetails { get; set; } = new List<SelectOrderDetails>();
    }
    public class CategoryItemListData
    {
        public string itemOrderGroupName { get; set; }
        public int itemOrderGroupId { get; set; }
        public ObservableCollection<CategoryItemData> ItemOrderResponses { get; set; } = new ObservableCollection<CategoryItemData>();       
    }

    public class CategoryItemDataGroup : ObservableCollection<CategoryItemData>
    {
        public string itemOrderGroupName { get; set; }
        public int itemOrderGroupId { get; set; }
        public CategoryItemDataGroup(string name, int groupid, ObservableCollection<CategoryItemData> categoryItems) : base(categoryItems)
        {
            itemOrderGroupName = name;
            itemOrderGroupId = groupid;
        }
    }

}
