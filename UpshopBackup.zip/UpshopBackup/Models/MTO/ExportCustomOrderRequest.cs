﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models.MTO
{
    public class ExportCustomOrderRequest
    {
        public int Id { get; set; }
    }
}
