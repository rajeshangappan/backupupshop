﻿using MobileUI2.Constants;
using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Maui.Controls.Compatibility;
using Microsoft.Maui.Controls;
using Microsoft.Maui;

namespace MobileUI2.Models
{
    public class ItemCustomOrderListData : BindableObject
    {
        public int ItemCustomOrderId { get; set; }
        public int OrderNumber { get; set; }
        public DateTime OrderDateTime { get; set; }
        public DateTime PickupDateTime { get; set; }
        public OrderStatus OrderStatus { get; set; }
        public string OrderLabel { get; set; }
        public string Time { get; set; }
        public string PastDate { get; set; }
        public string StatusLabel { get; set; }
        private string _statusColor { get; set; }
        public bool IsOfflineSubmission { get; set; }
        public string StatusColor 
        {
            get => _statusColor;
            set { _statusColor = value; OnPropertyChanged(); } 
        }
        private bool _statusVisible { get; set; }
        public bool StatusVisible
        {
            get => _statusVisible;
            set { _statusVisible = value; OnPropertyChanged(); }
        }
        private bool? _pastDue { get; set; }
        public bool? PastDue
        {
            get => _pastDue;
            set { _pastDue = value; OnPropertyChanged(); }
        }
        private int _completedItems { get; set; }
        public int CompletedItems
        {
            get => _completedItems;
            set { _completedItems = value; OnPropertyChanged(); }
        }
        public int TotalItems { get; set; }
        public bool PastDueVisible
        {
            get
            {
                return PastDue == null ? false : (bool)PastDue;
            }
        }
        private double _progressData { get; set; }
        public double ProgressData 
        {
            get => _progressData;
            set { _progressData = value; OnPropertyChanged(); }
        }
        public List<CustomOrderItemResponse> OrderitemDetails { get; set; } = new List<CustomOrderItemResponse>();
    }
}
