﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models.MTO
{
    public class OrderItemStatusRequest
    {
        public int ItemCustomOrderId { get; set; }
    }
}
