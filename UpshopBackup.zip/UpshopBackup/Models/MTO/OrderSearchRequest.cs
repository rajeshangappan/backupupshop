﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models
{
    public class OrderSearchRequest
    {
        public string DescriptionToken { get; set; }
    }
}
