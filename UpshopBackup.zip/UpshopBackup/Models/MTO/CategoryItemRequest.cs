﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models
{
    public class CategoryItemRequest
    {
        public int ItemId {get; set;}
        public int ItemOrderId { get; set; }
    }
}
