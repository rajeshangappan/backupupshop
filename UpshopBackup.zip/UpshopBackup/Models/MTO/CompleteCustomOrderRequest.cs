﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models
{
    public class CompleteCustomOrderRequest
    {
        public int Id { get; set; }
        public DateTime CompleteDate { get; set; }
    }
}
