﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Text;
using Microsoft.Maui.Controls.Compatibility;
using Microsoft.Maui.Controls;
using Microsoft.Maui;

namespace MobileUI2.Models
{
    public class CategoryItemDetailData
    {
        public int ItemOrderId { get; set; }
        public int ItemId { get; set; }
        public bool AllowCustomization { get; set; }
        public bool AllowHalves { get; set; }
        public List<ItemCategoryDetails> CategoryDetails { get; set; } = new List<ItemCategoryDetails>();
    }
    public class ItemCategoryDetails : INotifyPropertyChanged
    {
        List<ItemCategoryChildDetails> _CategoryChild;
        public int ItemCategoryId { get; set; }
        public string Description { get; set; }
        public decimal? MinChoice { get; set; }
        public decimal? MaxChoice { get; set; }
        public bool IsVisibleMultiSelection { get; set; }
        public List<ItemCategoryChildDetails> CategoryChild
        {
            get => _CategoryChild;
            set => SetAndRaisePropertyChanged(ref _CategoryChild, value);
        }
        public event PropertyChangedEventHandler PropertyChanged;
        protected void SetAndRaisePropertyChanged<TRef>(
           ref TRef field, TRef value, [CallerMemberName] string propertyName = null)
        {
            field = value;
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
    public class ItemCategoryChildDetails : INotifyPropertyChanged
    {
        public int IngredientId { get; set; }
        public int ItemCategoryId { get; set; }
        private bool isToppingChecked;
        public string IngredientDescription { get; set; }
        public string FriendlyName { get; set; }
        public decimal? ExtraCost { get; set; }
        public bool ShowPrice { get; set; }
        public string CurrencySymbolLabel { get; set; }
        string _LefthalfImage = "LeftCircleClear.png";
        string _RighthalfImage = "RightCircleClear.png";
        string _CircleImage = "\uf111";
        string _checkedIcon = "\uf04d";
        string _radioImage = "RadioClear.png";
        string _middleImage = "MiddleCircleClear.png";
        bool _IsChecked;
        bool _AllowHalves;
        Style _checkIconStyle;
        Color _checkIconColor;
        public Style CheckIconStyle
        {
            get => _checkIconStyle;
            set => SetAndRaisePropertyChanged(ref _checkIconStyle, value);
        }
        public Color CheckIconColor
        {
            get => _checkIconColor;
            set => SetAndRaisePropertyChanged(ref _checkIconColor, value);
        }
        public string LefthalfImage
        {
            get => _LefthalfImage;
            set => SetAndRaisePropertyChanged(ref _LefthalfImage, value);
        }
        public string RighthalfImage
        {
            get => _RighthalfImage;
            set => SetAndRaisePropertyChanged(ref _RighthalfImage, value);
        }
        public string CircleImage
        {
            get => _CircleImage;
            set => SetAndRaisePropertyChanged(ref _CircleImage, value);
        }
        public bool IsChecked
        {
            get => _IsChecked;
            set => SetAndRaisePropertyChanged(ref _IsChecked, value);
        }
        public bool IsToppingChecked
        {
            get => isToppingChecked;
            set => SetAndRaisePropertyChanged(ref isToppingChecked, value);
        }
        public string CheckedIcon
        {
            get => _checkedIcon;
            set => SetAndRaisePropertyChanged(ref _checkedIcon, value);
        }
        public string RadioImage
        {
            get => _radioImage;
            set => SetAndRaisePropertyChanged(ref _radioImage, value);
        }
        public string MiddleImage
        {
            get => _middleImage;
            set => SetAndRaisePropertyChanged(ref _middleImage, value);
        }
        public bool AllowHalves
        {
            get => _AllowHalves;
            set => SetAndRaisePropertyChanged(ref _AllowHalves, value);
        }

        public event PropertyChangedEventHandler PropertyChanged;
        protected void SetAndRaisePropertyChanged<TRef>(
           ref TRef field, TRef value, [CallerMemberName] string propertyName = null)
        {
            field = value;
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
