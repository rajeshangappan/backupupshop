﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Maui.Controls.Compatibility;
using Microsoft.Maui.Controls;
using Microsoft.Maui;

namespace MobileUI2.Models
{
    public class MTOTabletCardGrouping : BindableObject
    {
        private string _backgroundColor;
        public string BackgroundColor
        {
            get => _backgroundColor;
            set { _backgroundColor = value; OnPropertyChanged(); }
        }
        public bool IsSelected;
        private List<ItemCustomOrderListDataTablet> _customOrders { get; set; }
        public List<ItemCustomOrderListDataTablet> CustomOrders
        {
            get => _customOrders;
            set { _customOrders = value; OnPropertyChanged(); }
        }
    }
}
