﻿using MobileUI2.Constants;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Text;
using Microsoft.Maui.Controls.Compatibility;
using Microsoft.Maui.Controls;
using Microsoft.Maui;

namespace MobileUI2.Models
{
    public class ItemCustomOrderDetailData
    {
        public int ItemCustomOrderId { get; set; }
        public int OrderNumber { get; set; }
        public DateTime OrderDateTime { get; set; }
        public int OrderStatus { get; set; }
        public List<CustomOrderItemResponse> OrderItems { get; set; }
    }
    public class CustomOrderItemResponse
    {
        public int ItemId { get; set; }
        public string itemDescription { get; set; }
        public decimal Qty { get; set; }
        public int QtyLabel
        {
            get { return (int)Qty; }
        }
        public bool IsVisibleCheckedIcon { get; set; }
        public OrderStatus OrderStatus { get; set; }
        public string CheckedIcon { get; set; } = "\uf04d";
        public string ItemNotes { get; set; }
        public string LblIngredientText { get; set; }
        public bool IsChecked { get; set; }
    }
}
