﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models
{
    public class OrgUnitDTO
    {
        public int OrgUnitNumber { get; set; }
        public string OrgUnitName { get; set; }
        public bool? OrgUnitActive { get; set; }
        public int OrgUnitAutoId { get; set; }
        public string OrgUnitTypeCode { get; set; }
    }
}
