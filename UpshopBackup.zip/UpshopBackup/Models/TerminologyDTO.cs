﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models
{
    public class TerminologyDTO
    {
        public string Item { get; set; }
        public string Items { get; set; }
        public string Barcode { get; set; }
        public string Family { get; set; }
        public string Category { get; set; }
        public string Class { get; set; }
        public string Department { get; set; }
        public string Shrink { get; set; }
        public string Modified { get; set; }
    }
}
