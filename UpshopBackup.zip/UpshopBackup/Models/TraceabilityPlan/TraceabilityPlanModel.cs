using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Models.TraceabilityPlan
{
    public class TraceabilityPlanModel
    {
        public int TraceabilityPlanId { get; set; }
        public string RecordStorage { get; set; }
        public string Identification { get; set; }
        public string LotCodes { get; set; }
        public string PlanForMaintenance { get; set; }
        public string ContactName { get; set; }
        public string Title { get; set; }
        public string EmailAddress { get; set; }
        public string PhoneNumber { get; set; }
    }
}