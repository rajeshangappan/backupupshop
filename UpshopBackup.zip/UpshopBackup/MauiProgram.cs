﻿using CommunityToolkit.Maui;
using FFImageLoading.Maui;
using Microsoft.Extensions.Logging;
using Microsoft.Maui.Platform;
using MobileUI2.BluetoothHelper;
using MobileUI2.Components.Controls;
using MobileUI2.Components.ItemTagsComponent;
using MobileUI2.Components.TaskBool;
using MobileUI2.Components.TaskMultipleSelectCheckboxView;
using MobileUI2.Components.TaskNumericResponseView;
using MobileUI2.Components.TaskParagraphView;
using MobileUI2.Components.TaskPointScaleView;
using MobileUI2.Components.TaskSingleLineView;
using MobileUI2.Components.TaskSingleSelectRadioButton;
using MobileUI2.Components.TaskUploadPictureView;
using MobileUI2.Controls;
using MobileUI2.DayMark;
using MobileUI2.Logging;
using MobileUI2.Service;
using MobileUI2.Services;
using MobileUI2.Services.CycleCount;
using MobileUI2.Services.Login;
using MobileUI2.Services.Navigation;
using MobileUI2.Services.PrintLabels.DaymarkPrinter;
using MobileUI2.Services.RequestProvider;
using MobileUI2.Services.StoreWalks;
using MobileUI2.Services.TaskActivities;
using MobileUI2.Services.TraceabilityPlan;
using MobileUI2.Services.Transfers;
using MobileUI2.Services.Waste;
using MobileUI2.TabletViews;
using MobileUI2.TabletViews.UserAccount;
using MobileUI2.ViewModels;
using MobileUI2.ViewModels.Base;
using MobileUI2.ViewModels.Orders;
using MobileUI2.ViewModels.StoreWalks;
using MobileUI2.ViewModels.TemperatureCheck;
using MobileUI2.ViewModels.UserAccount;
using MobileUI2.Views;
using MobileUI2.Views.MarkDown;
using MobileUI2.Views.MarkDown;
using MobileUI2.Views.Orders;
using MobileUI2.Views.Orders.ContentViews;
using MobileUI2.Views.UserAccount;
using Mopups.Hosting;
using RGPopup.Maui.Extensions;
using Shiny;
using SkiaSharp.Views.Maui.Controls.Hosting;
using ZXing.Net.Maui;
using ZXing.Net.Maui.Controls;
using MobileUI2.ViewModels.Distribution;

namespace MobileUI2
{
    public static class MauiProgram
    {
        public static MauiApp CreateMauiApp()
        {
            var builder = MauiApp.CreateBuilder();
            
#if ANDROID
            //Popup.Init();
#endif
            
            builder
                .UseMauiApp<App>()
                .UseMauiCommunityToolkitMediaElement()
                .UseMauiCommunityToolkit()
                .UseFFImageLoading()
                .UseMauiRGPopup()
                .UseShiny()
                .ConfigureMopups()
                .UseBarcodeReader()
                .UseSkiaSharp()
                .ConfigureMauiHandlers(ConfigureHandlers)
                .ConfigureFonts(fonts =>
                {
                    fonts.AddFont("OpenSans-Regular.ttf", "OpenSansRegular");
                    fonts.AddFont("OpenSans-Semibold.ttf", "OpenSansSemibold");
                    fonts.AddFont("ProximaNova-Regular.otf", "ProximaNova-Regular");
                    fonts.AddFont("Proxima Nova Bold.otf", "Proxima Nova Bold");
                    fonts.AddFont("Proxima Nova Semibold.ttf", "Proxima Nova Semibold");    
                });

            ConfigureSearchBarHandler();
            RegisterServices(builder.Services);
            RegisterViewModels(builder.Services);
            RegisterViews(builder.Services);
            ConfigureEntryHandler();

#if DEBUG
            builder.Logging.AddDebug();
#endif

            return builder.Build();
        }

        private static void ConfigureHandlers(IMauiHandlersCollection handlers)
        {
#if ANDROID
            handlers.AddHandler(typeof(Editor), typeof(MobileUI2.Platforms.Android.Handlers.BorderlessEditorHandler));
            handlers.AddHandler(typeof(Picker), typeof(MobileUI2.Platforms.Android.Handlers.BorderlessPickerHandler));
            handlers.AddHandler(typeof(CustomEntry), typeof(MobileUI2.Platforms.Android.Handlers.CustomEntryHandler));
            handlers.AddHandler(typeof(NavigationPage), typeof(MobileUI2.Platforms.Android.Handlers.CustomNavigationPageHandler));
            handlers.AddHandler(typeof(Entry), typeof(MobileUI2.Platforms.Android.Handlers.EntryHandler));
            handlers.AddHandler(typeof(HybridWebView), typeof(MobileUI2.Platforms.Android.Handlers.HybridWebViewHandler));
            handlers.AddHandler(typeof(NumericInput), typeof(MobileUI2.Platforms.Android.Handlers.NumericInputHandler));
            handlers.AddHandler(typeof(MauiScrollView), typeof(MobileUI2.Platforms.Android.Handlers.CustomScrollViewHandler));
            handlers.AddHandler(typeof(Editor), typeof(MobileUI2.Platforms.Android.Handlers.TaskEditorHandler));
            handlers.AddHandler(typeof(Editor), typeof(MobileUI2.Platforms.Android.Handlers.TaskParaEditorHandler));
            handlers.AddHandler<CameraBarcodeReaderView, CameraBarcodeReaderViewHandler>();
            handlers.AddHandler(typeof(Scandit.DataCapture.Barcode.Spark.UI.Maui.SparkScanView), typeof(Scandit.DataCapture.Barcode.Spark.UI.Maui.SparkScanViewHandler));
            handlers.AddHandler(typeof(Scandit.DataCapture.Core.UI.Maui.DataCaptureView), typeof(Scandit.DataCapture.Core.UI.Maui.DataCaptureViewHandler));
#endif
#if IOS
            handlers.AddHandler(typeof(Scandit.DataCapture.Barcode.Spark.UI.Maui.SparkScanView), typeof(Scandit.DataCapture.Barcode.Spark.UI.Maui.SparkScanViewHandler));
            handlers.AddHandler(typeof(Scandit.DataCapture.Core.UI.Maui.DataCaptureView), typeof(Scandit.DataCapture.Core.UI.Maui.DataCaptureViewHandler));
            handlers.AddHandler(typeof(SearchBar), typeof(MobileUI2.Platforms.iOS.Handlers.CustomSearchBarHandler));
#endif  
        }

        private static void ConfigureSearchBarHandler()
        {
            Microsoft.Maui.Handlers.SearchBarHandler.Mapper.AppendToMapping("MyCustomization", (handler, view) =>
            {
#if ANDROID
                Android.Widget.LinearLayout? linearLayout = handler.PlatformView?.GetChildAt(0) as Android.Widget.LinearLayout;
                if (linearLayout != null)
                {
                    linearLayout = linearLayout.GetChildAt(2) as Android.Widget.LinearLayout;
                    linearLayout = linearLayout.GetChildAt(1) as Android.Widget.LinearLayout;
                    linearLayout.Background = null;
                }
#endif
            });
        }

        private static void ConfigureEntryHandler()
        {
            Microsoft.Maui.Handlers.EntryHandler.Mapper.AppendToMapping("MyCustomization", (handler, view) =>
            {
#if ANDROID
                handler.PlatformView.BackgroundTintList =
                    Android.Content.Res.ColorStateList.ValueOf(Android.Graphics.Color.Transparent);

                Microsoft.Maui.Handlers.EditorHandler.Mapper.AppendToMapping("NoUnderline", (handler, view) =>
                {
                    var nativeView = handler.PlatformView;
                    nativeView.Background = null!;
                });
#elif IOS
                handler.PlatformView.BackgroundColor = UIKit.UIColor.Clear;
                handler.PlatformView.Layer.BorderWidth = 0;
                handler.PlatformView.BorderStyle = UIKit.UITextBorderStyle.None;
#endif
            });
        }

        private static void RegisterServices(IServiceCollection services)
        {
            // Core Services
            services.AddSingleton<IRequestProvider, RequestProvider>();
            services.AddSingleton<INavigationService, NavigationService>();
            services.AddSingleton<ILoginService, LoginService>();
            services.AddSingleton<IPreferences, PreferencesImplementation>();
            services.AddSingleton<IConnectivity, ConnectivityImplementation>();
            services.AddSingleton<ISecureStorage, SecureStorageImplementation>();
            services.AddSingleton<IDeviceInfo, DeviceInfoImplementation>();
            services.AddSingleton<ISignalRService, SignalRService>();
            services.AddSingleton<ISignalRMessageProcessor, SignalRMessageProcessor>();
            services.AddSingleton<ILocalCacheService, LocalCacheService>();
            services.AddSingleton<IDialogService, DialogService>();
            services.AddSingleton<ILoggingService, AppCenterLoggingService>();
            services.AddSingleton<IPreferences>(Preferences.Default);
            services.AddSingleton<IPendoCustomService, PendoCustomService>();

            // Business Services
            services.AddSingleton<IRecipeService, RecipeService>();
            services.AddSingleton<IProductionPlanService, ProductionPlanService>();
            services.AddSingleton<IWasteService, WasteService>();
            services.AddSingleton<IOfflineWasteService, OfflineWasteService>();
            services.AddSingleton<IItemLookupService, ItemLookupService>();
            services.AddSingleton<IOrderingService, OrderingService>();
            services.AddSingleton<ITraceabilityService, TraceabilityService>();
            services.AddSingleton<ISyncService, SyncService>();
            services.AddSingleton<ILabelPrinterService, LabelPrinterService>();
            services.AddSingleton<IMarkdownService, MarkdownService>();
            services.AddSingleton<ICountInventoryService, CountInventoryService>();
            services.AddSingleton<ITaskActivityService, TaskActivityService>();
            services.AddSingleton<ITransferService, TransferService>();
            services.AddSingleton<IPrepService, PrepService>();
            services.AddSingleton<ICodeBenchmarks, CodeBenchmarks>();
            services.AddSingleton<IDSDService, DSDService>();
            services.AddSingleton<IDayMarkService, DayMarkService>();
            services.AddSingleton<IDistributionService, DistributionService>();
            services.AddSingleton<IDayMarkPrinterService, MobileUI2.Services.PrintLabels.DaymarkPrinter.DayMarkPrinterService>();
            services.AddSingleton<IItemTagsMapper,ItemTagsMapper>();
            services.AddSingleton<ICycleCountService, CycleCountService>();


            // Task Services
            services.AddSingleton<ITaskBoolService, TaskBoolService>();
            services.AddSingleton<ITaskMultipleSelectCheckboxService, TaskMultipleSelectCheckboxService>();
            services.AddSingleton<ITaskSingleSelectRadioButtonService, TaskSingleSelectRadioButtonService>();
            services.AddSingleton<ITaskPararaphService, TaskParagraphService>();
            services.AddSingleton<ITaskPointScaleService, TaskPointScaleService>();
            services.AddSingleton<ITaskNumericResponseService, TaskNumericResponseService>();
            services.AddSingleton<ITaskSingleLineService, TaskSingleLineService>();
            services.AddSingleton<IStoreWalkService, StoreWalkService>();
            services.AddSingleton<IStoreWalkMapper, StoreWalkMapper>();
            services.AddSingleton<ITaskUploadPictureService, TaskUploadPictureService>();

            // Device Services
            services.AddSingleton<IBLEService, BLEService>();
            services.AddSingleton<ITemperatureProbeService, TemperatureProbeService>();
            services.AddSingleton<ITraceabilityPlanService, TraceabilityPlanService>();

#if ANDROID
            services.AddSingleton<IPDFPrinterService, PrintAPP.Droid.Services.PDFPrinterService>();
            services.AddSingleton<IOrientationLockService, Droid.OrientationLockService>();
#elif IOS
            services.AddSingleton<IPDFPrinterService, PrintAPP.iOS.Services.PDFPrinterService>();
            services.AddSingleton<IOrientationLockService, iOS.OrientationLockService>();

#endif

            services.AddBluetoothLE();
        }

        private static void RegisterViewModels(IServiceCollection services)
        {
            // Singleton ViewModels
            services.AddSingleton<LoginViewModel>();
            services.AddSingleton<QRScanViewModel>();
            services.AddSingleton<ManualEntryViewModel>();

            // Transient ViewModels
            services.AddTransient<ZxingQRScanViewModel>();
            services.AddTransient<BarcodeScannerViewModel>();
            services.AddTransient<ConfigManualEntryViewModel>();
            services.AddTransient<UserAccountViewModel>();
            services.AddTransient<ModuleContentViewModel>();
            services.AddTransient<ProductionPlanHomeViewModel>();
            services.AddTransient<SSOLoginViewModel>();
            services.AddTransient<ProductionPlanItemMainPopupViewModel>();
            services.AddTransient<RecipeVideoPlayerViewModel>();
            services.AddTransient<InventoryAdjustmentViewModel>();
            services.AddTransient<ReviewAdjustmentViewModel>();
            services.AddTransient<AddAdjustmentPopupViewModel>();
            services.AddTransient<SetAdjustmentItemDataPopupViewModel>();
            services.AddTransient<ItemDetailsViewModel>();
            services.AddTransient<EstablishmentSelectionPopupViewModel>();
            services.AddTransient<EstablishmentListPopupViewModel>();
            services.AddTransient<PLUSelectionViewModel>();
            services.AddTransient<SelectMarkdownPrinterViewModel>();
            services.AddTransient<PLUSearchViewModel>();
            services.AddTransient<PLUDetailsViewModel>();
            services.AddTransient<CountInventoryListViewModel>();
            services.AddTransient<CountInventoryItemPopUpViewModel>();
            services.AddTransient<ReviewCountInventoryViewModel>();
            services.AddTransient<CustomOrdersListViewModel>();
            services.AddTransient<CreateCustomOrderViewModel>();
            services.AddTransient<CategoryItemDetailsViewModel>();
            services.AddTransient<ConfirmOrderDetailsViewModel>();
            services.AddTransient<UpdateCategoryItemDetailsViewModel>();
            services.AddTransient<MainMenuViewModel>();
            services.AddTransient<TodaysTaskListViewModel>();
            services.AddTransient<UserInfoSettingsViewModel>();
            services.AddTransient<PrepViewModel>();
            services.AddTransient<PrepItemDetailsPopupViewModel>();
            services.AddTransient<DayMarkAddCreditsPopupViewModel>();
            services.AddTransient<ProductionPlanLabelQtyPopupViewModel>();
            services.AddTransient<ProductionPlanItemViewModel>();
            services.AddTransient<ProductionPlanStartViewModel>();
            services.AddTransient<RecipeDetailsViewModel>();
            services.AddTransient<RecipeInstructionsViewModel>();
            services.AddTransient<RecipeQuantityEnterPopupViewModel>();
            services.AddTransient<ProductionPlanItemRecipeViewModel>();
            services.AddTransient<ProductionPlanCompleteViewModel>();
            services.AddTransient<ProductionPlanCommissaryViewModel>();
            services.AddTransient<InventoryAdjustmentItemDetailsViewModel>();
            services.AddTransient<ItemLookupViewModel>();
            services.AddTransient<ProductionPlanPrintViewModel>();
            services.AddTransient<PrintersPopupViewModel>();
            services.AddTransient<PrintOptionsPopupViewModel>();
            services.AddTransient<ItemLookupScannerViewModel>();
            services.AddTransient<OrderingViewModel>();
            services.AddTransient<TraceabilityViewModel>();
            services.AddTransient<CustomerRequestViewModel>();
            services.AddTransient<OrderDetailsViewModel>();
            services.AddTransient<OrderQtyUpdateViewModel>();
            services.AddTransient<ReceiveTransferListViewModel>();
            services.AddTransient<TransferReviewListViewModel>();
            services.AddTransient<ProductionPlanUpdateQuantitiesPopupViewModel>();
            services.AddTransient<PrepItemConsolidatedDetailsViewModel>();
            services.AddTransient<PrepSemiFinishedItemsViewModel>();
            services.AddTransient<SelectGrindOptionsViewModel>();
            services.AddTransient<GrindBarcodeScannerViewModel>();
            services.AddTransient<MarkdownListViewModel>();
            services.AddTransient<CountInventoryScanViewModel>();
            services.AddTransient<TaskActivityStepsViewModel>();
            services.AddTransient<TaskActivityListViewModel>();
            services.AddTransient<MTOReviewViewModel>();
            services.AddTransient<TemperatureCheckStepsViewModel>();
            services.AddTransient<TemperatureCheckCaptureViewModel>();
            services.AddTransient<WorkstationSelectPopupViewModel>();
            services.AddTransient<SignatureTaskVerificationViewModel>();
            services.AddTransient<SignatureTaskViewModel>();
            services.AddTransient<TransfersListViewModel>();
            services.AddTransient<TransferScanViewModel>();
            services.AddTransient<TransferQuantityEnterPopupViewModel>();
            services.AddTransient<ProductionOrderDetailsViewModel>();
            services.AddTransient<PrepStepDetailsViewModel>();
            services.AddTransient<CutTestScanDetailsViewModel>();
            services.AddTransient<InvoicesMainViewModel>();
            services.AddTransient<SupplierViewModel>();
            services.AddTransient<CreateInvoiceViewModel>();
            services.AddTransient<CompleteInvoiceViewModel>();
            services.AddTransient<InvoiceTotalCountViewModel>();
            services.AddTransient<InvoiceItemDetailsViewModel>();
            services.AddTransient<CreateReturnInvoiceViewModel>();
            services.AddTransient<AddInvoiceItemViewModel>();
            services.AddTransient<ReturnInvoiceItemDetailsViewModel>();
            services.AddTransient<FinalizeReturnInvoiceViewModel>();
            services.AddTransient<InvoiceItemExceptionViewModel>();
            services.AddTransient<StoreWalksViewModel>();
            services.AddTransient<TaskBoolViewModel>();
            services.AddTransient<StoreWalkListViewModel>();
            services.AddTransient<TemperatureProbeViewModel>();
            services.AddTransient<OrdersTodayHomeViewModel>();
            services.AddTransient<OrderItemDetailsViewModel>();
            services.AddTransient<TraceabilityPlanViewModel>();
            services.AddTransient<SettingsViewModel>();
            services.AddTransient<ScanditQRScanViewModel>();
            services.AddTransient<ProductionPlanUnLabeledQtyPopupViewModel>();
            services.AddTransient<ProductionPlanPickListViewModel>();
            services.AddTransient<CutTestReviewtemDetailsViewModel>();
            services.AddTransient<CutTestStartViewModel>();
            services.AddTransient<CutTestTaskViewModel>();
            services.AddTransient<ProductionPlanUpdateModifyQtyPopupViewModel>();
            services.AddTransient<ProductionPlanOnHandPopupViewModel>();
            services.AddTransient<ProductionPlanOnHandPopupView>();
            services.AddTransient<ScanditSparkViewModelBase>();
            services.AddTransient<RecipeListViewModel>();
            services.AddTransient<MenuSettingsViewModel>();
            services.AddTransient<AddOrderViewModel>();
            services.AddTransient<OrderItemDetailsBaseViewModel>();
            services.AddTransient<DistributionHomeViewModel>();
            services.AddTransient<DistributionItemDetailsViewModel>();
            services.AddTransient<DistributionStoreViewModel>();
            services.AddTransient<StoreItemDetailsViewModel>();
            services.AddTransient<CycleCountsHomeViewModel>();
        }

        private static void RegisterViews(IServiceCollection services)
        {
            // Common Views
            services.AddTransient<PageFactory>();
            
            // Authentication Views
            services.AddTransient<SSOLoginView>();
            services.AddTransient<SSOLoginTabletView>();
            services.AddTransient<LoginView>();
            services.AddTransient<LoginTabletView>();
            
            // QR/Barcode Views
            services.AddTransient<QRScanView>();
            services.AddTransient<ZxingQRScanView>();
            services.AddTransient<ConfigManualEntryView>();
            services.AddTransient<QRScanTabletView>();
            services.AddTransient<ZxingQRScanTabletView>();
            services.AddTransient<ConfigManualEntryTabletView>();
            services.AddTransient<ScanditQRScanView>();
            services.AddTransient<ScanditQRScanTabletView>();
            
            // Main Application Views
            services.AddTransient<TodaysTaskListView>();
            services.AddTransient<MainMenuView>();
            services.AddTransient<UserInfoSettingsView>();
            services.AddTransient<SettingsView>();
            services.AddTransient<ProductionPlanHomeView>();
            services.AddTransient<ProductionPlanCompleteView>();
            services.AddTransient<ProductionPlanStartView>();
            services.AddTransient<RecipeListView>();
            services.AddTransient<RecipeDetailsView>();
            services.AddTransient<RecipeQuantityEnterPopupView>();
            services.AddTransient<RecipeVideoPlayerView>();
            services.AddTransient<RecipeInstructionsView>();
            services.AddTransient<ItemLookupView>();
            services.AddTransient<ItemDetailsView>();
            services.AddTransient<ItemLookupScannerView>();
            services.AddTransient<TraceabilityView>();
            services.AddTransient<TraceabilityPlanView>();
            services.AddTransient<GrindBarcodeScannerView>();
            services.AddTransient<CustomerRequestView>();
            services.AddTransient<SelectGrindOptionsView>();
            services.AddTransient<CustomOrdersListView>();
            services.AddTransient<CreateCustomOrderView>();
            services.AddTransient<TodaysTaskListTabletView>();
            services.AddTransient<MainMenuTabletView>();
            services.AddTransient<ItemLookupTabletView>();
            services.AddTransient<ItemDetailsTabletView>();
            services.AddTransient<TraceabilityTabletView>();
            services.AddTransient<TraceabilityPlanTabletView>();
            services.AddTransient<SelectGrindOptionsTabletView>();
            services.AddTransient<GrindWeightTabletView>();
            services.AddTransient<GrindBarcodeScannerTabletView>();
            services.AddTransient<CustomerRequestTabletView>();
            services.AddTransient<CleanGrindTabletView>();
            services.AddTransient<ManualEntryView>();
            services.AddTransient<ProductionPlanHomeTabletView>();
            services.AddTransient<ProductionPlanCompleteTabletView>();
            services.AddTransient<ProductionPlanStartTabletView>();
            services.AddTransient<PLUSearchTabletView>();
            services.AddTransient<RecipeListTabletView>();
            services.AddTransient<RecipeDetailsTabletView>();
            services.AddTransient<RecipeQuantityEnterPopupTabletView>();
            services.AddTransient<RecipeInstructionsTabletView>();
            services.AddTransient<InventoryAdjustmentTabletView>();
            services.AddTransient<InventoryAdjustmentItemDetailsTabletView>();
            services.AddTransient<ReviewAdjustmentTabletView>();
            services.AddTransient<ReviewAdjustmentView>();
            services.AddTransient<InventoryAdjustmentView>();
            services.AddTransient<InventoryAdjustmentItemDetailsView>();
            services.AddTransient<PLUSearchView>();
            services.AddTransient<CategoryItemDetailsView>();
            services.AddTransient<MTOReviewView>();
            services.AddTransient<ProductionPlanItemView>();
            services.AddTransient<ProductionPlanItemMainPopupView>();
            services.AddTransient<ProductionPlanItemRecipeView>();
            services.AddTransient<UserInfoSettingsTabletView>();
            services.AddTransient<PrepView>();
            services.AddTransient<ConfirmOrderDetailsView>();
            services.AddTransient<TransfersListView>();
            services.AddTransient<TransfersListTabletView>();
            services.AddTransient<ReceiveTransferListView>();
            services.AddTransient<ReceiveTransferListTabletView>();
            services.AddTransient<TransferQuantityEnterPopupTabletView>();
            services.AddTransient<TransferQuantityEnterPopupView>();
            services.AddTransient<TransferScanTabletView>();
            services.AddTransient<TransferScanView>();
            services.AddTransient<TransferReviewListTabletView>();
            services.AddTransient<TransferReviewListView>();
            services.AddTransient<StoreWalksView>();
            services.AddTransient<StoreWalksTabletView>();
            services.AddTransient<StoreWalkListView>();
            services.AddTransient<TaskActivityListView>();
            services.AddTransient<TaskActivityStepsView>();
            services.AddTransient<CutTestReviewtemDetailsTabletView>();
            services.AddTransient<CutTestScanDetailsTabletView>();
            services.AddTransient<CutTestStartTabletView>();
            services.AddTransient<CutTestTaskTabletView>();
            services.AddTransient<CutTestTaskView>();
            services.AddTransient<CutTestStartView>();
            services.AddTransient<CutTestScanDetailsView>();
            services.AddTransient<CutTestReviewtemDetailsView>();
            services.AddTransient<TaskActivityListTabletView>();
            services.AddTransient<MenuSettingsView>();
            services.AddTransient<ProductionPlanUpdateModifyQtyPopupView>();
            services.AddTransient<ProductionPlanCommissaryView>();
            services.AddTransient<ProductionPlanLabelQtyPopupView>();
            services.AddTransient<ProductionPlanOnHandPopupView>();
            services.AddTransient<PrintersPopupView>();
            services.AddTransient<MenuSettingsTabletView>();
            services.AddTransient<ProductionPlanUnLabeledQtyPopupView>();
            services.AddSingleton<UpShopActivityIndicatorView>();
            services.AddTransient<PrepTabletView>();
            services.AddTransient<PrepStepDetailsTabletView>();
            services.AddTransient<PrepItemDetailsPopupTabletView>();
            services.AddTransient<PrepItemConsolidatedDetailsTabletView>();
            services.AddTransient<PrepHeaderView>();
            services.AddTransient<PrepStepDetailsView>();
            services.AddTransient<PrepItemDetailsPopupView>();
            services.AddTransient<PrepItemConsolidatedDetailsView>();
            services.AddTransient<SignatureTaskView>();
            services.AddTransient<SignatureTaskTabletView>();
            services.AddTransient<SignatureTaskVerificationView>();
            services.AddTransient<ProductionPlanPickListTabletView>();
            services.AddTransient<InvoicesMainView>();
            services.AddTransient<AddInvoiceItemView>();
            services.AddTransient<CompleteInvoiceView>();
            services.AddTransient<CreateInvoiceView>();
            services.AddTransient<CreateReturnInvoiceView>();
            services.AddTransient<FinalizeReturnInvoiceView>();
            services.AddTransient<InvoiceItemDetailsView>();
            services.AddTransient<InvoiceItemExceptionView>();
            services.AddTransient<InvoiceTotalCountView>();
            services.AddTransient<ReturnInvoiceItemDetailsView>();
            services.AddTransient<SupplierConfirmPopUpView>();
            services.AddTransient<SupplierView>();
            services.AddTransient<TemperatureCheckCaptureView>();
            services.AddTransient<TemperatureCheckStepsTabletView>();
            services.AddTransient<TemperatureCheckStepsView>();
            services.AddTransient<MarkdownListView>();
            services.AddTransient<ReasonCodesPopupView>();
            services.AddTransient<PrintersPopupTabletView>();
            services.AddTransient<OrdersTodayHomeView>();
            services.AddTransient<OrderItemDetailsView>();
            services.AddTransient<OrderKeypad>();
            services.AddTransient<AddOrderContentView>();
            services.AddTransient<OrderItemDetailsContentView>();
            services.AddTransient<OrderItemHistoryContentView>();
            services.AddTransient<OrderItemMovementForecastContentView>();
            services.AddTransient<OrderItemMovementHistoryContentView>();
            services.AddTransient<OrderItemPromotionsContentView>();
            services.AddTransient<SubmitOrderContentView>();
            services.AddTransient<AddOrderPopUpView>();
            services.AddTransient<AddOrderView>();
            services.AddTransient<OrderDetailsView>();
            services.AddTransient<OrderingView>();
            services.AddTransient<OrderQtyUpdateView>();
            services.AddTransient<OrdersTodayHomeTabletView>();
            services.AddTransient<OrderItemDetailsTabletView>();
            services.AddTransient<CycleCountsHomeView>();
        }
    }
}