﻿using MobileUI2.Services.Navigation;
using MonkeyCache.LiteDB;
using MobileUI2.Services;
using MobileUI2.Resources;
using MobileUI2.Models;
using MobileUI2.Models.PushNotification;
using MobileUI2.Services.Login;
using System.Text.Json;
using Application = Microsoft.Maui.Controls.Application;
using System.Globalization;

namespace MobileUI2
{
    public partial class App : Application
    {
        //  private NotificationHubClient hub;
        public static IServiceProvider? _serviceProvider;


        public App(IServiceProvider serviceProvider)
        {
            InitializeComponent();
            _serviceProvider = serviceProvider;

            if (DeviceInfo.Idiom != DeviceIdiom.Tablet)
                GlobalSettings.IsTabletDevice = false;
            else
                GlobalSettings.IsTabletDevice = true;


            if (CultureInfo.CurrentCulture.Name.ToLowerInvariant().Equals("es-us"))
            {
                var culture = new CultureInfo("es-MX");

                // Set the culture for the entire app
                CultureInfo.DefaultThreadCurrentCulture = culture;
                CultureInfo.DefaultThreadCurrentUICulture = culture;

                // If you are using AppResources, update the culture for resource loading
                AppResources.Culture = culture;
            }
            Barrel.ApplicationId = AppInfo.Name;
            LiteralTranslator.Initialize(_serviceProvider);
            LiteralTranslator.JsonInitialize();           
        }

        protected override Window CreateWindow(IActivationState? activationState)
        {
            MainThread.BeginInvokeOnMainThread(async () =>
               {
                   var navigationService = _serviceProvider.GetService<INavigationService>();
                   await navigationService.InitializeAsync();
               });

            if (App.Current.MainPage == null)
            {
                MainThread.BeginInvokeOnMainThread(() =>
                {
                    var task = Task.Run(async () => await InitiateUI());
                    task.Wait();
                });
            }

            return new Window(App.Current.MainPage);
        }

        private async Task InitiateUI()
        {
            var navigationService = _serviceProvider.GetService<INavigationService>();
            await navigationService.InitializeAsync();
        }

        protected override async void OnStart()
        {
            //await InitNavigation();
            PendoInit();
            await CacheQDTypes.UpdateCacheQDTypes(_serviceProvider);
            CheckDeviceStatus.ConnectDevice();
            await ConnectToSignalR();
            base.OnStart();
        }

        private void PendoInit()
        {
            var pendoService = _serviceProvider.GetService<IPendoCustomService>();
            pendoService.PendoSetup();
        }
        protected override void OnSleep()
        {
            RequestedThemeChanged -= App_RequestedThemeChanged;
        }
        public static event EventHandler Resumed;
        protected override async void OnResume()
        {
            Resumed?.Invoke(this, EventArgs.Empty);
            await ConnectToSignalR();
            RequestedThemeChanged += App_RequestedThemeChanged;
        }
        private async Task ConnectToSignalR()
        {
            var sr = _serviceProvider.GetService<ISignalRService>();
            await sr.ConnectAsync();
        }
        private void App_RequestedThemeChanged(object sender, AppThemeChangedEventArgs e)
        {
            MainThread.BeginInvokeOnMainThread(() =>
            {
                AppTheme.SetTheme();

            });
        }

        private async void RemoveNotifications()
        {
            try
            {
                if (GlobalSettings.Instance.IsAppConfigured)
                {
                    var notificationToken = Preferences.Get("NotificationToken", string.Empty);
                    if (string.IsNullOrWhiteSpace(notificationToken))
                        return;

                    var loginService = _serviceProvider.GetService<ILoginService>();
                    var request = new DeviceRegistrationRequest
                    {
                        DeviceRegistrationToken = notificationToken
                    };
                    await loginService.RemoveDeviceRegistrationForPushNotifications(request);
                    Preferences.Clear("NotificationToken");
                }
            }
            catch (Exception e)
            {

            }
        }

        private async void AddNotifications(string notificationToken)
        {
            try
            {
                if (GlobalSettings.Instance.IsAppConfigured)
                {
                    var userData = Preferences.Get(GlobalSettings.UserData, null);
                    if (string.IsNullOrWhiteSpace(userData))
                        return;
                    var user = JsonSerializer.Deserialize<UserInfo>(userData);
                    var loginService = _serviceProvider.GetService<ILoginService>();
                    var request = new DeviceRegistrationRequest
                    {
                        UserId = user.UserId ?? 0,
                        DeviceRegistrationToken = notificationToken
                    };
                    await loginService.DeviceRegistrationForPushNotifications(request);
                }
            }
            catch (Exception e)
            {

            }
        }

        //To do Firebase
        //private void InitializeDeviceSpecificAddIns()
        //{
        //    CrossFirebasePushNotification.Current.OnTokenRefresh += (s, p) =>
        //    {
        //        System.Diagnostics.Debug.WriteLine($"TOKEN : {p.Token}");
        //        if (Preferences.ContainsKey("NotificationToken"))
        //        { 
        //            RemoveNotifications();
        //        }
        //        AddNotifications(p.Token);
        //        Preferences.Set("NotificationToken",p.Token);
        //    };

        //    CrossFirebasePushNotification.Current.OnNotificationReceived += (s, p) =>
        //    {
        //        System.Diagnostics.Debug.WriteLine("Received");
        //    };

        //    CrossFirebasePushNotification.Current.OnNotificationOpened += (s, p) =>
        //    {
        //        System.Diagnostics.Debug.WriteLine("Opened");
        //        foreach (var data in p.Data)
        //        {
        //            System.Diagnostics.Debug.WriteLine($"{data.Key} : {data.Value}");
        //        }
        //    };

        //    CrossFirebasePushNotification.Current.OnNotificationAction += (s, p) =>
        //    {
        //        System.Diagnostics.Debug.WriteLine("Action");

        //        if (!string.IsNullOrEmpty(p.Identifier))
        //        {
        //            System.Diagnostics.Debug.WriteLine($"ActionId: {p.Identifier}");
        //            foreach (var data in p.Data)
        //            {
        //                System.Diagnostics.Debug.WriteLine($"{data.Key} : {data.Value}");
        //            }
        //        }
        //    };

        //    CrossFirebasePushNotification.Current.OnNotificationDeleted += (s, p) =>
        //    {
        //        System.Diagnostics.Debug.WriteLine("Deleted");
        //    };
        //}
    }
}