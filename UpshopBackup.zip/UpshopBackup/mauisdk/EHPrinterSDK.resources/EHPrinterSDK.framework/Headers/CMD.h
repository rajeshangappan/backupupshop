//
//  CMD.h
//  EHPrinterSDK
//
//  Created by RTApple on 2021/2/8.
//  Copyright © 2021 vsir. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "EHDefine.h"

NS_ASSUME_NONNULL_BEGIN

@interface CMD : NSObject

/*!
 获取初始化实例
 get instance
 @param encoding please use EHPrinterEncodingUTF8
 */
+ (instancetype)getInstanceByEncoding:(EHPrinterEncoding)encoding;

/*!
 获取编码
 get encode, No need to use
 */
- (EHPrinterEncoding)encoding;

/*!
 拼接新的命令
 append cmd data
 */
- (void)appendCMD:(NSData *)cmd;

/*!
 返回搜所有的指令数据
 get cmd data
 */
- (NSData *)data;

/*!
 自测页指令
 print self test page
 */
+ (NSData *)selfTestCMD;

/*!
 回车
 \r
 */
+ (NSData *)crCMD;

/*!
 换行
 \n
 */
+ (NSData *)lfCMD;

/*!
 回车换行
 \r\n
 */
+ (NSData *)crLfCMD;

/*!
 get printer state
 */
+ (NSData *)getPrinterState;

/*!
 询问是否打印成功，返回$80
 */
+ (NSData *)askPrintOkCMD;

/*!
 设置XY轴
 set x,y axios
 */
+ (NSData *)setPointCMDByX:(int)x andY:(int)y;

/*! 黑标设置 */
+ (NSData *)blackLabelPlusCMD:(int)plus;

/*! 黑标设置 */
+ (NSData *)blackLabelSubCMD:(int)sub;

/*! 打印机版本 */
+ (NSData *)printerVersion;

/** 蓝牙版本 */
+ (NSData *)bleVersion;


+ (NSData *)firmware:(NSData *)fileData;

+ (NSData *)fontHeaderByFileName:(NSString *)fileName fileLength:(NSUInteger)fileLength;
+ (NSArray<NSData *> *)fontBodyData:(NSData *)fileData;

@end

NS_ASSUME_NONNULL_END
