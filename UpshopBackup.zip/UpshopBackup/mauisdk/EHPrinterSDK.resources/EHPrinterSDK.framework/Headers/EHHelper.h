//
//  EHHelper.h
//  EHPrinterSDK
//
//  Created by RTApple on 2021/2/23.
//  Copyright © 2021 vsir. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "EHDefine.h"

NS_ASSUME_NONNULL_BEGIN

@interface EHHelper : NSObject

+ (EHCoordinate)makeCoordinateByX:(NSInteger)x
                                y:(NSInteger)y
                            width:(NSInteger)width
                           height:(NSInteger)height;

@end

NS_ASSUME_NONNULL_END
