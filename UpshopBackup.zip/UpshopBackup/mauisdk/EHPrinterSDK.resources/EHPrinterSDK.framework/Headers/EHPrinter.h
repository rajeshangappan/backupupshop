//
//  EHPrinter.h
//  EHPrinterSDK
//
//  Created by RTApple on 2020/9/2.
//  Copyright © 2020 vsir. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "EHDefine.h"
#import "EHBLEDevice.h"


NS_ASSUME_NONNULL_BEGIN

typedef void (^WriteAuthorizeBlock)(BOOL isSuccessWrite,  NSError * _Nullable error);

#pragma mark -  protocol Methods
@protocol EHPrinterDelegate <NSObject>

@optional
/*!
 返回蓝牙状态
 Return  Bluetooth status from here
 @param state see EHPrinterSystemState
 */
- (void)ehPrinterSystemState:(EHPrinterSystemState)state;
/*!
 找到设备
 Find the bluetooth device
 @param device EHBLEDevice object
 */
- (void)ehPrinterDeviceFound:(EHBLEDevice *)device;
///
/*!
 连接成功
 Connect to bluetooth device success
 @param device EHBLEDevice object
 */
- (void)ehPrinterDidConnectDevice:(EHBLEDevice *)device;
/*!
 连接失败
 Connect to bluetooth device failed
 @param device EHBLEDevice object
 @param error print
 */
- (void)ehPrinterDidFailToConnectDevice:(EHBLEDevice *)device error:(nullable NSError *)error;
/*!
 连接断开，
 如果 error.domain == NSCocoaErrorDomain  && error.code == 8585，是因为调用 searchConnectedDeviceAndConnectByUUID:maxSecond: 导致自动断开当前连接的。根据个人需求，是否需要显示不同提示语。
 
 Disconnected,
 If error.domain == NSCocoaErrorDomain  && error.code == 8585, because calling searchconnecteddeviceandconnectbyuuid:maxsecond: automatically disconnects the current connection. Whether different prompts need to be displayed according to individual needs.
 
 disconnect to bluetooth device
 @param device EHBLEDevice object
 @param error print
 */
- (void)ehPrinterDidDisconnectDevice:(EHBLEDevice *)device error:(nullable NSError *)error;
/*!
 初始化完毕，可以开始进行数据发送了
 After initialization, you can start sending data
 */
- (void)ehPrinterDidReadyToSendData;
/*!
 接收数据
 receive printer data
 @param revData NSData object
 */
- (void)ehPrinterDidDataReceived:(nonnull NSData *)revData;

/*!
 发送的数据长度
 sent data length
 */
- (void)ehPrinterDidSendDataLength:(NSInteger)length;

/*!
 升级进度回调 ( 你也可以通过 ehPrinterDidSendDataLength: 计算 )
 update printer progress ( You can also calculate by ehprinterdidsenddatalength: )
 @param progress 0.00-1.00
 */
- (void)ehPrinterUpdateProgress:(float)progress;


/*!
 升级字体进度回调 ( 你也可以通过 ehPrinterDidSendDataLength: 计算 )
 update printer font progress ( You can also calculate by ehprinterdidsenddatalength: )
 @param progress 0.00-1.00
 */
- (void)ehPrinterUpdateFontProgress:(float)progress;

/*!
 搜索连接过的设备超时
 Searching for connected devices timed out
 @param uuid uuid
 */
- (void)ehPrinterSearchConnectedDeviceOvertime:(NSString *)uuid;


@end






#pragma mark -  common Methods
@interface EHPrinter : NSObject
/*!
 连接的设备（数据没有持久化）
 Connected devices（Data is not persistent）
 */
@property (nonatomic, strong)  EHBLEDevice * _Nullable connectDevice;

/*!
 单例
 get  single instance
 */
+ (EHPrinter *)shared;

/*!
 登陆账号
 sign in account
 */
- (void)signInUserName:(NSString*)userName
        labelSecretKey:(NSString*)labelSecretKey
             labelSize:(NSString*)labelSize;

/*!
 退出当前账号,并断开当前连接
 sign out account and disconnect the current connection
 */
- (void)signOut;

/*!
 初始化蓝牙
 init bluetooth
 @param delegate use delegate to process data
 */
- (void)initWithDelegate:(id<EHPrinterDelegate>)delegate;
/*!
 设置MTU长度（一般不需要设置）
 set mtu bytes length  ( Usually no setting is required )
 @param mtuLength bytes length
 */
- (void)setMTULength:(NSInteger)mtuLength;
/*!
 设置MTU延时毫秒（一般不需要设置）
 set mtu delay millisecond ( Usually no setting is required )
 */
- (void)setMTUDelay:(NSInteger)mtuDelay;
/*!
 扫描附近蓝牙
 scan nearby bluetooth
 */
- (void)scan;
/*!
 停止扫描
 stop scan
 */
- (void)stopScan;
/*!
 连接蓝牙设备
 Connecting Bluetooth devices
 @param device  device EHBLEDevice object
 */
- (void)connect:(EHBLEDevice *)device;
/*!
 断开蓝牙连接
 Disconnecting Bluetooth devices
 @param device  device EHBLEDevice object
 */
- (void)disconnect:(EHBLEDevice *)device;

/*!
 上次连接的蓝牙外设的UUIDString（数据持久化）
 UUIDString of the last connected Bluetooth peripheral（Data Persistence）
 UUIDString,没有时返回nil
 return nil when not available
 */
+ (NSString *)UUIDStringForLastPeripheral;

/*!
 搜索UUID设备并连接
       1、在搜索期间，再次调用该方法，会自动结束上次搜索的uuid，开始新的搜索。
       2、在搜索期间，调用connect:，会自动结束上次搜索的uuid，连接 connect 的 EHBLEDevice。
       3、如果 connectdevice != nil，且 search uuid ==  connectdevice.peripheral.identifier.UUIDString , 将快速返回连接成功
        4、如果 connectdevice != nil，且 search uuid !=  connectdevice.peripheral.identifier.UUIDString , 将自动断开当前设备，搜索uuid设备
 
 Search UUID device and connect
    1. During the search, calling this method again will automatically end the UUID of the previous search and start a new search.
    2. During the search, call connect:, which will automatically end the UUID of the last search and connect the EHBLEDevice of connect: .
    2. If connectdevice != nil, and search uuid ==  connectdevice.peripheral.identifier.UUIDString, which will quickly return the connection success
    3. If connectdevice != nil, and  search uuid !=  connectdevice.peripheral.identifier.UUIDString will automatically disconnect the current device and search for uuid device
 
 @param uuid  uuid
 @param maxSecond  0 ~  NSIntegerMax
                  0:  keep searching until find , you can call cancelSearchConnectedDevice stop, or when you call connect: and scan method,  search will also stop
                  > 0, when timing ends and not find, the search is automatically stopped and  ehPrinterSearchConnectedDeviceOvertime:  is called back
 */
- (void)searchConnectedDeviceAndConnectByUUID:(NSString *)uuid maxSecond:(NSUInteger)maxSecond;

/*!
 取消搜索连接过的设备
 Cancel search for connected devices
 */
- (void)cancelSearchConnectedDevice;

/*!
 发送数据
 send data to bluetooth devices
 @param data  NSData object
 */
- (void)write:(NSData *)data writeBlock:(WriteAuthorizeBlock)writeBlock;

/*!
 获取蓝牙状态
 Get Bluetooth status
 */
- (EHPrinterSystemState)state;

/*!
 取消打印
 cancel print
 */
- (void)cancelPrint;

/*!
 设置纸张类型 0～2（0:连续纸 1:标签纸 2:黑标）
 Set paper type  0～2 (0: continuous paper 1: label paper 2: Black Label)
 */
- (void)setPaperType:(NSInteger)type;

/*!
 设置速度 0～9
 Set speed  0～9
 */
- (void)setSpeed:(NSInteger)speed;

/*!
 设置浓度 0～15
 Set density 0 ~ 15
 */
- (void)setDensity:(NSInteger)density;


@end







#pragma mark - UpdataPrinter Methods
@interface EHPrinter (UpdataPrinter)

/*!
 判断固件是否匹配当前打印机(在updatePrinterFirmwareWithData:已判断过)
 Determine whether the firmware matches the current printer(It has been judged in method updatePrinterFirmwareWithData:)
 return false, can't update printer firmware,change other bin file. or  no printer is connected at this time
 */
- (BOOL)checkCurrentPrinterIsMatchFirmwareData:(NSData*)data;

/*!
 升级打印机固件
 update printer firmware
 return false, maybe BLEDevice no match bin file, maybe No Bluetooth device is connected at this time
 return true, The upgrade is not complete, but is in progress. get progress by ehPrinterUpdateProgress: call back method
 
 */
- (BOOL)updatePrinterFirmwareWithData:(NSData*)data;


/*!
 升级打印机字体
 update printer font
 return false, maybe No Bluetooth device is connected at this time
 return true, The upgrade is not complete, but is in progress. get progress by ehPrinterUpdateFontProgress: call back method
 
 */
- (BOOL)updatePrinterFontName:(NSString*)name withFontData:(NSData*)fontData;

@end






#pragma mark - ReadPrinterInfo Methods
@interface EHPrinter (ReadPrinterInfo)
/*!
 发送获取打印机参数指令
 Send command to get printer parameters
 */
- (void)sendGetPrinterInfoCmdWithType:(PrinterInfoType)type;


- (PrinterInfoType)getPrinterInfoByReceivedData:(NSData *)revData
                                       saveData:(NSData*_Nonnull*_Nullable)saveData
                                     saveString:(NSString*_Nonnull*_Nullable)saveString;

/*!
 判断设备芯片
 Judgment device chip
 */
- (EHChipType)getPrinterChipTypeByPrinterVersionString:(NSString *)version;



/*!
 是否查询打印状态
 is Printer Prints Done Report
 */
- (BOOL)isQueryPrinterReportStateByRevertData:(NSData*)revData;

/*!
 是否打印完成事件
 is Printer Prints Done Report State
 */
- (BOOL)isPrinterPrintsDoneReportStateByRevertData:(NSData*)revData;

@end

NS_ASSUME_NONNULL_END


