//
//  EHStateEnum.h
//  EHPrinterSDK
//
//  Created by RTApple on 2020/9/8.
//  Copyright © 2020 vsir. All rights reserved.
//

#ifndef EHStateEnum_h
#define EHStateEnum_h

#import <CoreBluetooth/CoreBluetooth.h>

typedef NS_ENUM(NSUInteger, EHPrinterSystemState) {
    EHPrinterSystemStatePoweredOn = CBCentralManagerStatePoweredOn, // bluetooth poweron 设备开启状态 -- 可用状态
    EHPrinterSystemStatePoweredOff = CBCentralManagerStatePoweredOff, // bluetooth poweroff  设备关闭状态
    EHPrinterSystemStateResetting = CBCentralManagerStateResetting, // bluetooth resetting 正在重置状态
    EHPrinterSystemStateUnauthorized = CBCentralManagerStateUnauthorized, // bluetooth unauthorized 设备未授权状态
    EHPrinterSystemStateUnknown = CBCentralManagerStateUnknown, //bluetooth unknown 初始的时候是未知的
    EHPrinterSystemStateUnsupported = CBCentralManagerStateUnsupported, // bluetooth unsupported 设备不支持的状态
};

typedef NS_ENUM(NSUInteger, EHPrinterBLEType) {
    EHPrinterBLETypeCommon, //common bluetooth 通用蓝牙
    EHPrinterBLETypeBarrot, // barrot bluetooth 百瑞互联（原IVT）
    EHPrinterBLETypeFeasycom, // feasy bluetooth 飞易通
};

typedef NS_ENUM(NSUInteger, EHChipType) {
    EHChipTypeError,            //  unknown chip or error data from printer
    EHChipTypeNXP,              //  old chip printer
    EHChipTypeGD                //  new chip printer
};

typedef NS_ENUM(NSUInteger, EHPrinterEncoding) {
    EHPrinterEncodingGBK, // GBK 编码
    EHPrinterEncodingUTF8, // UTF8 编码
};

/** ZPL 字体 */
typedef NS_ENUM(NSUInteger, EHZPLFontType) {
    EHZPLFontTypeVector = 0,//矢量字体 Vector font
    EHZPLFontTypeFont1 = 1,
    EHZPLFontTypeFont2 = 2,
    EHZPLFontTypeFont3 = 3,
    EHZPLFontTypeFont4 = 4,
    EHZPLFontTypeFont5 = 5,
    EHZPLFontTypeFont6 = 6,
    EHZPLFontTypeFont7 = 7,
    EHZPLFontTypeFont8 = 8,
    EHZPLFontTypeFont9 = 9,
    EHZPLFontTypeFontA = 10, //A
    EHZPLFontTypeFontB = 11, //B
    EHZPLFontTypeFontC = 12, //C
    EHZPLFontTypeFontD = 13, //D
    EHZPLFontTypeFontE = 14, //E
    EHZPLFontTypeFontF = 15, //F
    EHZPLFontTypeFontG = 16, //G
};

typedef NS_ENUM(NSUInteger, EHRotationDegrees) {
    EHRotationDegrees0      = 0,
    EHRotationDegrees90     = 1,
    EHRotationDegrees180    = 2,
    EHRotationDegrees270    = 3,
};

/*!
 错误纠正能力等级
 Error correction level
 */

typedef NS_ENUM(NSUInteger, EHECCLevel) {
    /*!%7*/
    EHECCLevelL,
    /*!%15*/
    EHECCLevelM,
    /*!%25*/
    EHECCLevelQ,
    /*!30%*/
    EHECCLevelH,
};

typedef NS_ENUM(NSUInteger, EHBarcodeHRIPosition) {
    EHBarcodeHRIPositionNone    = 0, // do not show barcode content
    EHBarcodeHRIPositionShow    = 1, // show barcode content
};

/*!
 条码类别 barcode type
 */

typedef NS_ENUM(NSUInteger, EHBarcodeType) {
    EHBarcodeTypeUPCA       = 0,
    EHBarcodeTypeUPCE       = 1,
    EHBarcodeTypeEAN13      = 2,
    EHBarcodeTypeEAN8       = 3,
    EHBarcodeTypeCODE39     = 4,
    EHBarcodeTypeITF        = 5,
    EHBarcodeTypeCODABAR    = 6,
    EHBarcodeTypeCODE128    = 7,
    EHBarcodeTypeQRCODE     = 8,
    EHBarcodeTypeCODE93     = 9,
};

typedef NS_ENUM(NSInteger, EHBarcodeErrorCode) {
    EHBarcodeErrorCodeOK            = 0,
    EHBarcodeErrorCodeTooLong       = -1,
    EHBarcodeErrorCodeFormatError   = -2,
    EHBarcodeErrorCodeUnknownType   = -3,
    EHBarcodeErrorCodeTooShort      = -4,
};

/** 坐标 coordinate*/
typedef struct EHCoordinate {
    NSInteger x;
    NSInteger y;
    NSInteger width;
    NSInteger height;
} EHCoordinate;

/*!
 打印机状态询问命令
 printer Stauts enquiry
 */
typedef NS_ENUM(NSUInteger, EHPrinterState) {
    /*!
     未定义
     unknown
     */
    EHPrinterStateUnknown       = 0,
    /*!
     410询问打印机当前状态 for RP410, ZPL
     Printer status, such as paper jam, out of paper, open cover, etc.
     */
    EHPrinterStateHQPRNSTA410   = 1,
    /*!
     for Rpp806 TSC, for Rpp80 ESC
     打印机的状态，如卡纸，缺纸，开盖等
     Printer status, such as paper jam, out of paper, open cover, etc.
     */
    EHPrinterStateNormal        = 2,
    /*!
     for Rpp806 TSC
     已打印的里程单位：m
     Mileage printed: m
     */
    EHPrinterStateMileage       = 3,
    /*!
     for Rpp806 TSC
     打印机模块名，及系列号
     Printer module name, and serial number
     */
    EHPrinterStateModelName     = 4,
    /*!
     for Rpp806 TSC
     打印机内存大小:单位：Byte
     Printer memory size: unit: Byte
     */
    EHPrinterStateMemorySize    = 5,
    /*!
     for Rpp806 TSC
     打印成功,打印机自动返回
     The print is successful and the printer automatically returns
     */
    EHPrinterStatePrintEnd      = 6,
};

/*!
   标签打印方向(for TSC,CPCL,zpl)
   Label printing direction
 */
typedef NS_ENUM(NSUInteger, EHDirection) {
    EHDirectionForward = 0,
    EHDirectionReverse = 1,
};

typedef NS_ENUM(NSUInteger, EHDPI) {
    EHDPI200,
    EHDPI300,
};

/*!
 Priner report state
 */
typedef NS_OPTIONS(NSUInteger, EHPrinterReportState) {
    /*!
     机芯错误
     Printer movement error
     */
    EHPrinterReportStateMoveMentErr     = 0x01 << 0,
    /*!
     卡纸
     Paper jammed error
     */
    EHPrinterReportStatePaperJammed     = 0x01 << 1,
    /*!
     缺纸
     No Paper
     */
    EHPrinterReportStateNoPaper         = 0x01 << 2,
    /*!
     碳带用尽==>低电量
     Low power
     */
    EHPrinterReportStateLowPower        = 0x01 << 3,
    /*!
     打印机暂停
     Printer Pause
     */
    EHPrinterReportStatePrinterPause    = 0x01 << 4,
    /*!
     正在打印
     Printer is printing
     */
    EHPrinterReportStatePrinting        = 0x01 << 5,
    /*!
     开盖状态
     The printer's lid is open
     */
    EHPrinterReportStateLidOpened       = 0x01 << 6,
    /*!
     头片过热
     The printer is overheated
     */
    EHPrinterReportStateOverHeated      = 0x01 << 7,
    /*!
     打印准备就续
     Read to print
     */
    EHPrinterReportStatePrintReady      = 0x01 << 8,
};


/*!
 打印机参数
 Printer parameters
 */
typedef NS_ENUM(NSInteger, PrinterInfoType) {
    PrinterInfoTypeUnknown= -1,
    
    PrinterInfoTypePrinterModel = 1,
    PrinterInfoTypeSN = 2,
    PrinterInfoTypePrinterVersion = 3,
    PrinterInfoTypeFontName = 4,
    PrinterInfoTypePrintLenth = 5,
    PrinterInfoTypePrinterStatus = 6,
    PrinterInfoTypePrintModel = 7,
    PrinterInfoTypeBootPosition = 8,    
    PrinterInfoTypeLabelHeight = 9,
    PrinterInfoTypePaperType = 10,
    PrinterInfoTypeErrorReprint = 11,
    PrinterInfoTypePreventStickyPaper = 12,
    PrinterInfoTypeSpecialLabel = 13,
    PrinterInfoTypeSpeed = 14,
    PrinterInfoTypeDensity = 15,
    PrinterInfoTypeXStart = 16,
    PrinterInfoTypeYStart = 17,
    PrinterInfoTypePrintStopPosition = 18,
    PrinterInfoTypeBleVersion= 20,
};



/*!
 打印机状态
 Printer Status
 */
typedef NS_OPTIONS(NSInteger, PrinterStatus) {
    PrinterStatusReady = 0x00,
    
    PrinterStatusErrRam         = 0x01 << 0,
    PrinterStatusErrOverHeated  = 0x01 << 1,
    PrinterStatusErrLidIsOpen   = 0x01 << 2,
    PrinterStatusErrNoPaper     = 0x01 << 3,
    PrinterStatusErrVoltage     = 0x01 << 4,
    PrinterStatusErrPaperStuck  = 0x01 << 5,
    PrinterStatusErrPrintPause  = 0x01 << 6,
};

/*!
 打印机模型
 Printer Model
 */
typedef NS_ENUM(NSInteger, PrinterModelType) {
    PrinterModelTypeThermal = 0x00,     //热敏
    PrinterModelTypeRibbon  = 0x01,     //碳带
};


/*!
 纸张类型
 Paper Type
 */
typedef NS_ENUM(NSInteger, PaperType) {
    PaperTypeContinousPaper     = 0x00,     //连续纸
    PaperTypeLabelPaper         = 0x01,     //标签纸
    PaperTypeBlackMarkPaper     = 0x02,     //黑标纸
};


#endif /* EHStateEnum_h */
