//
//  ZPLTextSetting.h
//  EHPrinterSDK
//
//  Created by RTApple on 2021/2/18.
//  Copyright © 2021 vsir. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "EHDefine.h"

NS_ASSUME_NONNULL_BEGIN

@interface ZPLTextSetting : NSObject
/*! font type */
@property (nonatomic, assign) EHZPLFontType fontType;
/*! text height */
@property (nonatomic, assign) NSUInteger heihtFactor;
/*! text width */
@property (nonatomic, assign) NSUInteger widthFactor;

/// text left top x axios (in points)
@property (nonatomic, assign) NSInteger leftTopX;
/// text left top y axios (in points)
@property (nonatomic, assign) NSInteger leftTopY;

/*!旋转度数
 Degree of rotation
 */
@property (nonatomic, assign) EHRotationDegrees rotationDegrees;

@end

NS_ASSUME_NONNULL_END
