//
//  EHBarcodeSetting.h
//  EHPrinterSDK
//
//  Created by RTApple on 2021/2/19.
//  Copyright © 2021 vsir. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "EHDefine.h"

NS_ASSUME_NONNULL_BEGIN

@interface EHBarcodeSetting : NSObject

/*!条码字符的位置
 The location of barcode characters
 */
@property (nonatomic, assign) EHBarcodeHRIPosition barcodeHRIPosition;
/*!旋转度数
 Degree of rotation
 */
@property (nonatomic, assign) EHRotationDegrees rotationDegrees;
/*!
  条码的坐标
  ESC->coord.height   Default:162
  ESC->coord.width <coord.width<=6  Default:3
  ESC->coord.x  0=<coord.x<=255 Default 0
  TSC->QRcode 1=<coord.widh<=10
 */
@property (nonatomic, assign) EHCoordinate coord;

@property (nonatomic, assign) EHECCLevel eccLevel;

/*!
 二维码放大系数1〜10  for zpl
 Two-dimensional code magnification factor 1 ~ 10
 */
@property (nonatomic, assign) NSInteger qrcodeDotSize;

@end

NS_ASSUME_NONNULL_END
