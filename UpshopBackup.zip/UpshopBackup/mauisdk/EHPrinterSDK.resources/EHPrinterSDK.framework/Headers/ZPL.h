//
//  ZPL.h
//  EHPrinterSDK
//
//  Created by RTApple on 2020/9/15.
//  Copyright © 2020 vsir. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "CMD.h"
#import "EHBarcodeSetting.h"
#import "ZPLTextSetting.h"

NS_ASSUME_NONNULL_BEGIN

@interface ZPL : CMD

/*!
 获取初始化实例
 get instance
 @param encoding please use EHPrinterEncodingUTF8
 */
+ (instancetype)getInstanceByEncoding:(EHPrinterEncoding)encoding;

/*!
 ZPL 指令的开头
 ZPL command begin
 */
- (NSData *)beginCMD;
/*!
 ZPL 指令的结尾
 ZPL command end
 */
- (NSData *)endCMD;

/*!
 取消打印ZPL 指令
 cancel print ZPL command
 */
- (NSData *)cancelCMD;

/*!
 打印份数
 Number of copies printed
 @param printCopies Number of copies printed
 */
- (NSData *)printCopiesCMD:(NSUInteger)printCopies;
/*!
 设置打印机的浓度 0~15
 Set the printer's Denisty
 
 @param density 0〜15
 */
- (NSData *)densityCMD:(NSInteger)density;
/*!
 设置标签的尺寸
 @param width width of the label (in millimeter)
 @param height height of the label (in millimeter)
 @param dpi use EHDPI200
 */
- (NSData *)sizeCMDByWidth:(NSInteger)width height:(NSInteger)height dpi:(EHDPI)dpi;
/*!
 设置打印方向
 @param direction direction of the label print way
 */
- (NSData *)directionCMD:(EHDirection)direction;
/*
 * Draw Box
 * 画矩形
 *
 * @param x     box's x axis x轴
 * @param y     box's axis width y轴
 * @param width     box's width 矩形宽度
 * @param height    box's height 矩形高度
 * @param lineWidth line's width 线粗
 */
- (NSData *)drawBoxCMD:(NSInteger)x y:(NSInteger)y width:(NSInteger)width height:(NSInteger)height lineWidth:(NSInteger)lineWidth;
/*!
 获取图像打印数据
 get image cmd
 @param image UIImage object
 @param x start x axios (in millimeter)
 @param y start y axios (in millimeter)
 @param width (in millimeter)
 @param height (in millimeter)
 @param dpi use EHDPI200
 @param isDither better use NO for test,use YES for colorful image
 */
- (NSData *)imageCMD:(UIImage *)image
                   x:(NSInteger)x
                   y:(NSInteger)y
               width:(NSInteger)width
              height:(NSInteger)height
                 dpi:(EHDPI)dpi
            isDither:(BOOL)isDither;

/*!
 生成文字名命令
 get text cmd
 @param textSetting text setting
 @param content text content
 */
- (NSData *)textCMD:(ZPLTextSetting *)textSetting content:(NSString *)content;
/*!
 获取barcode命令
 get barcode cmd
 @param barcodeSetting barcode setting
 @param barcodeType  see EHBarcodeType
 @param content barcode content
 @param barcodeErrorCode see EHBarcodeErrorCode
 */
- (NSData *)barcodeCMD:(EHBarcodeSetting *)barcodeSetting
           barcodeType:(EHBarcodeType)barcodeType
               content:(NSString *)content
                 error:(EHBarcodeErrorCode *)barcodeErrorCode;

/*!
enable USB
 @param enable YES or NO
 */
- (NSData *)enableUSBCMD:(BOOL)enable;

@end

NS_ASSUME_NONNULL_END
