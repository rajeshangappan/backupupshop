//
//  EHBLEDevice.h
//  EHPrinterSDK
//
//  Created by RTApple on 2020/9/10.
//  Copyright © 2020 vsir. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreBluetooth/CoreBluetooth.h>

NS_ASSUME_NONNULL_BEGIN

@interface EHBLEDevice : NSObject

- (instancetype)initWithPeripheral:(CBPeripheral *)peripheral;
- (instancetype)init __attribute__((unavailable("Use initWithPeripheral")));
+ (instancetype)new  __attribute__((unavailable("Use initWithPeripheral")));

- (nullable CBPeripheral *)peripheral;
- (nullable NSString *)name;
- (nullable NSString *)uuidString;
- (nullable NSString *)macAddress;
- (nullable NSDictionary *)advertisementData;
- (int)rssi;

- (instancetype)initWithPeripheral:(CBPeripheral *)peripheral mac:(NSString*)mac;

@end

NS_ASSUME_NONNULL_END
