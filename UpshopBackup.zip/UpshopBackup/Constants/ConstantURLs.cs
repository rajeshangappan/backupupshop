﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2
{
    public static class ConstantURLs
    {
        //logins
        public static readonly string AuthLoginUrl = "auth/user/authenticate";
        public static readonly string GetUserDataUrl = "auth/mobileuser/get";
        public static readonly string ConfigValidate = "auth/config/validate";
        public static readonly string ChangeThemeUrl = "auth/user/savesettings";
        public static readonly string MobileTenantInfoUrl = "auth/tenant/mobiletenantinfo";
        public static readonly string RefreshTokenUrl = "auth/user/refresh";
        public static readonly string GetTimeZoneInfo = "masterdata/timezone/get";
        public static readonly string GetTokenForSelectedStore = "auth/accesstoken/get";
        public static readonly string RegisterPushNotifications = "rulesengine/pushnotifications/register";
        public static readonly string RemovePushNotifications = "rulesengine/pushnotifications/remove";

        public static readonly string GetDayMarkAccountId = "masterdata/daymarkid/get";
        public static readonly string GetReceivingTaxes = "dsd/receivingtaxes/get";

        //SignalR
        public static readonly string SignalRConnect = "masterdata/SignalRConnect";
        public static readonly string SignalRJoinGroup = "masterdata/signalr/addtogroup";
        public static readonly string SignalRRemoveGroup = "masterdata/signalr/removefromgroup";

        //Literals
        public static readonly string StringLiteralUrl = "masterdata/mobileliterals/get";


        //receipes
        public static readonly string RecipeSearch = "recipes/recipes/getbyfcc";
        public static readonly string RecipesbyGroup = "recipes/recipes/getbygroup";
        public static readonly string RecipesandTags = "recipes/recipes/getbyitemtag";
        public static readonly string GetRecipeData = "recipes/recipe/mobileview";

        //Production Plans
        public static readonly string PlanTodayGroupingByTagsGet = "productionplanning/plantodaygroupingbytags/get";
        public static readonly string getTodayplansUrl = "productionplanning/productionplan/todaygroupingmobile";
        public static readonly string ScheduledPlansByTagsMobileGet = "productionplanning/scheduledplansbytagsmobile/get";
        public static readonly string getUpComingUrl = "productionplanning/productionplan/getscheduledplansmobile";
        public static readonly string getPrepUrl = "productionplanning/productionplanitem/getprepstepsmobile";
        public static readonly string getTodaysTasksURL = "traceability/alltasks/view";
        public static readonly string updateItemOnHandURL = "productionplanning/productionplan/updateonhandinventoryquantity";
        public static readonly string updatePlanItemOnHand = "productionplanning/productionplan/updateplanitemonhandinventoryquantity";
        public static readonly string finalizePlanURL = "ProductionPlanning/productionplan/finalizeplan";
        public static readonly string updateItemForecastURL = "productionplanning/productionplanitem/UpdateForecastQtyMobile";
        public static readonly string updateUnLabeledQuantityURL = "productionplanning/productionplanitem/updateunlabeledquantity";
        public static readonly string GetPrepLabelPreintData = "labeling/preplabeldata/get";
        public static readonly string GetLabelPrintData = "labeling/labelprinting/getlabelprinterdata";
        public static readonly string GetLabelPrinters = "labeling/labelprinting/getprinters";
        public static readonly string DaymarkKeylabelValidationBaseUri = "https://menucommand-api-dev.azurewebsites.net/";
        public static readonly string DaymarkKeylabelValidationEndpoint = "api/KeyLabelValidation/ValidateKeyLabel";
        public static readonly string GetLabelPrintPlanReport = "labeling/labelprinting/getlabelprintplanreport";
        public static readonly string GetLabelPrintPrepItems = "labeling/labelprinting/getlabelprintprepitems";
        public static readonly string InsertTotalRecord = "labeling/labelprinting/inserttotalrecord";
        public static readonly string GetPlanItems = "ProductionPlanning/productionplan/getplanitems";
        public static readonly string reopenplan = "ProductionPlanning/productionplan/reopen";
        public static readonly string GetWorkstations = "ProductionPlanning/workstationsbystore/get";
        public static readonly string SaveUserWorkstation = "Masterdata/userworkstation/save";
        public static readonly string getPrepStepsURL = "productionplanning/productionplanitembyitemtags/getprepstepsmobile";
        public static readonly string GetMobilePickList = "productionplanning/picklist/getmobilepicklist";
        public static readonly string GetRecalculatedPlan = "productionplanning/productionplan/getrecalculatedplan";
        public static readonly string StartPlan = "productionplanning/productionplan/start";

        //prep
        public static readonly string startprepURL = "ProductionPlanning/productionplanitem/startprepstep";
        public static readonly string completeprepURL = "ProductionPlanning/productionplanitem/completeprepstep";
        public static readonly string updatePrepURL = "productionplanning/productionplanitem/updateprepstepqty";
        public static readonly string updatePrepSemiItemsURL = "ProductionPlanning/prepproduceditems/update";
        public static readonly string PrepOfflineSyncURL = "ProductionPlanning/productionplanitem/syncprodprepmobile";

        //Production plan Offlince Sync
        public static readonly string ProductionPlanOfflineSyncUrl = "productionplanning/productionplanitem/syncprodplanmobile";

        //Waste
        public static readonly string GetAdjustmentsList = "inventory/adjustment/getlist";
        public static readonly string GetAdjustmentReviewData = "inventory/adjustment/reviewadjustment";
        public static readonly string GetDepartmentsData = "inventory/departmentadjustmenttypes/get";
        public static readonly string GetAdjustmentBarcodeScan = "inventory/adjustment/getbarcodedatamobile";
        public static readonly string AddAdjustmentItem = "inventory/adjustment/additem";
        public static readonly string UpdateAdjustmentItem = "inventory/adjustment/updateAdjustmentQuantity";
        public static readonly string FinalizeAdjustment = "inventory/adjustment/finalizeAdjustment";
        public static readonly string GetInventoryStateList = "inventory/adjustment/getInventoryStatesForItem";
        public static readonly string CreateAdjustment = "inventory/adjustment/save";
        public static readonly string GetMaxConfig = "inventory/adjustment/getadjustmentconfigvalues";
        public static readonly string DeleteReviewItem = "inventory/adjustment/deleteadjustmentItem";
        public static readonly string ProcessOfflineAdjustmentRequests = "inventory/adjustment/processofflinerequests";
        public static readonly string GetBarcodes = "inventory/allbarcodes/get";
        public static readonly string DeleteAdjustment = "inventory/adjustment/delete";

        //CutTest
        public static readonly string GetCutTestList = "waste/cuttestschedule/getallforstoremobile";
        public static readonly string GetCutTestVendorItems = "waste/cuttestprimal/get";
        public static readonly string CutTestPrimalBarcodeScan = "waste/cuttestschedule/decodebarcode";
        public static readonly string StartCutTest = "waste/cuttestschedule/start";
        public static readonly string AddCutTestItems = "waste/cuttestitem/save";
        public static readonly string GetReviewCutTestItems = "waste/cuttestitem/review";
        public static readonly string CompleteCutTest = "waste/cuttestschedule/complete";
        public static readonly string LatestCutTestDetails = "waste/latestcuttestdetail/get";
        public static readonly string GeCutTestReviewItemDetails = "waste/cuttestdetaillist/list";
        public static readonly string DeleteCutTestReviewItem = "waste/cuttestdetaillist/delete";

        //Markdown
        public static readonly string GetMarkdownPrinters = "waste/markdown/getprinters";
        public static readonly string GetScanBarcodesForMarkdownMobile = "waste/markdown/scanbarcodemobile";
        public static readonly string SaveMarkdownLabel = "waste/markdownlabelprintdata/save";
        public static readonly string GetMarkdownsForStore = "waste/markdownsforstore/get";
        public static readonly string GetMarkdownLabelDataMobile = "waste/markdown/labeldatamobile";

        //Item lookup
        public static readonly string GetItemsByFCC = "inventory/items/getfccmobile";
        public static readonly string GetItemDetailsByBarcode = "recipes/items/getitembarcodemobile";
        public static readonly string UpdateInventoryQty = "recipes/iteminventory/update";

        //Ordering
        public static readonly string GetOrderDetailsById = "ordering/orderdetailsbyid/get";
        public static readonly string GetOrderingListURL = "ordering/OrdersGroupByItemTag/get";
        public static readonly string GetReviewItems = "ordering/orders/edit";
        public static readonly string UpdateStatus = "ordering/order/updatestatus";
        public static readonly string Updateorderitem = "ordering/multipleorder/update";
        public static readonly string UpdateQtys = "ordering/orders/updateqtys";
        public static readonly string GetTodayUpComingOrdersUrl = "ordering/orders/getlistformobile";
        public static readonly string GetOrderItemDetailsByIdUrl = "ordering/orderitemdetails/get";
        public static readonly string GetOrderItemHistoryDetailsUrl = "ordering/orderitemhistory/get";
        public static readonly string GetOrderItemPromotionsUrl = "ordering/itemspreviouspromotions/get";
        public static readonly string GetOrderItemMovementHistoryUrl = "ordering/itemmovementhistory/get";
        public static readonly string GetOrderItemForecastUrl = "ordering/itemmovementforecast/get";
        public static readonly string getOrderingSuppliers = "ordering/listofsuppliers/get";
        public static readonly string GetOrderingDepartments = "ordering/listofdepartments/get";
        public static readonly string CreateOnDemandOrderUrl = "ordering/orders/createondemandorder";
        public static readonly string GetScannedItemForOrder = "ordering/order/scanbarcode";
        public static readonly string GetOrderHeadersDetailsByIdUrl = "ordering/orderheaderbyId/get";
        public static readonly string GetItemTags = "ordering/orderitemtag/get";
        public static readonly string GetOrderItemInfoDetailsUrl = "ordering/ordersingleitemdetails/get";
        public static readonly string GetCurrentPromotionDetailUrl = "ordering/promotiondetail/get";


        //MTO
        public static readonly string GetCustomOrders = "inventory/orders/getall";
        public static readonly string GetCompletedCustomOrders = "inventory/orders/getcompleted";
        public static readonly string GetOrderItems = "inventory/items/getitemsformobile";
        public static readonly string GetCustomOrderItemDetails = "inventory/orders/get";
        public static readonly string GetCategoryItemDetails = "inventory/orders/getitem";
        public static readonly string GetCustomOrdersTablet = "inventory/orders/gettabletorders";
        public static readonly string ChangeCustomOrderItemStatus = "inventory/orders/itemstatus";
        public static readonly string CompleteCustomOrder = "inventory/orders/complete";
        public static readonly string GetAllCategoryItems = "inventory/orders/getitemsformobile";
        public static readonly string GetItemCategories = "inventory/orders/getgroups";
        public static readonly string GetCategoryItems = "inventory/orders/getitemsfromgroup";
        public static readonly string GetCategoryItemSearch = "inventory/orders/searchitems";
        public static readonly string savecustomorderFun = "inventory/orders/save";
        public static readonly string CustomorderOfflineSyncURL = "inventory/customorder/processofflinesync";
        public static readonly string GetMTOPrintData = "labeling/mtolabeldata/get";
        public static readonly string CompleteOrder = "inventory/orders/complete";
        public static readonly string ExportCustomOrderData = "labeling/labelprinting/exportcustomorder";
        public static readonly string ChangeOrderStatus = "inventory/orders/itemstatus";

        //Traceability
        public static readonly string GetGrindDetails = "traceability/grinddetails/get";
        public static readonly string GetLeanPointItems = "traceability/grind/getitemsbyleanpoint";
        public static readonly string GetOfflineVendorInfoForGrind = "traceability/packers/getallmobile";
        public static readonly string decodebarcodeURL = "traceability/tubegrind/decodebarcodemobile";
        public static readonly string getestablishmentsURL = "traceability/establishments/getall";
        public static readonly string submittrimlugitemURL = "traceability/trimlug/submit";
        public static readonly string gettrimlugreviewItemURL = "traceability/trimreview/get";
        public static readonly string submittubegrindURL = "traceability/tubegrind/submitadd";
        public static readonly string gettubegrindreviewURL = "traceability/tubegrindreview/get";
        public static readonly string deletelugreviewItemURL = "traceability/trimlugreview/delete";
        public static readonly string finalizetubegrindURL = "traceability/grind/completetubegrindmobile2";
        public static readonly string sanitizegrindequipmentURL = "traceability/grind/sanitizegrinder";
        public static readonly string TrimOfflineSyncURL = "traceability/meat/trimsyncmobile";
        public static readonly string deletegrindreviewitemURL = "traceability/grindlugreviewitem/delete";
        public static readonly string submitluggrindURL = "traceability/grind/completegrindlugmobile2";
        public static readonly string TubeGrindOfflineSyncURL = "traceability/meat/tubegrindsyncmobile";
        public static readonly string getlugswithtrimURL = "traceability/grind/getlugstrim";
        public static readonly string LugGrindOfflineSyncURL = "traceability/meat/luggrindsyncmobile";
        public static readonly string GrindSanitization = "traceability/tubegrind/savesanitization";
        public static readonly string CustomerRequestGrind = "traceability/grind/submitcaseitemforluggrind";

        //Pricing
        public static readonly string GetRetailPricesbyBarcodes = "pricing/retailpricesbybarcode/get";

        //label printing
        public static readonly string GetPrintGroups = "inventory/items/getgroupsforlabelprint";
        public static readonly string GetItemGroupCollections = "labeling/item/getcategoryanditem";
        public static readonly string GetItemTagsCollections = "labeling/itemsandtags/get";
        public static readonly string GetPluDeptURL = "labeling/labelprinting/pludepts";
        public static readonly string GetRecevingStoresURL = "traceability/labelprinting/getstores";
        public static readonly string InsertTotalData = "labeling/labelprinting/inserttotalrecord";
        public static readonly string GenerateSecretKey = "labeling/labelprinting/generatesecretkeylabelsize";

        //CountInventory
        public static readonly string getcountinventories = "waste/physicalinventory/gettodaysinventories";
        public static readonly string decodebarcodePhysicalInventoryURL = "Waste/physicalinventory/scanbarcodeforphysicalinventory";
        public static readonly string savephysicalinventoryURL = "Waste/physicalinventorycount/save";
        public static readonly string reviewphyscialinventoryitemsURL = "Waste/reviewphysicalinventoryscans/get";
        public static readonly string updatephyscialinventoryitemURL = "Waste/physicalinventoryscan/update";
        public static readonly string finalizeinventoryURL = "Waste/physicalinventory/complete";
        public static readonly string deletephyscialinventoryitemURL = "Waste/physicalinventoryscan/delete";


        //Task Activity
        public static readonly string startTaskActivity = "taskactivity/taskactivity/start";
        public static readonly string saveTaskStep = "taskactivity/taskactivity/save";
        public static readonly string SavePhotoTaskStep = "taskactivity/taskstep/saveimage";
        public static readonly string DeleteTaskPhotos = "taskactivity/taskstep/deleteimage";
        public static readonly string DeleteAllTaskPhotos = "taskactivity/taskstep/deleteallimages";
        public static readonly string SaveSignOffTaskDetails = "taskactivity/signoffdetails/save";
        public static readonly string TemperatureCheckGetSteps = "taskactivity/temperaturecheck/getsteps";

        //store walks
        public static readonly string GetStoreWalksQuestions = "taskactivity/tasksteps/get";
        public static readonly string GetAdditionalResponseQuestions = "taskactivity/additionalresponse/get";
        public static readonly string SaveAdditionalResponseAnswers = "taskactivity/additionalresponselist/save";
        //transfers
        public static readonly string getAllTransferRules = "Waste/transfers/getAllTransferRules";
        public static readonly string initializeTransfer = "waste/transfer/initialize";
        public static readonly string getOpenTransfers = "waste/transfers/get";
        public static readonly string TransferBarcodeDetails = "waste/transfers/barcodedecode";
        public static readonly string SaveTransfer = "waste/transfers/save";
        public static readonly string TransferReviewItems = "waste/transfers/items";
        public static readonly string CompletedTransferReviewItems = "waste/completedtransfer/items";
        public static readonly string TransferUpdateItems = "waste/transfers/update";
        public static readonly string TransferFinalize = "waste/transfer/complete";
        public static readonly string DeleteTransferReviewItems = "waste/transferitem/delete";
        public static readonly string GetReceiveTransfers = "Waste/receivetransfers/getall";
        public static readonly string UpdateReceivedReviewTransfer = "waste/recevietransfer/update";
        public static readonly string ReceivedTransferFinalize = "waste/recevietransfer/complete";
        public static readonly string DeleteTransfer = "waste/transfer/delete";
        public static readonly string RejectTranfer = "waste/transfer/reject";

        //Production Orders
        public static readonly string getTodayProductionOrders = "productionplanning/productionorders/get";
        public static readonly string updateProductionOrderItems = "productionplanning/productionorder/update";
        public static readonly string submitProductionOrders = "productionplanning/Productionorder/submit";

        //DSD Receiving
        public static readonly string getSupplierInvoiceDetails = "dsd/supplierinvoice/get";
        public static readonly string getSuppliersDetails = "masterdata/supplierauthorization/getformobile";
        public static readonly string GetAllMajorDepartments = "masterdata/majordepartment/getformobile";
        public static readonly string SupplierSaveInvoice = "dsd/supplierinvoice/save";
        public static readonly string CompleteInvoice = "dsd/supplierinvoice/complete";
        public static readonly string PrintInvoice = "dsd/supplierinvoice/print";
        public static readonly string sumbitInvoiceSupplierTotalQty = "dsd/supplierinvoiceitems/process";
        public static readonly string SumbitInvoiceItemQty = "dsd/supplierinvoiceitem/process";
        public static readonly string GetReasonCode = "dsd/returnsreasoncodes/get";
        public static readonly string InvoiceItemBarcode = "dsd/invoiceitem/decodebarcode";
        public static readonly string SaveInvoiceItem = "dsd/supplierinvoiceitem/save";
        public static readonly string GetInvoiceById = "dsd/supplierinvoicebyid/get";
        public static readonly string SupplierDecodeBarcode = "dsd/getsupplier/barcode";
        
        //Traceability Plan
        public static readonly string GetTraceabilityPlan = "masterdata/traceabilityplanmobile/get";
        public static readonly string GetPrintDataForTraceabilityPlan = "masterdata/traceabilityplanmobile/print";
        
        //Distribution
        public static readonly string GetItemDistribution = "productionplanning/distributionbyitem/get";
        public static readonly string GetStoreDistribution = "productionplanning/distributionbystore/get";
        public static readonly string GetScannedItemForDistribution = "productionplanning/distribution/scanbarcode";
        public static readonly string GetStoreListForItem = "productionplanning/storelistforitem/get";
        public static readonly string GetItemListForStore = "productionplanning/distributionitems/getforstore";
        public static readonly string GetScannedToteForDistribution = "productionplanning/distribution/scantotebarcode";

        //CycleCounts
        public static readonly string GetCycleCounts = "inventory/cyclecounts/get";
    }
}
