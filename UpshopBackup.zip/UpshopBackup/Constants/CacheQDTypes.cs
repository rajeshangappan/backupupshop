﻿using Microsoft.Extensions.DependencyInjection;
using MobileUI2.Models.Orders;
using MobileUI2.Services;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace MobileUI2
{
    public class CacheQDTypes
    {
        private static IServiceProvider _serviceProvider;
        public static async Task UpdateCacheQDTypes(IServiceProvider serviceProvider=null)
        {
            try
            {
                _serviceProvider = serviceProvider;
                var cache = serviceProvider.GetService<ILocalCacheService>();
                foreach (var qdtype in RefreshableQDTypes)
                {
                    await cache.Delete(qdtype + "Refresh");
                    await cache.Save(qdtype + "Refresh", false);
                }
            }
            catch (Exception)
            {
            }
        }
        public static async Task RefreshCacheQDType(string qdtype)
        {
            try
            {
                var cache = _serviceProvider.GetService<ILocalCacheService>();
                await cache.Delete(qdtype + "Refresh");
                await cache.Save(qdtype + "Refresh", false);
            }
            catch (Exception)
            {
            }
        }


        public const string RecipeSearch = "RecipeSearchData";
        public const string RecipeDetails = "RecipeDetails";
        public const string PrepSteps = "PrepSteps";
        public const string UpcomingPlans = "UpcomingProductionPlans";
        public const string TodayPlans = "TodayProductionPlans";
        public const string TodayTasks = "TodaysTasks";
        public const string Literals = "Literals";
        public const string MobileTenantInfo = "MobileTenantInfo";
        public const string BiometricLogin = "BiometricLogin";
        public const string Adjustments = "Adjustments";
        public const string AdjustmentConfig = "AdjustmentConfig";
        public const string InventoryStates = "InventoryStates";
        public const string InitializedAdjustments = "InitializedAdjustments";
        public const string AllowedDepartForAdjustments = "AllowedDepartForAdjustments";
        public const string LabelPrinters = "LabelPrinters";
        public const string ItemsSearchDataByFcc = "ItemsSearchDataByFcc";
        public const string Orders = "Orders";
        public const string GrindDetails = "GrindDetails";
        public const string GrinderDetails = "GrinderDetails";
        public const string LeanPoints = "LeanPoints";
        public const string LeanPointItems = "LeanPointItems";
        public const string Lugs = "Lugs";
        public const string CacheSyncData = "CacheSyncData";
        public const string UserTimeZone = "TimeZone";
        public const string VendorsInfo = "VendorsInfo";
        public const string Establishments = "Establishments";
        public const string TrimLugandCaseItemReview = "TrimLugandCaseItemReview";
        public const string TrimLugReview = "TrimLugReview";
        public const string TubeGrindReview = "TubeGrindReview";
        public const string TrimLugandCaseReview = "TrimLugandCaseReview";
        public const string TrimLugs = "TrimLugs";
        public const string Barcodes = "Barcodes";
        public const string RetailPrices = "RetailPrices";
        public const string SanitizationMessage = "SanitizationMessage";
        public const string ItemGroupCollections = "ItemGroupCollections";
        public const string ItemTagsCollections = "ItemTagsCollections";
        public const string PrintGroups = "PrintGroups";
        public const string MarkdownLabelsforStore = "MarkdownLabelsforStore";
        public const string MarkdownPrintersforStore = "MarkdownPrintersforStore";
        public const string TodayCountInventories = "TodayCountInventories";                
        public const string CompletedCustomOrders = "CompletedCustomOrders";
        public const string OpenCustomOrders = "OpenCustomOrders";
        public const string CustomOrderItems = "CustomOrderItems";
        public const string CustomOrdersTablet = "CustomOrdersTablet";
        public const string CustomOrderItemDetails = "CustomOrderItemDetails";
        public const string CategoryItemDetails = "OrderItemDetails";
        public const string AllCategoryItems = "AllCategoryItems";
        public const string CategoryItems = "CategoryItems";
        public const string ItemCategories = "ItemCategories";
        public const string RecipesAndCategories = "RecipesandCategories";
        public const string RecipesandTags = "RecipesandTags";
        public const string Workstations = "Workstations";
        public const string SelectedPrinterData = "SelectedPrinterData";
        public const string TransferRules = "TransferRules";
        public const string OpenTransfers = "OpenTransfers";
        public const string ReceiveTransfers = "ReceiveTransfers";
        public const string ReviewTransferItems = "ReceiveTransferItems";
        public const string TransferDetails = "TransferDetails";
        public const string ProductionOrders = "ProductionOrders";
        public const string ProductionOrderPrepSteps = "ProductionOrderPrepSteps";
        public const string CutTest = "CutTest";
        public const string PickList = "PickList";
        public const string SupplierResponses = "SupplierResponses";
        public const string DayMarkAccountId = "DayMarkAccountId";
        public const string InvoiceDTO = "InvoiceDTO";
        public const string TemperatureProbeDetails = "TemperatureProbeDetails";
        public const string OpenOrdersDTO = "OpenOrdersDTO";
        public const string OrderItemDetailsDTO = "OrderItemDetailsDTO";
        public const string OrdersSuppliers = "OrdersSuppliers";
        public const string OrdersDepartments = "OrdersDepartments";
        public const string DistributionByItem = "DistributionByItem";
        public const string DistributionByStore = "DistributionByStore";
        public const string DistributionItemDetails = "DistributionItemDetails";
        public const string DistributionStoreItemDetails = "DistributionStoreItemDetails";

        public static List<string> RefreshableQDTypes = new List<string>()
        {
                    RecipeSearch,
                    RecipeDetails,
                    PrepSteps,
                    UpcomingPlans,
                    TodayPlans,
                    TodayTasks,
                    Adjustments,
                    AdjustmentConfig,
                    InventoryStates,
                    InitializedAdjustments,
                    AllowedDepartForAdjustments,
                    LabelPrinters,
                    ItemsSearchDataByFcc,
                    Orders,
                    GrindDetails,
                    GrinderDetails,
                    LeanPoints,
                    LeanPointItems,
                    Lugs,
                    CacheSyncData,
                    UserTimeZone,
                    VendorsInfo,
                    Establishments,
                    TrimLugandCaseItemReview,
                    TrimLugReview,
                    TubeGrindReview,
                    TrimLugandCaseReview,
                    TrimLugs,
                    Barcodes,
                    RetailPrices,
                    SanitizationMessage,
                    ItemGroupCollections,
                    PrintGroups,
                    MarkdownLabelsforStore,
                    MarkdownPrintersforStore,
                    TodayCountInventories,
                    CompletedCustomOrders,
                    OpenCustomOrders,
                    CustomOrderItems,
                    CustomOrderItemDetails,
                    CategoryItemDetails,
                    AllCategoryItems,
                    CategoryItems,
                    ItemCategories,
                    Workstations,
                    TransferRules,
                    TransferDetails,
                    OpenTransfers,
                    ProductionOrders,
                    ProductionOrderPrepSteps,
                    CutTest,
                    PickList,
                    SupplierResponses,
                    InvoiceDTO,
                    DayMarkAccountId,
                    TemperatureProbeDetails,
                    OpenOrdersDTO,
                    OrderItemDetailsDTO
        };

    }

}
