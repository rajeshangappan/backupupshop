﻿using MobileUI2.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Constants
{
    public class MessengerKeys
    {
        public const string AdjustmentUpdate = "AdjustmentUpdate";
        public const string AdjustmentRefresh = "AdjustmentRefresh";
        public const string AdjustmentDelete = "AdjustmentDelete";
        public static string languageCodeString { get; set; }
        public const string UpdateProductionPlans = "UpdateProductionPlans";
        public const string ScannerPage = "ScannerPage";
        public const string TodaysTasks = "TodaysTasks";
        public const string AdjustmentItemDetailData = "AdjustmentItemDetailData";
        public const string InternalAdjustmentItemDetailData = "InternalAdjustmentItemDetailData";
        public const string AdjustmentItemDetailUpdateData = "AdjustmentItemDetailUpdateData";
        public const string AdjustmentItemDetailDelete = "AdjustmentItemDetailDelete";
        public const string AddAdjustmentError = "AddAdjustmentError";
        public const string SelectedInventoryState = "SelectedInventoryState";
        public const string OrderItemUpdate = "OrderItemUpdate";
        public const string OrderOnHandUpdate = "OrderOnHandUpdate";
        public const string OrderOnHandCreate = "OrderOnHandCreate";
        public const string OrderUpdate = "OrderUpdate";
        public const string OrderQtyUpdate = "OrderQtyUpdate";
        public const string RemoveOrder = "RemoveOrder";
        public const string AlertPopupClosed = "Alert Closed";
        public const string SelectedVendorLocation = "SelectedVendorLocation";
        public const string UpdateTrim = "UpdateTrim";
        public const string UpdateTrimLug = "UpdateTrimLug";
        public const string UpdateVendorDetails = "UpdateVendorDetails";
        public const string MarkdownLabelPrinterSelected = "MarkdownLabelPrinterSelected";
        public const string MarkdownListUpdate = "MarkdownListUpdate";
        public const string SelectedCountInventoryState = "SelectedCountInventoryState";
        public const string AddedCountInventory = "AddedCountInventory";
        public const string AddedCountInventoryItem = "AddedCountInventoryItem";
        public const string UpdatedCountInventory = "UpdatedCountInventory";
        public const string AddCountInventoryItem = "AddCountInventoryItem";
        public const string CustomOrderListUpdate = "CustomOrderListUpdate";
        public const string CustomOrderTabletListUpdate = "CustomOrderTabletListUpdate";
        public const string OfflineCustomOrderListUpdate = "OfflineCustomOrderListUpdate";
        public const string FinalizeCountInventory = "FinalizeCountInventory";
        public const string CustomOrderItemAddedtoCart = "CustomOrderItemAddedtoCart";
        public const string CustomOrderItemRemovedFromCart = "CustomOrderItemRemovedFromCart";
        public const string CategoryItemsListUpdate = "CategoryItemsListUpdate";
        public const string CategoryItemDetailsUpdate = "CategoryItemDetailsUpdate";
        public const string ConfirmCustomOrderUpdate = "ConfirmCustomOrderUpdate";
        public const string UpdateOrderCart = "UpdateOrderCart";
        public const string ReloadCutomOrderData = "ReloadCutomOrderData";
        public const string UpdateCutomOrderCart = "UpdateCutomOrderCart";
        public const string TaskAnswered = "TaskAnswered";
        public const string TaskClosed = "TaskClosed";
        public const string ChangeOrientationLandscape = "ChangeOrientationLandscape";
        public const string ChangeorientationPortriat = "ChangeOrientationPortriat";
        public const string SignatureSigned = "SignatureSigned";
        public const string SignatureImage = "SignatureImage";
        public const string SignaturepadAppear = "SignaturepadAppear";
        public const string TaskSignedOff = "TaskSignedOff";
        public const string RecipeDetailsClosed = "RecipeDetailsClosed";
        public const string RecipeSearchUpdate = "RecipeSearchUpdate";
        public const string FilterSelected = "FilterSelected";
        public const string RecipeDetailsUpdate = "RecipeDetailsUpdate";
        public const string WorkstationSelected = "WorkstationSelected";
        public const string SSOLoginFailed = "SSOLoginFailed";
        public const string KeyboardPopupClosed = "KeyboardPopupClosed";
        public const string RefreshGrindData = "RefreshGrindData";
        public const string RefreshGrindDataForLug = "RefreshGrindDataForLugGrind";
        public const string DeleteGrind = "DeleteGrind";
        public const string TenantScanned = "TenantScanned";
        public const string SubmitProductionOrder = "SubmitProductionOrder";
        public const string UpdateProductionPlanForecastQty = "UpdateProductionPlanForecastQty";
        public const string RefreshProdPlans = "RefreshProdPlans";
        public const string PrepStepUpdate = "PrepStepUpdate";
        public const string ReOpenProductionplan = "ReOpenProductionplan";
        public const string OrderCompleted = "OrderCompleted";
        public const string CutTestItemUpdate = "CutTestItemUpdate";
        public const string CutTestItemDelete = "CutTestItemDelete";
        public const string CutTestStatusUpdate = "CutTestStatusUpdate";
        public const string Logout = "Logout";
        public const string AddNewInvoice = "AddNewInvoice";
        public const string InvoiceStatusUpdate = "InvoiceStatusUpdate";
        public const string InvoiceItemsUpdate = "InvoiceItemsUpdate";
        public const string InvoiceItemQtyUpdate = "InvoiceItemQtyUpdate";
        public const string InvoiceItemRecountQtyUpdate = "InvoiceItemRecountQtyUpdate";
        public const string UpdateInvoiceTodaysList = "UpdateInvoiceTodaysList";
        public const string StartScan = "StartScan";
        public const string ReceivedTranfersUpdate = "ReceivedTranfersUpdate";
        public const string NewCustomOrderCreated = "NewCustomOrderCreated";
        public const string OrderItemsScrollToIndex = "OrderItemsScrollToIndex";

        public const string TransferListReload = "TransferListReload";


        public static string ScannedText { get; set; }
        public static string DatawedgeProfileName { get; set; }
        public static bool IsProfileAvailable { get; set; }
        public static int AdjustmentID { get; set; }
        public static bool AdjustmentFinalized { get; set; }
        public static int SelectedTaskStepId { get; set; }
        public static bool IsFinalized { get; set; }
        public static bool IsRefresh { get; set; }

    }

    public static class GlobalPopupTracker
    {
        public static bool IsFinalPopupOpen { get; set; } = false;
    }
}
