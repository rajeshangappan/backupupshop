﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Constants
{
    public enum BarcodeTypeEnum
    {
        UPC = 1,
        EAN13 = 2,
        EAN8 = 3,
        DatabarExpanded = 4,
        DatabarStacked = 5,
        DatabarExpandedStacked = 6
    }
    public enum InventoryType
    {
        ByWeight = 1,
        ByRetail = 2,
        ByCount = 3,
    }
    public enum ItemWeightUnit
    {
        Grams,
        Kilograms,
        Ounces,
        Pounds
    }
    public enum InventoryStateEnum
    {
        None = 0,
        Backroom = 1,
        SaleableUnlabeled = 2,
        SaleableLabeled = 3,
        UnsaleableUnlabeled = 4
    }
    public enum RetailPriceIn
    {
        Retail = 0,
        PriceReduction = 1,
        PercentOff = 2,
        Forced = 3
    }
    public enum MarkdownTypeEnum
    {
        Coupon = 1,
        CentsOff = 2,
        Off = 3
    }
    public enum PrinterCutterMode
    {
        DoNothing = 0,
        CutAfterEachLabel = 1,
        CutAfterEachBatch = 2,
        PeelOffAfterEachLabel = 3
    }
    public enum OrderStatus
    {
        NotStarted = 0,
        InProgress = 1,
        Completed = 2
    }
    public enum TaskStatus
    {
        InProgress = 0,
        Completed = 1
    }
    public enum GrindStatusType
    {
        Initiated,
        InProgress,
        SanitizationRequired,
        Finalized,
        CleaningRequired
    }
    public enum TemperatureType
    {
        Fahrenheit = 1,
        Celsius = 2
    }
    public enum TopOfLabelDetectionMode
    {
        GapSense,
        BarSense,
        Continuous
    }
    public enum PrintOption
    {
        PrintPlan = 0,
        PrintLabels = 1,
        PrintPrep = 2,
        None = 3
    }
    public enum GrinderCleanEnum
    {
        Never = 0,
        Required = 1,
        Optional = 2
    }
    public enum ProductionPlanStatus
    {
        CreatingPlanStatus = 0,
        Created = 1,
        InProgress = 2,
        Completed = 3
    }
    public enum CountType
    {
        Case = 0,
        Each = 1,
        Parcel = 2
    }
    public enum InvoiceStatus
    {
        Open = 1,
        Final = 2,
        Voided = 3,
        History = 4,
        VoidedFinal = 5,
        VoidedHistory = 6
    }
    public enum InvoiceMethodType
    {
        TotalOnly = 1,
        ReceiverScan = 2,
        VendorScan = 3,
        Dex = 4,
        Nex = 5,
        Asn = 6
    }
    public enum InvoiceSelectType
    {
        Delivery = 0,
        Return = 1
    }
    public enum SupplierInvoiceAction
    {
        TotalAccept = 1,
        TotalCount = 2
    }
    public enum TransferStatus
    {
        Initialized = 0,
        CreatingTransfer = 1,
        PendingReceipt = 2,
        ReceivingTransfer = 3,
        ReceivedTransfer = 4,
        TransferRejected = 5
    }
    public enum OpenOrdersType
    {
        All,
        Today,
        Upcoming
    }
    public enum Status
    {
        Success,
        Failed
    }
    public enum NavigationGlyph
    {
        ClosePopup,
        NavigateBack,
        Hamburger
    }
    public enum OrderByGlyph
    {
        None,
        Descending,
        Aescending
    }
    public enum FlagVisiblityEnum
    {
        SubmitOrder = 1,
        OrderTotals = 2,
        ReviewItems = 3
    }
    public enum OrderingStatus
    {
        None = 0,
        Created = 1,
        InProgress = 2,
        Submitted = 4,
        Approved = 8,
        Received = 16,
        Complete = 32,
        Cancelled = 64,
    }
    public enum AddCaseItemMode
    {
        None = 0,
        Trim = 1,
        Grind = 2
    }
}
