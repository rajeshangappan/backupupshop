﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Constants
{
    public static class PageNames
    {
        public static string TubeGrind = "TubeGrind";
        public static string LugGrind = "LugGrind";
        public static string TrimLug = "TrimLug";
        public static string InvoiceEdit = "InvoiceEdit";
        public static string InvocieCreate = "InvocieCreate";
    }
}
