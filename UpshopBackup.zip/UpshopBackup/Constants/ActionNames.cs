﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Constants
{
    public class ActionNames
    {
        public const string Production = "Production";
        public const string ProductionPlanOnHand = "ProductionPlanOnHand";
        public static string ProductionPlanForecast = "ProductionPlanForecast";
        public static string FinalizePlan = "FinalizePlan";
        public const string Adjustment = "Adjustment";
        public const string AddedTrimLogItem = "AddedTrimLogItem";
        public const string DeleteTrimLogItem = "DeleteTrimLogItem";
        public const string TrimLog = "TrimLog";
        public const string AddedTubeGrindItem = "AddedTrimLogItem";
        public const string DeleteTubeGrindItem = "DeleteTrimLogItem";
        public const string TubeGrind = "TubeGrind";
        public const string AddLugGrindItem = "AddLugGrindItem";
        public const string LugGrind = "LugGrind";
        public const string Prep = "Prep";
        public const string StartPrepStep = "StartPrepStep";
        public const string CompletePrepStep = "CompletePrepStep";
        public const string UpdatePrepStepQty = "UpdatePrepStepQty";
        public const string UpdatePrep = "UpdatePrep";
        public const string CountInventory = "CountInventory";
        public const string SavePhysicalInventory = "SavePhysicalInventory";
        public const string UpdatePhysicalInventory = "UpdatePhysicalInventory";
        public const string CompletePhysicalInventory = "CompletePhysicalInventory";
        public const string DeletePhysicalInventory= "DeletePhysicalInventory";
        public const string CustomOrder = "CustomOrder";
        public const string SaveCustomOrder = "SaveCustomOrder";
        public const string StartPlan = "StartPlan";
        public const string UpdateUnLabeledQuantity = "UpdateUnLabeledQuantity";
    }
}
