﻿using System;
using Microsoft.Maui.Controls.Compatibility;
using Microsoft.Maui.Controls;
using Microsoft.Maui;

namespace MobileUI2.Constants
{
	public static class DaymarkPrinterConstants
	{
		public const string InCorrectSDK = "sdk secret key is invalid";
		public const string IncorrectPackageName = "app package is invalid";
		public const string IncorrectLabelSecretKey = "label secret key is invalid";
		public const string LabelSecretKeyExpired = "label secret key has been expired";
		public const string LabelKeySizeMismatch = "label secret key and label size mismatch";
		public const string TotalScanCountExceeded = "keylabel exceeded scan count.";
		public const string InvalidKeyLabel = "keyLabel is invalid.";
		public const string UserNotFound = "user not found";
		public const string UsernameRequired = "the userName field is required";
        public const string PrintSuccess = "print success";
		public const string DeviceNotFound = "device not found or connected";
		public const string PrinterAddressNotFound = "the printeraddress field is required.";
    }
}

