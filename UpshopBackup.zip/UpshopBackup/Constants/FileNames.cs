﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Constants
{
    public class FileNames
    {
        public const string DaymarkLog = "DaymarkDebug.txt";
        public const string OrderingLog = "OrderingPerfromanceLog.txt";
    }
}
