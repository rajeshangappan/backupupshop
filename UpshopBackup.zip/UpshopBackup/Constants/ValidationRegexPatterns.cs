﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileUI2.Constants
{
    public static class ValidationRegexPatterns
    {
        public static string AllowedNumericElevenDigitsPattern = "^(?!0{11})[0-9]{11}$";
        public static string NumericWithNoDecimalsRegex = "^[0-9]*$";
        public static string NumericWithDecimalsRegex = "^[0-9.]*$";
    }
}
