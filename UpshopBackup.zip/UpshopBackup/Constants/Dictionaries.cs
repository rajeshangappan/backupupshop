﻿using System;
using System.Collections.Generic;
using System.Text;
using MobileUI2.Constants;

namespace MobileUI2.Constants
{
    public class Dictionaries
    {
        public static readonly Dictionary<NavigationGlyph, string> NavigationGlyphMappings = new Dictionary<NavigationGlyph, string>
        {
            { NavigationGlyph.ClosePopup, "X" },
            { NavigationGlyph.NavigateBack, "\uf060" },
            { NavigationGlyph.Hamburger, "\uf0c9" }
        };

        public static readonly Dictionary<OrderByGlyph, string> OrderByGlyphMappings = new Dictionary<OrderByGlyph, string>
        {
            {OrderByGlyph.None, "" },
            {OrderByGlyph.Descending, "\uf063" },
            {OrderByGlyph.Aescending, "\uf062" }
        };
    }
}
