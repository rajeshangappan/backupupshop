﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Maui.Controls;
using MobileUI2.Controls;
using Microsoft.Maui.Handlers;

namespace MobileUI2.Controls
{
    public class BorderLessEditor : Editor
    {

    }
}
