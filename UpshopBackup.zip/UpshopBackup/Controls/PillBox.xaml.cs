﻿using MobileUI2.Constants;
using MobileUI2.Models;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using Microsoft.Maui.Graphics;
using Microsoft.Maui.Controls.Compatibility;
using Microsoft.Maui.Controls;
using Microsoft.Maui;

namespace MobileUI2.Controls
{
    public partial class PillBox : ContentView
    {
        public static readonly BindableProperty Pill1TextProperty = BindableProperty.Create(nameof(Pill1Text), typeof(string), typeof(PillBox), string.Empty);
        public static readonly BindableProperty Pill2TextProperty = BindableProperty.Create(nameof(Pill2Text), typeof(string), typeof(PillBox), string.Empty);
        public static readonly BindableProperty DefaultCountTypeProperty = BindableProperty.Create(nameof(DefaultCountType), typeof(string), typeof(PillBox));
        public static readonly BindableProperty SelectedCountTypeProperty = BindableProperty.Create(nameof(SelectedCountType), typeof(CountTypeModel),typeof(PillBox), defaultBindingMode: BindingMode.TwoWay);
        public static readonly BindableProperty CountTypesProperty = BindableProperty.Create(nameof(CountTypes), typeof(ObservableCollection<CountTypeModel>),typeof(PillBox));

        public ObservableCollection<CountTypeModel> CountTypes
        {
            get => (ObservableCollection<CountTypeModel>)GetValue(CountTypesProperty);
            set => SetValue(CountTypesProperty, value);
        }
        public CountTypeModel SelectedCountType
        {
            get => (CountTypeModel)GetValue(SelectedCountTypeProperty);
            set => SetValue(SelectedCountTypeProperty, value);
        }
        public string DefaultCountType
        {
            get => (string)GetValue(DefaultCountTypeProperty);
            set => SetValue(DefaultCountTypeProperty, value);
        }

        public string Pill1Text
        {
            get => (string)GetValue(Pill1TextProperty);
            set => SetValue(Pill1TextProperty, value);
        }

        public string Pill2Text
        {
            get => (string)GetValue(Pill2TextProperty);
            set => SetValue(Pill2TextProperty, value);
        }

        public PillBox()
        {
            InitializeComponent();
            TapPill1Command = new Command(() => TogglePills(true));
            TapPill2Command = new Command(() => TogglePills(false));
            BindingContext = this;
            Hydrate();
        }

        public Command TapPill1Command { get; }
        public Command TapPill2Command { get; }

        public void Hydrate()
        {
            HydrateSetDefaultPillValues();
        }
        public void HydrateSetDefaultPillValues()
        {
            List<string> pillTexts = new List<string> { Pill1Text, Pill2Text };

            if (pillTexts[0] == DefaultCountType)
            {
                Pill1Frame.BackgroundColor = (Color)Application.Current.Resources["UpshopBackgroundColor"];
                Pill1Label.TextColor = Colors.White;
                Pill1Label.FontAttributes = FontAttributes.Bold;
                Pill2Frame.BackgroundColor = Colors.Transparent;
                Pill2Label.TextColor = (Color)Application.Current.Resources["UpshopBackgroundColor"];
                Pill2Label.FontAttributes = FontAttributes.None;
            }
            else if (pillTexts[1] == DefaultCountType)
            {
                Pill1Frame.BackgroundColor = Colors.Transparent;
                Pill1Label.TextColor = (Color)Application.Current.Resources["UpshopBackgroundColor"];
                Pill1Label.FontAttributes = FontAttributes.None;
                Pill2Frame.BackgroundColor = (Color)Application.Current.Resources["UpshopBackgroundColor"];
                Pill2Label.TextColor = Colors.White;
                Pill2Label.FontAttributes = FontAttributes.Bold;
            }
        }



        public void TogglePills(bool isPill1)
        {
            if(Pill2Text != string.Empty)
            {
                Pill1Frame.BackgroundColor = isPill1 ? (Color)Application.Current.Resources["UpshopBackgroundColor"] : Colors.Transparent;
                Pill1Label.TextColor = isPill1 ? Colors.White : (Color)Application.Current.Resources["UpshopBackgroundColor"];
                Pill1Label.FontAttributes = isPill1 ? FontAttributes.Bold : FontAttributes.None;

                Pill2Frame.BackgroundColor = !isPill1 ? (Color)Application.Current.Resources["UpshopBackgroundColor"] : Colors.Transparent;
                Pill2Label.TextColor = !isPill1 ? Colors.White : (Color)Application.Current.Resources["UpshopBackgroundColor"];
                Pill2Label.FontAttributes = !isPill1 ? FontAttributes.Bold : FontAttributes.None;
                SelectedCountType = isPill1 ? CountTypes.Where(type => string.Equals(type.DisplayName, Pill1Text)).FirstOrDefault() : CountTypes.Where(type => string.Equals(type.DisplayName, Pill2Text)).FirstOrDefault(); 
            }

        }
    }
}