﻿using Microsoft.Maui.Controls.Compatibility;
using Microsoft.Maui.Controls;
using Microsoft.Maui;

namespace MobileUI2.Components.Controls
{
	public class SearchBarProperties
	{
		public static readonly BindableProperty FieldBackgroundColorProperty = BindableProperty.CreateAttached("FieldBackgroundColor", typeof(Color), typeof(SearchBarProperties), null);

		public static readonly BindableProperty IconColorProperty = BindableProperty.CreateAttached("IconColor", typeof(Color), typeof(SearchBarProperties), null);

		public static readonly BindableProperty BorderWidthProperty = BindableProperty.CreateAttached("BorderWidth", typeof(float), typeof(SearchBarProperties), 0f);

		public static readonly BindableProperty BorderColorProperty = BindableProperty.CreateAttached("UpshopLightLightGray", typeof(Color), typeof(SearchBarProperties), null);
        public static readonly BindableProperty RemoveSearchIconProperty = BindableProperty.CreateAttached("RemoveSearchIcon", typeof(bool), typeof(SearchBarProperties), false);

        public static Color GetFieldBackgroundColor(BindableObject bo)
		{
			return (Color)bo.GetValue(FieldBackgroundColorProperty);
		}

		public static void SetFieldBackgroundColor(BindableObject bo, Color value)
		{
			bo.SetValue(FieldBackgroundColorProperty, value);
		}

		public static Color GetIconColor(BindableObject bo)
		{
			return (Color)bo.GetValue(IconColorProperty);
		}

		public static void SetIconColor(BindableObject bo, Color value)
		{
			bo.SetValue(IconColorProperty, value);
		}

		public static float GetBorderWidth(BindableObject bo)
		{
			return (float)bo.GetValue(BorderWidthProperty);
		}

		public static void SetBorderWidth(BindableObject bo, float value)
		{
			bo.SetValue(BorderWidthProperty, value);
		}

		public static Color GetBorderColor(BindableObject bo)
		{
			return (Color)bo.GetValue(BorderColorProperty);
		}

		public static void SetBorderColor(BindableObject bo, Color value)
		{
			bo.SetValue(BorderColorProperty, value);
		}

        public static bool GetRemoveSearchIcon(BindableObject bo)
        {
            return (bool)bo.GetValue(RemoveSearchIconProperty);
        }

        public static void SetRemoveSearchIcon(BindableObject bo, bool value)
        {
            bo.SetValue(RemoveSearchIconProperty, value);
        }
    }
}
