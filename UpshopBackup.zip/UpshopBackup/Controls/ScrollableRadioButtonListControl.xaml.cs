﻿using System;
using System.Collections.ObjectModel;
using Microsoft.Maui.Controls.Xaml;
using Microsoft.Maui.Controls.Compatibility;
using Microsoft.Maui.Controls;
using Microsoft.Maui;

namespace MobileUI2.Controls
{
    //[XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class ScrollableRadioButtonListControl : ContentView
    {
        public static readonly BindableProperty ItemsProperty = BindableProperty.Create(
            nameof(Items),
            typeof(ObservableCollection<object>),
            typeof(ScrollableRadioButtonListControl),
            defaultBindingMode: BindingMode.TwoWay,
            propertyChanged: OnItemsChanged);

        public static readonly BindableProperty DisplayMemberProperty = BindableProperty.Create(
            nameof(DisplayMember),
            typeof(string),
            typeof(ScrollableRadioButtonListControl),
            string.Empty);

        public static readonly BindableProperty TitleProperty = BindableProperty.Create(
            nameof(Title),
            typeof(string),
            typeof(ScrollableRadioButtonListControl),
            string.Empty,
            propertyChanged: OnTitleChanged);

        public static readonly BindableProperty SelectedValueProperty = BindableProperty.Create(
            nameof(SelectedValue),
            typeof(string),
            typeof(ScrollableRadioButtonListControl),
            defaultBindingMode: BindingMode.TwoWay);

        public static readonly BindableProperty IsControlVisibleProperty = BindableProperty.Create(
            nameof(IsControlVisible),
            typeof(bool),
            typeof(ScrollableRadioButtonListControl),
            true,
            propertyChanged: OnIsControlVisibleChanged);

        public ObservableCollection<object> Items
        {
            get => (ObservableCollection<object>)GetValue(ItemsProperty);
            set => SetValue(ItemsProperty, value);
        }

        public string DisplayMember
        {
            get => (string)GetValue(DisplayMemberProperty);
            set => SetValue(DisplayMemberProperty, value);
        }

        public string Title
        {
            get => TitleLabel.Text;
            set => TitleLabel.Text = value;
        }

        public string SelectedValue
        {
            get => (string)GetValue(SelectedValueProperty);
            set => SetValue(SelectedValueProperty, value);
        }

        public bool IsControlVisible
        {
            get => (bool)GetValue(IsControlVisibleProperty);
            set => SetValue(IsControlVisibleProperty, value);
        }

        public ScrollableRadioButtonListControl()
        {
            InitializeComponent();
        }

        private static void OnItemsChanged(BindableObject bindable, object oldValue, object newValue)
        {
            if (bindable is ScrollableRadioButtonListControl control && newValue is ObservableCollection<object> items)
            {
                control.RadioButtonLayout.Children.Clear();

                foreach (var item in items)
                {
                    string displayText = item.GetType().GetProperty(control.DisplayMember)?.GetValue(item)?.ToString() ?? item.ToString();

                    var radioButton = new RadioButton
                    {
                        Content = displayText,
                        Value = displayText,
                        FontSize = 16,
                        TextColor = Color.FromArgb("055C6B"),
                        GroupName = "optionsGroup",
                        BackgroundColor = Colors.Transparent,
                        //ControlTemplate = (ControlTemplate)Application.Current.Resources["RadioButtonTemplate"]
                    };

                    // Add padding and margin to make the touch area larger
                    radioButton.Padding = new Thickness(10);
                    radioButton.Margin = new Thickness(0, 5);

                    radioButton.CheckedChanged += (sender, e) =>
                    {
                        if (e.Value)
                        {
                            control.SelectedValue = displayText;
                        }
                    };

                    // Add tap gesture to the entire radio button area
                    var tapGesture = new TapGestureRecognizer
                    {
                        Command = new Command(() =>
                        {
                            radioButton.IsChecked = !radioButton.IsChecked;
                        }),
                        NumberOfTapsRequired = 1
                    };

                    radioButton.GestureRecognizers.Add(tapGesture);
                    control.RadioButtonLayout.Children.Add(radioButton);
                }
            }
        }
        private static void OnTitleChanged(BindableObject bindable, object oldValue, object newValue)
        {
            var control = (ScrollableRadioButtonListControl)bindable;
            control.TitleLabel.Text = (string)newValue;
        }

        private static void OnIsControlVisibleChanged(BindableObject bindable, object oldValue, object newValue)
        {
            var control = (ScrollableRadioButtonListControl)bindable;
            control.IsVisible = (bool)newValue;
        }
        public void UncheckAllExcept(ColoredRadioButton radioButtonToSkip)
        {
            foreach (var child in RadioButtonLayout.Children)
            {
                if (child is Microsoft.Maui.Controls.StackLayout horizontalStack && horizontalStack.Children[0] is ColoredRadioButton radioButton && radioButton != radioButtonToSkip)
                {
                    radioButton.IsChecked = false;
                }
            }
        }
    }
}