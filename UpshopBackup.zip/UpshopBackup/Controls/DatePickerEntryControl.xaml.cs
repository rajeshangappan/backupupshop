﻿using System;
using Microsoft.Maui.Controls.Xaml;
using Microsoft.Maui.Controls.Compatibility;
using Microsoft.Maui.Controls;
using Microsoft.Maui;

namespace MobileUI2.Controls
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class DatePickerEntryControl : ContentView
    {
        public static readonly BindableProperty SelectedDateProperty = BindableProperty.Create(nameof(SelectedDate), typeof(DateTime), typeof(DatePickerEntryControl), DateTime.Today, defaultBindingMode: BindingMode.TwoWay, propertyChanged: OnSelectedDateChanged);

        public DateTime SelectedDate
        {
            get { return (DateTime)GetValue(SelectedDateProperty); }
            set { SetValue(SelectedDateProperty, value); }
        }

        private static void OnSelectedDateChanged(BindableObject bindable, object oldValue, object newValue)
        {
            var control = (DatePickerEntryControl)bindable;
            control.DateLabel.Text = ((DateTime)newValue).ToString("d");
        }


        public DatePickerEntryControl()
        {
            InitializeComponent();

            var tapGesture = new TapGestureRecognizer();
            tapGesture.Tapped += (sender, args) =>
            {
                DateLabel.Text = DateTime.Today.ToString("d");
                DateLabel.IsVisible = true;
                DatePickerControl.Focus();
                DateLabel.IsVisible = false;
            };
            GestureRecognizers.Add(tapGesture);

            DatePickerControl.DateSelected += (s, e) =>
            {
                DateLabel.Text = e.NewDate.ToString("d");
                SelectedDate = e.NewDate.Date;
                DateLabel.IsVisible = true;
            };

            DatePickerControl.Unfocused += (s, e) =>
            {
                if (DatePickerControl.Date >= DateTime.Today.Date)
                {
                    DateLabel.IsVisible = true;
                    DateLabel.Text = DatePickerControl.Date.ToString("d");
                    SelectedDate = DatePickerControl.Date;
                }
            };
        }
    }
}