﻿using System;
using Microsoft.Maui.Controls.Compatibility;
using Microsoft.Maui.Controls;
using Microsoft.Maui;
using Grid = Microsoft.Maui.Controls.Grid;

namespace MobileUI2.Controls
{
	public class KeyboardView : Grid
	{

	}
}

