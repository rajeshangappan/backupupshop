﻿using Microsoft.Maui.Controls.Xaml;
using Microsoft.Maui.Controls.Compatibility;
using Microsoft.Maui.Controls;
using Microsoft.Maui;

namespace MobileUI2.Controls
{
	[XamlCompilation(XamlCompilationOptions.Compile)]
	public partial class ScanBarcodeButton
    {
        public static readonly BindableProperty ScannedUpcProperty = BindableProperty.Create(nameof(ScannedUpc), typeof(string), typeof(ScanBarcodeButton), "Scan Barcode");
        public static readonly BindableProperty IsEntryVisibleProperty = BindableProperty.Create(nameof(IsEntryVisible), typeof(bool), typeof(ScanBarcodeButton), false);
        public string ScannedUpc
        {
            get => (string)GetValue(ScannedUpcProperty);
            set => SetValue(ScannedUpcProperty, value);
        }

        public bool IsEntryVisible
        {
            get => (bool)GetValue(IsEntryVisibleProperty);
            set => SetValue(IsEntryVisibleProperty, value);
        }

        public ScanBarcodeButton ()
		{
			InitializeComponent ();
        }
	}
}