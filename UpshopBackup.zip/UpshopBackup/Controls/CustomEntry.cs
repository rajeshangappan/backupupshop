﻿using Microsoft.Maui.Controls;
using Microsoft.Maui;

namespace MobileUI2.Controls
{
    public enum CustomKeyboard
    {
        Default,
        CustomBoHKeypad,
        CustomFoHKeyboard,
        CustomFoHKeypad
    }

    public enum BorderStyle
    {
        Default = 0,
        None = 1,
        BottomLine = 2,
        Rect = 3,
        RoundRect = 4
    }

    public class CustomEntry : Entry
    {
        public static readonly BindableProperty CustomKeyboardProperty =
            BindableProperty.Create(nameof(CustomKeyboard), typeof(CustomKeyboard), typeof(CustomEntry), CustomKeyboard.Default);

        public static readonly BindableProperty BorderColorProperty =
            BindableProperty.Create(nameof(BorderColor), typeof(Color), typeof(CustomEntry), Colors.Transparent);

        public static readonly BindableProperty BorderWidthProperty =
            BindableProperty.Create(nameof(BorderWidth), typeof(float), typeof(CustomEntry), 1f);

        public static readonly BindableProperty BorderCornerRadiusProperty =
            BindableProperty.Create(nameof(BorderCornerRadius), typeof(float), typeof(CustomEntry), 10f);

        public static readonly BindableProperty HorizontalPaddingProperty =
            BindableProperty.Create(nameof(HorizontalPadding), typeof(double), typeof(CustomEntry), 0.0);

        public static readonly BindableProperty BorderStyleProperty =
            BindableProperty.Create(nameof(BorderStyle), typeof(BorderStyle), typeof(CustomEntry), BorderStyle.RoundRect);

        public static readonly BindableProperty AllowFractionProperty =
            BindableProperty.Create(nameof(AllowFraction), typeof(bool), typeof(CustomEntry), false, BindingMode.TwoWay);

        public bool AllowFraction
        {
            get => (bool)GetValue(AllowFractionProperty);
            set => SetValue(AllowFractionProperty, value);
        }

        public double HorizontalPadding
        {
            get => (double)GetValue(HorizontalPaddingProperty);
            set => SetValue(HorizontalPaddingProperty, value);
        }

        public CustomKeyboard CustomKeyboard
        {
            get => (CustomKeyboard)GetValue(CustomKeyboardProperty);
            set => SetValue(CustomKeyboardProperty, value);
        }

        public Color BorderColor
        {
            get => (Color)GetValue(BorderColorProperty);
            set => SetValue(BorderColorProperty, value);
        }

        public float BorderWidth
        {
            get => (float)GetValue(BorderWidthProperty);
            set => SetValue(BorderWidthProperty, value);
        }

        public float BorderCornerRadius
        {
            get => (float)GetValue(BorderCornerRadiusProperty);
            set => SetValue(BorderCornerRadiusProperty, value);
        }

        public BorderStyle BorderStyle
        {
            get => (BorderStyle)GetValue(BorderStyleProperty);
            set => SetValue(BorderStyleProperty, value);
        }
    }
}