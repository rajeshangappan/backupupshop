﻿using System;
using MobileUI2.Components.Controls;
using Microsoft.Maui.Controls.Compatibility;
using Microsoft.Maui.Controls;
using Microsoft.Maui;

namespace MobileUI2.Controls
{
	public class EntryFocusedTrigger : TriggerAction<Entry>
	{
        protected override void Invoke(Entry sender)
        {
            //sender.SetDynamicResource(EntryProperties.BorderColorProperty, "UpshopOrange");
        }
    }
}

