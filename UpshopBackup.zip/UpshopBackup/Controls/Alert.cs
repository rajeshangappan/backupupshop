﻿using MobileUI2.Views;
using MobileUI2.TabletViews;
using Mopups.Services;
using Mopups.Pages;

namespace MobileUI2.Controls
{
    public  class Alert : PopupPage
    {
        public static async Task OpenAlert(string Title,
            string Message, Command ConfirmCommand, bool IsErrorPopup = false, bool IsTabletDevice = false,bool isJustAlert = false)
        {
            if (DeviceInfo.Idiom == DeviceIdiom.Tablet)
            {
                var page = new AlertPopupTabletView()
                {
                    TitleText = Title,  
                    Message = Message,
                    ButtonClickCommand = ConfirmCommand,
                    IsError = IsErrorPopup,
                    IsJustAlert = isJustAlert
                };
                await MopupService.Instance.PushAsync(page);
            }
            else
            {
                var page = new AlertPopupView()
                {
                    TitleText = Title,
                    Message = Message,
                    ButtonClickCommand = ConfirmCommand,
                    IsError = IsErrorPopup,
                    IsJustAlert = isJustAlert
                };
                await MopupService.Instance.PushAsync(page);
            }
        }
        public static async Task OpenAlert(string Title,
          string Message, Command ConfirmCommand, Command CancelCommand, bool IsErrorPopup = false, bool IsTabletDevice = false, bool IsCancelCommandClosePopUp = false)
        {
            if (DeviceInfo.Idiom == DeviceIdiom.Tablet)
            {
                var page = new AlertPopupTabletView()
                {
                    TitleText = Title,
                    Message = Message,
                    ButtonClickCommand = ConfirmCommand,
                    CancelClickCommand = CancelCommand,
                    IsError = IsErrorPopup,
                    IsConfirmPopUp = IsCancelCommandClosePopUp
                };
                await MopupService.Instance.PushAsync(page);
            }
            else
            {
                var page = new AlertPopupView()
                {
                    TitleText = Title,
                    Message = Message,
                    ButtonClickCommand = ConfirmCommand,
                    CancelClickCommand = CancelCommand,
                    IsError = IsErrorPopup,
                    IsCancelCommandClosePopUp = IsCancelCommandClosePopUp
                };
                await MopupService.Instance.PushAsync(page);
            }
        }
        public static async Task OpenAlert(string Title,
           string Message, Command ConfirmCommand, string ClosePopupText, bool IsErrorPopup = false, bool IsTabletDevice = false)
        {
            if (DeviceInfo.Idiom == DeviceIdiom.Tablet)
            {
                var page = new AlertPopupTabletView()
                {
                    TitleText = Title,
                    Message = Message,
                    ButtonClickCommand = ConfirmCommand,
                    CancelText = ClosePopupText,
                    IsError = IsErrorPopup
                };
                await MopupService.Instance.PushAsync(page);
            }
            else
            {
                var page = new AlertPopupView()
                {
                    TitleText = Title,
                    Message = Message,
                    ButtonClickCommand = ConfirmCommand,
                    CancelText = ClosePopupText,
                    IsError = IsErrorPopup
                };
                await MopupService.Instance.PushAsync(page);
            }
        }
        public static async Task OpenAlert(string Title,
            string Message, Command ConfirmCommand, string ConfirmPopupText, string ClosePopupText, Command CancelCommand, bool IsConfirmPopUp = false, bool IsErrorPopup = false, bool IsTabletDevice = false)
        {
            if (DeviceInfo.Idiom == DeviceIdiom.Tablet)
            {
                var page = new AlertPopupTabletView()
                {
                    TitleText = Title,
                    Message = Message,
                    ButtonClickCommand = ConfirmCommand,
                    CancelClickCommand = CancelCommand,
                    ConfirmText = ConfirmPopupText,
                    CancelText = ClosePopupText,
                    IsConfirmPopUp = IsConfirmPopUp,
                    IsInverseConfirmPopUp = IsConfirmPopUp ? false : true,
                    IsError = IsErrorPopup
                };
                await MopupService.Instance.PushAsync(page);
            }
            else
            {
                var page = new AlertPopupView()
                {
                    TitleText = Title,
                    Message = Message,
                    ButtonClickCommand = ConfirmCommand,
                    CancelClickCommand = CancelCommand,
                    ConfirmText = ConfirmPopupText,
                    CancelText = ClosePopupText,
                    IsConfirmPopUp = IsConfirmPopUp,
                    IsInverseConfirmPopUp = IsConfirmPopUp ? false : true,
                    IsError = IsErrorPopup
                };
                await MopupService.Instance.PushAsync(page);
            }
        }
        public static async Task OpenAlert(string Title,
            string Message, bool IsTabletDevice = false)
        {
            if (DeviceInfo.Idiom == DeviceIdiom.Tablet)
            {
                var page = new AlertPopupTabletView()
                {
                    TitleText = Title,
                    Message = Message,
                    IsJustAlert = true
                };
                await MopupService.Instance.PushAsync(page);
            }
            else
            {
                var page = new AlertPopupView()
                {
                    TitleText = Title,
                    Message = Message,
                    IsJustAlert = true
                };
                await MopupService.Instance.PushAsync(page);
            }
        }
        public static async Task OpenAlert(string title,string primaryMessage, Command confirmCommand,string confirmText, Command cancelCommand,string cancelText,string subTitleMessage,string bottomTitleMessage,bool isVisibleSubTitleMessage = false, bool isVisibleBottomMessage = false)
        {
            var page = new AlertConfrimPopupView
            {
                TitleText = title,
                PrimaryMessage = primaryMessage,
                SubTitleMessage = subTitleMessage,
                BottomTitleMessage = bottomTitleMessage,
                CancelButtonText = cancelText,
                ConfirmButtonText = confirmText,
                CancelClickCommand = cancelCommand,
                ButtonClickCommand = confirmCommand,
                IsVisibleSubTitleMessage = isVisibleSubTitleMessage,
                IsVisibleBottomMessage = isVisibleBottomMessage
            };
            await MopupService.Instance.PushAsync(page);
        }

        public static async Task CloseAlert()
        {
            if (MopupService.Instance.PopupStack.Count > 0)
                await MopupService.Instance.PopAsync();
        }

        public static async Task CloseAllAlert()
        {
            if (MopupService.Instance.PopupStack.Count > 0)
                await MopupService.Instance.PopAllAsync();
        }

        public static async Task ShowToast(string Message, bool IsErrorPopup = false)
        {
            var page = new ToastNotification()
            {
                Message = Message
            };
            await MopupService.Instance.PushAsync(page);
        }
        public static async Task OpenNewAlert(string Message, Command ConfirmCommand, string ConfirmPopupText, string ClosePopupText, Command CancelCommand)
        {
            var page = new AlertNewConfirmPopupView()
            {
                Message = Message,
                ButtonClickCommand = ConfirmCommand,
                CancelClickCommand = CancelCommand,
                ConfirmText = ConfirmPopupText,
                CancelText = ClosePopupText
            };
            await MopupService.Instance.PushAsync(page);
        }
    }
}
