﻿using MobileUI2.Components.TaskSingleSelectRadioButton;
using System;
using Microsoft.Maui.Controls.Compatibility;
using Microsoft.Maui.Controls;
using Microsoft.Maui;

namespace MobileUI2.Controls
{
    public class ColoredRadioButton : RadioButton
    {
        private View _checked;
        private View _unchecked;
        public ScrollableRadioButtonListControl ParentControl { get; set; }

        public TaskSingleSelectRadioButtonView TaskRadioParentControl { get; set; }

        public static readonly BindableProperty IsCheckedProperty = BindableProperty.Create("IsChecked", typeof(bool), typeof(ColoredRadioButton), false, BindingMode.OneWay, null, OnCheckedChanged);
        public static BindableProperty CheckedBackgroundColorProperty = BindableProperty.Create("CheckedBackgroundColor", typeof(Color), typeof(ColoredRadioButton));
        public static BindableProperty CheckedBorderColorProperty = BindableProperty.Create("CheckedBorderColor", typeof(Color), typeof(ColoredRadioButton));
        public static BindableProperty UncheckedBackgroundColorProperty = BindableProperty.Create("UncheckedBackgroundColor", typeof(Color), typeof(ColoredRadioButton));
        public static BindableProperty UncheckedBorderColorProperty = BindableProperty.Create("UncheckedBorderColor", typeof(Color), typeof(ColoredRadioButton));
        public static BindableProperty IconColorProperty = BindableProperty.Create("IconColor", typeof(Color), typeof(ColoredRadioButton));
        public static BindableProperty IconFontSizeProperty = BindableProperty.Create("IconFontSize", typeof(double), typeof(ColoredRadioButton), 16.0);
        public static readonly BindableProperty CheckedColorProperty = BindableProperty.Create(nameof(CheckedColor), typeof(Color), typeof(ColoredRadioButton));
        public static readonly BindableProperty UncheckedColorProperty = BindableProperty.Create(nameof(UncheckedColor), typeof(Color), typeof(ColoredRadioButton));


        public bool IsChecked
        {
            get => (bool)GetValue(IsCheckedProperty);
            set => SetValue(IsCheckedProperty, value);
        }
        public Color CheckedBackgroundColor
        {
            get => (Color)GetValue(CheckedBackgroundColorProperty);
            set => SetValue(CheckedBackgroundColorProperty, value);
        }
        public Color CheckedBorderColor
        {
            get => (Color)GetValue(CheckedBorderColorProperty);
            set => SetValue(CheckedBorderColorProperty, value);
        }
        public Color UncheckedBackgroundColor
        {
            get => (Color)GetValue(UncheckedBackgroundColorProperty);
            set => SetValue(UncheckedBackgroundColorProperty, value);
        }
        public Color UncheckedBorderColor
        {
            get => (Color)GetValue(UncheckedBorderColorProperty);
            set => SetValue(UncheckedBorderColorProperty, value);
        }
        public Color IconColor
        {
            get => (Color)GetValue(IconColorProperty);
            set => SetValue(IconColorProperty, value);
        }
        public double IconFontSize
        {
            get => (double)GetValue(IconFontSizeProperty);
            set => SetValue(IconFontSizeProperty, value);
        }

        public Color CheckedColor
        {
            get => (Color)GetValue(CheckedColorProperty);
            set => SetValue(CheckedColorProperty, value);
        }

        public Color UncheckedColor
        {
            get => (Color)GetValue(UncheckedColorProperty);
            set => SetValue(UncheckedColorProperty, value);
        }


        public event EventHandler<IsCheckedChangedEventArgs> IsCheckedChanged;

        public ColoredRadioButton(ScrollableRadioButtonListControl scrollableParent = null, TaskSingleSelectRadioButtonView taskRadioParent = null)
        {
            ParentControl = scrollableParent;
            TaskRadioParentControl = taskRadioParent;

            base.GestureRecognizers.Add(new TapGestureRecognizer
            {
                Command = new Command((Action<object>)delegate
                {
                    if (TaskRadioParentControl?.IsCompletedTask ?? false)
                        return;
                    if (TaskRadioParentControl != null)
                    {
                        TaskRadioParentControl.UncheckAllExcept(this);
                    }
                    else if (ParentControl != null)
                    {
                        ParentControl.UncheckAllExcept(this);
                    }

                    IsChecked = !IsChecked;
                })
            });
        }


        private void UpdateButtonColor()
        {
            this.BackgroundColor = IsChecked ? CheckedColor : UncheckedColor;
        }
        private static void OnCheckedChanged(BindableObject bindable, object oldValue, object newValue)
        {
            ((ColoredRadioButton)bindable).Update(notify: true);
        }
        protected override void OnChildAdded(Element child)
        {
            base.OnChildAdded(child);
            _checked = child.FindByName<View>("Checked");
            _unchecked = child.FindByName<View>("Unchecked");
            Update(notify: false);
        }
        private void Update(bool notify)
        {
            if (_checked != null)
            {
                _checked.IsVisible = IsChecked;
            }
            if (_unchecked != null)
            {
                _unchecked.IsVisible = !IsChecked;
            }
            if (notify)
            {
                IsCheckedChanged?.Invoke(this, new IsCheckedChangedEventArgs { IsChecked = IsChecked });
            }
        }
    }

    public class IsCheckedChangedEventArgs : EventArgs
    {
        public bool IsChecked { get; set; }
    }
}
