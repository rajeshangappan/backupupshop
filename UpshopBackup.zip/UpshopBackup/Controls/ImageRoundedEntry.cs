﻿using Microsoft.Maui.Graphics;
using Microsoft.Maui.Controls.Compatibility;
using Microsoft.Maui.Controls;
using Microsoft.Maui;

namespace MobileUI2.Controls
{
    public class ImageRoundedEntry : Entry
    {

        public static readonly BindableProperty BorderColorProperty =
           BindableProperty.Create(nameof(BorderColor),
               typeof(Color), typeof(ImageRoundedEntry), Colors.Gray);

        public Color BorderColor
        {
            get => (Color)GetValue(BorderColorProperty);
            set => SetValue(BorderColorProperty, value);
        }

        public static readonly BindableProperty BorderWidthProperty =
            BindableProperty.Create(nameof(BorderWidth), typeof(int),
                typeof(ImageRoundedEntry), // TODO Xamarin.Forms.Device.OnPlatform is not longer supported. For more details see https://learn.microsoft.com/en-us/dotnet/maui/migration/forms-projects#device-changes
     defaultValue: 2.0);

        public int BorderWidth
        {
            get => (int)GetValue(BorderWidthProperty);
            set => SetValue(BorderWidthProperty, value);
        }
        public static readonly BindableProperty CornerRadiusProperty =
            BindableProperty.Create(nameof(CornerRadius),
                typeof(double), typeof(ImageRoundedEntry), // TODO Xamarin.Forms.Device.OnPlatform is not longer supported. For more details see https://learn.microsoft.com/en-us/dotnet/maui/migration/forms-projects#device-changes
     defaultValue: 6.0);

        public double CornerRadius
        {
            get => (double)GetValue(CornerRadiusProperty);
            set => SetValue(CornerRadiusProperty, value);
        }
        public static readonly BindableProperty HasFocusProperty =
            BindableProperty.Create(nameof(HasFocus),
                typeof(bool), typeof(ImageRoundedEntry), false,
                propertyChanged: (b, o, n) =>
                {
                    if ((bool)n)
                    {
                        Device.BeginInvokeOnMainThread(                            () =>
                            {
                                ((ImageRoundedEntry)b).Focus();
                                ((ImageRoundedEntry)b).CursorPosition = 0;
                                ((ImageRoundedEntry)b).SelectionLength = ((ImageRoundedEntry)b).Text != null ? ((ImageRoundedEntry)b).Text.Length : 0;
                            });
                    }
                });

        public bool HasFocus
        {
            get { return (bool)GetValue(HasFocusProperty); }
            set { SetValue(HasFocusProperty, value); }
        }

        public static readonly BindableProperty IsCurvedCornersEnabledProperty =
           BindableProperty.Create(nameof(IsCurvedCornersEnabled),
               typeof(bool), typeof(ImageRoundedEntry), true);

        public bool IsCurvedCornersEnabled
        {
            get => (bool)GetValue(IsCurvedCornersEnabledProperty);
            set => SetValue(IsCurvedCornersEnabledProperty, value);
        }
        private double GetPlatformCornerRadius()
        {
#if ANDROID
            return 6.0;
#elif IOS
            return 7.0;
#elif WINDOWS
            return 7.0;
#else
            return 6.0; // Default
#endif
        }
    }
}
