﻿using MobileUI2.ViewControllers;
using System.Linq;
using Microsoft.Maui.Controls.Compatibility;
using Microsoft.Maui.Controls;
using Microsoft.Maui;

namespace MobileUI2.Controls
{
    public class CustomCollectionView : CollectionView
    {
        public CustomCollectionView()
        {
            SelectionMode = SelectionMode.Single;
            SelectionChanged += CustomCollectionView_SelectionChanged;
        }

        private void CustomCollectionView_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (e.PreviousSelection.FirstOrDefault() is object oldItem)
            {
                var oldCell = FindByName<CustomCollectionViewFrameController>("CustomCollectionViewFrameController", oldItem);
                if (oldCell != null)
                {
                    oldCell.IsSelected = false;
                }
            }

            if (e.CurrentSelection.FirstOrDefault() is object newItem)
            {
                var newCell = FindByName<CustomCollectionViewFrameController>("CustomCollectionViewFrameController", newItem);
                if (newCell != null)
                {
                    newCell.IsSelected = true;
                }
            }
        }

        public T FindByName<T>(string name, object context) where T : BindableObject
        {
            if (ItemTemplate.CreateContent() is VisualElement content)
            {
                content.BindingContext = context;
                return content.FindByName<T>(name);
            }

            return null;
        }
    }
}