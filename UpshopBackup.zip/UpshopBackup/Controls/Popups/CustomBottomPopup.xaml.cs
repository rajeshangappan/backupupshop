﻿using Mopups.Pages;

namespace MobileUI2.Controls.Popups
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class CustomBottomPopup : PopupPage
    {
        public CustomBottomPopup()
        {
            InitializeComponent();
        }
        public static readonly BindableProperty TitleTextProperty =
            BindableProperty.Create(
                nameof(TitleText),
                typeof(string),
                typeof(Label),
                defaultValue: string.Empty);

        public string TitleText
        {
            get { return (string)GetValue(TitleTextProperty); }
            set { SetValue(TitleTextProperty, value); }
        }
        public static readonly BindableProperty SubTitleTextProperty =
            BindableProperty.Create(
                nameof(SubTitleText),
                typeof(string),
                typeof(Label),
                defaultValue: string.Empty);

        public string SubTitleText
        {
            get { return (string)GetValue(SubTitleTextProperty); }
            set { SetValue(SubTitleTextProperty, value); }
        }
    }
}