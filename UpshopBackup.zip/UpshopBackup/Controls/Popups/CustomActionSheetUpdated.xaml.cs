﻿using Mopups.Pages;
using Mopups.Services;

namespace MobileUI2.Controls.Popups
{
    public partial class CustomActionSheetUpdated : PopupPage
    {
        public CustomActionSheetUpdated()
        {
            InitializeComponent();
            this.BackgroundColor = Color.FromRgba(0, 0, 0, 0.7);

        }

        private void OnClose(object sender, EventArgs e)
        {
            MopupService.Instance.PopAsync();
        }
    }
}