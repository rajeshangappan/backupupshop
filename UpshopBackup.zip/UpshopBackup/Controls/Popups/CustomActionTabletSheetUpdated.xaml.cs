﻿using Mopups.Services;
using Mopups.Pages;

namespace MobileUI2.Controls.Popups
{
    public partial class CustomActionTabletSheetUpdated : PopupPage
    {
        public CustomActionTabletSheetUpdated()
        {
            InitializeComponent();
            this.BackgroundColor = Color.FromRgba(0, 0, 0, 0.7);
        }

        private void OnClose(object sender, EventArgs e)
        {
            MessagingCenter.Send<object>(this, "PopupClose");
            MopupService.Instance.PopAsync();
        }
    }
}
