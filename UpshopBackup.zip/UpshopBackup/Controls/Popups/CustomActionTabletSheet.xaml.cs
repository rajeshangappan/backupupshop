﻿using System;
using CommunityToolkit.Maui.Behaviors;
using Mopups.Services;
using RGPopup.Maui.Pages;
using RGPopup.Maui.Services;

namespace MobileUI2
{
    public partial class CustomActionTabletSheet : Mopups.Pages.PopupPage
    {
        public CustomActionTabletSheet()
        {
            InitializeComponent();
            this.BackgroundColor = (Color)Application.Current.Resources["UpshopBackgroundColor"];
        }

        private void OnClose(object sender, EventArgs e)
        {
            MopupService.Instance.PopAsync();
        }
    }
}
