

using Mopups.Pages;
using Mopups.Services;

namespace MobileUI2
{
    public partial class IrregularDialog : PopupPage
    {
        public IrregularDialog()
        {
            InitializeComponent();
        }

        private void OnClose(object sender, EventArgs e)
        {
            MopupService.Instance.PopAsync();
        }
    }
}
