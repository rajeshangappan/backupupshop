﻿using Microsoft.Maui.Controls.Compatibility;
using Microsoft.Maui.Controls;
using Microsoft.Maui;

namespace MobileUI2.Controls
{
    public class NoMinimumWidthButton : Button
    {
        protected override SizeRequest OnMeasure(double widthConstraint, double heightConstraint)
        {
            // Set the minimum width of the button to 50 device-independent pixels (dp)
            var baseResult = base.OnMeasure(widthConstraint, heightConstraint);
            var minimumWidth = 0;
            return new SizeRequest(new Size(baseResult.Request.Width < minimumWidth ? minimumWidth : baseResult.Request.Width, baseResult.Request.Height));
        }
    }
}
