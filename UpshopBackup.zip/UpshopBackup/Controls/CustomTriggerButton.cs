﻿using Microsoft.Maui.Controls.Shapes;
using Microsoft.Maui.Layouts;

namespace MobileUI2.Controls
{
    public partial class CustomTriggerButton : Border
    {
        public CustomTriggerButton()
        {
            // Set appearance
            BackgroundColor = Color.FromArgb("#008180");
            HeightRequest = 150;
            WidthRequest = 60;
            StrokeShape = new RoundRectangle
            {
                CornerRadius = new CornerRadius(6, 0, 6, 0)
            };

            // Centered Image
            var image = new Image
            {
                Source = "scanimg.png",
                HorizontalOptions = LayoutOptions.Center,
                VerticalOptions = LayoutOptions.Center
            };

            Content = image;

            // Pan gesture
            var panGesture = new PanGestureRecognizer();
            panGesture.PanUpdated += PanGestureRecognizer_PanUpdated;
            GestureRecognizers.Add(panGesture);
        }

        protected override void OnSizeAllocated(double width, double height)
        {
            base.OnSizeAllocated(width, height);
            PositionBorderAtRightCenter();
        }

        private void PositionBorderAtRightCenter()
        {
            // Position at center of right edge
            double x = ((View)Parent).Width - this.WidthRequest;
            double y = (((View)Parent).Height - this.HeightRequest) / 2;

            AbsoluteLayout.SetLayoutBounds(this, new Rect(x, 0, this.WidthRequest, this.HeightRequest));
            AbsoluteLayout.SetLayoutFlags(this, AbsoluteLayoutFlags.None);
            this.TranslationY = y;
        }

        double _startTranslateY;

        private void PanGestureRecognizer_PanUpdated(object sender, PanUpdatedEventArgs e)
        {
            switch (e.StatusType)
            {
                case GestureStatus.Started:
                    _startTranslateY = this.TranslationY;
                    break;

                case GestureStatus.Running:
                    var finalY = Math.Max(0, (_startTranslateY + e.TotalY));
                    finalY = Math.Min(((View)Parent).Height - 200, finalY);
                    this.TranslationY = finalY;
                    _startTranslateY = finalY;
                    Console.WriteLine(finalY);
                    break;
            }
        }
    }
}
