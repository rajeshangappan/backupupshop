﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;
using Microsoft.Maui.Controls.Compatibility;
using Microsoft.Maui.Controls;
using Microsoft.Maui;

namespace MobileUI2.Controls
{
    public class SelectableCollectionView : ListView
    {
       
        //protected override void OnElementPropertyChanged(object sender, PropertyChangedEventArgs e)
        //{
        //    base.OnElementPropertyChanged(sender, e);
        //    if (e.PropertyName == "SelectedItem")
        //    {
        //        var collectionView = sender as SelectableCollectionView;
        //        if (collectionView.SelectedItem != null)
        //        {
        //            var selectedCell =
        //                Control?.VisibleCells.FirstOrDefault(c => c.BindingContext == collectionView.SelectedItem);
        //            if (selectedCell != null)
        //            {
        //                selectedCell.TextLabel.TextColor =
        //                    UIColor.Red; // Set the text color of the selected item }} }}}
        //            }
        //        }
        //    }
        //}
    }
}
