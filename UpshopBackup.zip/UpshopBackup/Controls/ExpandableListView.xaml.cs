using MobileUI2.Models;
using System.Collections.ObjectModel;
using System.Windows.Input;
using System.ComponentModel;
using System.Linq;

namespace MobileUI2.Controls;

public partial class ExpandableListView : ContentView, INotifyPropertyChanged
{
    public static readonly BindableProperty HeaderTextProperty =
        BindableProperty.Create(nameof(HeaderText), typeof(string), typeof(ExpandableListView), default(string));

    public static readonly BindableProperty FullItemsSourceProperty =
        BindableProperty.Create(nameof(FullItemsSource), typeof(ObservableCollection<CycleCountDTO>), typeof(ExpandableListView), default(ObservableCollection<CycleCountDTO>));

    public static readonly BindableProperty IsExpandedProperty =
        BindableProperty.Create(nameof(IsExpanded), typeof(bool), typeof(ExpandableListView), false, propertyChanged: OnIsExpandedChanged);

    public static readonly BindableProperty DisplayedItemsProperty =
        BindableProperty.Create(nameof(DisplayedItems), typeof(ObservableCollection<CycleCountDTO>), typeof(ExpandableListView), default(ObservableCollection<CycleCountDTO>));

    public static readonly BindableProperty ItemCountTextProperty =
        BindableProperty.Create(nameof(ItemCountText), typeof(string), typeof(ExpandableListView), default(string));

    public static readonly BindableProperty ArrowIconProperty =
        BindableProperty.Create(nameof(ArrowIcon), typeof(string), typeof(ExpandableListView), "\uf0d7");


    public string HeaderText
    {
        get => (string)GetValue(HeaderTextProperty);
        set => SetValue(HeaderTextProperty, value);
    }

    public ObservableCollection<CycleCountDTO> FullItemsSource
    {
        get => (ObservableCollection<CycleCountDTO>)GetValue(FullItemsSourceProperty);
        set => SetValue(FullItemsSourceProperty, value);
    }

    public bool IsExpanded
    {
        get => (bool)GetValue(IsExpandedProperty);
        set => SetValue(IsExpandedProperty, value);
    }

    public ObservableCollection<CycleCountDTO> DisplayedItems
    {
        get => (ObservableCollection<CycleCountDTO>)GetValue(DisplayedItemsProperty);
        set => SetValue(DisplayedItemsProperty, value);
    }

    public string ItemCountText
    {
        get => (string)GetValue(ItemCountTextProperty);
        set => SetValue(ItemCountTextProperty, value);
    }

    public string ArrowIcon
    {
        get => (string)GetValue(ArrowIconProperty);
        set => SetValue(ArrowIconProperty, value);
    }



    public ExpandableListView()
    {
        InitializeComponent();
        DisplayedItems = new ObservableCollection<CycleCountDTO>();

        UpdateDisplayedItems();
        UpdateItemCountText();
        UpdateArrowIcon();
    }



    //private static void OnFullItemsSourceChanged(BindableObject bindable, object oldValue, object newValue)
    //{
    //    if (bindable is ExpandableListView control)
    //    {
    //        control.UpdateDisplayedItems();
    //        control.UpdateItemCountText();
    //    }
    //}

    private static void OnIsExpandedChanged(BindableObject bindable, object oldValue, object newValue)
    {
        if (bindable is ExpandableListView control)
        {
            control.UpdateDisplayedItems();
            control.UpdateItemCountText();
            control.UpdateArrowIcon();
        }
    }

    private void UpdateDisplayedItems()
    {
        if (DisplayedItems == null)
        {
            DisplayedItems = new ObservableCollection<CycleCountDTO>();
        }
        if (FullItemsSource == null || FullItemsSource.Count == 0)
        {
            OnPropertyChanged(nameof(DisplayedItems));
            return;
        }

        if (IsExpanded)
        {
            DisplayedItems = new ObservableCollection<CycleCountDTO>(FullItemsSource);
        }
        else
        {
            DisplayedItems = new ObservableCollection<CycleCountDTO>();
        }
        OnPropertyChanged(nameof(DisplayedItems));
    }

    private void UpdateItemCountText()
    {
        if (FullItemsSource != null)
        {
            ItemCountText = $"{HeaderText} ({FullItemsSource.Count})";
        }
        else
        {
            ItemCountText = $"{HeaderText} (0)";
        }
        OnPropertyChanged(nameof(ItemCountText));
    }

    private void UpdateArrowIcon()
    {
        ArrowIcon = IsExpanded ? "\uf0d8" : "\uf0d7";
        OnPropertyChanged(nameof(ArrowIcon));
    }

    public event PropertyChangedEventHandler PropertyChanged;

    protected virtual void OnPropertyChanged([System.Runtime.CompilerServices.CallerMemberName] string propertyName = null)
    {
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
    }

    private void OnExpandCollapseClicked(object sender, EventArgs e)
    {
        IsExpanded = !IsExpanded;
    }
}