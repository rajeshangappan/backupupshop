﻿using MobileUI2.ViewControllers;
using System.Linq;
using Microsoft.Maui.Controls.Compatibility;
using Microsoft.Maui.Controls;
using Microsoft.Maui;

namespace MobileUI2.Controls
{
    public class CustomListView : ListView
    {

    }
}