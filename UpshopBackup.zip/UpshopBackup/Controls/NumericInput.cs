﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MobileUI2.Components.Controls
{
    public class NumericInput : Entry
    {
        public static readonly BindableProperty AllowFractionProperty =
            BindableProperty.Create(nameof(AllowFraction), typeof(bool), typeof(NumericInput), false);

        public bool AllowFraction
        {
            get => (bool)GetValue(AllowFractionProperty);
            set => SetValue(AllowFractionProperty, value);
        }
    }
}
